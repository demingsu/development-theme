/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="container">
        This is home page.
    </div>
</template>

<script>
    import BaseView from "../BaseView.vue";
    
    export default {
        mixins: [BaseView],
        /**
         * 所有参数变量说明
         */
        data() {
            return {

            }
        },
        created() {

        }
    }
</script>