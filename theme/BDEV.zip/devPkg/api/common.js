/*********************************************************************
 * defined common api file
 * Created by deming-su on 2019/6/6
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/url.config";

/**
 * post 请求方法 （如果有上传进度方法或需要转码，都默认为form提交，提交类型也默认）
 * @param {String}      key                请求地址key
 * @param {Object}      data               请求参数
 * @param {Function}    onUploadProgress   form提交进度回调函数
 * @param {Boolean}     encode             是否需要转码
 */
let postRequestMethod = (key, data, onUploadProgress, encode) => {
    if (!key || key.trim() === '') return {code: 600, message: '请求地址为空'};
    return Ajax({
        method: "POST",
        url: UrlConfig[key],
        contentType: !!onUploadProgress || encode !== undefined ? 'application/x-www-form-urlencoded' : undefined,
        data,

    });
};

/**
 * get 请求方法
 * @param {String}      key                请求地址key
 * @param {Object}      params             请求参数
 */
let getRequestMethod = (key, params) => {
    if (!key || key.trim() === '') return {code: 600, message: '请求地址为空'};
    return Ajax({
        url: UrlConfig[key],
        params
    });
};

/**
 * 获取菜单menu
 */
let getRequestUrl = (key) => {
    return `${UrlConfig.BASE_URL}${UrlConfig[key] || ''}`;
};

export {
    postRequestMethod,
    getRequestMethod,
    getRequestUrl
};