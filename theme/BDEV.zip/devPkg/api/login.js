/*********************************************************************
 * login page api
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/url.config";
import { ROLE_COOPERATION, ROLE_INTERNAL } from "@/config/const.config";
import { COOPERATION_MENU, INTERNAL_MENU } from "@/config/menu.config";

/**
 * 用户登录
 * @param {object} data
 */
let loginApi = data => {
    /**
    return Ajax({
        method: "post",
        url: UrlConfig.LOGIN_URL,
        data
    });
     */
    return {
        "meta": {
            "code": 200,
            "message": "查询数据成功"
        },
        "data": [
            {
                "id": "sue",
                "name": "deming-su"
            }
        ]
    };
};

/**
 * 获取菜单menu
 */
let getUserMenuApi = (type, data) => {

    console.log(data);
    if (type === ROLE_INTERNAL) {
        return INTERNAL_MENU;
    } else if (type === ROLE_COOPERATION) {
        return COOPERATION_MENU;
    } else {
        return {};
    }
};

/**
 * 引用页面用法释义
 * import Login form "./api/login";
 * Login.login();
 */
export {
    loginApi,
    getUserMenuApi
};