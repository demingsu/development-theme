/*********************************************************************
* Vue BlockCard file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="block-card-container" :class="[showHeader ? '' : 'no-header', mb20 ? 'mb20' : '']">
        <div v-if="showHeader" class="header">
            <div class="label">
                {{title}}
                <i class="sub">{{sub}}</i>
            </div>
            <div v-if="hasOpt" class="opt">
                <slot name="opt"></slot>
            </div>
        </div>
        <div class="content">
            <slot></slot>
        </div>
    </div>
</template>
<script>
    export default {
        props: {
            title: String,
            sub: String,
            mb20: {
                type: Boolean,
                default: true
            },
            showHeader: {
                type: Boolean,
                default: true
            }
        },
        computed: {
            hasOpt: function() {
                return !!this.$slots.opt;
            }
        }
    }
</script>