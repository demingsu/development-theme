/*********************************************************************
* Vue BreadItem file
* Created by deming-su on 2019/6/7
*********************************************************************/

<template>
    <div class="bread-item-container">
        <div class="label">当前位置：</div>
        <el-breadcrumb separator="/">
            <el-breadcrumb-item v-for="(item, idx) in breadcrumbList" :key="`key_${idx}`" :to="item.path">{{item.name}}</el-breadcrumb-item>
        </el-breadcrumb>
        <div class="slot-box">
            <slot></slot>
        </div>
    </div>
</template>
<script>
    export default {
        props: {
            breadcrumbList: {
                type: Array,
                default: () => []
            }
        }
    }
</script>