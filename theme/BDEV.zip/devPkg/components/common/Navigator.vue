/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="navigator-container">
        <div class="box">
            <div class="brand">
                <i class="icon"></i>
                <span class="text">ZZNODE ADMIN</span>
            </div>
            <div class="content">
                <div class="item"
                     v-for="(item, idx) in menuData"
                     @mouseover="itemEvent('over', item)"
                     @mouseout="itemEvent('out', item)"
                     :key="`main_key_${idx}`">
                    <span @click="itemEvent('pick', item)">{{item.label}}</span>
                    <div :id="`childrenId_${item.key}`"
                         class="children"
                         v-if="!!item.children && item.path === '' && item.children.length > 0">
                        <div class="box">
                            <div class="per"
                                 v-for="(it, k) in item.children"
                                 @click="itemEvent('pick', it)"
                                 :style="[{width: `${100 / Math.ceil(item.children.length/5)}%`}]"
                                 :key="`child_key_${k}`">{{it.label}}</div>
                        </div>
                    </div>
                </div>
                <div class="info user" @click="itemEvent('user')"></div>
                <div class="info" :class="hasInfo ? 'active' : ''" @click="itemEvent('info')"></div>
            </div>
        </div>
    </div>
</template>
<script>
    import { mapGetters } from 'vuex';
    import { NAVIGATOR_INFO_EVENT, NAVIGATOR_USER_EVENT } from "@/config/const.config";

    export default{
        computed: {
            ...mapGetters({
                menuData: 'getCurrentMenuData'
            })
        },
        data() {
            return {
                hasInfo: true
            }
        },
        methods: {
            /* 鼠标事件 */
            itemEvent(type, data) {

                let node = null;

                switch (type) {
                    case 'over':
                        node = document.getElementById(`childrenId_${data.key}`);
                        if (!!node) {
                            node.setAttribute('style', `height: ${node.scrollHeight}px; width: ${Math.ceil(data.children.length / 5) * 100}%;`);
                        }
                        break;
                    case 'out':
                        node = document.getElementById(`childrenId_${data.key}`);
                        if (!!node) {
                            node.setAttribute('style', `height: 0;`);
                        }
                        break;
                    case 'pick':
                        if (!!data.path && data.path.trim() !== '') {
                            this.$router.push({path: data.path, query: data.query});
                        }
                        break;
                    case 'user':
                        this.$root.eventBus.$emit(NAVIGATOR_USER_EVENT, {});
                        break;
                    case 'info':
                        this.$root.eventBus.$emit(NAVIGATOR_INFO_EVENT, {});
                        break;
                }
            }
        }
    }
</script>
