/*********************************************************************
* Vue RegisterBlock file
* Created by deming-su on 2019/6/7
*********************************************************************/

<template>
    <div class="register-block-container" :class="width">
        <div class="header">
            <div class="info">
                <div class="title">{{title}}</div>
                <div class="sub">{{sub}}</div>
            </div>
            <div class="btn">
                <slot name="btn"></slot>
            </div>
        </div>
        <div class="content">
            <slot></slot>
        </div>
    </div>
</template>
<script>
    export default {
        props: {
            width: '',
            title: '',
            sub: ''
        }
    }
</script>