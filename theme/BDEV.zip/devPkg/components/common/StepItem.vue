/*********************************************************************
* Vue StepItem file
* Created by deming-su on 2019/6/7
*********************************************************************/

<template>
    <div class="step-item-container">
        <div class="item"
             v-for="(item, idx) in stepList"
             :style="[{width: `${100/stepList.length}%`}]"
             :key="`key_${idx}`">
            <div class="box" :class="item.active ? 'active' : ''">
                <div class="icon"></div>
                <div class="text">{{item.text}}</div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: {
            stepList: {
                type: Array,
                default: () => []
            }
        }
    }
</script>