/*********************************************************************
* Vue button file
* Created by demin on 2018/12/21
*********************************************************************/

<template>
    <div>
        <el-tag :size="size" :type="type">{{text}}</el-tag>
        <span>{{myText}}</span>
    </div>
</template>
<script>
    export default {
        /**
         * 属性参数释义
         */
        props: {
            size: String,
            type: String,
            text: String,
            myText: String
        },
        /**
         * 页面参数释义
         */
        data() {
            return {}
        },
        /**
         * 页面初始化
         */
        created() {

        }
    }
</script>