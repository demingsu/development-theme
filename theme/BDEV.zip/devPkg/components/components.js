/*********************************************************************
 * Vue components file
 * Created by deming-su on 2017/12/30
 *********************************************************************/


const BlockCard = () => import(/* webpackChunkName: "BlockCard"*/"./common/BlockCard.vue");
const StepItem = () => import(/* webpackChunkName: "StepItem"*/"./common/StepItem.vue");
const RegisterBlock = () => import(/* webpackChunkName: "RegisterBlock"*/"./common/RegisterBlock.vue");
const BreadItem = () => import(/* webpackChunkName: "BreadItem"*/"./common/BreadItem.vue");

export {
    BlockCard,
    StepItem,
    RegisterBlock,
    BreadItem
};