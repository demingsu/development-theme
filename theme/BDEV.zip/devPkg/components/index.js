/*********************************************************************
 * Vue directive & filter register file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import * as Filter from "./filter";
import * as Directive from "./directive";
import ToastNode from "./toast/Toast.install";
import Components from "./components";

export default {
    install(Vue) {
        if (!Vue.prototype.$shuimo) {
            Vue.prototype.$shuimo = {};
        }
        this.registerFilter(Vue);
        this.registerDirective(Vue);
        this.registerPrototype(Vue);
        this.registerComponents(Vue);
    },

    registerFilter(Vue) {
        Vue.filter("dateFormat", Filter.dateFormat);
        Vue.filter("hexToRgba", Filter.hexToRgba);
        Vue.filter("hexToRgba", Filter.fixNumber);
    },

    registerDirective(Vue) {
        Vue.directive("autofocus", Directive.Autofocus);
    },

    registerPrototype(Vue) {
        ToastNode.install(Vue);
    },

    registerComponents(Vue) {
        for (let name in Components) {
            if (Components.hasOwnProperty(name)) {

                /* 生成组件key */
                let key = name.replace(/[A-Z]/g, (char, index) => {
                    let res = char.toLowerCase();
                    res = index > 0 ? `-${res}` : res;
                    return res;
                });

                /* 注册组件 */
                Vue.component(key, Components[name]);
            }
        }
    }
};