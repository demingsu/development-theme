/*********************************************************************
 * Static variable file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* Ajax请求超时设置 */
const TIMEOUT_TIME = 60 * 5 * 1000;

/* 系统默认路由 */
const DEFAULT_ROUTES = [
    {path: '/login'},
    {path: '/not/found'},
    {path: '/not/right'},
    {path: '/login/register'},
    {path: '/home'},
    {path: '/home/cooperation'},
];

/* 系统类别--内部人员 */
const ROLE_INTERNAL = 'internalRole';

/* 系统类别--合作人员 */
const ROLE_COOPERATION = 'cooperationRole';

/* 导航点击事件--用户图标 */
const NAVIGATOR_USER_EVENT = 'navigatorUserEvent';

/* 导航点击事件--消息图标 */
const NAVIGATOR_INFO_EVENT = 'navigatorInfoEvent';

export {
    DEFAULT_ROUTES,
    TIMEOUT_TIME,
    ROLE_COOPERATION,
    ROLE_INTERNAL,
    NAVIGATOR_INFO_EVENT,
    NAVIGATOR_USER_EVENT
};