/*********************************************************************
 * Static variable file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* Ajax请求超时设置 */
const TIMEOUT_TIME = 5000;

/* 系统默认路由 */
const DEFAULT_ROUTES = [
    {path: '/login'},
    {path: '/not/found'},
    {path: '/not/right'}
];

 /* 登陆接口mock数据 */
 const LOGIN_MOCK_DATA = {
     "meta": {
         "code": 200,
         "message": "查询数据成功"
        },
        "data": [
            {
                "id": "sue",
                "name": "deming-su",
                "sex": "0",
                "birthday": "1984-01-09",
                "phone": "136XXXXXXXX",
                "address": "chengdu City.sichuan Province",
                "email": "suedeming@163.com",
                "sign": "Do everything in one's power.",
                "role": "99999",
                "remark": "system administrator",
                "loginTime": "2018-10-16 11:15:32"
            }
        ]
    };

export default {
    DEFAULT_ROUTES,
    TIMEOUT_TIME,
    LOGIN_MOCK_DATA
};