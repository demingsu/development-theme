/*********************************************************************
 * defined home.url.config page url file
 * Created by deming-su on 2019/6/6
 *********************************************************************/

/* 登陆页面--登陆接口 */
const LOGIN_URL = "/login/login";

/* 登陆页面--上传文件地址（测试用） */
const LOGIN_UPLOAD_FILE = "/login/login";

/* ueditor服务器地址 */
const UEDITOR_URL = "/login/login";

export {
    LOGIN_URL,
    LOGIN_UPLOAD_FILE,
    UEDITOR_URL
}