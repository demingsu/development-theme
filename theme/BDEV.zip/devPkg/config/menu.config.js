/*********************************************************************
 * defined menu config file
 * Created by deming-su on 2019/6/6
 *********************************************************************/


const INTERNAL_MENU = [
    {
        "label": "首页",
        "key": "home&internal",
        "path": "/home/internal",
        "children": [
            {
                "label": "数据看板",
                "key": "home&dashboard",
                "path": "/home/dashboard",
            }
        ]
    },
    {
        "label": "合作伙伴招募管理",
        "key": "recruit&list",
        "path": "/recruit/list",
        "children": [
            {
                "label": "申请招募",
                "key": "recruit&apply",
                "path": "/recruit/apply"
            },
            {
                "label": "审批公告",
                "key": "recruit&approve",
                "path": "/recruit/approve"
            }
        ]
    },
    {
        "label": "合作伙伴管理",
        "key": "internal&management",
        "path": "/internal/management"
    },
    {
        "label": "合作产品管理",
        "key": "internal&management_prd",
        "path": "/internal/management_prd"
    },
    {
        "label": "考核模板管理",
        "key": "internal&template",
        "path": "/internal/template"
    },
    {
        "label": "系统管理",
        "key": "internal&system",
        "path": "",
        "children": [
            {
                "label": "人员管理",
                "key": "internal&employee",
                "path": "/internal/employee"
            },
            {
                "label": "角色管理",
                "key": "internal&role",
                "path": "/internal/role"
            },
            {
                "label": "待办管理",
                "key": "internal&schedule",
                "path": "/internal/schedule"
            },
            {
                "label": "合作伙伴管理",
                "key": "internal&partner",
                "path": "/internal/partner"
            }
        ]
    }
];

let COOPERATION_MENU = [
    {
        "label": "首页",
        "key": "home&cooperation",
        "path": "/home/cooperation"
    },
    {
        "label": "公告公示",
        "key": "cooperation&recruit",
        "path": "",
        "children": [
            {
                "label": "招募公告",
                "key": "cooperation&notice_recruit",
                "path": "/cooperation/notice_recruit",
            },
            {
                "label": "结果公示",
                "key": "cooperation&notice_result",
                "path": "/cooperation/notice_result",
            }
        ]
    },
    {
        "label": "产品及服务",
        "key": "cooperation&production",
        "path": "",
        "children": [
            {
                "label": "产品类型",
                "key": "production&types/type",
                "path": "/production/types",
                "query": {type: 'type'}
            },
            {
                "label": "产品类型1",
                "key": "production&types/type1",
                "path": "/production/types",
                "query": {type: 'type1'}
            },
            {
                "label": "产品类型2",
                "key": "production&types/type2",
                "path": "/production/types",
                "query": {type: 'type2'}
            },
            {
                "label": "产品类型3",
                "key": "production&types/type3",
                "path": "/production/types",
                "query": {type: 'type3'}
            },
            {
                "label": "产品类型4",
                "key": "production&types/type4",
                "path": "/production/types",
                "query": {type: 'type4'}
            },
            {
                "label": "产品类型5",
                "key": "production&types/type5",
                "path": "/production/types",
                "query": {type: 'type5'}
            },
            {
                "label": "产品类型6",
                "key": "production&types/type6",
                "path": "/production/types",
                "query": {type: 'type6'}
            }
        ]
    },
    {
        "label": "商机共享",
        "key": "cooperation&business",
        "path": "",
        "children": [
            {
                "label": "发布商机",
                "key": "business&publish",
                "path": "/business/publish",
            },
            {
                "label": "寻求商机",
                "key": "business&found",
                "path": "/business/found",
            }
        ]
    },
    {
        "label": "优秀合作伙伴",
        "key": "cooperation&excellent",
        "path": "/cooperation/excellent",
    },
    {
        "label": "加入我们",
        "key": "cooperation&join",
        "path": "/cooperation/join",
    }
];

export {
    INTERNAL_MENU,
    COOPERATION_MENU
}