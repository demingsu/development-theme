/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2017/12/30
 * 请求地址定义规则为：功能块名_功能点名_其它标识 如：
 *********************************************************************/

/* 通用 ---start--- */
let BASE_URL = "/api";

let env = (process.env.NODE_ENV || "").trim();
if (env === "production") BASE_URL = "http://111.23.233.128:8104";
/* 通用 ---end--- */

import * as HomeUrl from './home.url.config';

export default {
    BASE_URL,
    ...HomeUrl
};