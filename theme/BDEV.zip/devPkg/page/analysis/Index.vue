/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div>
        <h1>{{title}}</h1>
        <router-view></router-view>
    </div>
</template>

<script>
    
    export default {
        data() {
            return {
                title: "This is analysis component container box ..."
            }
        }
    }
</script>