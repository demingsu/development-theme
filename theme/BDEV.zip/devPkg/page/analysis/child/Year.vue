/*********************************************************************
* Created by deming-su on 2017/12/30
*********************************************************************/

<template>
    <div>
        <h1 ref="testNode">{{title}}</h1>
        <!-- v-html、v-text、v-model、{{}} 使用 -->
        <div v-html="iconfont"></div>
        <div v-text="iconfont"></div>
        <div>{{iconfont}}</div>
        <input v-model="iconfont"/>

        <!-- v-if v-show -->
        <div v-if="true">v-if</div>
        <div v-else>v-else</div>
        <div v-show="true">v-show</div>

        <!-- v-on v-bind -->
        <div v-on:click="testEvent($event)"></div>
        <div @click="testEvent($event)"></div>
        <div v-bind:my-props="myProps"></div>
        <div :my-props="myProps"></div>

        <!-- v-for 使用 -->
        <ul>
            <li v-for="item in list" :key="item.id">{{item.name}}</li>
        </ul>

        <year-comp></year-comp>
    </div>
</template>

<script>
    import YearComp from "./YearComp.vue";

    export default {
        components: {
            YearComp
        },
        data() {
            return {
                myProps: 'myProps',
                iconfont: '&#xe632;',
                list: [
                    {id: 'id_001', name: 'test_001'},
                    {id: 'id_002', name: 'test_002'},
                    {id: 'id_003', name: 'test_003'}
                ],
                title: "",
                looper: null
            }
        },
        methods: {
            loopNode(node) {
                this.looper = setTimeout(() => {
                    clearTimeout(this.looper);
                    this.looper = null;
                    node.setAttribute('style', `font-size: ${Math.ceil(Math.random() * 10) + 12}px;`)
                }, 2000);
            },
            testEvent() {

            }
        },
        created() {
            // initial page data here
            this.title = 'This is year\'s analysis component container box ...';
        },
        mounted() {
            // operation page dom properties here
            this.loopNode(this.$refs.testNode);
        },
        beforeDestroy() {
            // clear page cache data or destroy timer etc.
            if (!!this.looper) {
                clearTimeout(this.looper);
                this.looper = null;
            }
        }
    }
</script>