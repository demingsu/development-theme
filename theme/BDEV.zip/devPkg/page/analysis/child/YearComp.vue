/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<script>

    export default {
        data() {
            return {
                list: [
                    {id: 'id_001', name: 'test_001', fontSize: 16},
                    {id: 'id_002', name: 'test_002', fontSize: 16},
                    {id: 'id_003', name: 'test_003', fontSize: 16}
                ],
                title: "fdsfdsfsdfs"
            }
        },
        methods: {
            clickEvt(item) {
                console.log('click event ... ...', item.name);
            }
        },
        render() {
            const title = this.title;
            return (
                <div>
                    <div domPropsInnerHTML={this.title}></div>
                    <div domPropsInnerHTML={title}></div>
                    <div>{title}</div>
                    <div onClick={this.clickEvt}>click test</div>
                    <ul>
                    {
                        this.list.map(it => {
                            return <li style={{color: 'red', fontSize: `${it.fontSize}px`}} onClick={this.clickEvt}>{it.name}</li>
                        })
                    }
                    </ul>
                </div>

            )
        }
    }
</script>