/*********************************************************************
* Vue NoticeResult file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="NoticeResult-container">
        this is NoticeResult page content
    </div>
</template>
<script>
    export default {
        /**
         * 页面参数释义
         */
        data() {
            return {}
        },
        /**
         * 页面初始化
         */
        created() {

        }
    }
</script>