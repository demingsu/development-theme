/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <router-view></router-view>
</template>

<script>
    import BaseView from "../BaseView.vue";
    
    export default {
        mixins: [BaseView],
        /**
         * 所有参数变量说明
         */
        data() {
            return {
                hasLogin: false
            }
        },
        created() {
            this.hasLogin = this.validateUserLogin();
        }
    }
</script>