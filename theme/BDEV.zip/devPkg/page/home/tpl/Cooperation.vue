/*********************************************************************
* Vue Cooperation file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="fix-width-container full scroll">
        <div class="box">
            <el-row :gutter="20">
                <el-col :span="16">
                    <block-card :showHeader="false">
                        <div class="cooperation-login-box banner"></div>
                    </block-card>
                </el-col>
                <el-col :span="8">
                    <block-card :showHeader="false">
                        <div class="cooperation-login-box">
                            <div class="tower-line-form">
                                <div class="cooperation-user-photo">
                                    <div class="box">
                                        <img :src="defaultUser" alt="">
                                    </div>
                                </div>
                                <div class="text">未登录</div>
                                <div class="line full">
                                    <div class="box">
                                        <el-input size="medium" placeholder="请输入账号"></el-input>
                                    </div>
                                </div>
                                <div class="line full">
                                    <div class="box">
                                        <el-input size="medium" placeholder="请输入密码"></el-input>
                                    </div>
                                </div>
                                <div class="line full mr100">
                                    <div class="box">
                                        <el-input size="medium" placeholder="请输入右图验证码"></el-input>
                                    </div>
                                    <img class="cooperation-validate" :src="validateImg" alt="">
                                </div>
                                <div class="register-check-box full mb16">
                                    <span class="active">保存账号</span>
                                    <span class="left active">保存密码</span>
                                    <span class="active">找回密码</span>
                                    <span class="active">注册</span>
                                </div>
                                <div class="line center">
                                    <el-button size="medium" type="danger">登陆</el-button>
                                </div>
                            </div>
                        </div>
                    </block-card>
                </el-col>
            </el-row>
            <el-row :gutter="20">
                <el-col :span="6">
                    <block-card title="商机共享">
                        <div class="register-list-info no-border no-padding hei188">
                            <div class="line" v-for="(item, idx) in businessList" :key="`key_${idx}`">{{item.info}}</div>
                        </div>
                    </block-card>
                </el-col>
                <el-col :span="8">
                    <block-card title="招募公告">
                        <div class="register-list-info no-border no-padding hei188">
                            <div class="line" v-for="(item, idx) in recruitList" :key="`key_${idx}`">
                                {{item.info}}<span class="sub right">{{item.sub}}</span>
                            </div>
                        </div>
                    </block-card>
                </el-col>
                <el-col :span="10">
                    <block-card :showHeader="false">
                        <div class="cooperation-login-box hei211">
                            <img :src="budongJpg" alt="">
                            <div class="cooperation-display-info">
                                <div class="title b">分析</div>
                                <div class="title">概览</div>
                                <div class="title small line">ANALYSIS OVERVIEW</div>
                            </div>
                            <div class="cooperation-display-info bottom">
                                <div class="title box">
                                    <span class="num">26</span>
                                    <span>合作伙伴数</span>
                                </div>
                                <div class="title box">
                                    <span class="num">38</span>
                                    <span>产品数</span>
                                </div>
                            </div>
                        </div>
                    </block-card>
                </el-col>
            </el-row>
            <block-card title="商机共享">
                <div slot="opt">
                    <el-input size="small" placeholder="请输入产品名称搜索" suffix-icon="search-icon-btn"></el-input>
                </div>
                <div class="cooperation-production-list">
                    <div class="item" v-for="(item, idx) in productionList" :key="`key_${idx}`">
                        <div class="box">
                            <img :src="yyPng" alt="">
                            <div class="title">{{item.title}}</div>
                            <div class="text">{{item.text}}</div>
                            <el-button type="danger" size="mini" plain>智享</el-button>
                        </div>
                    </div>
                </div>
            </block-card>
            <block-card :mb20="false" title="优秀合作伙伴">
                <div class="cooperation-excellent-list">
                    <div class="item" v-for="(item, idx) in excellentList" :key="`key_${idx}`">
                        <div class="img">
                            <img :src="excellentPng" alt="">
                        </div>
                        <span class="text"><em>{{item.type}}</em>{{item.info}}</span>
                    </div>
                </div>
            </block-card>
        </div>
    </div>
</template>
<script>
    import { getUserMenuApi } from "@/api/login";
    import { ROLE_COOPERATION } from "@/config/const.config";
    import { convertToDimensional } from "@/util/tool";
    import validateImg from "@/images/home/validate.png";
    import defaultUser from "@/images/home/user-default.png";
    import budongJpg from "@/images/home/budong-icon.jpg";
    import yyPng from "@/images/home/test.png";
    import excellentPng from "@/images/home/excellent.png";

    export default {
        data() {
            return {
                validateImg,
                defaultUser,
                budongJpg,
                yyPng,
                excellentPng,
                businessList: [
                    {info: '中国铁塔XXXXXXXXXXXXXX商机共享'},
                    {info: '中国铁塔XXXXXXXXXXXXXX商机共享'},
                    {info: '中国铁塔XXXXXXXXXXXXXX商机共享'},
                    {info: '中国铁塔XXXXXXXXXXXXXX商机共享'},
                    {info: '中国铁塔XXXXXXXXXXXXXX商机共享'},
                    {info: '中国铁塔XXXXXXXXXXXXXX商机共享'}
                ],
                recruitList: [
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'}
                ],
                productionList: [
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'},
                    {title: '挂高系列', text: '以上即是介绍了使用css来设置字间距、字符间距、字体间距、段落开头缩进，分别使用了letter-spacing（间距设置）、text-indent（缩进）两个css属性，以上是div+css网divcss5为你简单通过实例讲解介绍'}
                ],
                excellentList: [
                    {info: '诚信互联科技有限公司', type: 'web应用'},
                    {info: '诚信互联科技有限公司', type: 'web应用'},
                    {info: '诚信互联科技有限公司', type: 'web应用'},
                    {info: '诚信互联科技有限公司', type: 'web应用'},
                    {info: '诚信互联科技有限公司', type: 'web应用'}
                ]
            }
        },
        methods: {
            /* 获取本类菜单 */
            async getMenuData() {
                let load = this.$loading();

                let result = await getUserMenuApi(ROLE_COOPERATION, this.loginName);
                load.close();

                /* 缓存目录数据本地缓存 */
                this.$store.dispatch('setCurrentMenuData', {data: result});
                sessionStorage.setItem('current_menu_data', JSON.stringify(result));

                /* 请求回来的菜单应为树数据，遍历为一维数据 */
                sessionStorage.setItem('current_user_right', JSON.stringify(convertToDimensional(result)));
            }
        },
        created() {

            /* 获取本类菜单 */
            this.getMenuData();
        }
    }
</script>