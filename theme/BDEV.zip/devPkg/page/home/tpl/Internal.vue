/*********************************************************************
* Vue Internal file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="fix-width-container full scroll">
        <div class="box">
            <div class="internal-home-header">
                <div class="left">
                    <div class="title">{{new Date() | dateFormat('MM月DD日')}}</div>
                    <div class="title small">administrator，观迎您登录系统</div>
                </div>
                <div class="right">
                    <div class="item" @click="viewAnalysis('recruit')">
                        <i class="icon"></i>
                        <span class="title">30</span>
                        <span class="name">招聘管理</span>
                    </div>
                    <div class="item" @click="viewAnalysis('info')">
                        <i class="icon info"></i>
                        <span class="title">30</span>
                        <span class="name">信息管理</span>
                    </div>
                    <div class="item" @click="viewAnalysis('business')">
                        <i class="icon business"></i>
                        <span class="title">30</span>
                        <span class="name">商机管理</span>
                    </div>
                    <div class="item" @click="viewAnalysis('evaluate')">
                        <i class="icon ass"></i>
                        <span class="title">999</span>
                        <span class="name">考评管理</span>
                    </div>
                </div>
            </div>
            <el-row class="internal-home-content" :gutter="20">
                <el-col :span="17">
                    <block-card style="height: 100%;" :mb20="false" title="合作伙伴统计分析">
                        <el-tabs type="border-card">
                            <el-tab-pane label="消息中心">
                                <div class="tower-accurate-query-container">
                                    <div class="query">
                                        <div class="item">
                                            <el-input v-show="!accurateData.show" v-model="accurateData.data[0].value" size="medium" placeholder="请输入查询条件"></el-input>
                                        </div>
                                        <div class="item w120">
                                            <el-button v-show="!accurateData.show" size="medium" @click="accurateEvent('query')" type="danger">查询</el-button>
                                        </div>
                                        <div class="item w120">
                                            <el-button @click="accurateEvent('expand')" size="medium" type="danger">
                                                精确查询<i class="el-icon-arrow-down  el-icon--right"></i>
                                            </el-button>
                                        </div>
                                        <div class="drop-box" :class="[accurateData.show ? 'active' : '']">
                                            <div class="tower-line-form">
                                                <div class="line w3" v-for="(item, idx) in accurateData.data" :key="`key_${idx}`">
                                                    <div class="label right">{{item.label}}</div>
                                                    <div class="box">
                                                        <el-input v-if="item.type !== 'drop' && item.type !== 'time'" size="medium" v-model="item.value" :placeholder="item.placeholder"></el-input>
                                                        <el-select v-if="item.type === 'drop'" size="medium" v-model="item.value" placeholder="请选择">
                                                            <el-option v-for="it in item.options"
                                                                       :key="it.value"
                                                                       :label="it.label"
                                                                       :value="it.value">
                                                            </el-option>
                                                        </el-select>
                                                        <el-date-picker v-if="item.type === 'time'" v-model="item.value" type="date" placeholder="选择日期"></el-date-picker>
                                                    </div>
                                                </div>
                                                <div class="line center">
                                                    <el-button @click="accurateEvent('query')" size="medium" type="danger">查询</el-button>
                                                    <el-button @click="accurateEvent('reset')" size="medium">重置</el-button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="content">
                                        <el-table v-loading='accurateData.load' :data="accurateData.tableData" height="100%">
                                            <el-table-column prop="col01" label="待办内容" width="140"></el-table-column>
                                            <el-table-column prop="col02" label="开始时间" width="160"></el-table-column>
                                            <el-table-column prop="col03" label="结束时间"></el-table-column>
                                            <el-table-column prop="col04" label="历时"></el-table-column>
                                            <el-table-column prop="col05" label="备注"></el-table-column>
                                            <el-table-column width="120" label="操作">
                                                <template slot-scope="scope">
                                                    <span @click="accurateEvent('handle', scope.row)" class="operation-btn-color">处理</span>
                                                    <span @click="accurateEvent('progress', scope.row)" class="operation-btn-color success">进度</span>
                                                </template>
                                            </el-table-column>
                                        </el-table>
                                        <div class="paging-box">
                                            <el-pagination @size-change="pagingEvent($event, 'size')"
                                                           @current-change="pagingEvent($event, 'current')"
                                                           :current-page="accurateData.current"
                                                           :page-sizes="accurateData.sizes"
                                                           :page-size="accurateData.size"
                                                           :total="accurateData.total"
                                                           style="float: right;"
                                                           layout="total, sizes, prev, pager, next, jumper">
                                            </el-pagination>
                                        </div>
                                    </div>
                                </div>
                            </el-tab-pane>
                            <el-tab-pane label="角色管理">
                                <div>哈哈哈哈</div>
                            </el-tab-pane>
                            <el-tab-pane label="定时任务补偿">
                                <div>哈哈哈哈-----------------</div>
                            </el-tab-pane>
                        </el-tabs>
                    </block-card>
                </el-col>
                <el-col :span="7">
                    <div class="internal-home-content-top">
                        <block-card style="height: 100%;" :mb20="false" title="招募公告">
                            <div class="register-list-info no-border no-padding">
                                <div class="line" v-for="(item, idx) in recruitList" :key="`key_${idx}`">
                                    {{item.info}}<span class="sub right">{{item.sub}}</span>
                                </div>
                            </div>
                        </block-card>
                        <div class="bottom">
                            <block-card :mb20="false" :showHeader="false">
                                <div class="cooperation-login-box hei211">
                                    <div class="tower-line-form">
                                        <div class="cooperation-user-photo p10">
                                            <div class="box">
                                                <img :src="defaultUser" alt="">
                                            </div>
                                        </div>
                                        <div class="text">administrator</div>
                                        <div class="line center">
                                            <el-button class="w150" size="medium" type="danger" plain>注销账户</el-button>
                                        </div>
                                        <div class="line center">
                                            <el-button class="w150" size="medium" type="danger" plain>修改密码</el-button>
                                        </div>
                                    </div>
                                </div>
                            </block-card>
                        </div>
                    </div>
                </el-col>
            </el-row>
        </div>
    </div>
</template>
<script>
    import defaultUser from "@/images/home/user-default.png";

    export default {
        data() {
            return {
                defaultUser,
                accurateData: {
                    show: false,
                    data: [
                        {id: 'key01', key: 'key_01', label: '分公司', value: '', placeholder: '请输入分公司'},
                        {id: 'key01', key: 'key_02', label: '区域', value: '', type: 'drop', placeholder: '请输入区域', options: [
                                {value: 'cd', label: '成都'},
                                {value: 'xa', label: '西安'},
                                {value: 'sh', label: '上海'},
                                {value: 'sz', label: '苏州'}
                            ]},
                        {id: 'key01', key: 'key_03', label: '时间', value: new Date(), type: 'time', placeholder: '请输入时间'},
                        {id: 'key01', key: 'key_04', label: '产品', value: '', placeholder: '请输入产品'},
                        {id: 'key01', key: 'key_05', label: '行业', value: '', placeholder: '请输入行业'}
                    ],
                    load: false,
                    tableHeight: 0,
                    total: 123,
                    current: 1,
                    size: 15,
                    sizes: [15, 30, 50, 100],
                    tableData: []
                },
                recruitList: [
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'},
                    {info: '中国铁塔XXXX招募公告', sub: '2019-01-22 12:20:30'}
                ]
            }
        },
        methods: {
            accurateEvent(type) {
                let temp = [];
                if (type === 'expand') {
                    this.accurateData.show = !this.accurateData.show;
                } else if (type === 'reset') {
                    this.accurateData.data.map(it => {
                        it.value = it.type === 'time' ? new Date() : '';
                        temp.push(it);
                    });

                    this.accurateData.data = temp;
                } else if (type === 'query') {

                    this.getTableInfo();
                }
            },
            /* 获取表格数据 */
            getTableInfo() {

                let temp = [];
                for (let i = 0;i < this.accurateData.size;i ++) {
                    temp.push({
                        col01: `测试待办内容00${Math.ceil(Math.random() * 50)}`,
                        col02: '2019-01-03 10:20',
                        col03: '-',
                        col04: '1天2小时30分',
                        col05: '呵呵呵'
                    })
                }

                this.accurateData.load = true;
                setTimeout(() => {
                    this.accurateData.load = false;
                }, 1200);

                this.accurateData.tableData = temp;

                this.accurateData.show = false;
            },
            /* 分页事件 */
            pagingEvent(val, type) {
                if (type === 'size') this.accurateData.size = val;
                if (type === 'current') this.accurateData.current = val;

                this.getTableInfo();
            },
            /* 看板页面 */
            viewAnalysis(type) {
                this.$router.push({path: '/home/dashboard', query: {type}})
            }
        }
    }
</script>