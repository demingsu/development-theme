/*********************************************************************
* Vue Index file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <router-view></router-view>
</template>
<script>
    export default {

    }
</script>