/*********************************************************************
* Vue ManagementPrd file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="fix-width-container full scroll bread">
        <bread-item :breadcrumbList="breadcrumbList"></bread-item>
        <div class="box">
            <div class="fix-width-container w1080">
                <div class="box w900">
                    <step-item :stepList="stepList"></step-item>
                    <div class="tower-line-form">
                        <div class="line p10"
                             v-for="(item, idx) in queryData"
                             v-show="item.id === stepFlag"
                             :class="item.cls"
                             :key="`key_${idx}`">
                            <div class="label feed">{{item.label}}</div>
                            <div class="box ml0" :class="item.type === 'file' ? 'mr200' : ''">
                                <el-select v-if="item.type === 'drop'" size="medium" v-model="item.value" placeholder="请选择">
                                    <el-option v-for="it in item.options"
                                               :key="it.value"
                                               :label="it.label"
                                               :value="it.value">
                                    </el-option>
                                </el-select>
                                <el-date-picker size="medium" v-else-if="item.type === 'time'" v-model="item.value" type="date" placeholder="选择日期"></el-date-picker>
                                <el-input v-else size="medium" v-model="item.value" :placeholder="item.placeholder"></el-input>
                            </div>
                            <el-button v-if="item.type === 'file'"
                                       class="from-upload-button"
                                       size="medium"
                                       type="danger"
                                       @click="pickFileEvent(item)"
                                       icon="el-icon-upload2" plain>上传文件</el-button>
                        </div>
                        <div class="line center">
                            <el-button v-show="'key01' === stepFlag" @click="formEvent('next')" size="medium" type="danger">下一步</el-button>
                            <el-button v-show="'key02' === stepFlag" @click="formEvent('previous')" size="medium" type="danger">上一步</el-button>
                            <el-button v-show="'key02' === stepFlag" @click="formEvent('save')" size="medium" type="danger">保存</el-button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import { fileUploadMethod } from "@/util/tool";
    import { postRequestMethod } from "@/api/common";

    export default {
        data() {
            return {
                stepFlag: 'key01',
                breadcrumbList: [
                    {path: '', name: '招募管理'},
                    {path: '', name: '合作伙伴报名'},
                    {path: '', name: '填报'}
                ],
                stepList: [
                    {active: true, key: 'key01', text: '企业详细信息'},
                    {active: false, key: 'key02', text: '附件及标签信息'}
                ],
                queryData: [
                    {id: 'key01', key: 'key_01', label: '公司名称', value: '', placeholder: '请输入公司名称'},
                    {id: 'key01', key: 'key_02', cls: 'w3', label: '公司联系人', value: '', placeholder: '请输入公司联系人'},
                    {id: 'key01', key: 'key_03', cls: 'w3', label: '联系电话', value: '', placeholder: '请输入联系电话'},
                    {id: 'key01', key: 'key_04', cls: 'w3', label: '电子邮箱', value: '', placeholder: '请输入电子邮箱'},
                    {id: 'key01', key: 'key_05', label: '公司性质', value: '', placeholder: '请输入公司性质'},
                    {id: 'key01', key: 'key_06', label: '公司地址', value: '', placeholder: '请输入公司地址'},
                    {id: 'key01', key: 'key_07', cls: 'w2', label: '开户银行', value: '', placeholder: '请输入开户银行'},
                    {id: 'key01', key: 'key_08', cls: 'w2', label: '银行账号', value: '', placeholder: '请输入银行账号'},
                    {id: 'key01', key: 'key_09', cls: 'w3', label: '营业执照编号', value: '', placeholder: '请输入营业执照编号'},
                    {id: 'key01', key: 'key_10', cls: 'w3', label: '公司法人', value: '', placeholder: '请输入公司法人'},
                    {id: 'key01', key: 'key_11', cls: 'w3', label: '法人身份证号', value: '', placeholder: '请输入法人身份证号'},
                    {id: 'key01', key: 'key_12', cls: 'w3', label: '注册资金（万元）', value: '', placeholder: '请输入注册资金（万元）'},
                    {id: 'key01', key: 'key_13', cls: 'w3', label: '成立日期', value: new Date(), type: 'time', placeholder: '请选择成立日期'},
                    {id: 'key01', key: 'key_14', cls: 'w3', label: '年营业额（万元）', value: '', placeholder: '请输入年营业额（万元）'},
                    {id: 'key01', key: 'key_15', label: '经营范围', value: '', placeholder: '请输入经营范围'},
                    {id: 'key01', key: 'key_16', label: '公司人数', value: '', placeholder: '请输入公司人数'},

                    {id: 'key02', key: 'key_17', type: 'file', label: '法人代表人身份证身份证', value: '', placeholder: '请输入法人代表人身份证身份证'},
                    {id: 'key02', key: 'key_18', type: 'file', label: '营业执照', value: '', placeholder: '请输入营业执照'},
                    {id: 'key02', key: 'key_19', type: 'file', label: '银行开户许可证', value: '', placeholder: '请输入银行开户许可证'},
                    {id: 'key02', key: 'key_20', type: 'file', label: '开户经办人身份证', value: '', placeholder: '请输入开户经办人身份证'},
                    {id: 'key02', key: 'key_21', type: 'file', label: '开具增值税专用发票证明', value: '', placeholder: '请输入开具增值税专用发票证明'},
                    {id: 'key02', key: 'key_22', label: '行业', value: '', type: 'drop', placeholder: '请选择行业', options: [
                            {value: 'cd', label: '成都'},
                            {value: 'xa', label: '西安'},
                            {value: 'sh', label: '上海'},
                            {value: 'sz', label: '苏州'}
                        ]},
                    {id: 'key02', key: 'key_23', label: '能力', value: '', type: 'drop', placeholder: '请选择能力', options: [
                            {value: 'cd', label: '成都'},
                            {value: 'xa', label: '西安'},
                            {value: 'sh', label: '上海'},
                            {value: 'sz', label: '苏州'}
                        ]},
                    {id: 'key02', key: 'key_24', label: '服务区域', value: '', type: 'drop', placeholder: '请选择服务区域', options: [
                            {value: 'cd', label: '成都'},
                            {value: 'xa', label: '西安'},
                            {value: 'sh', label: '上海'},
                            {value: 'sz', label: '苏州'}
                        ]},
                    {id: 'key02', key: 'key_25', type: 'file', label: '招募应答方案', value: '', placeholder: '请输入招募应答方案'}
                ]
            }
        },
        methods: {
            formEvent(type) {

                if (type === 'save') return;

                this.stepFlag = type === 'next' ? 'key02' : type === 'previous' ? 'key01' : '';

                let temp = [];
                this.stepList.map(it => {
                    it.active = it.key === this.stepFlag;
                    temp.push(it);
                });

                this.stepList = temp;
            },
            /* 文件上传方法 */
            pickFileEvent(item) {
                fileUploadMethod(async files => {

                    let str = `【${item.label}】上传了文件${files[0].name}`;

                    /* 文件上传方法 */
                    /*let result = await postRequestMethod('LOGIN_UPLOAD_FILE', {'fileName': files[0]}, progress => {
                        console.log(`当前的进度--${(progress.loaded / progress.total) * 100}%`)
                    });
                    console.log('上传文件返回结果', result);
                    */

                    this.$notify.success({
                        title: '上传文件',
                        type: 'success',
                        message: str,
                        duration: 2000,
                        showClose: false
                    });
                });
            }
        }
    }
</script>