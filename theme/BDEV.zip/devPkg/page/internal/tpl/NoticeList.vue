/*********************************************************************
* Vue NoticeList file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="fix-width-container full scroll bread">
        <bread-item :breadcrumbList="breadcrumbList"></bread-item>
        <div class="box">
            <block-card style="height: 98px;" title="工作台">
                <div class="tower-line-form">
                    <div class="line w3" v-for="(item, idx) in queryData" :key="`key_${idx}`">
                        <div class="label right">{{item.label}}</div>
                        <div class="box">
                            <el-input v-if="item.type !== 'drop' && item.type !== 'time'" size="medium" v-model="item.value" :placeholder="item.placeholder"></el-input>
                            <el-select v-if="item.type === 'drop'" size="medium" v-model="item.value" placeholder="请选择">
                                <el-option v-for="it in item.options"
                                           :key="it.value"
                                           :label="it.label"
                                           :value="it.value">
                                </el-option>
                            </el-select>
                            <el-date-picker size="medium" v-if="item.type === 'time'" v-model="item.value" type="date" placeholder="选择日期"></el-date-picker>
                        </div>
                    </div>
                    <div class="line w3 pl90">
                        <el-button size="medium" type="danger">查询</el-button>
                        <el-button size="medium">重置</el-button>
                    </div>
                </div>
            </block-card>
            <div class="home-dashboard-analysis-content top118">
                <block-card style="height: 100%" title="合作伙伴列表">
                    <div class="tower-accurate-query-container no-query">
                        <div class="content">
                            <el-table v-loading='tableData.load' :data="tableData.data" height="100%">
                                <el-table-column prop="col01" label="待办内容" width="140"></el-table-column>
                                <el-table-column prop="col02" label="开始时间" width="160"></el-table-column>
                                <el-table-column prop="col03" label="结束时间"></el-table-column>
                                <el-table-column prop="col04" label="历时"></el-table-column>
                                <el-table-column prop="col05" label="备注"></el-table-column>
                                <el-table-column width="120" label="操作">
                                    <template slot-scope="scope">
                                        <span class="operation-btn-color">处理</span>
                                        <span class="operation-btn-color success">进度</span>
                                    </template>
                                </el-table-column>
                            </el-table>
                            <div class="paging-box">
                                <el-pagination @size-change="pagingEvent($event, 'size')"
                                               @current-change="pagingEvent($event, 'current')"
                                               :current-page="tableData.current"
                                               :page-sizes="tableData.sizes"
                                               :page-size="tableData.size"
                                               :total="tableData.total"
                                               style="float: right;"
                                               layout="total, sizes, prev, pager, next, jumper">
                                </el-pagination>
                            </div>
                        </div>
                    </div>
                </block-card>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                breadcrumbList: [
                    {path: '', name: '合作伙伴信息'},
                    {path: '/internal/management_info', name: '合作伙伴列表'}
                ],
                queryData: [
                    {id: 'key01', key: 'key_01', label: '分公司', value: '', placeholder: '请输入分公司'},
                    {id: 'key01', key: 'key_02', label: '区域', value: '', type: 'drop', placeholder: '请输入区域', options: [
                            {value: 'cd', label: '成都'},
                            {value: 'xa', label: '西安'},
                            {value: 'sh', label: '上海'},
                            {value: 'sz', label: '苏州'}
                        ]}
                ],
                tableData: {
                    load: false,
                    tableHeight: 0,
                    total: 123,
                    current: 1,
                    size: 15,
                    sizes: [15, 30, 50, 100],
                    data: []
                }
            }
        },
        methods: {
            /* 获取表格数据 */
            getTableInfo() {

                let temp = [];
                for (let i = 0;i < this.tableData.size;i ++) {
                    temp.push({
                        col01: `测试待办内容00${Math.ceil(Math.random() * 50)}`,
                        col02: '2019-01-03 10:20',
                        col03: '-',
                        col04: '1天2小时30分',
                        col05: '呵呵呵'
                    })
                }

                this.tableData.load = true;
                setTimeout(() => {
                    this.tableData.load = false;
                }, 1200);

                this.tableData.data = temp;

                this.tableData.show = false;
            },
            /* 分页事件 */
            pagingEvent(val, type) {
                if (type === 'size') this.tableData.size = val;
                if (type === 'current') this.tableData.current = val;

                this.getTableInfo();
            }
        }
    }
</script>