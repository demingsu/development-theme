/*********************************************************************
* Vue Template file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="fix-width-container full scroll bread">
        <bread-item :breadcrumbList="breadcrumbList"></bread-item>
        <div class="box">
            <block-card style="height: 98px;" title="工作台">
                <div class="tower-line-form">
                    <div class="line w3" v-for="(item, idx) in queryData" :key="`key_${idx}`">
                        <div class="label right">{{item.label}}</div>
                        <div class="box">
                            <el-input v-if="item.type !== 'drop' && item.type !== 'time'" size="medium" v-model="item.value" :placeholder="item.placeholder"></el-input>
                            <el-select v-if="item.type === 'drop'" size="medium" v-model="item.value" placeholder="请选择">
                                <el-option v-for="it in item.options"
                                           :key="it.value"
                                           :label="it.label"
                                           :value="it.value">
                                </el-option>
                            </el-select>
                            <el-date-picker size="medium" v-if="item.type === 'time'" v-model="item.value" type="date" placeholder="选择日期"></el-date-picker>
                        </div>
                    </div>
                    <div class="line w3 pl90">
                        <el-button size="medium" type="danger">查询</el-button>
                        <el-button size="medium">重置</el-button>
                    </div>
                </div>
            </block-card>
            <div class="home-dashboard-analysis-content top118">
                <block-card style="height: 100%" title="合作伙伴列表">
                    <div class="tower-scroll-box">
                        <div class="register-row-info" v-for="(item, idx) in recruitList" :key="`key_${idx}`">
                            <span class="label mr15">{{item.name}}</span>
                            <span class="text mr15"><i class="el-icon-time"></i>报名截止时间：{{item.time}}</span>
                            <span class="text mr15"><i class="el-icon-location-outline"></i>{{item.address}}</span>
                            <span class="text right expand" @click="expandEvent(item)">{{item.expand ? '收起' : '展开'}}<i class="el-icon-arrow-down"></i></span>
                            <div :style="{height: item.expand ? '400px' : '0', transition: 'all .3s', overflow: 'hidden'}">
                                <p>合作伙伴列表</p>
                                <p>合作伙伴信息</p>
                                <p>请输入分公司</p>
                                <p>请输入区域</p>
                                <p>中国铁塔QWE业务合作招募公告</p>
                            </div>
                        </div>
                    </div>
                </block-card>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                breadcrumbList: [
                    {path: '', name: '合作伙伴信息'},
                    {path: '/internal/management_info', name: '合作伙伴列表'}
                ],
                queryData: [
                    {id: 'key01', key: 'key_01', label: '分公司', value: '', placeholder: '请输入分公司'},
                    {id: 'key01', key: 'key_02', label: '区域', value: '', type: 'drop', placeholder: '请输入区域', options: [
                            {value: 'cd', label: '成都'},
                            {value: 'xa', label: '西安'},
                            {value: 'sh', label: '上海'},
                            {value: 'sz', label: '苏州'}
                        ]}
                ],
                recruitList: [
                    {id: 'key_01', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_02', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_03', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_04', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_05', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_06', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_07', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_08', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_09', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_10', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_11', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_12', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_13', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_14', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false},
                    {id: 'key_15', name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省', expand: false}
                ]
            }
        },
        methods: {
            expandEvent(item) {
                let temp = [];
                this.recruitList.map(it => {
                    if (item.id === it.id) it.expand = !it.expand;
                    temp.push(it);
                });

                this.recruitList = temp;
            }
        }
    }
</script>