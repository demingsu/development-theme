/*********************************************************************
 * Vue private blank layout file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="application-container">
        <router-view></router-view>
    </div>
</template>

<script>
    export default {

    };
</script>

