/*********************************************************************
 * Vue private main layout file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="application-container">
        <!-- 顶部导航菜单 ---start--- -->
        <navigator-container/>
        <!-- 顶部导航菜单 ---end--- -->

        <!-- 主体路由样式 ---start--- -->
        <div class="application-view-container">
            <router-view></router-view>
        </div>
        <!-- 主体路由样式 ---end--- -->
    </div>
</template>

<script>
    import NavigatorContainer from "../../components/common/Navigator.vue";

    export default {
        components: {
            NavigatorContainer
        },
        data() {
            return {

            }
        },
        mounted() {
            this.$nextTick(() => {

                this.$root.eventBus.$emit('NoticeBroadcast', {type: 'notice', data: {}});
            });
        }
    };
</script>