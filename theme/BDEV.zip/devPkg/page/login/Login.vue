/*********************************************************************
 * Created by deming-su on 2017/10/24                                *
 *********************************************************************/

<template>
    <div class="login-container">
        <div class="bg"></div>
        <div class="box">
            <div class="bg"></div>
            <div class="line"></div>
            <div class="content">
                <div class="name"></div>
                <div class="ipt">
                    <div class="c"><i class="icon"></i><input type="text" v-model="loginName"></div>
                </div>
                <div class="ipt">
                    <div class="c"><i class="icon pwd"></i><input type="text" v-model="loginPassword"></div>
                </div>
                <div class="register-check-box">
                    <span :class="[{'active': isRemember}]" @click="rememberEvt">记住密码</span>
                    <span @click="registerEvt">找回密码</span>
                </div>
                <div class="btn" @click="loginEvt">登陆</div>
            </div>
        </div>
    </div>
</template>
<style>

</style>
<script>
    import BaseView from "../BaseView.vue";
    import { loginApi, getUserMenuApi } from "@/api/login";
    import { trimObject, convertToDimensional } from "@/util/tool";
    import { ROLE_INTERNAL } from "@/config/const.config";
    import { INTERNAL_MENU } from "@/config/menu.config";

    export default{
        extends: BaseView,
        data() {
            return {
                loginName: "",
                loginPassword: "",
                isRemember: false
            }
        },
        methods: {
            async loginEvt() {
                /* 登录信息保存 */
                let loading = this.$loading({
                    lock: true
                });
                let subObj = trimObject({id: this.loginName, pwd: this.loginPassword});
                if (subObj.id !== '' && subObj.pwd !== '') {
                    let result = await loginApi(subObj);
                    loading.close();
                    if (result.meta.code === 200) {

                        /* 是否需要记住密码 */
                        if (this.isRemember) {
                            localStorage.setItem('hasRememberUserInfo', '1');
                            localStorage.setItem('cache_user_information', JSON.stringify(subObj));
                        } else {
                            localStorage.removeItem('hasRememberUserInfo');
                            localStorage.removeItem('cache_user_information');
                        }

                        /* 设置个人信息到缓存 */
                        sessionStorage.setItem('current_login_user_info', JSON.stringify(result.data[0]));

                        /* 获取个人权限菜单 */
                        this.getUserRole();
                    } else {
                        this.handleErrorMessage(result);
                    }
                } else {
                    loading.close();
                    this.$message({
                        message: '填写用户名和密码',
                        type: 'error'
                    });
                }
            },
            async getUserRole() {
                let result = await getUserMenuApi(ROLE_INTERNAL, this.loginName);

                /* 缓存目录数据本地缓存 */
                this.$store.dispatch('setCurrentMenuData', {data: result});
                sessionStorage.setItem('current_menu_data', JSON.stringify(result));

                /* 请求回来的菜单应为树数据，遍历为一维数据 */
                sessionStorage.setItem('current_user_right', JSON.stringify(convertToDimensional(result)));
                this.$router.push({path: '/home/internal'});
            },
            rememberEvt() {
                this.isRemember = !this.isRemember;
            },
            /* 注册用户信息 */
            registerEvt() {
                this.$router.push('/login/register');
            }
        },
        created() {

            let cache = localStorage.getItem('hasRememberUserInfo');
            if (!!cache) {
                let userInfo = localStorage.getItem('cache_user_information');
                try {
                    userInfo = JSON.parse(userInfo);
                    this.loginName = userInfo.id;
                    this.loginPassword = userInfo.pwd;
                    this.isRemember = true;
                } catch (e) {
                    console.log(e);
                }
            }
        }
    }
</script>
