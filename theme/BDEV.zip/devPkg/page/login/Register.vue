/*********************************************************************
* Vue Register file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="register-container">
        <div class="banner"></div>
        <div class="content">
            <div class="fix-width-container">
                <div class="box w600">
                    <register-block title="注册账号" sub="LOGIN">
                        <step-item :stepList="stepList"></step-item>
                        <div class="tower-line-form">
                            <div class="line"
                                 v-for="(item, idx) in registerData"
                                 v-show="item.id === stepFlag"
                                 :key="`key_${idx}`">
                                <div class="label">{{item.label}}</div>
                                <div class="box">
                                    <el-input size="medium" v-model="item.value" :placeholder="item.placeholder"></el-input>
                                </div>
                            </div>
                            <div class="register-check-box full mb16" v-show="stepFlag === 'key01'">
                                <span class="active">同意《中国铁塔合作伙伴服务协议》</span>
                            </div>
                            <div class="line center">
                                <el-button @click="formEvent('next')" v-show="stepFlag === 'key01'" size="medium" type="danger">下一步</el-button>
                                <el-button @click="formEvent('previous')" v-show="stepFlag === 'key02'" size="medium" type="danger">上一步</el-button>
                                <el-button @click="formEvent('register')" v-show="stepFlag === 'key02'" size="medium" type="danger">注册</el-button>
                            </div>
                        </div>
                    </register-block>
                </div>
            </div>
        </div>
        <div class="bottom">
            <div class="box">
                <register-block title="招募公告" sub="RECRUITMENT" width="w61">
                    <el-button slot="btn" size="medium" type="danger" plain>更多</el-button>
                    <div class="register-row-info" v-for="(item, idx) in recruitList" :key="`key_${idx}`">
                        <span class="label w40">{{item.name}}</span>
                        <span class="text w40"><i class="el-icon-time"></i>报名截止时间：{{item.time}}</span>
                        <span class="text w20"><i class="el-icon-location-outline"></i>{{item.address}}</span>
                    </div>
                </register-block>
                <register-block title="系统公告" sub="SYSTEM NOTICE" width="w39">
                    <div class="register-list-info hei188">
                        <div class="line" v-for="(item, idx) in systemList" :key="`key_${idx}`">{{item.info}}</div>
                    </div>
                </register-block>
            </div>
            <div class="info">Copyright  2015-2018 WWW.jhuouhoo.com</div>
        </div>
    </div>
</template>
<script>
    export default {
        /**
         * 页面参数释义
         */
        data() {
            return {
                stepFlag: 'key01',
                stepList: [
                    {active: true, key: 'key01', text: '企业详细信息'},
                    {active: false, key: 'key02', text: '附件及标签信息'}
                ],
                registerData: [
                    {id: 'key01', key: 'key_01', label: '用户名', value: '', placeholder: '请输入账号'},
                    {id: 'key01', key: 'key_02', label: '邀请码', value: '', placeholder: '请输入邀请码'},
                    {id: 'key01', key: 'key_03', label: '邮箱', value: '', placeholder: '请输入密码'},
                    {id: 'key01', key: 'key_04', label: '手机号码', value: '', placeholder: '请输入手机号码'},
                    {id: 'key01', key: 'key_05', label: '密码', value: '', placeholder: '请输入密码'},
                    {id: 'key01', key: 'key_06', label: '确认密码', value: '', placeholder: '请再次输入密码'},
                    {id: 'key02', key: 'key_07', label: '公司名称', value: '', placeholder: '请输入公司名称'},
                    {id: 'key02', key: 'key_08', label: '公司地址', value: '', placeholder: '请输入公司地址'},
                    {id: 'key02', key: 'key_09', label: '公司法人', value: '', placeholder: '请输入公司法人'},
                    {id: 'key02', key: 'key_10', label: '营业执照', value: '', placeholder: '请输入营业执照'},
                    {id: 'key02', key: 'key_11', label: '公司联系人', value: '', placeholder: '请输入公司联系人'},
                    {id: 'key02', key: 'key_12', label: '联系电话', value: '', placeholder: '请再次联系电话'}
                ],
                recruitList: [
                    {name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省'},
                    {name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省'},
                    {name: '中国铁塔QWE业务合作招募公告', time: '2019-01-22 12:20:30', address: '广东省'}
                ],
                systemList: [
                    {info: '【更新公告】2019年5月31日更新版本，修复已知bug，优化使用体验优化使用体验优化使用体验优化使用体验'},
                    {info: '【更新公告】2019年5月31日更新版本，修复已知bug，优化使用体验优化使用体验'},
                    {info: '【更新公告】2019年5月31日更新版本，修复已知bug，优化使用体验优化使用体验优化使用体验优化使用体验'},
                    {info: '【更新公告】2019年5月31日更新版本，修复已知bug，优化使用体验优化使用体验优化使用体验优化使用体验'},
                    {info: '【更新公告】2019年5月31日更新版本，修复已知bug，优化使用体验优化使用体验'},
                    {info: '【更新公告】2019年5月31日更新版本，修复已知bug，优化使用体验优化使用体验'}
                ]
            }
        },
        methods: {
            formEvent(type) {

                if (type === 'register') this.$router.push('/login');

                this.stepFlag = type === 'next' ? 'key02' : type === 'previous' ? 'key01' : '';

                let temp = [];
                this.stepList.map(it => {
                    it.active = it.key === this.stepFlag;
                    temp.push(it);
                });

                this.stepList = temp;
            }
        },
        created() {

        }
    }
</script>