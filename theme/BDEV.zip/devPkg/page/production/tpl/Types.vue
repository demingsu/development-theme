/*********************************************************************
* Vue Types file
* Created by deming-su on 2019/6/6
*********************************************************************/

<template>
    <div class="Types-container">
        this is Types page content
    </div>
</template>
<script>
    export default {
        /**
         * 页面参数释义
         */
        data() {
            return {}
        },
        /**
         * 页面初始化
         */
        created() {

        }
    }
</script>