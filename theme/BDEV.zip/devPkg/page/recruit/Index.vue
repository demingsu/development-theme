/*********************************************************************
* Vue Index file
* Created by deming-su on 2019/6/9
*********************************************************************/

<template>
    <div style="display: block; position: relative; height: 100%;">
        <keep-alive>
            <router-view v-if="$route.meta.cache"></router-view>
        </keep-alive>
        <router-view v-if="!$route.meta.cache"></router-view>
    </div>
</template>
<script>
    export default {

    }
</script>