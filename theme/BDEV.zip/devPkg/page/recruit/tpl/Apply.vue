/*********************************************************************
* Vue Apply file
* Created by deming-su on 2019/6/9
*********************************************************************/

<template>
    <div class="fix-width-container full scroll bread">
        <bread-item :breadcrumbList="breadcrumbList"></bread-item>
        <div class="box">
            <div class="fix-width-container w1080">
                <div class="box w900">
                    <div class="tower-line-form">
                        <div class="line p10">
                            <div class="label feed red">1、公告信息</div>
                        </div>
                        <div class="line p10">
                            <div class="label feed">公告标题</div>
                            <div class="box ml0">
                                <el-input size="medium" v-model="pageQuery.title" placeholder="请输入公告标题"></el-input>
                            </div>
                        </div>
                        <div class="line p10">
                            <div class="label feed">公告模板</div>
                            <div class="box ml0">
                                <el-select size="medium" v-model="pageQuery.template" placeholder="请选择公告模板">
                                    <el-option v-for="it in pageQueryOptions.template"
                                               :key="it.value"
                                               :label="it.label"
                                               :value="it.value">
                                    </el-option>
                                </el-select>
                            </div>
                        </div>
                        <div class="line p10">
                            <div class="label feed">公告内容</div>
                            <div class="box ml0">
                                <iframe id="editorNode" src="./editor.html" frameborder="0"></iframe>
                            </div>
                        </div>
                        <div class="line p10 w2">
                            <div class="label feed">发布时间</div>
                            <div class="box ml0">
                                <el-date-picker size="medium" v-model="pageQuery.publishDate" type="date" placeholder="选择日期"></el-date-picker>
                            </div>
                        </div>
                        <div class="line p10 w2">
                            <div class="label feed">截止时间</div>
                            <div class="box ml0">
                                <el-date-picker size="medium" v-model="pageQuery.endDate" type="date" placeholder="选择日期"></el-date-picker>
                            </div>
                        </div>
                        <div class="line p10">
                            <div class="label feed">公告附件</div>
                            <div class="box ml0 mr200">
                                <el-input size="medium" :readonly="true" v-model="pageQuery.fileName" placeholder="请选择文件"></el-input>
                            </div>
                            <el-button class="from-upload-button"
                                       size="medium"
                                       type="danger"
                                       @click="pickFileEvent"
                                       icon="el-icon-upload2" plain>上传文件</el-button>
                        </div>
                        <div class="line p10 split-line"></div>
                        <div class="line p10">
                            <div class="label feed red">2、处理意见区</div>
                        </div>
                        <div class="line p10 w2">
                            <div class="label feed">选择审批方式</div>
                            <div class="box ml0">
                                <el-select size="medium" v-model="pageQuery.type" placeholder="请选择公告模板">
                                    <el-option v-for="it in pageQueryOptions.type"
                                               :key="it.value"
                                               :label="it.label"
                                               :value="it.value">
                                    </el-option>
                                </el-select>
                            </div>
                        </div>
                        <div class="line p10 w2">
                            <div class="label feed">选择下一环节处理人</div>
                            <div class="box ml0">
                                <el-select size="medium" v-model="pageQuery.name" placeholder="请选择公告模板">
                                    <el-option v-for="it in pageQueryOptions.name"
                                               :key="it.value"
                                               :label="it.label"
                                               :value="it.value">
                                    </el-option>
                                </el-select>
                            </div>
                        </div>
                        <div class="line p10">
                            <div class="label feed">处理意见</div>
                            <div class="box ml0">
                                <el-input size="medium" v-model="pageQuery.remark" placeholder="请输入公告标题"></el-input>
                            </div>
                        </div>
                        <div class="line center">
                            <el-button @click="pageEvent('save')" size="medium" type="danger">存为草稿</el-button>
                            <el-button @click="pageEvent('apply')" size="medium" type="danger">申请发布</el-button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import { fileUploadMethod } from "@/util/tool";
    import { postRequestMethod, getRequestUrl } from "@/api/common";

    export default {
        data() {
            return {
                editorNode: null,
                breadcrumbList: [
                    {path: '', name: '招募管理'},
                    {path: '', name: '招募公告'},
                    {path: '', name: '申请招募'}
                ],
                pageQuery: {
                    title: '',
                    template: '',
                    publishDate: new Date(),
                    endDate: new Date(),
                    fileName: '',
                    type: '',
                    name: '',
                    remark: ''
                },
                pageQueryOptions: {
                    template: [
                        {value: 't1', label: '模板一'},
                        {value: 't2', label: '模板二'},
                        {value: 't3', label: '模板三'},
                        {value: 't4', label: '模板四'},
                        {value: 't5', label: '模板五'},
                        {value: 't6', label: '模板六'}
                    ],
                    type: [
                        {value: 'p1', label: '类型一'},
                        {value: 'p2', label: '类型二'},
                        {value: 'p3', label: '类型三'},
                        {value: 'p4', label: '类型四'},
                        {value: 'p5', label: '类型五'},
                        {value: 'p6', label: '类型六'}
                    ],
                    name: [
                        {value: 'p1', label: '张三'},
                        {value: 'p2', label: '李四'},
                        {value: 'p3', label: '王五'},
                        {value: 'p4', label: '赵六'},
                        {value: 'p5', label: '陈霸'},
                        {value: 'p6', label: '路名'}
                    ]
                }
            }
        },
        methods: {
            /* 文件上传方法 */
            pickFileEvent() {
                fileUploadMethod(async files => {

                    let str = `【ME】上传了文件${files[0].name}`;

                    /* 文件上传方法 */
                    /*let result = await postRequestMethod('LOGIN_UPLOAD_FILE', {'fileName': files[0]}, progress => {
                        console.log(`当前的进度--${(progress.loaded / progress.total) * 100}%`)
                    });
                    console.log('上传文件返回结果', result);
                    */
                    this.pageQuery.fileName = files[0].name;
                    this.$notify.success({
                        title: '上传文件',
                        type: 'success',
                        message: str,
                        duration: 2000,
                        showClose: false
                    });
                });
            },
            /* 获取初始化内容数据 */
            getInitContent() {

                let load = this.$loading();

                setTimeout(() => {
                    this.editorNode.contentWindow.postMessage(`{"type": "setContent", "data": "fldjslkfjsljfdslkflskflsaj"}`, '*');
                    load.close();
                }, 1200);

            },
            /* 页面按钮事件 */
            pageEvent(type) {
                console.log(type);

                this.$notify.success({
                    title: '富文本内容',
                    type: 'success',
                    message: this.editorNode.contentWindow.getEditorContent(),
                    duration: 2000,
                    showClose: false
                });

                setTimeout(() => {
                    this.$notify.success({
                        title: '提交内容',
                        type: 'success',
                        message: JSON.stringify(this.pageQuery),
                        duration: 2000,
                        showClose: false
                    });
                });
            }
        },
        created() {

            /* UEditor通信 */
            window.addEventListener('message', evt => {
                let _d = evt.data;
                try {
                    _d = JSON.parse(_d);
                } catch (e) {
                    _d = {};
                }
                if(_d.type === 'init') {
                    this.editorNode = document.getElementById('editorNode');
                    if (!!this.editorNode) this.editorNode.contentWindow.postMessage(`{"type": "setUrl", "data": ${getRequestUrl('UEDITOR_URL')}`, '*');

                    /* 获取初始化内容 */
                    this.getInitContent();
                }
            }) ;
        }
    }
</script>