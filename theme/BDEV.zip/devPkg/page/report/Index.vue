/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div>
        this is report page.
    </div>
</template>

<script>
    
    export default {
        /**
         * 所有参数变量说明
         */
        data() {
            return {

            }
        }
    }
</script>