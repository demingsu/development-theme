/*********************************************************************
 * defined Home page router file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 登录页面--主页面 */
const LoginIndex = () => import(/* webpackChunkName: "LoginIndex"*/"../page/login/Login.vue");

/* 登录页面--注册页面 */
const LoginRegister = () => import(/* webpackChunkName: "LoginRegister"*/"../page/login/Register.vue");

/* 错误路径页面页面 */
const NotFound = () => import(/* webpackChunkName: "NotFound"*/"../page/default/NotFound.vue");

/* 错误路径页面页面 */
const NotRight = () => import(/* webpackChunkName: "NotRight"*/"../page/default/NotRight.vue");

const routes = [
    {path: "/", redirect: '/login'},
    {path: "/login", component: LoginIndex, meta: { layout: "blank-layout", requestLogin: false }},
    {path: "/login/register", component: LoginRegister, meta: { layout: "blank-layout", requestLogin: false }},
    {path: "/not/found", component: NotFound, meta: { layout: "blank-layout", requestLogin: false }},
    {path: "/not/right", component: NotRight, meta: { layout: "blank-layout", requestLogin: false }}
];

export default routes;