/*********************************************************************
 * defined Cooperation page router file
 * Created by deming-su on 2019/6/6
 *********************************************************************/


/* 合作伙伴功能--主路由容器 */
const CooperationIndex = () => import(/* webpackChunkName: "CooperationIndex"*/"../page/cooperation/Index.vue");

/* 合作伙伴功能--招募公告 */
const CooperationNoticeRecruit = () => import(/* webpackChunkName: "CooperationNoticeRecruit"*/"../page/cooperation/tpl/NoticeRecruit.vue");

/* 合作伙伴功能--结果公示 */
const CooperationNoticeResult = () => import(/* webpackChunkName: "CooperationNoticeResult"*/"../page/cooperation/tpl/NoticeResult.vue");

/* 合作伙伴功能--优秀合作伙伴 */
const CooperationExcellent = () => import(/* webpackChunkName: "CooperationExcellent"*/"../page/cooperation/tpl/Excellent.vue");

/* 合作伙伴功能--优秀合作伙伴 */
const CooperationJoin = () => import(/* webpackChunkName: "CooperationJoin"*/"../page/cooperation/tpl/Join.vue");

/* 商机共享--主路由 */
const BusinessIndex = () => import(/* webpackChunkName: "BusinessIndex"*/"../page/business/Index.vue");

/* 商机共享--发布商机 */
const BusinessPublish = () => import(/* webpackChunkName: "BusinessPublish"*/"../page/business/tpl/Publish.vue");

/* 合作伙伴功能--寻求商机 */
const BusinessFound = () => import(/* webpackChunkName: "BusinessFound"*/"../page/business/tpl/Found.vue");

/* 产品及服务--主路由 */
const ProductionIndex = () => import(/* webpackChunkName: "ProductionIndex"*/"../page/production/Index.vue");

/* 产品及服务--主路由 */
const ProductionTypes = () => import(/* webpackChunkName: "ProductionTypes"*/"../page/production/tpl/Types.vue");

const routes = [
    {
        path: "/cooperation",
        component: CooperationIndex,
        children: [
            {path: '', redirect: 'notice_recruit'},
            {path: 'notice_recruit', component: CooperationNoticeRecruit, meta: { layout: "blank-layout", requestLogin: false }},
            {path: 'notice_result', component: CooperationNoticeResult, meta: { layout: "blank-layout", requestLogin: false }},
            {path: 'excellent', component: CooperationExcellent, meta: { layout: "blank-layout", requestLogin: false }},
            {path: 'join', component: CooperationJoin, meta: { layout: "main-layout", requestLogin: false }}
        ]
    },
    {
        path: "/business",
        component: BusinessIndex,
        children: [
            {path: '', redirect: 'publish'},
            {path: 'publish', component: BusinessPublish, meta: { layout: "blank-layout", requestLogin: false }},
            {path: 'found', component: BusinessFound, meta: { layout: "blank-layout", requestLogin: false }}
        ]
    },
    {
        path: "/production",
        component: ProductionIndex,
        children: [
            {path: '', redirect: 'types'},
            {path: 'types', component: ProductionTypes, meta: { layout: "blank-layout", requestLogin: false }}
        ]
    }
];

export default routes;