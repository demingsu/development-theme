/*********************************************************************
 * defined Home page router file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 首页--容器路由 */
const HomeIndex = () => import(/* webpackChunkName: "HomeIndex"*/"../page/home/Index.vue");

/* 首页--合作伙伴路由 */
const HomeCooperation = () => import(/* webpackChunkName: "HomeCooperation"*/"../page/home/tpl/Cooperation.vue");

/* 首页--内部首页路由 */
const HomeInternal = () => import(/* webpackChunkName: "HomeInternal"*/"../page/home/tpl/Internal.vue");

/* 首页--数据看板路由 */
const HomeDashboard = () => import(/* webpackChunkName: "HomeDashboard"*/"../page/home/tpl/Dashboard.vue");

const routes = [
    {
        path: "/home",
        component: HomeIndex,
        children: [
            {path: '', redirect: 'cooperation'},
            {path: 'cooperation', component: HomeCooperation, meta: { layout: "main-layout", requestLogin: false }},
            {path: 'internal', component: HomeInternal, meta: { layout: "main-layout", requestLogin: true }},
            {path: 'dashboard', component: HomeDashboard, meta: { layout: "main-layout", requestLogin: true }}
        ]
    }
];

export default routes;