/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/


"use strict";

/* 加载vue路由 */
import Router from "vue-router";

/* 各个功能模块 --start-- */

/* 通用路由设置 */
import Common from "./common";

/* 首页路由 */
import Home from "./home";

/* 内部人员路由 */
import Internal from "./internal";

/* 内部人员路由 */
import Cooperation from "./cooperation";

/* 招募管理路由 */
import Recruit from "./recruit";

/* 各个功能模块 --end-- */

/* 路由集合 */
const RouterCollection = [
    ...Common,
    ...Home,
    ...Internal,
    ...Cooperation,
    ...Recruit
];

/* 路由配置 */
const router = new Router({routes: RouterCollection});

/* 路由拦截、校验规则 */
import ValidateRule from "../util/right";

/* 路由权限拦截 */
router.beforeEach((to, from, next) => ValidateRule(to, from, next, RouterCollection));

export default router;