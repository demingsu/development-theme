/*********************************************************************
 * defined internal page router file
 * Created by deming-su on 2019/6/6
 *********************************************************************/

/* 内部功能--主路由容器 */
const InternalIndex = () => import(/* webpackChunkName: "InternalIndex"*/"../page/internal/Index.vue");

/* 内部功能--合作伙伴管理 */
const InternalNoticeList = () => import(/* webpackChunkName: "InternalNoticeList"*/"../page/internal/tpl/NoticeList.vue");

/* 内部功能--合作产品管理 */
const InternalManagementPrd = () => import(/* webpackChunkName: "InternalManagementPrd"*/"../page/internal/tpl/ManagementPrd.vue");

/* 内部功能--考核模板管理 */
const InternalTemplate = () => import(/* webpackChunkName: "InternalTemplate"*/"../page/internal/tpl/Template.vue");

/* 内部功能--系统管理 */
const InternalSystem = () => import(/* webpackChunkName: "InternalSystem"*/"../page/internal/tpl/System.vue");

/* 内部功能--人员管理 */
const InternalEmployee = () => import(/* webpackChunkName: "InternalEmployee"*/"../page/internal/tpl/Employee.vue");

/* 内部功能--角色管理 */
const InternalRole = () => import(/* webpackChunkName: "InternalRole"*/"../page/internal/tpl/Role.vue");

/* 内部功能--待办管理 */
const InternalSchedule = () => import(/* webpackChunkName: "InternalSchedule"*/"../page/internal/tpl/Schedule.vue");

/* 内部功能--合作伙伴管理 */
const InternalPartner = () => import(/* webpackChunkName: "InternalPartner"*/"../page/internal/tpl/Partner.vue");

const routes = [
    {
        path: "/internal",
        component: InternalIndex,
        children: [
            {path: '', redirect: 'management'},
            {path: 'management', component: InternalNoticeList, meta: { layout: "main-layout", requestLogin: true }},
            {path: 'management_prd', component: InternalManagementPrd, meta: { layout: "main-layout", requestLogin: true }},
            {path: 'template', component: InternalTemplate, meta: { layout: "main-layout", requestLogin: true }},
            {path: 'system', component: InternalSystem, meta: { layout: "blank-layout", requestLogin: false }},
            {path: 'employee', component: InternalEmployee, meta: { layout: "blank-layout", requestLogin: false }},
            {path: 'role', component: InternalRole, meta: { layout: "blank-layout", requestLogin: false }},
            {path: 'schedule', component: InternalSchedule, meta: { layout: "blank-layout", requestLogin: false }},
            {path: 'partner', component: InternalPartner, meta: { layout: "blank-layout", requestLogin: false }}
        ]
    }
];

export default routes;