/*********************************************************************
 * defined recruit page router file
 * Created by deming-su on 2019/6/9
 *********************************************************************/


/* 内部功能--合作伙伴招募管理主路由 */
const InternalManagement = () => import(/* webpackChunkName: "InternalManagement"*/"../page/recruit/Index.vue");

/* 内部功能--合作伙伴招募管理列表页面 */
const InternalManagementList = () => import(/* webpackChunkName: "InternalManagementList"*/"../page/recruit/tpl/Management.vue");

/* 内部功能--合作伙伴招募管理申请页面 */
const InternalManagementApply = () => import(/* webpackChunkName: "InternalManagementApply"*/"../page/recruit/tpl/Apply.vue");

const routes = [
    {
        path: "/recruit",
        component: InternalManagement,
        children: [
            {path: '', redirect: 'list'},
            {path: 'list', component: InternalManagementList, meta: { layout: "main-layout", requestLogin: true, cache: true }},
            {path: 'apply', component: InternalManagementApply, meta: { layout: "main-layout", requestLogin: true }}
        ]
    }
];

export default routes;