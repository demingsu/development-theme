/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/**
 * 状态数据库对象
 */
const state = {
    userInfo: {},
    currentMenuData: []
};

/**
 * 状态数据库设值方法
 */
const getters = {
    getUserInfo: state => state.userInfo,
    getCurrentMenuData: (state) => {
    	if (state.currentMenuData.length > 0) {
    		return state.currentMenuData
		} else {
			let cache = sessionStorage.getItem('current_menu_data') || '[]';
			try {
				cache = JSON.parse(cache);
				return cache;
            } catch (e) {
				return [];
            }
		}
	}
};

/**
 * 派发指令
 */
const actions = {
	setUserInfo({commit}, {data}) {
    	commit('mutationUserInfo', {data});
	},
    setCurrentMenuData({commit}, {data}) {
    	commit('mutationMenuData', {data});
	}
};

const mutations = {
    mutationUserInfo(state, {data}) {

		/* 扭转数据状态 */
		state.userInfo = data;
	},
    mutationMenuData(state, {data}) {

		/* 扭转数据状态 */
		state.currentMenuData = data;
	}
};

export default {
	state,
	getters,
	actions,
	mutations
};