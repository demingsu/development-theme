/*********************************************************************
 * common util function file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 16进制颜色转rgba */
let hexToRgba = (val, opacity) => {
    if (!opacity) opacity = 1;
    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(val)) {
        /* 自动补全3位16进制字符串 */
        if (val.length === 4) {
            let str = "#";
            for (let i = 1; i < 4; i ++) {
                let char = val.slice(i, i + 1);
                str += char.concat(char);
            }
            val = str;
        }
        let res = [];
        /* 遍历字符串转为十进制rgb */
        for (let i = 1; i < 7; i += 2) {
            /* 两个方法都可以转 */
            res.push(parseInt(val.slice(i, i + 2), 16));
        }
        res.push(opacity);
        val = `rgba(${res.join(',')})`;
    }
    return val;
};

/**
 *  日期转换方法
 *  @param YYYY-MM-DD hh:mm:ss
 */
let dateFormat = (type, val) => {
    let date = val ? new Date(/^[0-9]*$/g.test(val) ? val * 1 : val) : new Date();
    let YYYY = date.getFullYear() + '';
    let m = date.getMonth() + 1;
    let MM = m > 9 ? m + '' : '0' + m;
    let d = date.getDate();
    let DD = d > 9 ? d + '' : '0' + d;
    let h = date.getHours();
    let hh = h > 9 ? h + '' : '0' + h;
    let $m = date.getMinutes();
    let mm = $m > 9 ? $m + '' : '0' + $m;
    let s = date.getSeconds();
    let ss = s > 9 ? s + '' : '0' + s;
    let obj = { YYYY, MM, DD, hh, mm, ss};

    return type.replace(/(YYYY)|(MM)|(DD)|(hh)|(mm)|(ss)/g, (key) => obj[key]);
};

/**
 *  去掉字段的两端空格
 *  @param Object
 */
let trimObject = (obj) => {
    let res = {};
    console.log(obj);
    for (let name in obj) {
        if (obj.hasOwnProperty(name)) {
            res[name] = obj[name].replace(/(^\s*)|(\s*$)/g, '');
        }
    }

    return res;
};

/**
 *  去掉字段的两端空格
 *  @param Object
 */
let fileSize = (size, count) => {
    if (!count) count = 0;
    if (isNaN(size)) return 0;
    var names = ['byte', 'KByte', 'MB', 'GB', 'TB'];
    if (size < 1024) {
        return size + names[count];
    } else {
        return fileSize(parseFloat((size / 1024).toFixed(2)), ++count);
    }
};

/**
 * 转换树数据到一维数组
 * @param data  树数组
 * @return 一维数组
 */
let convertToDimensional = (data, newData) => {

    if (!newData) newData = [];
    for (let i = 0;i < data.length;i ++) {
        if (data[i].children && data[i].children.length > 0) {
            convertToDimensional(data[i].children, newData);
        }
        newData.push(data[i]);
    }
    return newData;
};

/**
 * 文件上传方法，回调给调用方文件集
 * @param {Function}  cb   回调函数
 */
let fileUploadMethod = cb => {
    let box = document.createElement('div');
    document.body.appendChild(box);
    box.setAttribute('style', 'display: block; height: 0; width: 0; overflow: hidden;');

    let input = document.createElement('input');
    input.setAttribute('name', 'file');
    input.setAttribute('type', 'file');
    input.setAttribute('multiple', 'multiple');
    box.appendChild(input);

    input.addEventListener('change', function() {

        let files = input.files;

        document.body.removeChild(box);

        cb(files);
    });

    input.click();
};


export {
    dateFormat,
    hexToRgba,
    trimObject,
    fileSize,
    convertToDimensional,
    fileUploadMethod
};