/****************************************
 * 初始化设置editor内容
 * iframe.postmessage({type: 'initContent', data: data}, '*');
 * data = {titleProps: { name: '陈娜<chenn@lensyn.com>', date: '昨天 09:00（周三）', title: '公司问卷调查（20180615）', receive: ['张三', '张三', '李四', '王五'], repeat: ['张三', '王五'], archive: 5 }, content: '<p><span style="display: block; font-weight: 600; color: #232425; font-size: 14px;"><br/></span></p>', archiveList: [ {id: 'testId001', icon: '&#xe644;', color: '#FF5562', name: '后台管理-选择公告+水电门户日程提醒与日程删除.zip'} ], sign: '<p style="display: block; margin: 15px 0;">签名：测试</p>' };
 ****************************************/

/* 编辑器对象 */
var editor = null;

/* 页面样式 */
var title_cls = 'display: block; font-weight: 600; color: #232425; font-size: 14px; padding: 0 30px;';
var sub_box_cls = 'display: block; position: relative; margin: 0; padding: 4px 30px 4px 82px; overflow: hidden;';
var sub_title_cls = 'float: left; font-size: 12px; height: 18px; line-height: 18px; font-weight: 400; color: #515151;';
var sub_title_right = 'float: right';
var sub_content_cls = 'font-size: 14px; color: #232425;';
var sub_content_cls0 = 'font-size: 12px;';
var sub_content_cls1 = 'font-size: 12px; color: #888888;';
var sub_content_cls2 = 'position: absolute; top: 4px; left: 30px; width: 52px;';
var archive_item_cls = 'position: relative; float: left; width: 100px; padding: 8px;';
var archive_item_icon_cls = 'display: block; width: 100px; height: 50px; margin: 0 auto; text-align: center; font-family: "iconfont" !important;font-style: normal;font-size: 30px;color: #6CCBFF;-webkit-font-smoothing: antialiased;-moz-osx-font-smoothing: grayscale;'
var archive_item_text_cls = 'display: block; width: 100px; height: 32px; margin-top: 5px; font-size: 12px; color: #515151; line-height: 16px; overflow: hidden;'

$(function () {
    /* 获取token */
    $.ajax({
        url: '/api/access_token',
        success: function (data) {
            if(data.meta.code === 1) {

                // 服务器统一请求接口路径
                window.UEDITOR_CONFIG.serverUrl = '/api/announcement/ueditor/exec?access_token=' + data.data.access_token;

                // 获取ueditor实例
                editor = UE.getEditor('editor', {
                    elementPathEnabled: false,
                    wordCount: false,
                    autoHeightEnabled: false
                });

                //复写UEDITOR的getActionUrl 方法,定义自己的Action
                UE.Editor.prototype._bkGetActionUrl = UE.Editor.prototype.getActionUrl;
                UE.Editor.prototype.getActionUrl = function (action) {
                    if (action == 'config') {
                        return './static/assets/ueditor/config.json';
                    } else {
                        return this._bkGetActionUrl.call(this, action);
                    }
                };
                /* 编辑器准备完成，执行外部广播通知 */
                editor.ready(function () {
                    /* 设置窗口高度 */
                    editor.setHeight(document.body.clientHeight - 80);
                    window.parent.postMessage({type: 'editorReady'}, '*');

                    /* 添加附件点击事件 */
                    editor.addListener('click', function (type, evt) {
                        var node = evt.target;
                        if(!node) return;
                        var style = node.getAttribute('style');
                        if(!style) return;
                        var key = style.indexOf('archive-key: archiveKey;');
                        var id = style.indexOf('archive-id: ');
                        if(node.tagName === 'A' && key > -1 && id > -1) {
                            var nodeRect = node.getBoundingClientRect();
                            var idStr = style.substring(12 + id);
                            idStr = idStr.substring(0, idStr.indexOf(';'));
                            var rect = {id: idStr, width: nodeRect.width, height: nodeRect.height, top: nodeRect.top, left: nodeRect.left};
                            window.parent.postMessage({type: 'archiveClickEvt', data: rect}, '*');
                        }
                    });

                    /* TODO 参数仅供测试用 */
                    // assembleContent({
                    //     titleProps: {
                    //         name: '陈娜<chenn@lensyn.com>',
                    //         date: '昨天 09:00（周三）',
                    //         title: '公司问卷调查（20180615）',
                    //         receive: ['张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五'],
                    //         repeat: ['张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五', '张三', '李四', '王五'],
                    //         archive: 5
                    //     },
                    //     content: '<p><span style="display: block; font-weight: 600; color: #232425; font-size: 14px;"><br/></span><p>各位同事：</p><p>&nbsp; &nbsp; 大家好，耽误大家几分钟时间，请大家尽快填写一下这个调查问卷！</p><p>&nbsp; &nbsp; 此次调查的目的在于在独立客观的视角上，回顾您在公司工作生活的点滴、领导的管理方式、公司企业文化、并为公司的发展提出建议与措施，给我们中肯的意见或建议，以制定改进措施提高大家对公司的认同感、归属感，不断增强公司的向心力、凝聚力。此问卷采用不记名方式，请您根据实际情况如实填写，我们承诺将会对您的填写结果完全保密。</p><p>&nbsp; &nbsp; 感谢您的配合与支持，祝您工作愉快！</p><p>&nbsp; &nbsp; 参与方式 1、微信扫描二维码</p><p>&nbsp; &nbsp; 参与方式 2、链接登入&nbsp; &nbsp;链接：http://www.91pxb.com/survey/sc-12566144-3078812-794295-458123</p></p>',
                    //     archiveList: [
                    //         {id: 'testId001', icon: '&#xe644;', color: '#FF5562', name: '后台管理-选择公告+水电门户日程提醒与日程删除.zip'},
                    //         {id: 'testId002', icon: '&#xe646;', color: '#FF8976', name: '后台管理-选择公告+水电门户日程提醒与日程删除.zip'},
                    //         {id: 'testId003', icon: '&#xe648;', color: '#6CCBFF', name: '后台管理-选择公告+水电门户日程提醒与日程删除.zip'},
                    //         {id: 'testId004', icon: '&#xe63c;', color: '#46CBAA', name: '后台管理-选择公告+水电门户日程提醒与日程删除.zip'},
                    //         {id: 'testId005', icon: '&#xe66b;', color: '#58C012', name: '后台管理-选择公告+水电门户日程提醒与日程删除.zip'},
                    //         {id: 'testId006', icon: '&#xe668;', color: '#4D97FF', name: '后台管理-选择公告+水电门户日程提醒与日程删除.zip'},
                    //         {id: 'testId007', icon: '&#xe667;', color: '#FFAC33', name: '后台管理-选择公告+水电门户日程提醒与日程删除.zip'}
                    //     ],
                    //     sign: '<p style="display: block; margin: 15px 0;">签名：测试</p>'
                    // });
                });
            }
        }
    });
    /* 注册监听 */
    registerEvent();
});

/* 页面通信监听及分发方法 */
function registerEvent() {
    window.addEventListener('resize', function() {
        editor.setHeight(document.body.clientHeight - 80);
    });
    window.getCurrentContent = function () {
        return editor.getContent();
    };
    window.addEventListener('message',function(event){
        handleEvent(event.data);
    }, false);
}

/* 通信处理方法 */
function handleEvent(data) {
    switch (data.type) {
        case 'content':
            editor.setContent(event.data);
            break;
        case 'initContent':
            assembleContent(data.data);
            break;
        default:
            break;
    }
}

/* 组合页面元素 */
function assembleContent(data) {
    var cacheBox = document.createElement('div');

    /* 标题属性 */
    if(data.titleProps) {
        var titleProps = data.titleProps;
        var originTitle = createEle({name: 'p', content: '以下是原邮件：', style: title_cls});
        cacheBox.appendChild(originTitle);
        /* 设置标题属性，递归创建元素并添加到母元素中 */
        var c = [
            {key: 'name', name: ['发件人：', titleProps.name, titleProps.date], type: 1},
            {key: 'title', name: ['主题：', titleProps.title], type: 1},
            {key: 'receive', name: ['收件人：'].concat((titleProps.receive.join('；|||') + '；').split('|||')), type: 2},
            {key: 'repeat', name: ['抄送：'].concat((titleProps.repeat.join('；|||') + '；').split('|||')), type: 2},
            {key: 'archive', name: ['附件：', titleProps.archive], type: 3}];
        c.forEach(function (it, i) {
            var cObj = {name: 'p', content: '', style: sub_box_cls, children: []};
            it.name.forEach(function (item, k) {
                var style = k === 0 ? sub_title_cls + sub_content_cls2 : sub_title_cls + (it.type === 1 ? sub_content_cls : it.type === 2 ? sub_content_cls1 : sub_content_cls0);
                if(i === 0 && k === 2) style += sub_title_right;
                cObj.children.push({name: 'span', content: item, style: style});
            });
            var pNode = createEle(cObj);
            cacheBox.appendChild(pNode);
        });
    }

    /* 附件创建 */
    var archiveBox = document.createElement('div');
    if(data.archiveList && data.archiveList.length > 0) {
        /* 附件标题 */
        var archiveTitle = createEle({name: 'p', content: '附件：', style: sub_box_cls + sub_content_cls0 + 'padding-left: 30px;'});
        archiveBox.appendChild(archiveTitle);
        /* 附件列表 */
        var archiveItemBox = createEle({name: 'p', content: '', style: sub_box_cls + 'padding-left: 22px;'});
        archiveBox.appendChild(archiveItemBox);
        /* 遍历渲染附件单个展示内容 */
        data.archiveList.forEach(function (it) {
            var archiveItem = createEle({name: 'span', content: '', style: archive_item_cls});
            archiveItemBox.appendChild(archiveItem);
            /* 附件图标及附件名字展示 */
            var archiveIcon = createEle({name: 'span', content: it.icon, style: archive_item_icon_cls + 'color: ' + it.color});
            var archiveText = createEle({name: 'span', content: it.name, style: archive_item_text_cls});
            /* 遮罩及点击层 */
            var archiveLayer = createEle({name: 'a', content: '', style: 'archive-id: ' + it.id + ';archive-key: archiveKey; display: block; position: absolute; top: 0; left: 0; width: 100%; height: 100%; opacity: 0; z-index: 99;'});
            /* 为layer添加唯一属性以便点击事件监听 */
            archiveItem.appendChild(archiveIcon);
            archiveItem.appendChild(archiveText);
            archiveItem.appendChild(archiveLayer);
        });
    }

    /* 设置内容偏移量 */
    var t = createEle({name: 'div', content: '', style: 'display: block;'});
    t.innerHTML = data.content;
    t.querySelectorAll('p').forEach(function (it) {
        it.setAttribute('style', it.getAttribute('style') + '; padding: 0 30px');
    })
    /* 设置签名偏移量 */
    var t0 = createEle({name: 'div', content: '', style: 'display: block;'});
    if(data.sign) {
        t0.innerHTML = data.sign;
        t0.querySelectorAll('p').forEach(function (it) {
            it.setAttribute('style', it.getAttribute('style') + '; padding: 0 30px');
        })
    }

    editor.setContent(cacheBox.innerHTML + t.innerHTML + archiveBox.innerHTML + t0.innerHTML);
}

/* 创建元素方法 */
function createEle(d) {
    var node = document.createElement(d.name);
    node.innerHTML = d.content;
    node.setAttribute('style', d.style);
    /* 递归创建子元素 */
    if(d.children && d.children.length > 0) {
        d.children.forEach(function (it) {
            var children = createEle(it);
            node.appendChild(children);
        })
    }
    return node;
}