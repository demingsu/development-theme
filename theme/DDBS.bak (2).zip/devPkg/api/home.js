/*********************************************************************
 * homoe page api
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/url.config";

/**
 * 根据url传的 type,获取不同类型的类型:1 业务量统计 2 客户量统计 3 业务级别统计
 * @param {object} params
 */
let getHomeBusinessData = (params) => {
    return Ajax({
        url: UrlConfig.HOME_BUSINESS_URL,
        params
    });
};

export default {
    getHomeBusinessData
};