/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="navigator-container">
        <div class="container">
            <!--<div class="center">无锡集客专线一体化支撑平台</div>-->
            <div class="operation" style="text-align: center;">
                <div class="brand" @click="navigatorEvt(navigatorList[0])"></div>
                <div class="item"
                     v-for="item in navigatorList"
                     @click="navigatorEvt(item)"
                     :class="[{'active': item.active}]"
                     :key="item.id"
                     style="display: inline-block; vertical-align: baseline; padding: 8px 20px; font-size: 16px;">{{item.name}}</div>
                <div class="item" @click="autoPlayEvent" style="display: inline-block; vertical-align: baseline; padding: 8px 20px; font-size: 16px;">{{autoPlay ? '手动刷新' : '自动刷新'}}</div>
            </div>
        </div>
    </div>
</template>
<script>

    export default{
        data() {
            return {
                navigatorList: [
                    {id: 'navigator_list_001', name: '首页', active: false, key: 'home'}
                ],
                autoPlay: true
            }
        },
        watch: {
            '$route.path': function(val) {
                this.resetBrand(val.replace('/', ''));
            }
        },
        methods: {
            /* 返回首页 */
            backHome() {
                this.$router.push({path: '/home'});
            },
            /* 根据路由设置标签 */
            resetBrand(val) {
                let list = JSON.parse(JSON.stringify(this.navigatorList));
                let temp = [];
                for (let item of list) {
                    item.active = val === item.key;
                    temp.push(item);
                }
                this.navigatorList = temp;
            },
            /* 标题点击事件 */
            navigatorEvt(item) {
                /* 设为自动刷新数据 */
                this.autoPlay = true;
                this.$router.push({path: `/${item.key}`});
            },
            /* 自动播放事件 */
            autoPlayEvent() {
                this.autoPlay = !this.autoPlay;
                this.$root.eventBus.$emit('autoPlayEvent', {type: 'autoPlayEvent', data: this.autoPlay});
            }
        },
        created() {
            this.resetBrand(this.$route.path.replace('/', ''));
        }
    }
</script>
