/*********************************************************************
 * Static variable file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 页面轮播超时数值 */
const PAGE_TIMEOUT_VALUE = 30000;

/* Ajax请求超时设置 */
const TIMEOUT_TIME = 5000;

/* 系统默认路由 */
const DEFAULT_ROUTES = [
    {path: '/not/found'}
];

export default {
    PAGE_TIMEOUT_VALUE,
    TIMEOUT_TIME,
    DEFAULT_ROUTES
};