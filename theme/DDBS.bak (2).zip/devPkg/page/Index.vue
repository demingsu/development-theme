/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="application-container">
        <!-- 顶部导航菜单 ---start--- -->
        <navigator-content/>
        <!-- 顶部导航菜单 ---end--- -->

        <!-- 主体路由样式 ---start--- -->
        <div class="view-container">
            <router-view></router-view>
        </div>
        <!-- 主体路由样式 ---end--- -->
    </div>
</template>

<script>
    import Navigator from "../components/common/Navigator.vue";

    export default {
        components: {
            "navigator-content": Navigator
        },
        methods: {
            /* 窗口变化事件 */
            resizeEvt() {
                this.$root.eventBus.$emit('windowResizeEvent', {type: 'windowResizeEvent'});
                setTimeout(() => {
                    this.resetGlobalMedia();
                });
            },
            /* 设置全局的媒体宽/高 */
            resetGlobalMedia() {
                window.CurrentScreenWidth = document.body.getBoundingClientRect().width;
                window.CurrentScreenHeight = document.body.getBoundingClientRect().height;
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.resetGlobalMedia();
                window.addEventListener('resize', this.resizeEvt, true);
            });
        },
        beforeDestroy() {
            window.removeEventListener('resize', this.resizeEvt, true);
        }
    };
</script>