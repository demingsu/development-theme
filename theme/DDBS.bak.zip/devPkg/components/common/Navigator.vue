/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="navigator-container">
        <div class="container">
            <div class="left">
                <div class="time">{{timeStr}}</div>
                <div class="week">{{weekStr}}</div>
                <div class="date">{{dateStr}}</div>
            </div>
            <span class="center">数据展示平台</span>
            <div class="right">
                <div class="item">报表</div>
                <div class="item active">首页</div>
            </div>
        </div>
    </div>
</template>
<script>
    import Tool from "../../util/tool";

    export default{
        data() {
            return {
                timeStr: '',
                weekStr: '',
                dateStr: '',
                weekLabel: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六']
            }
        },
        methods: {
            /* 返回首页 */
            backHome() {
                this.$router.push({path: '/home'});
            },
            /* 计算当前时间 */
            calculateTime() {
                this.timeStr = Tool.dateFormat('hh：mm：ss');
                this.weekStr = this.weekLabel[new Date().getDay()];
                this.dateStr = Tool.dateFormat('YYYY-MM-DD');
                setTimeout(() => {
                    this.calculateTime();
                }, 500);
            }
        },
        created() {
            this.calculateTime();
        }
    }
</script>
