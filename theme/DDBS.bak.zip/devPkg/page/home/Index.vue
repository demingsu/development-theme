/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="container">
        <div class="home-left-container">
            <div class="item"></div>
            <div class="item"></div>
            <div class="item bot"></div>
        </div>
        <div class="home-center-container">
            <div class="item">
                <div class="home-map-container">

                </div>
            </div>
            <div class="item bot" ref="lineChart"></div>
        </div>
        <div class="home-right-container">
            <div class="item"></div>
            <div class="item"></div>
            <div class="item bot"></div>
        </div>
    </div>
</template>

<script>
    import Tool from "../../util/tool";
    import echarts from "echarts";
    
    export default {
        /**
         * 所有参数变量说明
         * paging             boolean   是否需要分页
         */
        data() {
            return {
                lineChart: null
            }
        },
        methods: {
            /* 渲染中间线图 */
            renderLineChart() {
                let year = new Date().getFullYear();
                let time = Date.now();
                let timeData = [];
                let dataA = [];
                let dataB = [];
                for(let i = 0;i < 365;i ++) {
                    let dis = time - (i * 24 * 3600000);
                    timeData.push(Tool.dateFormat('MM-DD hh:mm', dis));
                    dataA.push((Math.random() * 500).toFixed(3));
                    dataB.push((Math.random() * 10).toFixed(3));
                }
                let option = {
                    title: {
                        text: '雨量流量关系图',
                        subtext: '数据来自西安兰特水电测控技术有限公司',
                        x: 'center'
                    },
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            animation: false
                        }
                    },
                    axisPointer: {
                        link: {xAxisIndex: 'all'}
                    },
                    dataZoom: [
                        {
                            show: true,
                            realtime: true,
                            start: 30,
                            end: 70,
                            xAxisIndex: [0, 1]
                        },
                        {
                            type: 'inside',
                            realtime: true,
                            start: 30,
                            end: 70,
                            xAxisIndex: [0, 1]
                        }
                    ],
                    grid: [
                        {
                            left: 50,
                            right: 50,
                            height: '35%'
                        }, {
                            left: 50,
                            right: 50,
                            top: '55%',
                            height: '35%'
                        }
                    ],
                    xAxis : [
                        {
                            type : 'category',
                            boundaryGap : false,
                            axisLine: {onZero: true},
                            data: timeData
                        },
                        {
                            gridIndex: 1,
                            type : 'category',
                            boundaryGap : false,
                            axisLine: {onZero: true},
                            data: timeData,
                            position: 'top'
                        }
                    ],
                    yAxis : [
                        {
                            name : '流量(m^3/s)',
                            type : 'value',
                            max : 500
                        },
                        {
                            gridIndex: 1,
                            name : '降雨量(mm)',
                            type : 'value',
                            inverse: true
                        }
                    ],
                    series: [
                        {
                            name:'流量',
                            type:'line',
                            symbolSize: 8,
                            hoverAnimation: false,
                            data: dataA
                        },
                        {
                            name:'降雨量',
                            type:'line',
                            xAxisIndex: 1,
                            yAxisIndex: 1,
                            symbolSize: 8,
                            hoverAnimation: false,
                            data: dataB
                        }
                    ]
                }
                this.lineChart.setOption(option);
            }
        },
        mounted() {
            this.$nextTick(() => {

                /* 初始化并渲染line chart */
                if(!this.lineChart) this.lineChart = echarts.init(this.$refs.lineChart);
                this.renderLineChart();
            });
        }
    }
</script>