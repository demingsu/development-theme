/*********************************************************************
 * homoe page api
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/url.config";
import ModuleConf from "../config/module.config";

/**
 * 根据用户ID获取个性化数据
 * @param {object} params userID 用户id
 */
let getPersonalizedData = (params) => {
    return Ajax({
        url: UrlConfig.GET_USER_CUSTOMIZED,
        params
    });
};

/**
 * 根据用户ID获取个性化数据
 * @param {object} params
 */
let getDefaultPersonalizedData = () => {
    let mainData = JSON.parse(JSON.stringify(ModuleConf.DEFAULT_TEMPLATE_DATA));
    let gk = JSON.parse(JSON.stringify(ModuleConf.DEFAULT_GROUP_KEYS));
    let groups = JSON.parse(JSON.stringify(ModuleConf.COMPONENTS_GROUPS));
    let blocks = JSON.parse(JSON.stringify(ModuleConf.TEMPLATE_ENGINES));
    groups.map(it => {

        /* 确定已经定义放置区域，且属于默认模块时可以放到默认数据中 */
        let obj = gk.find(pp => pp.key === it.key);
        if (!!obj) {
            it.pos = obj.pos;
            blocks.map(oo => {
                if (it.key === oo.def) {
                    it.compName.push(oo);
                }
            });
        }
    });
    mainData.blocks = groups;
    return mainData;
};

/**
 * 获取地图JSON数据
 * @param {String} name 地名拼音
 */
let getBroadbandMapData = async (keyName) => {
    let res = await systemGetMapDataFunc(keyName).catch(e => {
        return e;
    });
    if (!!res) return {
        status: 200,
        data: JSON.parse(res)
    };
};

let systemGetMapDataFunc = (name) => {
    return new Promise(resolve => {
        if (!!window.getSDMapData) {
            window.getSDMapData(name, data => {
                resolve(data);
            });
        } else {
            resolve({});
        }
    });
};

export default {
    getPersonalizedData,
    getDefaultPersonalizedData,
    getBroadbandMapData
};