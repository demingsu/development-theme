/*********************************************************************
 * homoe page api
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/url.config";

/**
 * 认证并发负载监控 transType 属性为单播/组播
 * @param {object} params
 */
let getLoadBalancing = params => {
    return [
        {
            "value": [
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0
            ],
            "name": "单播认证并发请求数"
        },
        {
            "value": [
                "09:15",
                "09:30",
                "09:45",
                "10:00",
                "10:15",
                "10:30",
                "10:45",
                "11:00",
                "11:15",
                "11:30",
                "11:45",
                "12:00",
                "12:15",
                "12:30",
                "12:45",
                "13:00",
                "13:15",
                "13:30",
                "13:45",
                "14:00",
                "14:15",
                "14:30",
                "14:45",
                "15:00",
                "15:15",
                "15:30",
                "15:45",
                "16:00",
                "16:15",
                "16:30",
                "16:45",
                "17:00",
                "17:15",
                "17:30",
                "17:45",
                "18:00",
                "18:15",
                "18:30",
                "18:45",
                "19:00",
                "19:15",
                "19:30",
                "19:45",
                "20:00",
                "20:15",
                "20:30",
                "20:45",
                "21:00",
                "21:15",
                "21:30",
                "21:45",
                "22:00",
                "22:15",
                "22:30",
                "22:45",
                "23:00",
                "23:15",
                "23:30",
                "00:00",
                "00:15",
                "00:30",
                "00:45",
                "01:00",
                "01:15",
                "01:30",
                "01:45",
                "02:00",
                "02:15",
                "02:30",
                "02:45",
                "03:00",
                "03:15",
                "03:30",
                "03:45",
                "04:00",
                "04:15",
                "04:30",
                "04:45",
                "05:00",
                "05:15",
                "05:30",
                "05:45",
                "06:00",
                "06:15",
                "06:30",
                "06:45",
                "07:00",
                "07:15",
                "07:30",
                "07:45",
                "08:00",
                "08:15",
                "08:30",
                "08:45",
                "09:00"
            ],
            "name": "TIME"
        }
    ]
};

/**
 * 全省宽带认证成功次数
 */
let getProvinceAuthTimes = () => {
    return Ajax({
        url: UrlConfig.PROVINCE_AUTHENTICATION_TIMES
    });
};

/**
 * 自助测速合格率
 */
let getSelfHelpSpeedData = () => {
    return Ajax({
        url: UrlConfig.SELF_HELP_SPEED
    });
};

/**
 * 光衰整治通过率排名TOP10
 * @param {object} params
 */
let getOpticalPassRate = params => {
    return Ajax({
        url: UrlConfig.OPTICAL_PASS_RATE,
        params
    });
};

/**
 * 宽带质量监控统计数据
 */
let getBroadbandStatistics = () => {
    return Ajax({
        url: UrlConfig.BROADBAND_STATISTICS
    });
};

/**
 * 全省实时用户信息俯瞰视图
 */
let getBroadbandMapData = () => {
    return Ajax({
        url: UrlConfig.BROADBAND_MAP_STATISTICS
    });
};

/**
 * 新装7天达标数据分析
 */
let getBroadbandNewWeekData = () => {
    return Ajax({
        url: UrlConfig.BROADBAND_NEW_WEEK_INFO
    });
};

/**
 * 申告7天达标数据分析
 */
let getBroadbandApplyWeekData = () => {
    return Ajax({
        url: UrlConfig.BROADBAND_APPLY_WEEK_INFO
    });
};

/**
 * 申告数据分析
 */
let getBroadbandRankData = () => {
    return Ajax({
        url: UrlConfig.BROADBAND_RANK_INFO
    });
};

/**
 * 光衰达标率地市排名
 */
let getHealthOpticalRankingData = () => {
    return Ajax({
        url: UrlConfig.HEALTH_OPTICAL_RANKING
    });
};

/**
 * 全省宽带自助测速数据分析
 */
let getHealthSpeedData = () => {
    return Ajax({
        url: UrlConfig.HEALTH_SPEED_DATA
    });
};

/**
 * 光衰整治通过率最差排名TOP10
 * @param {Object} params 区域id
 */
let getHealthOpticalLowerData = params => {
    return Ajax({
        url: UrlConfig.HEALTH_OPTICAL_LOWER,
        params
    });
};

/**
 * 青海电信网络健康度监控
 */
let getHealthTotalData = () => {
    return Ajax({
        url: UrlConfig.HEALTH_TOTAL_DATA
    });
};

/**
 * 宽带健康度俯瞰图
 */
let getHealthMapData = () => {
    return Ajax({
        url: UrlConfig.HEALTH_MAP_INFO
    });
};

/**
 * 宽带健康度俯瞰图
 */
let getHealthCityFlowData = () => {
    return Ajax({
        url: UrlConfig.HEALTH_CITY_FLOW
    });
};

/**
 * 全省用户申请率
 */
let getHealthApplyRateData = () => {
    return Ajax({
        url: UrlConfig.HEALTH_APPLY_RATE
    });
};

/**
 * 网格健康度最优/最差
 * @param {object} params
 */
let getHealthGridScoreData = params => {
    return Ajax({
        url: UrlConfig.HEALTH_GRID_SCORE,
        params
    });
};

/**
 * 直播频道收视TOP10
 * @param {object} params
 */
let getIptvLiveTopData = params => {
    return Ajax({
        url: UrlConfig.IPTV_LIVE_TOP,
        params
    });
};

/**
 * 点播节目收视TOP5
 * @param {object} params
 */
let getIptvDemandTopData = params => {
    return Ajax({
        url: UrlConfig.IPTV_DEMAND_TOP,
        params
    });
};

/**
 * ITV质差用户整治top
 */
let getIptvLowerUserTopData = () => {
    return Ajax({
        url: UrlConfig.IPTV_LOWER_USER_TOP
    });
};

/**
 * 青海电信ITV质量监控
 */
let getIptvTotalData = () => {
    return Ajax({
        url: UrlConfig.IPTV_TOTAL_DATA
    });
};

/**
 * 全省实时用户信息俯瞰视图
 */
let getIptvMapInfoData = () => {
    return Ajax({
        url: UrlConfig.IPTV_MAP_INFO
    });
};

/**
 * 机顶盒业务质量性能情况
 * @param {object} params
 */
let getIptvVideoPlayData = params => {
    return Ajax({
        url: UrlConfig.IPTV_VIDEO_PLAY_HEALTH,
        params
    });
};

/**
 * 节目源质量情况趋势
 */
let getIptvQualityInfoData = () => {
    return Ajax({
        url: UrlConfig.IPTV_QUALITY_INFO
    });
};

/**
 * 业务发展情况排名
 */
let getIptvCityUserRankData = () => {
    return Ajax({
        url: UrlConfig.IPTV_CITY_USER_RANK
    });
};


export default {
    getLoadBalancing,
    getProvinceAuthTimes,
    getSelfHelpSpeedData,
    getOpticalPassRate,
    getBroadbandStatistics,
    getBroadbandMapData,
    getBroadbandNewWeekData,
    getBroadbandApplyWeekData,
    getBroadbandRankData,

    getHealthOpticalRankingData,
    getHealthSpeedData,
    getHealthOpticalLowerData,
    getHealthTotalData,
    getHealthMapData,
    getHealthCityFlowData,
    getHealthApplyRateData,
    getHealthGridScoreData,

    getIptvLiveTopData,
    getIptvDemandTopData,
    getIptvLowerUserTopData,
    getIptvTotalData,
    getIptvMapInfoData,
    getIptvVideoPlayData,
    getIptvQualityInfoData,
    getIptvCityUserRankData
};