/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="default-block-container" :class="cls">
        <div class="title">
            <span v-html="blockTitle"></span>
            <i class="horn"></i>

            <!-- 轮播标题 -->
            <div class="items">
                <div class="item"
                     v-for="item in currentComponent"
                     :key="`${item.id}_00${Date.now()}`"
                     :class="[{'active': item.id === currentActiveComponent.id}]"
                     @click="loopEvent(item)">{{item.title}}</div>
            </div>
        </div>
        <div class="loop-box">

            <!-- 主题信息区 -->
            <transition :name="transType">
                <div class="box" v-if="!!currentActiveComponent">

                    <!-- activeComponentId 用户强制刷新只有一个组件的组件组控件 -->
                    <components :is="currentActiveComponent.name"
                                :activeComponentId="activeComponentId"
                                :active="true"
                                :self="currentActiveComponent"></components>
                </div>
            </transition>
        </div>
    </div>
</template>

<script>

    import ConstConf from "../../config/const.config";

    export default {
        watch: {
            compProps: function(val) {
                this.resetData(val);
            }
        },
        props: {
            theme: String,
            animationType: String,
            compProps: null,
            cls: String
        },
        data() {
            return {
                transType: 'blocked',
                looper: null,
                blockTitle: "",
                currentActiveComponent: {},
                currentComponent: [],
                activeComponentId: ''
            }
        },
        methods: {
            /* 重置数据 */
            resetData(val) {
                this.currentComponent = !!val && val.compName ? val.compName : [];
                this.loopComp();
            },
            /* 遍历展示 */
            loopComp() {
                if (this.looper) {
                    clearTimeout(this.looper);
                    this.looper = null;
                }

                /* 看当前组件属性是否为空，如果为空则取当前组件的第一个数据，否则根据当前组件查找下标，然后查找后一个需要展示的数据 */
                let obj = null;
                if (!this.currentActiveComponent.id) {
                    obj = JSON.parse(JSON.stringify(this.currentComponent[0]));
                } else {
                    let nowCompIdx = this.currentComponent.findIndex(it => it.id === this.currentActiveComponent.id);
                    nowCompIdx = nowCompIdx >= (this.currentComponent.length - 1) ? 0 : ++nowCompIdx;
                    obj = JSON.parse(JSON.stringify(this.currentComponent[nowCompIdx]));
                }

                /* 设置当前主题，子组件可以选择使用，不传递则为undefined */
                obj.theme = this.theme;
                this.currentActiveComponent = obj;
                this.activeComponentId = Date.now();

                /* 设置当前区块的标题信息，如果当前组件需要展示自己默认的区块标题则设置为自己的标题，否则设置为默认标题 */
                this.blockTitle = (!!this.currentActiveComponent.mainTitle && this.currentActiveComponent.mainTitle !== '') ? this.currentActiveComponent.mainTitle : (!!this.compProps ? this.compProps.title : "");

                /* 设置遍历超时任务 */
                this.looper = setTimeout(() => {
                    clearTimeout(this.looper);
                    this.looper = null;

                    /* 定时刷新页面，根据页面启动时间戳和当前时间对比是否与系统设置刷新时间一致 */
                    let st = parseInt(sessionStorage.getItem('system_start_item'));
                    if (Date.now() - st > ConstConf.PAGE_LOOP_REFRESH_MAX) {
                        location.reload();
                    } else {

                        /* 广播页面开始刷新机制，并稍停后才进行刷新 */
                        this.$root.eventBus.$emit(ConstConf.COMPONENT_REFRESH_EVENT, {type: ConstConf.COMPONENT_REFRESH_EVENT});
                        let currentTimer = setTimeout(() => {
                            clearTimeout(currentTimer);
                            currentTimer = null;
                            this.loopComp();
                        }, 300);
                    }
                }, ConstConf.PAGE_TIMEOUT_VALUE);
            },
            /* 设置当前显示模板 */
            loopEvent(item) {

                /* 清除计时器，并设置当前组件为选中组件 */
                if (this.looper) {
                    clearTimeout(this.looper);
                    this.looper = null;
                }

                /* 设置当前主题，子组件可以选择使用，不传递则为undefined */
                item.theme = this.theme;
                this.currentActiveComponent = item;
                this.activeComponentId = Date.now();

                /* 设置标题 */
                this.blockTitle = (!!item && item.mainTitle !== '') ? item.mainTitle : (!!this.compProps ? this.compProps.title : "");
            }
        },
        mounted() {

            /* 设置页面启动时间 */
            sessionStorage.setItem('system_start_item', `${Date.now()}`);

            /* 监听页面导航点击，刷新事件 */
            this.$root.eventBus.$on(ConstConf.NAVIGATOR_EVENT, data => {
                if (data.key === 'refresh') {
                    this.autoShow = data.active;
                    if (!data.active) {
                        clearTimeout(this.looper);
                        this.looper = null;
                    } else {
                        this.loopComp();
                    }
                }
            });

            /* 设置组件动画方向 */
            if (!!this.animationType) {
                this.transType = this.animationType === 'top' ? 'blockedt'
                    : this.animationType === 'right' ? 'blockedr'
                        : this.animationType === 'bottom' ? 'blockedb' : 'blocked';
            }

            /* 动态设置当前组件属性 */
            this.$nextTick(() => {
                this.resetData(this.compProps);
            });
        }
    }
</script>

<style lang="less" scoped>
    .blocked-enter-active {
        animation: blockin .5s 0s;
    }
    .blockedr-enter-active {
        animation: blockinr .5s 0s;
    }
    .blockedt-enter-active {
        animation: blockint .5s 0s;
    }
    .blockedb-enter-active {
        animation: blockinb .5s 0s;
    }
    @keyframes blockin {
        from {
            transform: translateX(-100%) scale(.6);
            opacity: .6;
        }
        to {
            transform: translateX(0) scale(1);
            opacity: 1;
        }
    }
    @keyframes blockinr {
        from {
            transform: translateX(100%) scale(.6);
            opacity: .6;
        }
        to {
            transform: translateX(0) scale(1);
            opacity: 1;
        }
    }
    @keyframes blockint {
        from {
            transform: translateY(-100%) scale(.6);
            opacity: .6;
        }
        to {
            transform: translateY(0) scale(1);
            opacity: 1;
        }
    }
    @keyframes blockinb {
        from {
            transform: translateY(100%) scale(.6);
            opacity: .6;
        }
        to {
            transform: translateY(0) scale(1);
            opacity: 1;
        }
    }
</style>