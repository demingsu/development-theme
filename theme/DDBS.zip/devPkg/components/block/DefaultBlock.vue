/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-block :compProps="compProps" :animationType="animationType" :cls="cls"></base-block>
</template>

<script>
    import BaseBlock from './BaseBlock.vue';

    export default {
        components: {
            BaseBlock
        },
        props: {
            animationType: String,
            compProps: null,
            cls: String
        }
    }
</script>