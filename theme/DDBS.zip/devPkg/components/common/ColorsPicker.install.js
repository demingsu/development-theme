/*********************************************************************
 * Loading file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import Colors from "./ColorsPicker.vue";

const ColorsPicker = {
    install(Vue) {
        let Constructor = Vue.extend(Colors);
        let pickerInstall = null;

        pickerInstall = {
            containerId: '',
            pickerNode: null,
            autoTimer: 0,
            show(cb, data) {
                let container = document.createElement('div');
                this.containerId = `color_picker_${Date.now()}`;
                document.body.appendChild(container);
                this.pickerNode = new Constructor({
                    el: container,
                    propsData: {
                        elId: this.containerId,
                        colors: data
                    },
                    methods: {
                        cb
                    }
                });
            },
            hide() {
                this.pickerNode.$destroy();
                this.pickerNode.$el.remove();
                this.pickerNode = null;
            }
        };
        Vue.prototype.$zznode.colorPick = pickerInstall;
    }
};

export default ColorsPicker;