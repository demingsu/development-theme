/*********************************************************************
 * Created by deming-su on 2018/5/3
 *********************************************************************/
 

<template>
    <div :id="elId" class="colors-picker-container">
        <div class="layer"></div>
        <div class="container">
            <div class="content">
                <span v-for="item in colorList" @click="pickEvt('item', item)" :key="item.id" :style="{'background': item.val}"></span>
                <div class="item" v-for="(item, i) in items" :key="`theme_color_key_${i}`">
                    <span>{{item.name}}</span>
                    <i :class="{'active': item.active}" :style="{background: item.value}"></i>
                </div>
            </div>
            <div class="footer">
                <span class="btn" @click="pickEvt('confirm')">确定</span>
                <span class="btn" @click="pickEvt('cancel')">取消</span>
            </div>
        </div>
    </div>
</template>
<script>
    import Tool from "../../util/tool";

    export default {
        props: {
            elId: String,
            colors: {
                type: Object,
                default: () => {
                    return {};
                }
            }
        },
        data() {
            return {
                colorList: [],
                items: []
            }
        },
        methods: {
            /* 组件点击事件 */
            pickEvt(type, data) {
                if (type === 'item') {
                    let temp = [];
                    this.items.map(it => {
                        if (it.active) it.value = Tool.rgbToHex(data.val);
                        temp.push(it);
                    });
                    this.items = temp;
                } else {
                    this.cb(type, this.items);
                }
            },
            /* 色条制作 */
            makeColorList() {
                let obj  = [
                    {r: 246, g: 0, b: 255},
                    {r: 0, g: 42, b: 255},
                    {r: 0, g: 255, b: 222},
                    {r: 30, g: 255, b: 0},
                    {r: 255, g: 246, b: 0},
                    {r: 255, g: 156, b: 0},
                    {r: 255, g: 0, b: 0},
                    {r: 255, g: 255, b: 255},
                    {r: 0, g: 0, b: 0}
                ];
                /* 根据总长度41进行颜色遍历 */
                let len = 41;
                for (let i = 0;i < obj.length - 1;i ++) {
                    let r = obj[i].r;
                    let g = obj[i].g;
                    let b = obj[i].b;
                    let rr = (r - obj[i+1].r)/len;
                    let rg = (g - obj[i+1].g)/len;
                    let rb = (b - obj[i+1].b)/len;
                    for (let k = 0;k < len;k ++) {
                        let cr = r-(Math.ceil(rr*k));
                        let cg = g-(Math.ceil(rg*k));
                        let cb = b-(Math.ceil(rb*k));
                        this.colorList.push({
                            id: `color_picker_key_${i}_${k}`, r: cr, g: cg, b: cb, val: 'rgb('+cr+','+cg+','+cb+')'
                        });
                    }
                }
            }
        },
        created() {
            this.makeColorList();

            /* 遍历主题颜色，提供用户定制选择 */
            if (this.colors) {
                for (let name in this.colors) {
                    if (this.colors.hasOwnProperty(name)) {
                        let color = this.colors[name];
                        this.items.push({name: color.name, value: color.value, key: name});
                    }
                }
                if (this.items.length > 0) this.items[0].active = true;
            }
        }
    }
</script>
<style lang="less" scoped>
    .colors-picker-container {
        display: block;
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 999999;
        > .layer {
            display: block;
            height: 100%;
            background: rgba(255, 255, 255, .3);
        }
        > .container {
            position: absolute;
            top: 18%;
            left: 50%;
            width: 358px;
            min-height: 120px;
            background: #fff;
            margin-left: -179px;
            >.content {
                display: block;
                min-height: 66px;
                padding: 15px;
                overflow: hidden;
                >span {
                    float: left;
                    width: 1px;
                    height: 40px;
                }
                >.item {
                    float: left;
                    width: 100%;
                    height: 20px;
                    margin-top: 10px;
                    >span {
                        float: left;
                        width: 100px;
                        height: 20px;
                        line-height: 20px;
                        font-size: 12px;
                        color: #999;
                    }
                    i {
                        float: left;
                        width: 20px;
                        height: 20px;
                        cursor: pointer;
                        -webkit-user-select: none;
                        -moz-user-select: none;
                        -ms-user-select: none;
                        user-select: none;
                        &.active {
                            border: solid 1px #000;
                        }
                    }
                }
            }
            >.footer {
                display: block;
                height: 40px;
                line-height: 40px;
                text-align: center;
                >.btn {
                    display: inline-block;
                    vertical-align: middle;
                    height: 28px;
                    line-height: 28px;
                    width: 60px;
                    margin: 0 5px;
                    border: solid 1px #eee;
                    color: #999;
                    text-align: center;
                    cursor: pointer;
                    -webkit-user-select: none;
                    -moz-user-select: none;
                    -ms-user-select: none;
                    user-select: none;
                }
            }
        }
    }
</style>