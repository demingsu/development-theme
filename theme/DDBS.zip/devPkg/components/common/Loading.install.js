/*********************************************************************
 * Loading file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import Loading from "./Loading.vue";

const LoadingNode = {
    install(Vue) {
        let Constructor = Vue.extend(Loading);
        let loadingInstall = null;

        loadingInstall = {
            containerId: '',
            loadNode: null,
            autoTimer: 0,
            show(node, auto) {
                if (!node) node = document.body;
                let container = document.createElement('div');
                node.appendChild(container);
                this.loadNode = new Constructor({
                    el: container,
                    propsData: {
                        isShow: true
                    }
                });
                if (!!auto) {
                    this.autoTimer = setTimeout(() => this.destroyNode(), 2600);
                }

            },
            hide() {
                this.destroyNode();
            },
            destroyNode() {
                if (!!this.autoTimer) {
                    clearTimeout(this.autoTimer);
                    this.autoTimer = 0;
                }
                if (!!this.loadNode) {
                    this.loadNode.$destroy();
                    this.loadNode.$el.remove();
                    this.loadNode = null;
                }
            }
        };
        Vue.prototype.$zznode.loading = loadingInstall;
    }
};

export default LoadingNode;