/*********************************************************************
 * Created by deming-su on 2018/5/3
 *********************************************************************/
 

<template>
    <div v-show="flag" :id="id" style="display: block; position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
        <div style="display: block; position: relative; height: 100%;">
            <div style="position: absolute; top: 50%; left: 50%; width: 60px; height: 60px; margin: -30px 0 0 -30px;">
                <img style="display: block; height: 60px; width: 60px; margin: 10px auto;" :src="loadImg" alt="">
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: {
            id: String,
            isShow: false
        },
        data() {
            return {
                flag: false,
                loadImg: require("../../images/common/loading.gif")
            }
        },
        watch: {
            isShow: function(val) {
                this.flag = val;
            }
        },
        methods: {
            getId() {
                return this.id;
            }
        },
        created() {
            if (this.isShow !== undefined) {
                this.flag = this.isShow;
            }
        }
    }
</script>