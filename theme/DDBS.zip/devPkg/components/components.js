/*********************************************************************
 * Vue directive file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

const LoadNode = () => { return import(/* webpackChunkName: "LoadNode"*/"./common/Loading.vue"); };

/* 模板组件 */
let WaitPage = () => { return import(/* webpackChunkName: "WaitPage"*/"../page/default/WaitPage.vue"); };
let DefaultTemplate = () => { return import(/* webpackChunkName: "DefaultTemplate"*/"./template/DefaultTemplate.vue"); };
let BlackTemplate = () => { return import(/* webpackChunkName: "BlackTemplate"*/"./template/BlackTemplate.vue"); };
let HolidayTemplate = () => { return import(/* webpackChunkName: "HolidayTemplate"*/"./template/HolidayTemplate.vue"); };
let BrightTemplate = () => { return import(/* webpackChunkName: "BrightTemplate"*/"./template/BrightTemplate.vue"); };
let SkyTemplate = () => { return import(/* webpackChunkName: "SkyTemplate"*/"./template/SkyTemplate.vue"); };

/* 布局组件 */
let DefaultLayout = () => { return import(/* webpackChunkName: "DefaultLayout"*/"./layout/DefaultLayout.vue"); };
let BlackLayout = () => { return import(/* webpackChunkName: "BlackLayout"*/"./layout/BlackLayout.vue"); };
let HolidayLayout = () => { return import(/* webpackChunkName: "HolidayLayout"*/"./layout/HolidayLayout.vue"); };
let BrightLayout = () => { return import(/* webpackChunkName: "HolidayLayout"*/"./layout/BrightLayout.vue"); };
let SkyLayout = () => { return import(/* webpackChunkName: "SkyLayout"*/"./layout/SkyLayout.vue"); };

/* 区域块组件 */
let DefaultBlock = () => { return import(/* webpackChunkName: "DefaultBlock"*/"./block/DefaultBlock.vue"); };
let BrightBlock = () => { return import(/* webpackChunkName: "BrightBlock"*/"./block/BrightBlock.vue"); };

/* 功能块组件 */
let SideMonitorA = () => { return import(/* webpackChunkName: "SideMonitorA"*/"../page/functionality/default/SideMonitorA.vue"); };
let SideMonitorB = () => { return import(/* webpackChunkName: "SideMonitorB"*/"../page/functionality/default/SideMonitorB.vue"); };
let SideMonitorC = () => { return import(/* webpackChunkName: "SideMonitorC"*/"../page/functionality/default/SideMonitorC.vue"); };
let SideMonitorD = () => { return import(/* webpackChunkName: "SideMonitorD"*/"../page/functionality/default/SideMonitorD.vue"); };
let SideMonitorE = () => { return import(/* webpackChunkName: "SideMonitorE"*/"../page/functionality/default/SideMonitorE.vue"); };
let SideMonitorF = () => { return import(/* webpackChunkName: "SideMonitorF"*/"../page/functionality/default/SideMonitorF.vue"); };
let SideMonitorG = () => { return import(/* webpackChunkName: "SideMonitorG"*/"../page/functionality/default/SideMonitorG.vue"); };
let SideMonitorH = () => { return import(/* webpackChunkName: "SideMonitorH"*/"../page/functionality/default/SideMonitorH.vue"); };

export {
    LoadNode,
    WaitPage,

    DefaultTemplate,
    BlackTemplate,
    HolidayTemplate,
    BrightTemplate,
    SkyTemplate,

    DefaultLayout,
    BlackLayout,
    HolidayLayout,
    BrightLayout,
    SkyLayout,

    DefaultBlock,
    BrightBlock,
    SideMonitorA,
    SideMonitorB,
    SideMonitorC,
    SideMonitorD,
    SideMonitorE,
    SideMonitorF,
    SideMonitorG,
    SideMonitorH
};