/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div></div>
</template>

<script>
    import { mapGetters } from "vuex";

    export default {
        computed: {
            ...mapGetters({
                personalizedCache: "getPersonalizedData",
                navColors: "getSystemCustomizedColors"
            })
        }
    }
</script>