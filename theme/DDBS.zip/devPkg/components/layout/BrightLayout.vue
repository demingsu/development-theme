/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="bright-red-layout" :style="{'border-color': mainBorder}">
        <div class="container">
            <div class="top">
                <div class="bright-block-container"
                     v-for="item in pageTopList"
                     :style="{'width': `${item.width}%`, 'height': `${item.height}%`}"
                     :key="item.id">
                    <div class="bright-block-content" :style="{'background-color': mainBackground}">
                        <div class="corner top">
                            <span class="b" :style="{'border-color': mainBorder}"></span>
                            <span class="a" :style="{'border-color': mainBorder}"></span>
                        </div>
                        <div class="corner bottom">
                            <span class="b" :style="{'border-color': mainBorder}"></span>
                            <span class="a" :style="{'border-color': mainBorder}"></span>
                        </div>
                        <bright-block :compProps="item.data" :animationType="`top`"></bright-block>
                    </div>
                </div>
            </div>
            <div class="bottom">
                <div class="bright-block-container"
                     v-for="item in pageBotList"
                     :style="{'width': `${item.width}%`, 'height': `${item.height}%`}"
                     :key="item.id">
                    <div class="bright-block-content" :style="{'background-color': mainBackground}">
                        <div class="corner top">
                            <span class="b" :style="{'border-color': mainBorder}"></span>
                            <span class="a" :style="{'border-color': mainBorder}"></span>
                        </div>
                        <div class="corner bottom">
                            <span class="b" :style="{'border-color': mainBorder}"></span>
                            <span class="a" :style="{'border-color': mainBorder}"></span>
                        </div>
                        <bright-block :compProps="item.data" :animationType="`bottom`"></bright-block>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<!--width: 42.65%;
height: 61.43%;-->

<script>
    import BaseLayout from "./BaseLayout.vue";

    import ConstConf from "../../config/const.config";
    import BrightBlock from "@/components/block/BrightBlock";
    import Tool from "../../util/tool";

    export default {
        components: {BrightBlock},
        extends: BaseLayout,
        computed: {
            mainBorder() {
                return this.navColors && this.navColors.navTitle ? Tool.hexToRgba(this.navColors.navTitle.value, '.6') : '';
            },
            mainBackground() {
                return this.navColors && this.navColors.navTitle ? Tool.hexToRgba(this.navColors.navTitle.value, '.23') : '';
            }
        },
        data() {
            return {
                pageTopList: [
                    {id: 'bright_block_key_001', width: '42.650', height: '100', key: 'leftSideE', data: {}},
                    {id: 'bright_block_key_002', width: '28.675', height: '50', key: 'leftSideA', data: {}},
                    {id: 'bright_block_key_003', width: '28.675', height: '50', key: 'leftSideB', data: {}},
                    {id: 'bright_block_key_004', width: '28.675', height: '50', key: 'leftSideF', data: {}},
                    {id: 'bright_block_key_005', width: '28.675', height: '50', key: 'leftSideG', data: {}}
                ],
                pageBotList: [
                    {id: 'bright_block_key_006', width: '33.333', height: '100', key: 'leftSideC', data: {}},
                    {id: 'bright_block_key_007', width: '33.333', height: '100', key: 'leftSideD', data: {}},
                    {id: 'bright_block_key_008', width: '33.333', height: '100', key: 'leftSideH', data: {}}
                ]
            }
        },
        methods: {
            /**
             * 组装页面数据，根据左中右规则，定义组装数据
             */
            assemblePageList() {
                let top = JSON.parse(JSON.stringify(this.pageTopList));
                top.map(it => it.data = {});

                let bot = JSON.parse(JSON.stringify(this.pageBotList));
                bot.map(it => it.data = {});

                let topTemp = [];
                top.map(it => {
                    let block = this.personalizedCache.blocks.find(oo => oo.key === it.key);
                    if (block) {
                        it.height = block.row;
                        it.width = block.column;
                        it.data = block;
                        topTemp.push(it);
                    }
                });

                let botTemp = [];
                bot.map(it => {
                    let block = this.personalizedCache.blocks.find(oo => oo.key === it.key);
                    if (block) {
                        it.height = block.row;
                        it.width = block.column;
                        it.data = block;
                        botTemp.push(it);
                    }
                });

                this.pageTopList = topTemp;
                this.pageBotList = botTemp;
            }
        },
        created() {

            /* 初始化页面显示组件 */
            this.assemblePageList();

            /* 设置导航栏标题 */
            this.$root.eventBus.$emit(ConstConf.NAVIGATOR_PROPS, {
                type: 'title',
                title: this.personalizedCache ? this.personalizedCache.homeNavigator : ''
            });
        }
    }
</script>