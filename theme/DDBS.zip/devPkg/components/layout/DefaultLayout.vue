/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="default-layout-container default">
        <div class="container">
            <div v-for="item in pageCompList"
                 :class="item.cls"
                 :key="item.id">
                <div :class="item.subCls">
                    <div class="item"
                         v-for="(it, k) in item.list"
                         :key="`layout_item_key_${k}`"
                         :class="[{'bottom': it.isBottom}]"
                         :style="[{'height': `${it.height}%`}]">
                        <default-block :compProps="it.data" :animationType="it.animationType" :cls="it.cls"></default-block>
                    </div>
                </div>
                <div v-if="item.type === 'right'" class="time-box">{{currentTime}}</div>
            </div>
        </div>
    </div>
</template>

<script>
    import BaseLayout from "./BaseLayout.vue";

    import ConstConf from "../../config/const.config";
    import Tool from "../../util/tool";

    export default {
        extends: BaseLayout,
        data() {
            return {
                pageCompList: [],
                currentTime: '',
                timeLooper: null
            }
        },
        methods: {
            /**
             * 组装页面数据，根据左中右规则，定义组装数据
             */
            assemblePageList() {
                let temp = [
                    {id: 'page_comp_list_001', type: 'left', cls: 'left', subCls: 'default-layout-side-container default', list: []},
                    {id: 'page_comp_list_002', type: 'center', cls: 'center', subCls: 'default-layout-center-container default', list: []},
                    {id: 'page_comp_list_003', type: 'right', cls: 'right', subCls: 'default-layout-side-container right default', list: []}
                ];
                let left = [];
                let center = [];
                let right = [];

                this.personalizedCache.blocks.map(it => {
                    switch (it.pos) {
                        case 'left':
                            left.push({data: it, cls: 'default', pos: it.pos, column: it.column, row: it.row,
                                height: Tool.numberFixed((it.row / 12 * 100), 2)});
                            break;
                        case 'center':
                            center.push({data: it, cls: it.compName && it.compName[0].type === 'top' ? 'default no-title' : 'default no-title bottom', animationType: 'top',
                                isBottom: center.length > 0, pos: it.pos, column: it.column, row: it.row,
                                height: Tool.numberFixed((it.row / 12 * 100), 2)});
                            break;
                        case 'right':
                            right.push({data: it, animationType: 'right', cls: 'right default', pos: it.pos, column: it.column, row: it.row,
                                height: Tool.numberFixed((it.row / 12 * 100), 2)});
                            break;
                        default:
                            break;
                    }
                });

                temp[0].list = left;
                temp[1].list = center;
                temp[2].list = right;
                this.pageCompList = temp;
            },
            loopShowTime() {
                this.currentTime = Tool.dateFormat('YYYY年MM月DD日 hh:mm:ss');
                this.timeLooper = setTimeout(() => {
                    clearTimeout(this.timeLooper);
                    this.timeLooper = null;
                    this.loopShowTime();
                }, 200);
            }
        },
        mounted() {

            /* 显示时间控件 */
            this.loopShowTime();

            /* 初始化页面显示组件 */
            this.assemblePageList();

            /* 设置导航栏标题 */
            this.$root.eventBus.$emit(ConstConf.NAVIGATOR_PROPS, {
                type: 'title',
                title: this.personalizedCache ? this.personalizedCache.homeNavigator : ''
            });
        },
        beforeDestroy() {
            if (this.timeLooper) {
                clearTimeout(this.timeLooper);
                this.timeLooper = null;
            }
        }
    }
</script>