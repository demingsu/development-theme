/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="default-layout-container sky-blue">
        <div class="container">
            <div v-for="item in pageCompList" :class="item.cls" :key="item.id">
                <div :class="item.subCls">
                    <div class="item"
                         v-for="(it, k) in item.list"
                         :key="`layout_item_key_${k}`"
                         :class="[{'bottom': it.isBottom}]"
                         :style="[{'height': it.type === 'center' ? `` : `${(it.row / 12 * 100).toFixed(2)}%`}]">
                        <div v-if="it.isBottom" class="box">
                            <default-block :compProps="it.data" :animationType="it.animationType" :cls="it.cls"></default-block>
                        </div>
                        <default-block v-else :compProps="it.data" :animationType="it.animationType" :cls="it.cls"></default-block>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import BaseLayout from "./BaseLayout.vue";

    import ConstConf from "../../config/const.config";
    import DefaultBlock from "@/components/block/DefaultBlock";

    export default {
        components: {DefaultBlock},
        extends: BaseLayout,
        data() {
            return {
                pageCompList: []
            }
        },
        methods: {
            /**
             * 组装页面数据，根据左中右规则，定义组装数据
             */
            assemblePageList() {
                let temp = [
                    {id: 'page_comp_list_001', type: 'left', cls: 'left', subCls: 'default-layout-side-container sky-blue', list: []},
                    {id: 'page_comp_list_002', type: 'center', cls: 'center', subCls: 'default-layout-center-container sky-blue', list: []},
                    {id: 'page_comp_list_003', type: 'right', cls: 'right', subCls: 'default-layout-side-container right sky-blue', list: []}
                ];
                let left = [];
                let center = [];
                let right = [];
                this.personalizedCache.blocks.map(it => {
                    switch (it.pos) {
                        case 'left':
                            left.push({data: it, cls: 'sky-blue', pos: it.pos, column: it.column, row: it.row});
                            break;
                        case 'center':
                            center.push({data: it, animationType: 'top', isBottom: center.length > 0, cls: 'center sky-blue', pos: it.pos, column: it.column, row: 12});
                            break;
                        case 'right':
                            right.push({data: it, animationType: 'right', cls: 'right sky-blue', pos: it.pos, column: it.column, row: it.row});
                            break;
                        default:
                            break;
                    }
                });
                temp[0].list = left;
                temp[1].list = center;
                temp[2].list = right;

                this.pageCompList = temp;
            }
        },
        mounted() {

            /* 初始化页面显示组件 */
            this.assemblePageList();

            /* 设置导航栏标题 */
            this.$root.eventBus.$emit(ConstConf.NAVIGATOR_PROPS, {
                type: 'title',
                title: this.personalizedCache ? this.personalizedCache.homeNavigator : ''
            });
        }
    }
</script>