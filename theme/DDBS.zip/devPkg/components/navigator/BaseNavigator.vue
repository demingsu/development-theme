/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="navigator-container" :class="[{'setting': !navigatorShow}]">
        <div class="container" :style="{'background': background ? `url(${background}) center center / 100% 100% no-repeat` : ''}">
            <slot name="brand"></slot>
            <span class="title" :style="{'color': navColor}">
                <i :style="{'color': navColor}">&#xe66e;</i>{{title}}
            </span>
            <slot name="times"></slot>
            <div class="operation">
                <div class="item" v-for="item in operationList" :key="item.id">
                    <div class="btn" :class="[{'active': item.active}]" @click="operationEvt(item)">{{item.name}}</div>
                </div>
            </div>
            <span class="setting-title" v-show="!navigatorShow">模板自定义</span>
        </div>
        <slot name="modal"></slot>
    </div>
</template>

<script>
    import ConstConf from "../../config/const.config";

    export default {
        props: {
            background: String,
            themeColor: Object
        },
        computed: {
            navColor() {
                return this.themeColor ? this.themeColor.value : '';
            }
        },
        data() {
            return {
                title: "",
                navigatorShow: true,
                operationList: [
                    {id: 'operation_id_001', type: 'btn', name: '手动刷新', key: 'refresh'},
                    {id: 'operation_id_003', type: 'menu', name: '设置', key: 'setting'},
                    {id: 'operation_id_002', type: 'menu', name: '首页', key: 'home', active: true}
                ]
            }
        },
        methods: {
            operationEvt(item) {
                let list = JSON.parse(JSON.stringify(this.operationList));
                if (item.type === 'menu') {
                    list.map(it => {
                        if (it.type === 'menu') {
                            it.active = item.id === it.id;
                        }
                    });
                    this.$router.push({path: `/${item.key}`});
                }
                if (item.type === 'btn' && item.key === 'refresh') {
                    list.map(it => {
                        if (it.id === item.id) {
                            it.name = item.name === "自动刷新" ? "手动刷新" : "自动刷新";
                            item.active = item.name === "自动刷新";
                        }
                    });
                }
                this.operationList = list;
                this.$root.eventBus.$emit(ConstConf.NAVIGATOR_EVENT, item);
            },
            registerBroadcast() {
                this.$root.eventBus.$on(ConstConf.NAVIGATOR_PROPS, data => {
                    switch (data.type) {
                        case 'title':
                            this.navigatorShow = true;
                                this.title = data.title;
                            break;
                        case 'show':
                            this.navigatorShow = data.show;
                            break;
                        default:
                            break;
                    }
                });
            }
        },
        created() {
            let path = this.$route.path.replace('/', '');
            let temp = [];
            /* 是否是test1用户登陆，如果是则有设置按钮权限否没有设置按钮权限 */
            let userId = sessionStorage.getItem('current_login_user_id');
            let isTestUser = userId && userId === ConstConf.SYSTEM_ADMIN_ID;
            this.operationList.map(it => {
                if (it.type === 'menu') {
                    it.active = it.key === path;
                }
                if (it.key === 'setting') {
                    if (isTestUser) temp.push(it);
                } else {
                    temp.push(it);
                }
            });

            /* 如果主题可配置，则显示主题颜色按钮 */
            /*if (this.background) {
                temp.unshift({id: 'operation_id_004', type: 'btn', name: '主题颜色', key: 'colors'});
            }*/


            this.operationList = temp;

            this.registerBroadcast();
        }
    }
</script>