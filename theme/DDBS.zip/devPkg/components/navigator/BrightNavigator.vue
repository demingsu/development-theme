/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-navigator class="bright-red" :background="background" :themeColor="navColor"></base-navigator>
</template>

<script>
    import BaseNavigator from "./BaseNavigator.vue";
    import ConstConf from "../../config/const.config";

    import { mapGetters } from "vuex";
    import Tool from "../../util/tool";

    export default {
        computed: {
            ...mapGetters({
                colors: 'getSystemCustomizedColors'
            }),
            navColor() {
                return this.colors && this.colors.navTitle ? this.colors.navTitle : {};
            }
        },
        components: {
            BaseNavigator
        },
        data() {
            return {
                colorShow: false,
                background: ConstConf.BRIGHT_RED_NAV_IMG
            }
        },
        methods: {
            async colorEvt(type, params) {
                if (type === 'confirm') {
                    let data = {};
                    for (let item of params) {
                        if (this.colors[item.key]) {
                            data[item.key] = {name: item.name, value: item.value};
                        }
                    }

                    /* 如果真是环境应该对页面进行重载 window.location.reload() */
                    this.$store.dispatch('setSystemCustomizedColors', {data});

                    this.$zznode.colorPick.hide();
                    if (this.navColor && this.navColor.value) {
                        let result = await Tool.replaceImgColor(this.background, Tool.hexToRgba(this.navColor.value));
                        if (result.code === 200) {
                            this.background = result.data;
                        }
                    }
                } else {
                    this.$zznode.colorPick.hide();
                }
            }
        },
        created() {
            this.$root.eventBus.$on(ConstConf.NAVIGATOR_EVENT, data => {
                if (data.key === "colors") {
                    this.$zznode.colorPick.show(this.colorEvt, this.colors);
                }
            });
        }
    }
</script>