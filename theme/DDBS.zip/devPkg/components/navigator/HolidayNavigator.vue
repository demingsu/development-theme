/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-navigator class="holiday"></base-navigator>
</template>

<script>
    import BaseNavigator from "./BaseNavigator.vue";
    export default {
        components: {
            BaseNavigator
        }
    }
</script>