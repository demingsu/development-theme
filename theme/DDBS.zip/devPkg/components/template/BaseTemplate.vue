/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="container">
        <!-- 顶部导航菜单 ---start--- -->
        <slot name="navigator"></slot>
        <!-- 顶部导航菜单 ---end--- -->

        <!-- 主体路由样式 ---start--- -->
        <div class="view-container" :class="viewCls">
            <router-view></router-view>
        </div>
        <!-- 主体路由样式 ---end--- -->
    </div>
</template>

<script>
    export default {
        props: {
            viewCls: String
        }
    }
</script>