/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-layout>
        <black-navigator slot="navigator"></black-navigator>
    </base-layout>
</template>

<script>
    import BlackNavigator from "../navigator/BlackNavigator.vue";
    import BaseLayout from "./BaseTemplate.vue";

    export default {
        components: {
            BlackNavigator,
            BaseLayout
        }
    }
</script>