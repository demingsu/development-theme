/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-layout class="bright-red">
        <bright-navigator slot="navigator"></bright-navigator>
    </base-layout>
</template>

<script>
    import BrightNavigator from "../navigator/BrightNavigator.vue";
    import BaseLayout from "./BaseTemplate.vue";

    export default {
        components: {
            BrightNavigator,
            BaseLayout
        }
    }
</script>