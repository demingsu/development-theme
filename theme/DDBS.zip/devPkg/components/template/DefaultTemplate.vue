/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-layout>
        <default-navigator slot="navigator"></default-navigator>
    </base-layout>
</template>

<script>
    import DefaultNavigator from "../navigator/DefaultNavigator.vue";
    import BaseLayout from "./BaseTemplate.vue";

    export default {
        components: {
            DefaultNavigator,
            BaseLayout
        }
    }
</script>