/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-layout class="holiday">
        <holiday-navigator slot="navigator"></holiday-navigator>
    </base-layout>
</template>

<script>
    import HolidayNavigator from "../navigator/HolidayNavigator.vue";
    import BaseLayout from "./BaseTemplate.vue";

    export default {
        components: {
            HolidayNavigator,
            BaseLayout
        }
    }
</script>