/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-layout class="sky-blue" view-cls="sky-blue">
        <sky-navigator slot="navigator"></sky-navigator>
    </base-layout>
</template>

<script>
    import SkyNavigator from "../navigator/SkyNavigator.vue";
    import BaseLayout from "./BaseTemplate.vue";

    export default {
        components: {
            SkyNavigator,
            BaseLayout
        }
    }
</script>