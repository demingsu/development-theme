/*********************************************************************
 * theme colors static variable file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 嫣红模板颜色配置 */
let BRIGHT_RED_COLORS = {
    navTitle: {name: '导航栏颜色', value: '#4271eb'}
};


export default {
    BRIGHT_RED_COLORS
};