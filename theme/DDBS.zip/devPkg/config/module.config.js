/*********************************************************************
 * system module config variable file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import ColorsConf from "./colors.config";

/**
 * 宽带质量模板主数据
 * @define {String} mainThemeName 主题名称key
 * @define {String} themeDesc 主题显示名
 * @define {String} homeLayout 主题布局key
 * @define {String} homeNavigator 标题
 * @define {Array} blocks 组建块数据列表
 * @define {String} group 组件配置文件key
 */
const DEFAULT_TEMPLATE_DATA = {
    mainThemeName: 'default-template',
    themeDesc: '宽带质量模板',
    homeLayout: 'default-layout',
    homeNavigator: '青海电信宽带质量监控',
    blocks: [],
    group: 'DEFAULT_GROUP_KEYS'
};

/**
 * 宽带质量组件
 * @define {String} key 定义组件块key
 * @define {String} pos 定义组件的基本位置，只有左，中，右（left, center, right）
 * @define {String} type 组件块类型，与组件的类型相匹配
 */
const DEFAULT_GROUP_KEYS = [
    {key: 'leftSideA', pos: 'left', type: 'side'},
    {key: 'leftSideB', pos: 'left', type: 'side'},
    {key: 'leftSideC', pos: 'left', type: 'side'},
    {key: 'leftSideD', pos: 'center', type: 'top'},
    {key: 'leftSideE', pos: 'center', type: 'center'},
    {key: 'leftSideF', pos: 'right', type: 'side'},
    {key: 'leftSideG', pos: 'right', type: 'side'},
    {key: 'leftSideH', pos: 'right', type: 'side'}
];

/* 科技黑模板数据 */
const BLACK_TEMPLATE_DATA = {
    mainThemeName: 'black-template',
    themeDesc: '科技黑模板',
    homeLayout: 'black-layout',
    homeNavigator: '青海电信监控',
    blocks: [],
    group: 'BLACK_GROUP_KEYS'
};

/* 科技黑组件 */
const BLACK_GROUP_KEYS = [
    {key: 'leftSideA', pos: 'left', type: 'side'},
    {key: 'leftSideB', pos: 'left', type: 'side'},
    {key: 'leftSideC', pos: 'left', type: 'side'},
    {key: 'leftSideD', pos: 'center', type: 'top'},
    {key: 'leftSideE', pos: 'center', type: 'center'},
    {key: 'leftSideF', pos: 'right', type: 'side'},
    {key: 'leftSideG', pos: 'right', type: 'side'},
    {key: 'leftSideH', pos: 'right', type: 'side'}
];

/* 节日模板数据 */
const HOLIDAY_TEMPLATE_DATA = {
    mainThemeName: 'holiday-template',
    themeDesc: '节日模板',
    homeLayout: 'holiday-layout',
    homeNavigator: '青海电信监控',
    blocks: [],
    group: 'HOLIDAY_GROUP_KEYS'
};

/* 节日组件 */
const HOLIDAY_GROUP_KEYS = [
    {key: 'leftSideA', pos: 'left', type: 'side'},
    {key: 'leftSideB', pos: 'left', type: 'side'},
    {key: 'leftSideC', pos: 'left', type: 'side'},
    {key: 'leftSideD', pos: 'center', type: 'top'},
    {key: 'leftSideE', pos: 'center', type: 'center'},
    {key: 'leftSideF', pos: 'right', type: 'side'},
    {key: 'leftSideG', pos: 'right', type: 'side'},
    {key: 'leftSideH', pos: 'right', type: 'side'}
];

/* 嫣红模板数据 */
const BRIGHT_TEMPLATE_DATA = {
    mainThemeName: 'bright-template',
    themeDesc: '嫣红模板',
    homeLayout: 'bright-layout',
    homeNavigator: '青海电信监控',
    blocks: [],
    colors: ColorsConf.BRIGHT_RED_COLORS,
    group: 'HOLIDAY_GROUP_KEYS'
};

/* 嫣红组件 */
const BRIGHT_GROUP_KEYS = [
    {key: 'leftSideA', pos: 'left', type: 'side'},
    {key: 'leftSideB', pos: 'left', type: 'side'},
    {key: 'leftSideC', pos: 'left', type: 'side'},
    {key: 'leftSideD', pos: 'center', type: 'top'},
    {key: 'leftSideE', pos: 'center', type: 'center'},
    {key: 'leftSideF', pos: 'right', type: 'side'},
    {key: 'leftSideG', pos: 'right', type: 'side'},
    {key: 'leftSideH', pos: 'right', type: 'side'}
];

/**
 * 组件块数组
 * @description 把屏幕分为上下24*12格的栅格，因此在每个模块中可以显示的最大宽度为24，最大高度为12（暂不作为系统功能支持）
 * @define {string} title 模块标题名字，可以被模块的mainTitle字段替换
 * @define {string} key 对应模板的key
 * @define {number} column 列宽
 * @define {number} column 行宽
 * @define {string} compName 数据组件列表
 */
const COMPONENTS_GROUPS = [
    {key: 'leftSideA', column: 7, row: 4, title: '全省宽带认证成功次数', compName: []},
    {key: 'leftSideB', column: 7, row: 4, title: '全省宽带自助测速数据分析', compName: []},
    {key: 'leftSideC', column: 7, row: 4, title: '光衰整治通过率排名TOP10', compName: []},
    {key: 'leftSideD', column: 10, row: 3, title: '', compName: []},
    {key: 'leftSideE', column: 10, row: 9, title: '全省实时用户信息俯瞰视图', compName: []},
    {key: 'leftSideF', column: 7, row: 4, title: '新装7天达标数据分析', compName: []},
    {key: 'leftSideG', column: 7, row: 4, title: '申告7天达标数据分析', compName: []},
    {key: 'leftSideH', column: 7, row: 4, title: '申告数据分析', compName: []},

    {key: 'leftSideI', column: 7, row: 4, title: '光衰达标率地市排名', compName: []},
    {key: 'leftSideJ', column: 7, row: 4, title: '全省宽带自助测速数据分析', compName: []},
    {key: 'leftSideK', column: 7, row: 4, title: '光衰整治通过率最差排名TOP10', compName: []},
    {key: 'leftSideL', column: 10, row: 3, title: '', compName: []},
    {key: 'leftSideM', column: 10, row: 9, title: '宽带健康度俯瞰视图', compName: []},
    {key: 'leftSideN', column: 7, row: 4, title: '地市OLT设备流量', compName: []},
    {key: 'leftSideO', column: 7, row: 4, title: '全省用户申请率', compName: []},
    {key: 'leftSideP', column: 7, row: 4, title: '网格健康度最优/最差', compName: []},

    {key: 'leftSideQ', column: 7, row: 4, title: '直播频道收视TOP10', compName: []},
    {key: 'leftSideR', column: 7, row: 4, title: '点播节目收视TOP5', compName: []},
    {key: 'leftSideS', column: 7, row: 4, title: 'ITV质差用户整治top', compName: []},
    {key: 'leftSideT', column: 10, row: 3, title: '', compName: []},
    {key: 'leftSideU', column: 10, row: 9, title: '全省实时用户信息俯瞰视图', compName: []},
    {key: 'leftSideV', column: 7, row: 4, title: '机顶盒业务质量性能情况', compName: []},
    {key: 'leftSideW', column: 7, row: 4, title: '节目源质量情况趋势', compName: []},
    {key: 'leftSideX', column: 7, row: 4, title: '业务发展情况排名', compName: []}
];

/**
 * 所有组件引擎
 * @define {string} id 唯一键值
 * @define {string} icon 图标
 * @define {string} def 默认所属模板
 * @define {string} type 组件类型
 * @define {string} name 组件键值名称，与组件的模板引擎名字一致
 * @define {string} mainTitle 替换块标题的名字
 * @define {string} myTitle 组件单独显示名字
 * @define {string} title 轮播时组件名字
 */
const TEMPLATE_ENGINES = [
    {id: 'blocks_001', icon: '&#xe60f;', def: 'leftSideA', type: 'side', name: 'side-monitor-a', mainTitle: '', myTitle: '全省宽带认证成功次数', title: '认证成功'},
    {id: 'blocks_004', icon: '&#xe60f;', def: 'leftSideB', type: 'side', name: 'side-monitor-b', mainTitle: '', myTitle: '自助测速合格率', title: '测速合格率'},
    {id: 'blocks_007', icon: '&#xe613;', def: 'leftSideC', type: 'side', name: 'side-monitor-c', mainTitle: '', myTitle: '光衰整治通过率排名TOP10', title: '通过率'},
    {id: 'blocks_010', icon: '&#xe62d;', def: 'leftSideD', type: 'top', name: 'side-monitor-d', mainTitle: '宽带质量监控统计数据', myTitle: '宽带质量监控统计数据', title: '宽带质量监控统计数据'},
    {id: 'blocks_013', icon: '&#xe605;', def: 'leftSideE', type: 'center', name: 'side-monitor-e', mainTitle: '实时用户信息俯瞰视图', myTitle: '全省实时用户信息俯瞰视图', title: '实时用户'},
    {id: 'blocks_016', icon: '&#xe6be;', def: 'leftSideF', type: 'side', name: 'side-monitor-f', mainTitle: '', myTitle: '新装7天达标数据分析', title: '新装达标'},
    {id: 'blocks_019', icon: '&#xe6be;', def: 'leftSideG', type: 'side', name: 'side-monitor-g', mainTitle: '', myTitle: '申告7天达标数据分析', title: '申告达标'},
    {id: 'blocks_022', icon: '&#xe60c;', def: 'leftSideH', type: 'side', name: 'side-monitor-h', mainTitle: '', myTitle: '申告数据分析', title: '申告分析'}
];

export default {
    DEFAULT_TEMPLATE_DATA,
    BLACK_TEMPLATE_DATA,
    HOLIDAY_TEMPLATE_DATA,
    BRIGHT_TEMPLATE_DATA,

    DEFAULT_GROUP_KEYS,
    BLACK_GROUP_KEYS,
    HOLIDAY_GROUP_KEYS,
    BRIGHT_GROUP_KEYS,

    COMPONENTS_GROUPS,

    TEMPLATE_ENGINES
};