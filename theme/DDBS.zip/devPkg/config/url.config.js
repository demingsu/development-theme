/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 通用 ---start--- */

/* 本地、现场环境 */
// const BASE_URL = window.location.origin + "/bigscreen";

/* 本地mock数据 */
const BASE_URL = "./static/assets/mockJson";

/* 通用 ---end--- */

/* 页面数据接口 ---start--- */

/* 添加/修改用户个性化数据 */
const USER_CUSTOMIZED_ADD = '/saveOrUpdateCustomTemplate.json';

/* 获取用户个性化数据 */
const GET_USER_CUSTOMIZED = '/queryCustomTemplate.json';

/* 全省宽带认证成功次数 */
const PROVINCE_AUTHENTICATION_TIMES = '/refreshAuthent.json';

/* 自助测速合格率 */
const SELF_HELP_SPEED = '/refreshOnSpeedData.json';

/* 光衰整治通过率排名TOP10 */
const OPTICAL_PASS_RATE = '/getOpticalData.json';

/* 宽带质量监控统计数据 */
const BROADBAND_STATISTICS = '/refreshBroadcastTotolData.json';

/* 全省实时用户信息俯瞰视图 */
const BROADBAND_MAP_STATISTICS = '/refreshQhBroadCastMapInfo.json';

/* 新装7天达标数据分析 */
const BROADBAND_NEW_WEEK_INFO = '/refreshNewInfo.json';

/* 申告7天达标数据分析 */
const BROADBAND_APPLY_WEEK_INFO = '/refreshColumApplyInfo.json';

/* 申告数据分析 */
const BROADBAND_RANK_INFO = '/refreshRank.json';

/* 页面数据接口 ---end--- */

export default {
    BASE_URL,
    USER_CUSTOMIZED_ADD,
    GET_USER_CUSTOMIZED,

    PROVINCE_AUTHENTICATION_TIMES,
    SELF_HELP_SPEED,
    OPTICAL_PASS_RATE,
    BROADBAND_STATISTICS,
    BROADBAND_MAP_STATISTICS,
    BROADBAND_NEW_WEEK_INFO,
    BROADBAND_APPLY_WEEK_INFO,
    BROADBAND_RANK_INFO
};