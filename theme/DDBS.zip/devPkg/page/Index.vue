/*********************************************************************
* Created by deming-su on 2017/12/30
*********************************************************************/

<template>
    <div class="application-container">
        <components :is="currentComponent"></components>
    </div>
</template>

<script>
    import ConstConf from "../config/const.config";
    import HomeApi from "../api/home";

    let Worker = require("worker-loader!../../static/assets/javascript/worker.main.js");

    export default {
        data() {
            return {
                currentComponent: 'wait-page',
                personalizedCache: null,
                webWorker: null
            }
        },
        watch: {
            '$route.path': function(val) {
                if (val === '/home') {
                    /* 如果页面被刷新，则刷新页面 */
                    let refreshRequest = sessionStorage.getItem('customized_finish_request_refresh');
                    if (refreshRequest && refreshRequest === 'require') {
                        sessionStorage.removeItem('customized_finish_request_refresh');
                        window.location.reload();
                    } else {
                        this.initPageEvent();
                    }
                }
            }
        },
        methods: {
            /* 窗口变化事件 */
            resizeEvt() {
                let rect = document.body ? document.body.getBoundingClientRect() : {width: 0, height: 0};
                this.$root.eventBus.$emit(ConstConf.WINDOW_RESIZE, {type: 'windowResizeEvent', width: rect.width, height: rect.height});
            },
            /* 页面初始化数据方法 */
            async initPageEvent() {
                /* 获取个性化数据，如果获取不到数据则使用默认模板渲染 */


                /**
                 * templateContent，userID
                 */
                /*
                let resultData = await HomeApi.getPersonalizedData({userID: sessionStorage.getItem(ConstConf.USER_ID_STORAGE) || ConstConf.SYSTEM_ADMIN_ID});
                if (!!resultData && resultData.status === 200 && resultData.data !== null) {
                    let _d = resultData.data.data;
                    try {
                        this.personalizedCache = JSON.parse(_d.templateContent);
                    } catch (e) {
                        this.personalizedCache = HomeApi.getDefaultPersonalizedData();
                    }
                } else {
                    this.personalizedCache = HomeApi.getDefaultPersonalizedData();
                }*/

                /* 测试数据 */
                let cache = sessionStorage.getItem('customized_cache_data');
                if (cache) {
                    this.personalizedCache = JSON.parse(cache);
                } else {
                    this.personalizedCache = HomeApi.getDefaultPersonalizedData();
                }


                /* 页面初始化时，如果存在主题颜色配置，需要把主题颜色配置到数据状态中 */
                if (this.personalizedCache.colors) {
                    this.$store.dispatch('setSystemCustomizedColors', {data: this.personalizedCache.colors});
                }

                /* 设置缓存和设置当前个性化数据状态 */
                sessionStorage.setItem('current_user_personalized_data', JSON.stringify(this.personalizedCache));
                this.$store.dispatch('setPersonalizedData', {data: this.personalizedCache});
                setTimeout(() => {
                    this.currentComponent = this.personalizedCache.mainThemeName;
                });
            }
        },
        created() {

            /* 页面初始化数据 */
            this.initPageEvent();

            /* 初始化页面socket专用线程 */
            this.webWorker = new Worker();
            this.webWorker.postMessage({message: 'test'});
            this.webWorker.addEventListener('message', data => {
                console.log(data);
            })
        },
        mounted() {
            this.$nextTick(() => {
                window.addEventListener('resize', this.resizeEvt, true);
            });
        },
        beforeDestroy() {
            window.removeEventListener('resize', this.resizeEvt, true);
        }
    };
</script>