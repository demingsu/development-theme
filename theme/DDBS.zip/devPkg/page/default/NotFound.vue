/*********************************************************************
 * Vue private blank layout file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
   <div>
       <h1 class="title">遇见外星人劫持页面了。。。</h1>
       <span class="btn" @click="backHistory">返回</span>
   </div>
</template>

<script>
    export default{
        methods: {
            backHistory() {
                this.$router.go(-1);
            }
        }
    };
</script>

<style lang="less" scoped>
    .title {
        text-align: center;
        margin: 0;
        padding: 10%;
    }
    .btn {
        display: block;
        height: 30px;
        width: 66px;
        margin: auto;
        line-height: 28px;
        border: solid 1px #0f7dd4;
        border-radius: 4px;
        color: #0f7dd4;
        font-size: 12px;
        text-align: center;
        letter-spacing: 2px;
        cursor: pointer;
    }
</style>

