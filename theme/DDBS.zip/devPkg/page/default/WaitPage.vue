/*********************************************************************
 * Vue private blank layout file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
   <div>
       <span class="title">{{title}}</span>
   </div>
</template>

<script>
    export default{
        data() {
            return {
                title: "",
                looper: null
            }
        },
        methods: {
            loopTitle(idx) {
                let dot = "";
                for (let i = 0;i < idx;i ++) {
                    dot += '.';
                }
                this.title = `页面加载中 ${dot}`;
                this.looper = setTimeout(() => {
                    clearTimeout(this.looper);
                    this.looper = null;
                    this.loopTitle(idx >= 5 ? 0 : ++ idx);
                }, 200);
            }
        },
        created() {
            this.loopTitle(0);
        },
        beforeDestroy() {
            if (!!this.looper) {
                clearTimeout(this.looper);
                this.looper = null;
            }
        }
    };
</script>

<style lang="less" scoped>
    .title {
        display: block;
        padding: 10% 0;
        text-align: center;
        font-size: 1.8rem;
        color: #67C23A;
    }
</style>

