/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div></div>
</template>

<script>
    import BaseChart from "./BaseChart.vue";

    export default {
        extends: BaseChart,
        methods: {
            /* 渲染chart方法 */
            renderBarChart(chart, data, props) {

                /* 设置chart属性数据 */
                let option = this.makeChartData(data, !!props ? props : {});
                this.renderChart(chart, option);
            },
            /* 制作chart数据 */
            makeChartData(data, props) {

                /* 如果有颜色属性则配置颜色属性 */
                let colors = props.color && props.color.length > 0 ? props.color : ['#00FFFF', '#0498FC', '#00CC00', '#F2D902'];

                let option = {
                    tooltip: {
                        trigger: 'axis'
                    },
                    color: colors,
                    grid: {
                        top: 30,
                        right: 0,
                        bottom: 35,
                        left: 30
                    },
                    xAxis: {
                        type: 'category',
                        axisLine: {
                            lineStyle: {
                                color: '#fff'
                            }
                        },
                        axisTick: {
                            show: false
                        },
                        axisLabel: {
                            color: '#fff',
                            fontSize: 12
                        },
                        data: data.labels
                    },
                    yAxis: [{
                        type: 'value',
                        axisLine: {
                            show: false
                        },
                        axisTick: {
                            show: false
                        },
                        splitLine: {
                            lineStyle: {
                                type: 'dotted',
                                color: 'rgba(255, 255, 255, .9)'
                            }
                        },
                        axisLabel: {
                            color: '#fff',
                            fontSize: 12
                        }
                    }],
                    series: [
                        {
                            type: 'bar',
                            barWidth: props.barWidth ? props.barWidth : '60%',
                            data: data.data
                        }
                    ]
                };

                /* 如果存在自定以xAxis属性 */
                if (props.xAxis) {
                    Object.assign(option.xAxis, props.xAxis);
                }

                /* 是否对tooltip有标签文字提示需求 */
                if (props.tooltip) {
                    Object.assign(option.tooltip, props.tooltip);
                }

                /* 如果存在legend属性 */
                if (!!props.legend) {
                    Object.assign(option, props.legend);
                }

                /* 如果存在grid属性 */
                if (!!props.grid) {
                    option.grid = props.grid;
                }

                /* 是否需要自己单独设置yAxis属性 */
                if (!!props.replaceYAxis) {
                    option.yAxis = props.replaceYAxis;
                }

                /* 如果存在yAxis属性，向原有yAxis添加属性 */
                if (!!props.yAxis) {
                    option.yAxis.push(props.yAxis);
                    option.series[1].yAxisIndex = 1;
                }

                return option;
            }
        }
    }
</script>