/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div></div>
</template>

<script>
    import ConstConf from "../../../config/const.config";
    export default {
        data() {
            return {
                maxValue: 0,
                currentValue: 0,
                myChart: null
            }
        },
        methods: {
            /* 渲染chart方法 */
            renderChart(chart, option) {
                this.myChart = chart;
                this.myChart.clear();

                /* 设置chart属性数据 */
                this.myChart.setOption(option);
            },
            /* 根据数组设置当前数据的峰值和当前值 */
            setCurrentLegendData(list) {
                let max = 0;
                if (!!list && list.length > 0) {
                    this.currentValue = list[list.length - 1];
                    for (let it of list) {
                        if (max < it) max = it;
                    }
                    this.maxValue = max;
                } else {
                    this.currentValue = 0;
                    this.maxValue = 0;
                }

            }
        },
        mounted() {
            this.$root.eventBus.$on([ConstConf.WINDOW_RESIZE, ConstConf.COMPONENT_REFRESH_EVENT], data => {
                if (data.type === ConstConf.WINDOW_RESIZE && !!this.myChart) {
                    this.myChart.resize();
                }
            });
        }
    }
</script>