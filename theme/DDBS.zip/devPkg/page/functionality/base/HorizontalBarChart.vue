/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div></div>
</template>

<script>
    import BaseChart from "./BaseChart.vue";

    export default {
        extends: BaseChart,
        methods: {
            /* 渲染chart方法 */
            renderHBarChart(chart, data, props) {

                /* 设置chart属性数据 */
                let option = this.makeChartData(data, !!props ? props : {});

                this.renderChart(chart, option);
            },
            /* 制作chart数据 */
            makeChartData(data, props) {
                let series = [];
                data.data.map((it, i) => {
                    if (!!it[0]) {
                        let obj = {
                            name: it[0].name || "",
                            type: 'bar',
                            stack: '总量',
                            data: it
                        };
                        if (i === data.data.length - 1) {
                            obj.label = {
                                normal: {
                                    show: true,
                                    position: props.barType === 'vertical' ? 'top' : 'right',
                                    color: '#fff',
                                    formatter: val => {
                                        return val ? val.data.total : 0
                                    }
                                }
                            };
                        }
                        series.push(obj);
                    }
                });

                let xAxis = {
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        show: false
                    },
                    splitLine: {
                        show: false
                    }
                };
                let yAxis = {
                    type: 'category',
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        color: '#fff',
                        interval: 0
                    },
                    splitLine: {
                        show: false
                    },
                    data: data.labels
                };

                let option = {
                    color: ['#0099FF', '#1ED2FF'],
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'none'
                        }
                    },
                    grid: {
                        top: 26,
                        left: props.barType === 'vertical' ? 16 : 46,
                        right: props.barType === 'vertical' ? 16 : 30,
                        bottom: props.barType === 'vertical' ? 50 : 0
                    },
                    xAxis: props.barType === 'vertical' ? yAxis : xAxis,
                    yAxis: props.barType === 'vertical' ? xAxis : yAxis,
                    series: series
                };

                /* 如果存在legend属性 */
                if (!!props.legend) {
                    option.legend = props.legend;
                }

                /* 添加标题 */
                if (props.markPoint) {
                    option.series[0].markPoint = props.markPoint;
                }

                /* 网格位置 */
                if (props.grid) {
                    option.grid = props.grid;
                }

                return option;
            }
        }
    }
</script>