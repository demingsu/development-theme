/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div></div>
</template>

<script>
    import BaseChart from "./BaseChart.vue";
    import LineChart from "./LineChart";

    export default {
        mixins: [BaseChart, LineChart],
        methods: {
            /* 渲染chart方法 */
            renderLineBarChart(chart, data, props) {

                /* 设置chart属性数据 */
                let option = this.makeChartData({labels: data.labels, data: data.line}, !!props ? props : {});
                option.series[0].yAxisIndex = 1;
                /* 设置bar属性数据 */
                let barSeries = this.makeBarData(data.bar);


                option.series.push(barSeries);

                this.renderChart(chart, option);
            },
            /* 制作chart数据 */
            makeBarData(data) {
                 return {
                    type: 'bar',
                    data: data
                };
            }
        }
    }
</script>