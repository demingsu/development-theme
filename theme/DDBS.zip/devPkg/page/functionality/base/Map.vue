/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div></div>
</template>

<script>
    import BaseChart from "./BaseChart.vue";

    export default {
        extends: BaseChart,
        methods: {
            /* 渲染chart方法 */
            renderMapChart(chart, data) {
                let option = this.makeOption(data.type, data.features, data.params);

                this.renderChart(chart, option);
            },
            makeOption(type, features, params) {

                /* 描点动图数据 */
                let scatterGeo = [];

                for (let item of features) {
                    let name = item.properties.name;
                    let cp = [];
                    if (item.properties.cp) {
                        cp = JSON.parse(JSON.stringify(item.properties.cp));
                    } else {
                        if (!!params.geo) {
                            cp = params.geo[name];
                        }
                    }
                    let info = params.data.find(it => it.cn === name);
                    scatterGeo.push({name: name, selected: false, value: cp, info});
                }

                /* 通用item和label配置信息 */
                let seriesProps = {
                    label: {
                        show: false,
                        color: 'rgba(0, 0, 0, 0)'
                    },
                    itemStyle: {
                        normal: {
                            opacity: 0
                        }
                    }
                };

                /* 是否有提示信息个性化 */
                if (!params.tooltipFormatter) {
                    params.tooltipFormatter = val => {
                        return val.value;
                    };
                }
                
                if (!params.scatterFormatter) {
                    params.scatterFormatter = val => {
                        return val.value;
                    };
                }

                let serise = {
                    calculable: false,
                    tooltip: {
                        trigger: 'item',
                        data: scatterGeo,
                        formatter: params.tooltipFormatter
                    },
                    geo: {
                        map: params.name,
                        show: true,
                        roam: false,
                        label: seriesProps.label,
                        itemStyle: seriesProps.itemStyle,
                        emphasis: seriesProps,
                        zlevel: 3
                    },
                    series: [
                        {
                            type: 'map',
                            map: params.name,
                            selectedMode: true,
                            silent: false,
                            data: scatterGeo,
                            itemStyle: {
                                normal: {
                                    areaColor: '#0488BF',
                                    borderColor: '#000'
                                }
                            },
                            emphasis: {
                                itemStyle: {
                                    areaColor: '#6BD8F9'
                                },
                                label: {
                                    show: false
                                }
                            },
                            zlevel: 8
                        }
                    ]
                };

                /* 气泡提示 */
                serise.series.push({
                    type: 'effectScatter',
                    coordinateSystem: 'geo',
                    data: scatterGeo,
                    symbolSize: () => {
                        return type !== 'cdn' ? 16 : 0;
                    },
                    showEffectOn: 'render',
                    rippleEffect: {
                        brushType: 'fill'
                    },
                    hoverAnimation: true,
                    label: {
                        normal: {
                            show: true,
                            formatter: val => {
                                return '\n\n\n' + val.data.name;
                            },
                            color: '#fff',
                            fontSize: 14,
                            opacity: 1,
                            zIndex: 2
                        }
                    },
                    itemStyle: {
                        normal: {
                            color: val => {
                                return '#F6FF75';
                            },
                            shadowBlur: 10,
                            shadowColor: '#333',
                            zIndex: 1
                        }
                    },
                    tooltip: {
                        trigger: 'item',
                        formatter: params.scatterFormatter
                    },
                    zlevel: 9
                });

                return serise;
            }
        }
    }
</script>