/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div></div>
</template>

<script>
    import BaseChart from "./BaseChart.vue";

    export default {
        extends: BaseChart,
        methods: {
            /* 渲染chart方法 */
            renderPieChart(chart, data, props) {

                /* 设置chart属性数据 */
                let option = this.makeChartData(data, !!props ? props : {});

                this.renderChart(chart, option);
            },
            /* 制作chart数据 */
            makeChartData(data, props) {
                let colors = props.color && props.color.length > 0 ? props.color : ['#00FFFF', '#FD6501', '#00E629', '#FFBA2F', '#409EFF'];
                data.map((it, i) => {
                    it.itemStyle = {
                        normal: {
                            color: colors[i % colors.length]
                        }
                    }
                });
                let option = {
                    tooltip: {
                        trigger: 'item',
                        formatter: val => {
                            return `${val.data.name}<br/>${val.data.value}`;
                        }
                    },
                    series: [
                        {
                            type: 'pie',
                            radius: props.radius && props.radius.length > 0 ? props.radius : ['30%', '80%'],
                            center: '50%',
                            roseType: 'radius',
                            label: {
                                normal: {
                                    show: false
                                }
                            },
                            lableLine: {
                                normal: {
                                    show: false
                                }
                            },
                            data: data
                        }
                    ]
                };
                /* 如果存在legend属性 */
                if (!!props.legend) {
                    Object.assign(option, props.legend);
                }
                return option;
            }
        }
    }
</script>