/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="chart-container map">
        <div class="map-btns">
            <div class="back-icon border" v-show="self.title !== 'CDN利用率'" @click="showInfo">质差小区数/小区总数</div>
            <div class="back-icon" v-if="!!mapCurrentData && !mapCurrentData.isProvince" @click="backProvinceEvt">&#xe806; 全省</div>
        </div>
        <div class="container" ref="chartNode">
            <!-- 内容区域 -->
        </div>
        <div class="map-legend">
            <span v-for="item in mapLegend" :key="item.id">
                <em class="pointer" :style="{'background-color': item.color}"></em>
                <em class="text">{{item.text}}</em>
            </span>
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import MapChart from "../base/Map.vue";
    import BaseMonitor from "../default/BaseMonitor.vue";

    import HomeApi from "../../../api/home";
    import MonitorApi from "../../../api/monitor";
    import SDMapData from "../../../config/shandongmap.config";
    import Tool from "../../../util/tool";
    import { mapGetters } from "vuex";

    export default {
        mixins: [BaseMonitor, MapChart],
        computed: {
            ...mapGetters({
                mapCurrentData: "getMapCurrentData",
                showItemInfo: "getShowMapQualityInfo"
            })
        },
        components: {
            LoadNode: () => import("../../../components/common/Loading.vue")
        },
        data() {
            return {
                chartNode: null,
                pageData: {},
                chartCacheData: SDMapData.SHANDONG_MAP_DATA.province,
                cityGeo: SDMapData.SHANDONG_MAP_DATA.city,
                cdnData: {
                    cdnBbandUsedCity: [],
                    cdnUseRateCity: []
                },
                sensationData: {
                    mosCity: [],
                    serviceAware_standard_city: [],
                    serviceAware_health_city: [],
                    chanelDelay_switch_city: [],
                    chanelDelay_vod_city: [],
                    mosCity_unicast: [],
                    serviceAware_standard_city_unicast: [],
                    serviceAware_health_city_unicast: [],
                    chanelDelay_switch_city_unicast: [],
                    chanelDelay_vod_city_unicast: [],
                    mosCity_multicast: [],
                    serviceAware_standard_city_multicast: [],
                    serviceAware_health_city_multicast: [],
                    chanelDelay_switch_city_multicast: [],
                    chanelDelay_vod_city_multicast: []
                },
                onlineData: {
                    onlineuserRange: [],
                    onlineuserRangeCity_unicast: [],
                    onlineuserRangeCity_multicast: []
                },
                qualityData: {
                    zcvillage_city: [],
                    zcvillage_city_multicast: [],
                    zcvillage_city_unicast: []
                },
                mapLegend: [
                    {color: '', text: '', id: 'map_legend_key_001'},
                    {color: '', text: '', id: 'map_legend_key_002'},
                    {color: '', text: '', id: 'map_legend_key_003'}
                ],
                mapColors: ['#00FB06', '#F0F80B', '#FD6400']
            }
        },
        watch: {
            /* 监听地图下钻点击事件，如果地图key发生变化，则 */
            "mapCurrentData.key": function() {
                this.getSingleLoadData(this.mapCurrentData);
            },
            /* 监听用户感知数据刷新，如果进行刷新后，需要重新刷新地图数据 */
            "sensationData": function () {
                this.getSingleLoadData(this.mapCurrentData);
            }
        },
        methods: {
            /* 是否显示地图说明数据方法 */
            showInfo() {
                this.$store.dispatch('setShowMapQualityInfo', {data: !this.showItemInfo});
                this.getSingleLoadData(this.mapCurrentData);
            },
            /* 获取地图中对应的数据数据 */
            async getSingleLoadData(item) {

                /* 获取地图绘制JSON，如果本地有缓存从缓存中取，没有则从本地JSON请求数据中获取 */
                let result = item.data;
                if (!item.data) {
                    result = await HomeApi.getBusinessMapData({keyName: item.key});

                    this.chartCacheData.map(it => {
                        if (it.key === item.key) {
                            it.data = result;
                        }
                    });
                }

                /* 如果存在数据 */
                if (result.status === 200) {
                    result = result.data;

                    /* echarts注册地图 */
                    echarts.registerMap(item.name, result);

                    /* 是否是省级地图，如果不是，需要把数据进行重新配置，因为城市级别地图的经纬度要从geo中获取，省级地图可以从cp中获取 */
                    if (!item.isProvince) {
                        item.geo = this.cityGeo[item.cn];
                    }

                    /* 是否显示标签 */
                    item.showItemInfo = this.self.title !== 'CDN利用率' ? this.showItemInfo : false;

                    /* 根据不同类型的组件对象，设置不同的展示数据 */
                    switch (this.self.title) {
                        case 'CDN利用率':
                            this.renderCDNChart(item, result.features);
                            break;
                        case '用户感知':
                            this.renderSensationChart(item, result.features, 'sensation');
                            break;
                        case '组播感知':
                            this.renderSensationChart(item, result.features, 'multi');
                            break;
                        case '单播感知':
                            this.renderSensationChart(item, result.features, 'single');
                            break;
                        default:
                            break;
                    }
                }
            },
            /* 渲染CDN利用地图数据 */
            renderCDNChart(params, geoPointers) {
                if (!!this.cdnData) {
                    let labelInfo = {
                        cdnBbandUsedCity: this.cdnData.cdnBbandUsedCity,
                        cdnUseRateCity: this.cdnData.cdnUseRateCity
                    };

                    this.renderMapChart(this.chartNode, {type: 'cdn', labelInfo, params, geoPointers, colors: this.mapColors});
                }
            },
            /* 渲染用户感知地图数据 */
            renderSensationChart(params, geoPointers, type) {
                if (!!this.sensationData) {
                    let labelInfo = {
                        mos: [],
                        standard: [],
                        health: [],
                        online: [],
                        chanelSwitch: [],
                        chanelVod: [],
                        quality: []
                    };
                    let mos = [],
                        standard = [],
                        health = [],
                        online = [],
                        chanelSwitch = [],
                        chanelVod = [],
                        lineList = null,
                        quality = [];
                    if (params.isProvince) {
                        mos = this.sensationData.mosProv || [];
                    }

                    /* 根据不同类型的地图查找不同的数据结构 */
                    switch (type) {
                        case 'single':
                            /* 判断数据是否存在 */
                            if (!!this.sensationData.serviceAware_standard_city_unicast[0]) {
                                if (!params.isProvince) {
                                    mos = this.sensationData.mosCity_unicast[0].value || [];
                                }
                                standard = this.sensationData.serviceAware_standard_city_unicast[0].value || [];
                                health = this.sensationData.serviceAware_health_city_unicast[0].value || [];
                                lineList = (this.onlineData && this.onlineData.onlineuserRangeCity_unicast) ? this.onlineData.onlineuserRangeCity_unicast[0] : {value: []};
                                online = lineList.value || [];
                                chanelSwitch = this.sensationData.chanelDelay_switch_city_unicast[0].value || [];
                                chanelVod = this.sensationData.chanelDelay_vod_city_unicast[0].value || [];
                                quality = this.qualityData.zcvillage_city_unicast;
                            }
                            break;
                        case 'multi':
                            /* 判断数据是否存在 */
                            if (!!this.sensationData.serviceAware_standard_city_multicast[0]) {
                                if (!params.isProvince) {
                                    mos = this.sensationData.mosCity_multicast[0].value || [];
                                }
                                standard = this.sensationData.serviceAware_standard_city_multicast[0].value || [];
                                health = this.sensationData.serviceAware_health_city_multicast[0].value || [];
                                lineList = (this.onlineData && this.onlineData.onlineuserRangeCity_multicast) ? this.onlineData.onlineuserRangeCity_multicast[0] : {value: []};
                                online = lineList.value || [];
                                chanelSwitch = this.sensationData.chanelDelay_switch_city_multicast[0].value || [];
                                chanelVod = this.sensationData.chanelDelay_vod_city_multicast[0].value || [];
                                quality = this.qualityData.zcvillage_city_multicast;
                            }
                            break;
                        default:
                            if (!!this.sensationData.serviceAware_standard_city[0]) {
                                if (!params.isProvince) {
                                    mos = this.sensationData.mosCity[0].value || [];
                                }
                                standard = this.sensationData.serviceAware_standard_city[0].value || [];
                                health = this.sensationData.serviceAware_health_city[0].value || [];
                                lineList = (this.onlineData && this.onlineData.onlineuserRange && this.onlineData.onlineuserRange[0]) ? this.onlineData.onlineuserRange[0] : {value: []};
                                online = lineList.value || [];
                                chanelSwitch = this.sensationData.chanelDelay_switch_city[0].value || [];
                                chanelVod = this.sensationData.chanelDelay_vod_city[0].value || [];
                                quality = this.qualityData.zcvillage_city;
                            }
                            break;
                    }

                    /* 重新组装数据，避免多数据在echart tooltip时的循环查找次数 */
                    for (let item of geoPointers) {
                        let key = item.properties.name;
                        labelInfo.mos.push(mos.find(it => it.name === key) || {name: key, value: 0});
                        labelInfo.standard.push(standard.find(it => it.name === key) || {name: key, value: 0});
                        labelInfo.health.push(health.find(it => it.name === key) || {name: key, value: 0});
                        labelInfo.online.push(online.find(it => it.name === key) || {name: key, value: 0});
                        labelInfo.chanelSwitch.push(chanelSwitch.find(it => it.name === key) || {name: key, value: 0});
                        labelInfo.chanelVod.push(chanelVod.find(it => it.name === key) || {name: key, value: 0});
                        labelInfo.quality.push(quality.find(it => it.citynName === key) || {citynName: key, dateBadQuality: 0, datePlayQuality: 0});
                    }

                    this.renderMapChart(this.chartNode, {type, labelInfo, params, geoPointers, colors: this.mapColors});
                }
            },
            /* 返回全省地图 */
            backProvinceEvt() {
                this.$store.dispatch('setMapCurrentData', {data: this.chartCacheData[0]});
                this.setQualityMapData('山东');
            },
            /* 获取当前地图所有数据 */
            async getMapData() {
                this.isShow = true;
                let result = await MonitorApi.getProvinceDataOverlook();
                if (result.status === 200) {
                    let _d = result.data;

                    /* 质差小区数据 */
                    this.qualityData = Tool.copyDataToDist(this.qualityData, _d);

                    /* 设置用户感知 */
                    this.sensationData = Tool.copyDataToDist(this.sensationData, _d);

                    /* 设置在线数据 */
                    this.onlineData = Tool.copyDataToDist(this.onlineData, _d);

                    /* 设置cdn数据 */
                    this.cdnData = Tool.copyDataToDist(this.cdnData, _d);
                }
                this.isShow = false;
            },
            /* 设置质差排行地图区域数据 */
            setQualityMapData(cityName) {
                let key = this.self.title;
                if (!!key && key !== 'CDN利用率') {
                    let cityItem = SDMapData.SHANDONG_CITY_LIST.find(it => it.cityAddress === cityName);
                    cityItem.transType = key === '用户感知' ? '全部' : key === '组播感知' ? '组播' : '单播';
                    this.$store.dispatch('setQualityRequestData', {data: cityItem});
                }
            }
        },
        created() {
            this.getMapData();
        },
        mounted() {

            /* 如果地图不存在数据，则重置数据为全省地图数据，如果有数据需要设置质差关联数据 */
            if (!this.mapCurrentData.key) {
                this.backProvinceEvt();
            } else {
                this.setQualityMapData(this.mapCurrentData.cn);
            }

            /* 设置当前地图的图例说明 */
            /* 现在大屏地图气泡是感知达标率，由于很多地市经常会显示橘黄色，用户让改为感知优良率。
                                大屏地图上气泡改为优良率，分三种颜色绿黄红。划分值如下：
                                全部：大于等于98是绿色，小于98大于等于95是一般告警（黄色）， 小于95是严重告警（红色）
                                组播：大于等于97是绿色，小于97大于等于95的是一般告警（黄色），小于95的是严重告警（红色）
                                单播：大于等于99是绿色，小于99大于等于95为一般告警（黄色），小于95是严重告警（红色）
                                >95% ffde00, <=95 >80% ff6600, <=80% 2cc5fe *#00FF00   #FFFF00 */
            let temp = [];
            let isBright = this.self.theme && this.self.theme === 'bright-red';
            this.mapColors = isBright ? ['#48E6FA', '#94F9A6', '#E14592']
                : ['#00FB06', '#F0F80B', '#FD6400'];
            this.mapColors = this.self.title === 'CDN利用率' ? ['#B07211', '#B9A713', '#047FB9'] : this.mapColors;
            let texts = this.self.title === '用户感知' ? ['≥98', '≥95', '<95']
                : this.self.title === '组播感知' ? ['≥97', '≥95', '<95']
                    : this.self.title === 'CDN利用率' ? ['≥90', '≥80', '<80'] : ['≥99', '≥95', '<95'];

            this.mapLegend.map((it, i) => {
                it.color = this.mapColors[i];
                it.text = this.self.title === 'CDN利用率' ? `利用率${texts[i]}` : `优良率${texts[i]}`;
                temp.push(it);
            });
            this.mapLegend = temp;

            this.$nextTick(() => {
                if (this.active) {
                    this.chartNode = echarts.init(this.$refs.chartNode);

                    this.getSingleLoadData(this.mapCurrentData);

                    /* 地图下钻点击事件，CDN利用率 地图不支持下钻 */
                    this.chartNode.on('click', val => {
                        let data = this.chartCacheData.find(it => it.cn === val.name);
                        if(!!data && this.self.title !== 'CDN利用率') {
                            this.$store.dispatch('setMapCurrentData', { data });
                        }
                        this.setQualityMapData(val.name);
                    });
                }
            });
        }
    }
</script>