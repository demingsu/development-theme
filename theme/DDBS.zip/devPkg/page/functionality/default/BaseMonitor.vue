/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div></div>
</template>

<script>
    export default {
        /**
         * 属性说明
         * @define {Number} activeComponentId 当前激活组件id
         * @define {Boolean} active 当前组件是否激活
         * @define {Object} self 当前组件的所有配置属性
         */
        props: {
            activeComponentId: Number,
            active: Boolean,
            self: Object
        },
        data() {
            return {
                isShow: false
            }
        }
    }
</script>