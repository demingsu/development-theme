/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="chart-container">
        <div class="chart-legend-container">
            <span class="max">峰值: {{maxValue}}</span>
            <span class="current">当前: {{currentValue}}</span>
        </div>
        <div class="container" ref="chartNode">
            <!-- chart区域 -->
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import LineBarChart from '../base/LineBarChart.vue';
    import BaseMonitor from "./BaseMonitor.vue";

    import MonitorApi from '../../../api/monitor';

    export default {
        mixins: [BaseMonitor, LineBarChart],
        data() {
            return {
                chartNode: null
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取负载监控数据 */
            async getSingleLoadData() {
                this.isShow = true;
                let result = await MonitorApi.getBroadbandApplyWeekData();
                this.isShow = false;

                let [line, bar, labels] = [[], [], []];
                if (result.applyNum && result.applyRate) {
                    bar = result.applyNum[0].value;
                    line = result.applyRate[0].value;
                    labels = result.applyRate[1].value;
                }

                /* 设置当前值和峰值数据，继承与baseChart对象 */
                this.setCurrentLegendData(bar);

                /* 根据主题设置不同的颜色 */
                let color = !this.self.theme ? [] : this.self.theme === 'bright-red' ? ['#4271eb'] : [];
                this.renderLineBarChart(this.chartNode, {line, bar, labels}, {color,
                    replaceYAxis: [
                        {
                            type: 'value',
                            axisLine: {
                                show: false
                            },
                            axisTick: {
                                show: false
                            },
                            splitLine: {
                                lineStyle: {
                                    type: 'dotted',
                                    color: 'rgba(255, 255, 255, .9)'
                                }
                            },
                            axisLabel: {
                                color: '#fff',
                                fontSize: 12
                            }
                        },
                        {
                            type: 'value',
                            axisLine: {
                                show: false
                            },
                            axisTick: {
                                show: false
                            },
                            splitLine: {
                                show: false
                            },
                            axisLabel: {
                                color: '#fff',
                                fontSize: 12,
                                formatter: '{value} %'
                            }
                        }
                    ],
                    tooltip: {
                        formatter: val => {
                            return `申告7天达标数: ${val[1].value}</br>申告7天达标率: ${val[0].value}%`;
                        }
                    },
                    grid: {
                        top: 30,
                        right: 50,
                        bottom: 35,
                        left: 50
                    }});
            }
        },
        mounted() {
            this.$nextTick(() => {
                if (this.active) {
                    this.chartNode = echarts.init(this.$refs.chartNode);
                    this.getSingleLoadData();
                }
            });
        }
    }
</script>