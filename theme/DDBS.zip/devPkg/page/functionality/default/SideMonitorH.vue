/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="chart-container">
        <div class="container" ref="chartNode">
            <!-- chart区域 -->
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import HBarChart from '../base/HorizontalBarChart.vue';
    import BaseMonitor from "./BaseMonitor.vue";

    import MonitorApi from '../../../api/monitor';

    export default {
        mixins: [BaseMonitor, HBarChart],
        data() {
            return {
                chartNode: null,
                up: 'image://data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAEaklEQVR4Xu2d0VUTYRCF708gPkoH2oHpQHz1GIwViBWoFQgd0AF0IIrHV7ECsQPtAB4NhN+zOQRBQ3Z2k4P5Z748wizZuffLzGU3J0niEVqBFLp7mhcABIcAAAAguALB22cCAEBwBYK3zwQAgOAKBG+fCQAAwRUI3j4TAACCKxC8fSYAAARXIHj7TAAACK5A8PaZAAAQXIHg7TMBACC4AsHbZwIAQHAFgrfPBACA4AoEb58JAADBFQjePhMAAIIrELx9JgAABFcgePtMAACIp8DmUC9z1iAlbUhaz9LRSHr7uavjaGqEmwD9ofaStDXF6OOVNT05SDqJBEEoAGaYP/E8HARhANgcalfSa8OrOxQEIQDoD7WVpD2D+eEmgXsAWpgfCgLXAMxhfhgI3AKwAPNDQOASgAWa7x4CdwA8Haq3Kn1rEPispS7/O3AFwKX5X6qre1ZXG9a5g8ANAHdgvst14AKABuaf5qyjlPR82is/Z324vD9wv2YyuJkExQPQxPxzaWM1a6Ckd1MNzto5TzpYlY4khYCgaAAGWQ8vzsaBr27nn1bmV3f7Nn9pexYAH+9p+xKqEBAUC8Aga/3iTFXg69WM6yvzqzoLAFVdFAiKBKCt+U0AiAJBkQDMfBX/GQc3XvmTH1snwKTePAmydqr10fDfyv9eXiQA/aGOkvR4hnpTzW86AZpAkKWvh93xO4yKengE4Fbz2wJgWQcAcIfc9881SBd6P+UpZ5o/DwB1EOQVvThc1cEdyrCQpypyAkwzMkvfR9JW3Rs7m2aAv1WuMkFH2k/So6vfFbr/q/MvFoDq5KvrAKORejnr5NPa+OJN7WNeACZP8OxMGylpvdPR8UHSj9onXtKCogFoo+miAGjz3Mt4DABcd6XgUd4WLgAAgLbslHkcK+Cmb0wAJkCZr+S2Z80EYALU3g5uC1eJx7ECWAElctv+nFkBrABWwDUGWAGsgPbjtMQjWQGsAFYAK+D2t4WX+LaueSYxGYAMMA8/5R1LBiADkAHIAGSACQNkADJAeXt8njMmA5AByABkADIAGWDaHuFNofNs1zKOJQOQAcgAZAAyABmADDBWgAtBXAgqI7wt6iwJgYRAQiAhkBBICCQEEgL/YYArgYuKWsv7dwiBhEBCICGQEEgIJAQSAgmBAS8Fz/pCqSy9Ouxqf3kj7OLPLNy9gOqTxkdDHaekBzduA2T97HTV48ujFw/Z0v3F8QdMDrV7+fUwqr5GptPVm5I/8LGtyOEmQFuhvB4HAF6dNfYFAEahvJYBgFdnjX0BgFEor2UA4NVZY18AYBTKaxkAeHXW2BcAGIXyWgYAXp019gUARqG8lgGAV2eNfQGAUSivZQDg1VljXwBgFMprGQB4ddbYFwAYhfJaBgBenTX2BQBGobyWAYBXZ419AYBRKK9lAODVWWNfAGAUymsZAHh11tgXABiF8loGAF6dNfYFAEahvJYBgFdnjX0BgFEor2UA4NVZY18AYBTKaxkAeHXW2NdvAu7HkGuz/4MAAAAASUVORK5CYII=',
                down: 'image://data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAALbSURBVHhe7d1BThNRHMfx94aykkSILkyskRuIN5Ab1IB7ewNugEfAG7A3KjeAI/QGagyJC0m7YCed5/ynD6JgSwc6pu/9vp8NzAzhDfy/HSYsOg4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAACw9Hz9KGfaebI47qwfVD//KtoNzJysXv/Y2jn58rb9AiFwAw976ermyNnDeP4+7JkL4VozPtzaORqO4R0IRP8oYFw96N4Zvqn31MTFyAfjCb8ZPb5h1LFdyAeBvBCCOAMQRgDgCEEcA4ghAHAGIIwBxBCCOAMQRgDgCEEcA4ghAHAGIIwBxBCCOAMQRgDgCEEcA4ghAHAGIIwBxBCCOAMQRgDgCEEcA4ghAHAGIIwBxBCCOAMQRgDgCEJd0APaGjz93nvWGu936DR//J1uzXrs6h7grSckGcLbbfVd2Vr947z6Xzh+f7XQHwzdPt+Lh1tgatpatWa9dnYOdSzycnCQDsFeec34/bk54/6IMxUmbEdj3tjVsrbgr8vuTc0pPmlcAH/biZ9c9bCuCq+FXa0z2XDP9nJZajjeBC4/g1uEnLMkAvHM2jFkWFsG8w5/jnJZSkgEUF+cHzoVB3Jzm3hHM/8oPg8k5pSfJAOwt3atf+HabETQc/naqbzOf7D1AmxHMPfzgqnO4eJ3yMwaSvglsI4JGwy/K6pWf9lNGkg7ANI0gOD81AjvWaPgfTm9bc+ll88iY+lEwnbXj6ke6803fXDIavsnqmUGtR5DZ8E12D41qM4LCly9zGr5J/h7gugb3BI2EsuznNnyT3RXg0iKvBDb8x59OD+NmVrINwCwigpyHb7IOwNwngtyHb7IPwNwlAoXhm+xuAv+l8Y1hCO8Vhm8krgCX5roSBHf46OP3ftzKnlQAZmYEYsM3En8C/lT/OfChH1yw//nb0EchhKMQyrdqwwcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAClw7jdiLT2cmXm9ZgAAAABJRU5ErkJggg==',
                line: 'image://data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAECAYAAACQli8lAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAAAAdSURBVHjaYvz///9/BjoAJgY6geFnEQAAAP//AwCICAQETa/POQAAAABJRU5ErkJggg=='
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取负载监控数据 */
            async getSingleLoadData() {
                this.isShow = true;
                let result = await MonitorApi.getBroadbandRankData();
                this.isShow = false;

                let data = [];
                let labels = [];
                let d1 = [];
                let d2 = [];
                let legend = {};
                let pointData = [];
                if (result && result.onlineuserRange) {
                    let cache = sessionStorage.getItem('iptv_online_user_range');
                    cache = cache ? JSON.parse(cache) : [];

                    let r0 = result.onlineuserRange[0].value;
                    let r1 = result.onlineuserRange[1].value;
                    for (let i = 0,j = r0.length;i < j;i ++) {
                        labels.push(r0[i].name);
                        d1.push({value: r0[i].value, total: r0[i].value + r1[i].value, name: result.onlineuserRange[0].name});
                        d2.push({value: r1[i].value, total: r0[i].value + r1[i].value, name: result.onlineuserRange[1].name});

                        let ci = cache.findIndex(oo => oo.name === r0[i].name);
                        pointData.push({
                            symbol: ci > i ? this.down : ci < i ? this.up : this.line,
                            symbolSize: ci === i ? [8, 2] : null,
                            x: 10,
                            y: 38 + (24 * i)
                        });
                    }

                    /* 设置刷新后对比数据缓存 */
                    sessionStorage.setItem('iptv_online_user_range', JSON.stringify(r0));

                    legend = {
                        show: true,
                        data: [result.onlineuserRange[0].name, result.onlineuserRange[1].name],
                        textStyle: {
                            color: '#fff'
                        }
                    }
                }
                data.push(d1);
                data.push(d2);

                /* 根据主题模板设置是否是横向显示柱状图 */
                let barType = this.self.theme && this.self.theme === 'bright-red' ? 'vertical' : 'horizontal';
                this.renderHBarChart(this.chartNode, {data, labels}, {legend, barType,
                    grid: {
                        top: 26,
                        left: 70,
                        right: 42,
                        bottom: 0
                    },
                    markPoint: {
                        data: pointData,
                        normal: {
                            show: true,
                            position: "inside",
                            formatter: "{b}",
                            color: "#fff"
                        },
                        symbolSize: 20
                    }
                });
            }
        },
        mounted() {
            this.$nextTick(() => {
                if (this.active) {
                    this.chartNode = echarts.init(this.$refs.chartNode);
                    this.getSingleLoadData();
                }
            });
        }
    }
</script>