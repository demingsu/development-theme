/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="table-container" :class="{'bright-red': this.self.theme === 'bright-red'}">
        <div class="list" v-for="(item, i) in tableList" :key="`table_list_key_00${i}`">
            <div class="item" v-for="it in item"
                 v-show="it.isShow"
                 :style="[{'width': `${(100/titleLength).toFixed(3)}%`}]"
                 :key="it.id">
                <span>{{it.value}}</span>
            </div>
        </div>
        <div class="setting" @click="pickEvent('set')"></div>
        <div class="setting-box" v-show="showSetting">
            <div class="item"
                 v-for="item in tableTitle"
                 :class="[{'active': item.isShow}]"
                 :key="`setting_${item.id}`"
                 @click="pickEvent('pick', item)">{{item.name}}</div>
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import BaseMonitor from "./BaseMonitor.vue";

    import MonitorApi from "../../../api/monitor";

    export default {
        extends: BaseMonitor,
        data() {
            return {
                showSetting: false,
                titleLength: 3,
                tableTitle: [
                    {id: 'table_title_001', name: '名次', isShow: true},
                    {id: 'table_title_002', name: '地名', isShow: true},
                    {id: 'table_title_003', name: '通过率', isShow: true}
                ],
                tableList: [],
                currentData: []
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取负载监控数据 */
            async getSingleLoadData() {
                this.isShow = true;
                let result = await MonitorApi.getHealthOpticalRankingData();
                this.isShow = false;

                let temp = [];
                if (result && result.length > 0) {
                    this.currentData = result;
                    this.currentData.sort(function (a, b) {
                        return a.rate - b.rate;
                    });
                    temp = this.assembleData(this.currentData);
                }
                this.tableList = temp;
            },

            /* 组装数据 */
            assembleData(result) {
                let temp = [];
                for (let i = 0,j = result.length;i < j;i ++) {
                    let it = result[i];
                    let arr = [];
                    arr.push({
                        id: `table_item_0${i}_${0}`,
                        value: it.rate,
                        isShow: this.tableTitle[0].isShow
                    });
                    arr.push({
                        id: `table_item_0${i}_${1}`,
                        value: it.name,
                        isShow: this.tableTitle[1].isShow
                    });
                    arr.push({
                        id: `table_item_0${i}_${2}`,
                        value: it.value,
                        isShow: this.tableTitle[2].isShow
                    });
                    temp.push(arr);
                }
                return temp;
            },
            /* 列选中器 */
            pickEvent(type, item) {
                if (type === 'pick') {
                    let len = 0;
                    this.tableTitle.map(it => {
                        if (it.id === item.id) {
                            it.isShow = !it.isShow;
                        }
                        if (it.isShow) {
                            ++ len;
                        }
                    });
                    this.titleLength = len;
                    if (this.currentData.length > 0) {
                        this.tableList = this.assembleData(this.currentData);
                    }
                }
                this.showSetting = !this.showSetting;
            }
        },
        mounted() {
            this.$nextTick(() => {
                if (this.active) {
                    this.getSingleLoadData();
                }
            });
        }
    }
</script>