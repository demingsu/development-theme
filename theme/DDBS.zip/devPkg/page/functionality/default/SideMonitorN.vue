/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="chart-container">
        <div class="chart-legend-container">
            <span class="max">峰值: {{maxValue}}G</span>
            <span class="current">当前: {{currentValue}}G</span>
        </div>
        <div class="container" ref="chartNode">
            <!-- chart区域 -->
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import BarChart from '../base/BarChart.vue';
    import BaseMonitor from "./BaseMonitor.vue";

    import MonitorApi from '../../../api/monitor';

    export default {
        mixins: [BaseMonitor, BarChart],
        data() {
            return {
                chartNode: null
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取负载监控数据 */
            async getSingleLoadData() {
                this.isShow = true;
                let result = await MonitorApi.getHealthCityFlowData();
                this.isShow = false;

                let data = [];
                let labels = [];
                if (result && result.cityPeakflow && result.cityPeakflow.length > 1) {
                    data = result.cityPeakflow[0].value;
                    labels = result.cityPeakflow[1].value;
                }

                /* 设置当前值和峰值数据，继承与baseChart对象 */
                this.setCurrentLegendData(data);

                /* 根据主题设置不同的颜色 */
                let color = !this.self.theme ? [] : this.self.theme === 'bright-red' ? ['#4271eb'] : [];
                this.renderBarChart(this.chartNode, {labels, data}, {color,
                    xAxis: {
                        axisLabel: {
                            rotate: 45
                        }
                    },
                    grid: {
                        top: 30,
                        right: 0,
                        bottom: 35,
                        left: 50
                    }});
            }
        },
        mounted() {
            this.$nextTick(() => {
                if (this.active) {
                    this.chartNode = echarts.init(this.$refs.chartNode);
                    this.getSingleLoadData();
                }
            });
        }
    }
</script>