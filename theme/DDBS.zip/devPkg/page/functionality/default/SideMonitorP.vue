/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="table-container" :class="{'bright-red': this.self.theme === 'bright-red'}">
        <div class="list" v-for="(item, i) in tableList" :key="`table_list_key_00${i}`">
            <div class="item" v-for="it in item"
                 v-show="it.isShow"
                 :style="[{'width': `${it.width}%`}]"
                 :key="it.id">
                <span>{{it.value}}</span>
            </div>
        </div>
        <div class="setting pick-icon" @click="pickEvent('set')">{{currentAreaId}}</div>
        <div class="setting-box" v-show="showSetting">
            <div class="item"
                 v-for="item in tableTitle"
                 :class="[{'active': item.active}]"
                 :key="`setting_${item.id}`"
                 @click="pickEvent('pick', item)">{{item.name}}</div>
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import BaseMonitor from "./BaseMonitor.vue";

    import MonitorApi from "../../../api/monitor";
    import { mapGetters } from "vuex";

    export default {
        extends: BaseMonitor,
        computed: {
            ...mapGetters({
                currentPageCacheData: "getHealthGridScoreData"
            })
        },
        data() {
            return {
                showSetting: false,
                titleLength: 3,
                tableTitle: [
                    {id: 'table_title_001', name: '青海省', active: true},
                    {id: 'table_title_002', name: '西宁', active: false},
                    {id: 'table_title_003', name: '格尔木', active: false},
                    {id: 'table_title_004', name: '海东', active: false},
                    {id: 'table_title_005', name: '海西', active: false},
                    {id: 'table_title_006', name: '海南', active: false},
                    {id: 'table_title_007', name: '海北', active: false},
                    {id: 'table_title_008', name: '黄南', active: false},
                    {id: 'table_title_009', name: '玉树', active: false},
                    {id: 'table_title_010', name: '果洛', active: false},
                ],
                tableList: [],
                pageData: [],
                currentData: [],
                currentAreaId: '青海省',
                loopTime: null,
                loopTimes: 1000,
                loopIndex: 0
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取负载监控数据 */
            async getSingleLoadData() {

                if (this.loopTime) {
                    clearTimeout(this.loopTime);
                    this.loopTime = null;
                }

                this.isShow = true;
                let result = await MonitorApi.getHealthGridScoreData({areaId: this.currentAreaId !== '青海省' ? this.currentAreaId : ''});
                this.isShow = false;

                if (result && result.list && result.list.length > 0) {
                    this.pageData = result.list;
                    this.loopData();
                }
            },
            /* 遍历当前数据 */
            loopData() {
                let temp = [];
                let st = this.loopIndex * 12;
                let et = (this.loopIndex + 1) * 12;
                this.currentData = this.pageData.slice(st, et);
                temp = this.assembleData(this.currentData);
                this.tableList = temp;

                this.isShow = false;
                this.loopTime = setTimeout(() => {
                    clearTimeout(this.loopTime);
                    this.loopTime = null;
                    ++ this.loopIndex;

                    if (this.loopIndex >= Math.ceil(this.pageData.length / 12)) this.loopIndex = 0;
                    this.loopData();
                }, this.loopTimes);
            },
            /* 组装数据 */
            assembleData(result) {
                let temp = [];
                for (let i = 0,j = result.length;i < j;i ++) {
                    let it = result[i];
                    let arr = [];
                    arr.push({
                        id: `table_item_0${i}_${0}`,
                        value: it.rate,
                        width: 10,
                        isShow: true
                    });
                    arr.push({
                        id: `table_item_0${i}_${1}`,
                        value: it.zwName,
                        width: 70,
                        isShow: true
                    });
                    arr.push({
                        id: `table_item_0${i}_${2}`,
                        value: `得分:${it.healthScore}`,
                        width: 20,
                        isShow: true
                    });
                    temp.push(arr);
                }
                return temp;
            },
            /* 列选中器 */
            pickEvent(type, item) {
                if (type === 'pick') {
                    let temp = [];
                    this.tableTitle.map(it => {
                        it.active = it.id === item.id;
                        temp.push(it);
                    });
                    this.tableTitle = temp;
                    this.currentAreaId = item.name;

                    this.getSingleLoadData();
                }
                this.showSetting = !this.showSetting;
            }
        },
        mounted() {
            this.$nextTick(() => {
                if (this.active) {
                    if (this.currentPageCacheData.index && this.currentPageCacheData.index > 0) {
                        this.pageData = this.currentPageCacheData.list;
                        this.loopIndex = this.currentPageCacheData.index;
                        this.loopData();

                    } else {
                        this.getSingleLoadData();
                    }
                }
            });
        },
        beforeDestroy() {
            this.$store.dispatch('setHealthGridScoreData', {data: {list: this.pageData, index: 1}});
            if (this.loopTime) {
                clearTimeout(this.loopTime);
                this.loopTime = null;
            }
        }
    }
</script>