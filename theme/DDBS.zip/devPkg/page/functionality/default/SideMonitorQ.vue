/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="chart-container">
        <div class="container" ref="chartNode">
            <!-- chart区域 -->
        </div>
        <div class="setting pick-icon" @click="pickEvent('set')">{{currentAreaId}}</div>
        <div class="setting-box" v-show="showSetting">
            <div class="item"
                 v-for="item in tableTitle"
                 :class="[{'active': item.active}]"
                 :key="`setting_${item.id}`"
                 @click="pickEvent('pick', item)">{{item.name}}</div>
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import BarChart from '../base/BarChart.vue';
    import BaseMonitor from "./BaseMonitor.vue";

    import MonitorApi from '../../../api/monitor';

    export default {
        mixins: [BaseMonitor, BarChart],
        data() {
            return {
                showSetting: false,
                tableTitle: [
                    {id: 'table_title_001', name: '青海省', active: true},
                    {id: 'table_title_002', name: '西宁', active: false},
                    {id: 'table_title_003', name: '格尔木', active: false},
                    {id: 'table_title_004', name: '海东', active: false},
                    {id: 'table_title_005', name: '海西', active: false},
                    {id: 'table_title_006', name: '海南', active: false},
                    {id: 'table_title_007', name: '海北', active: false},
                    {id: 'table_title_008', name: '黄南', active: false},
                    {id: 'table_title_009', name: '玉树', active: false},
                    {id: 'table_title_010', name: '果洛', active: false},
                ],
                currentAreaId: '青海省',
                chartNode: null,
                isShow: false
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取负载监控数据 */
            async getSingleLoadData() {
                this.isShow = true;
                let result = await MonitorApi.getIptvLiveTopData({areaId: this.currentAreaId});
                this.isShow = false;

                let data = [];
                let labels = [];
                let dataColor = ['#DF9D85', '#60E289', '#FFDF36', '#02CEF7', '#02E2FF', '#02CEF7'];
                if (result && result.onLiveData) {
                    result.onLiveData.yFileds[0].valueList.map((it, i) => {
                        data.push({
                            value: it,
                            itemStyle: {color: dataColor[i > 5 ? 5 : i]}
                        });
                    });
                    labels = result.onLiveData.xFiled.valueList;
                }

                /* 根据主题设置不同的颜色 */
                let color = this.self.theme === 'bright-red' ? ['#4271eb'] : [];
                this.renderBarChart(this.chartNode, {labels, data}, {color,
                    xAxis: {
                        axisLabel: {
                            rotate: 45,
                            fontSize: 10
                        }
                    },
                    grid: {
                        top: 30,
                        right: 15,
                        bottom: 55,
                        left: 56
                    }});
            },
            /* 列选中器 */
            pickEvent(type, item) {
                if (type === 'pick') {
                    let temp = [];
                    this.tableTitle.map(it => {
                        it.active = it.id === item.id;
                        temp.push(it);
                    });
                    this.tableTitle = temp;
                    this.currentAreaId = item.name;

                    this.getSingleLoadData();
                }
                this.showSetting = !this.showSetting;
            }
        },
        mounted() {
            this.$nextTick(() => {
                if (this.active) {
                    this.chartNode = echarts.init(this.$refs.chartNode);
                    this.getSingleLoadData();
                }
            });
        }
    }
</script>