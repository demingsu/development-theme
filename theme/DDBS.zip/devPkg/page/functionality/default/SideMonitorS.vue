/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="table-container" :class="{'bright-red': this.self.theme === 'bright-red'}">
        <div class="list" v-for="(item, i) in tableList" :key="`table_list_key_00${i}`">
            <div class="item" v-for="it in item"
                 v-show="it.isShow"
                 :style="[{'width': `${(100/titleLength).toFixed(3)}%`}]"
                 :key="it.id">
                <span>{{it.value}}</span>
            </div>
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import BaseMonitor from "./BaseMonitor.vue";

    import MonitorApi from "../../../api/monitor";

    export default {
        extends: BaseMonitor,
        data() {
            return {
                titleLength: 3,
                tableList: [],
                currentData: []
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取负载监控数据 */
            async getSingleLoadData() {
                this.isShow = true;
                let result = await MonitorApi.getIptvLowerUserTopData();
                this.isShow = false;

                let temp = [];
                if (result && result.length > 0) {
                    this.currentData = result.slice(0, 10);
                    temp = this.assembleData(this.currentData);
                }
                this.tableList = temp;
            },

            /* 组装数据 */
            assembleData(result) {
                let temp = [];
                for (let i = 0,j = result.length;i < j;i ++) {
                    let it = result[i];
                    let arr = [];
                    arr.push({
                        id: `table_item_0${i}_${0}`,
                        value: (i + 1),
                        isShow: true
                    });
                    arr.push({
                        id: `table_item_0${i}_${1}`,
                        value: it.name,
                        isShow: true
                    });
                    arr.push({
                        id: `table_item_0${i}_${2}`,
                        value: it.value,
                        isShow: true
                    });
                    temp.push(arr);
                }
                return temp;
            }
        },
        mounted() {
            this.$nextTick(() => {
                if (this.active) {
                    this.getSingleLoadData();
                }
            });
        }
    }
</script>