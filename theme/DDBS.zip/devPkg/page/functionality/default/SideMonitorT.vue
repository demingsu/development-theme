/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="note-container" :class="cls">
        <div class="item"
             v-for="item in noteList"
             :key="item.id">
            <div :class="item.icon"></div>
            <div class="desc"><span>{{item.desc}}</span></div>
            <div class="value">{{item.value}}<sub>{{item.unit}}</sub></div>
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import BaseMonitor from "./BaseMonitor.vue";
    import MonitorApi from "../../../api/monitor";

    import Tool from "../../../util/tool";

    export default {
        extends: BaseMonitor,
        data() {
            return {
                cls: '',
                noteList: [
                    {id: 'note_list_key_001', key: 'totalUser', icon: 'icon', desc: '全球用户总数', value: 0, unit: ''},
                    {id: 'note_list_key_002', key: 'iptvUser', icon: 'icon iptv', desc: 'Itv在线用户数', value: 0, unit: ''},
                    {id: 'note_list_key_003', key: 'addUser', icon: 'icon new-user', desc: '新增用户数', value: 0, unit: ''},
                    {id: 'note_list_key_004', key: 'cdnRate', icon: 'icon cdn', desc: 'CDN带宽利用率', value: 0, unit: '%'},
                    {id: 'note_list_key_005', key: 'epgRate', icon: 'icon epg-load', desc: 'EPG负载率', value: 0, unit: '%'}
                ]
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取负载监控数据 */
            async getSingleLoadData() {
                this.isShow = true;
                let result = await MonitorApi.getIptvTotalData();
                this.isShow = false;

                let list = JSON.parse(JSON.stringify(this.noteList));

                if (result && result.multicast) {
                    let _d = result.multicast;
                    list.map(it => {
                        it.value = it.unit === '' ? Tool.makeThousandsNum(_d[it.key]) : _d[it.key];
                    });
                }

                this.noteList = list;
            }
        },
        mounted() {
            /* 如果是嫣红模板，需要添加颜色系 */
            this.cls = this.self.theme && this.self.theme === 'bright-red' ? 'bright-red' : '';

            this.$nextTick(() => {
                if (this.active) {
                    this.getSingleLoadData();
                }
            });
        }
    }
</script>