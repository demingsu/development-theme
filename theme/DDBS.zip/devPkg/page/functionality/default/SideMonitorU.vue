/*********************************************************************
 * Created by deming-su on 2017/12/30
 * 认证并发负载监控 单播 组件
 *********************************************************************/

<template>
    <div class="chart-container map">
        <div class="map-name">{{mapAreaName}}{{self.mainTitle}}<i @click="backProvince" v-show="mapKey !== 'qinghai'" class="back-icon">全省</i></div>
        <div class="container" ref="chartNode">
            <!-- 内容区域 -->
        </div>
        <load-node :isShow="isShow"></load-node>
    </div>
</template>

<script>
    import MapChart from "../base/Map.vue";
    import BaseMonitor from "../default/BaseMonitor.vue";

    import HomeApi from "../../../api/home";
    import MonitorApi from "../../../api/monitor";
    import QHMapData from "../../../config/qinghaimap.config";

    export default {
        mixins: [BaseMonitor, MapChart],
        components: {
            LoadNode: () => import("../../../components/common/Loading.vue")
        },
        data() {
            return {
                chartNode: null,
                pageData: {},
                features: [],
                provinceNames: QHMapData.QINGHAI_MAP_DATA.provinceNames,
                cityNames: [],
                mapKey: 'qinghai',
                mapAreaName: ''
            }
        },
        watch: {
            activeComponentId: function() {
                this.getSingleLoadData();
            }
        },
        methods: {
            /* 获取地图中对应的数据数据 */
            async getSingleLoadData() {

                this.isShow = true;
                /* 从本地seesionstrage 取当前地图key，没有的话默认为全省key */
                this.mapKey = sessionStorage.getItem('current_broadband_map_key') || 'qinghai';
                let result = await HomeApi.getBroadbandMapData(this.mapKey);

                /* 根据当前地图key设置城市数据 */
                if (this.mapKey !== 'qinghai') {
                    let keys = this.provinceNames.find(oo => oo.key === this.mapKey);
                    this.cityNames = QHMapData.QINGHAI_MAP_DATA[keys.cn || 'qinghai'];
                    this.mapAreaName = keys.cn || "";
                } else {
                    this.mapAreaName = "";
                }


                /* 如果存在数据 */
                if (result.status === 200) {
                    this.features = result.data.features;

                    /* echarts注册地图 */
                    echarts.registerMap(this.mapKey, result.data);

                    /* 获取页面地图数据 */
                    this.getMapData();
                } else {
                    this.isShow = false;
                }
            },
            /* 获取当前地图所有数据 */
            async getMapData() {

                /* 获取业务数据 */
                this.pageData = await MonitorApi.getIptvMapInfoData();

                let data = [];

                /* 当前地区名字、父节点数据 */
                let currentNames = this.mapKey === 'qinghai' ? this.provinceNames : this.cityNames;
                let parentName = this.mapKey === 'qinghai' ? undefined : this.provinceNames.find(oo => oo.key === this.mapKey).cn;

                for (let i = 0;i < currentNames.length;i ++) {
                    let names = currentNames[i].cn;

                    let times = {value: 0};
                    if (this.pageData.dataTime && this.pageData.dataTime[0]) {
                        /* 根据当前地图key过滤数据 */
                        times = this.pageData.dataTime[0].value.find(it => it.name === names && it.parentName === parentName) || times;
                    }

                    let mosCity = {value: 0};
                    if (this.pageData.mosCity && this.pageData.mosCity[0]) {
                        /* 根据当前地图key过滤数据 */
                        mosCity = this.pageData.mosCity[0].value.find(it => it.name === names && it.parentName === parentName) || mosCity;
                    }

                    let healthCity = {value: 0};
                    if (this.pageData.serviceAware_health_city && this.pageData.serviceAware_health_city[0]) {
                        /* 根据当前地图key过滤数据 */
                        healthCity = this.pageData.serviceAware_health_city[0].value.find(it => it.name === names && it.parentName === parentName) || healthCity;
                    }

                    let standardCity = {value: 0};
                    if (this.pageData.serviceAware_standard_city && this.pageData.serviceAware_standard_city[0]) {
                        /* 根据当前地图key过滤数据 */
                        standardCity = this.pageData.serviceAware_standard_city[0].value.find(it => it.name === names && it.parentName === parentName) || standardCity;
                    }

                    data.push({
                        type: this.mapKey,
                        cn: currentNames[i].cn,
                        time: ['时间', times.value],
                        mos: ['在线用户', mosCity.value],
                        health: ['业务感知达标率', healthCity.value],
                        standard: ['在线用户', standardCity.value]
                    })
                }

                /* 如果是市级地图需要添加cp到地图数据中去 */
                let features = [];
                if (this.mapKey === 'qinghai') {
                    features = this.features;
                } else {
                    this.features.map(it => {
                        let obj = this.cityNames.find(city => city.cn === it.properties.name) || {cp: [0, 0]};
                        it.properties.cp = obj.cp;
                        features.push(it);
                    });
                }

                /* 根据数据渲染地图 */
                this.renderMapChart(this.chartNode, {
                    features: features,
                    params: {
                        name: this.mapKey,
                        data: data,
                        tooltipFormatter: val => {
                            let _d = val.data.info ? val.data.info : {cn: '', mos: ['', 0]};
                            return `${_d.cn}</br>${_d.mos[0]}: ${_d.mos[1]}`;
                        },
                        scatterFormatter: val => {
                            let hasProvince = val.data.info.type === 'qinghai';
                            let _d = val.data.info ? val.data.info : {mos: ['', 0], cn: '', standard: ['', 0]};
                            return hasProvince ? `${_d.mos[0]}</br>${_d.cn}:${_d.mos[1]}` : `${_d.standard[0]}</br>${_d.cn}:${_d.standard[1]}`;
                        }
                    }});

                this.isShow = false;
            },
            /* 返回全省 */
            backProvince() {
                sessionStorage.setItem('current_broadband_map_key', 'qinghai');
                this.getSingleLoadData();
            }
        },
        mounted() {
            this.chartNode = echarts.init(this.$refs.chartNode);
            this.getSingleLoadData();

            /* 地图下钻点击事件 */
            this.chartNode.on('click', val => {
                if (this.mapKey === 'qinghai') {

                    /* 设置地图key为当前选中数据的key，并根据key进行数据组装 */
                    let active = this.provinceNames.find(it => it.cn === val.name);

                    sessionStorage.setItem('current_broadband_map_key', active.key);
                    this.getSingleLoadData();
                } else {
                    this.chartNode.resize();
                }
            });
        }
    }
</script>