/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div>
        <span style="padding: 20px 15px; font-size: 16px;">This is test!!!</span>
        <ring-chart :values="ringData"></ring-chart>
        <div style="display: block; margin: 20px auto; height: 200px; width: 200px;">
            <div style="display: block; height: 100%" ref="chartNode"></div>
        </div>
    </div>
</template>

<script>
    import HomeApi from "../../api/home";
    import RingChart from "./tpl/RingChart.vue";
    import RectChart from "./tpl/RectChart.vue";
    import echarts from "echarts";
    
    export default {
        extends: RectChart,
        components: {
            RingChart
        },
        /**
         * 所有参数变量说明
         * paging             boolean   是否需要分页
         */
        data() {
            return {
                ringData: [50, 70, 110, 200],
                chartNode: null
            }
        },
        methods: {
            async getBusinessData() {
                let result = await HomeApi.getHomeBusinessData({type: 1});
                console.log(result);
                this.renderChart(this.chartNode);
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.chartNode = echarts.init(this.$refs.chartNode);
                this.getBusinessData();

                /* 窗口变化事件监听 */
                this.$root.eventBus.$on(['windowResizeEvent', 'autoPlayEvent'], data => {
                    if (data.type === 'windowResizeEvent') {
                        console.log('this is window resize event.');
                    }
                    if (data.type === 'autoPlayEvent') {
                        console.log(`Current auto play status is : ${data.data}`);
                    }
                });
            });
        }
    }
</script>