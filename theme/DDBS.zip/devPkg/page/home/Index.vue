/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="home-container">
        <div class="auto-layer" v-show="autoShow"></div>
        <components :is="currentComponent"></components>
    </div>
</template>

<script>

    import ConstConf from "../../config/const.config";

    import { mapGetters } from "vuex";
    export default {
        data() {
            return {
                autoShow: true
            }
        },
        computed: {
            ...mapGetters({
                personalizedCache: "getPersonalizedData"
            }),
            currentComponent() {
                return !!this.personalizedCache ? this.personalizedCache.homeLayout : 'wait-page';
            }
        },
        created() {
            this.$root.eventBus.$on(ConstConf.NAVIGATOR_EVENT, data => {
                if (data.key === 'refresh') {
                    this.autoShow = data.active;
                }
            });
        }
    }
</script>