/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div style="display: block; margin: 20px auto; height: 200px; width: 200px;">
        <div style="display: block; height: 100%" ref="charNode"></div>
    </div>
</template>

<script>
    import echarts from "echarts";
    
    export default {
        props: {
            values: Array
        },
        /**
         * 所有参数变量说明
         * paging             boolean   是否需要分页
         */
        data() {
            return {
                chartNode: null
            }
        },
        methods: {
            /* 渲染chart */
            renderChart() {
                let option = {
                    backgroundColor: "rgba(0, 0, 0, 0)",
                    series: [
                        {
                            type: 'pie',
                            radius: '90%',
                            center: ['50%', '50%'],
                            data:[
                                {value: 335, name: '直接访问'},
                                {value: 310, name: '邮件营销'},
                                {value: 274, name: '联盟广告'},
                                {value: 235, name: '视频广告'},
                                {value: 400, name: '搜索引擎'}
                            ].sort((a, b) => a.value - b.value),
                            roseType: 'radius',
                            label: {
                                normal: {
                                    textStyle: {
                                        color: 'rgba(255, 255, 255, 0.3)'
                                    }
                                }
                            },
                            labelLine: {
                                normal: {
                                    lineStyle: {
                                        color: 'rgba(255, 255, 255, 0.3)'
                                    },
                                    smooth: 0.2,
                                    length: 10,
                                    length2: 20
                                }
                            },
                            itemStyle: {
                                normal: {
                                    color: '#c23531',
                                    shadowBlur: 200,
                                    shadowColor: 'rgba(0, 0, 0, 0.5)'
                                }
                            }
                        }
                    ]
                };
                this.chartNode.setOption(option);
            }
        },
        mounted() {
            this.$nextTick(() => {
                this.chartNode = echarts.init(this.$refs.charNode);
                this.renderChart();
            });
        }
    }
</script>