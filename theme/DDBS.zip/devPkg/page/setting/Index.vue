/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="system-setting-container">
        <div class="container">
            <template-node v-if="step === 'tpl'"
                           @templatePick="templatePick"
                           :list="templateList"
                           :currentName="personalizedCache.mainThemeName"></template-node>
            <component-node v-else
                            :theme="pageData"
                            :list="componentList"
                            :group="componentGroup"
                            ref="componentNode"></component-node>
        </div>
        <div class="footer-container">
            <div class="item" @click="stepEvent(step)">{{step === 'comp' ? '上一步' : '下一步'}}</div>
            <div class="item" v-show="step === 'comp'" @click="stepEvent('finish')">完&nbsp;&nbsp;成</div>
        </div>
    </div>
</template>

<script>
    import TemplateNode from "./tpl/Template.vue";
    import ComponentNode from "./tpl/Components.vue";

    import MonitorApi from "../../api/monitor";
    import ModuleConf from "../../config/module.config";
    import ConstConf from "../../config/const.config";

    import { mapGetters } from "vuex";
    export default {
        components: {
            TemplateNode,
            ComponentNode
        },
        computed: {
            ...mapGetters({
                personalizedCache: "getPersonalizedData"
            })
        },
        /**
         * 参数说明
         * @define {String} step 操作步骤参数，tpl 选择模板步骤，comp 选择组件步骤
         * @define {Array} componentGroup 组件组列表对象
         * @define {Array} componentList 组件列表对象
         * @define {Array} templateList 模板列表对象
         * @define {Object} pageData 页面选择数据
         */
        data() {
            return {
                step: 'tpl',
                componentGroup: [],
                componentList: [],
                templateList: [],
                pageData: {
                    mainThemeName: '',
                    themeDesc: '',
                    homeLayout: '',
                    homeNavigator: '',
                    colors: {},
                    blocks: []
                }
            }
        },
        methods: {
            /* 步数点击事件 */
            async stepEvent(type) {
                if (type === 'finish') {
                    let list = await this.$refs.componentNode.getCurrentActiveComponent();
                    this.pageData.blocks = list;
                    let userID = sessionStorage.getItem(ConstConf.USER_ID_STORAGE);
                    if (!!userID && userID !== "") {

                        let str = JSON.stringify(this.pageData);
                        /*this.$zznode.loading.show();
                        let result = await MonitorApi.addUserCustomized({userID, templateContent: str});
                        this.$zznode.loading.hide();
                        if (result.data && result.data.desc === '操作成功') {
                            sessionStorage.setItem('customized_finish_request_refresh', 'require');
                            setTimeout(() => {
                                this.$router.push({path: '/home'});
                            }, 300);
                        } else {
                            alert('保存失败');
                        }*/

                        /* 本地mock数据使用 */
                        this.$zznode.loading.show();
                        sessionStorage.setItem('customized_cache_data', str);
                        setTimeout(() => {
                            this.$zznode.loading.hide();
                            sessionStorage.setItem('customized_finish_request_refresh', 'require');
                            this.$router.push({path: '/home'});
                        }, 1000);
                    } else {
                        alert('未登陆或用户信息丢失');
                    }
                } else {
                    this.step = type === 'tpl' ? 'comp' : 'tpl';
                }
            },
            /* 选择模板 */
            templatePick(key) {

                /* 设置当前主题主数据 */
                let obj = this.templateList.find(it => it.mainThemeName === key);
                this.pageData = JSON.parse(JSON.stringify(obj));

                /* 根据模块组设置主题所有组件数据 */
                let temp = [];
                let tpl = JSON.parse(JSON.stringify(ModuleConf[obj.group]));

                /* 遍历所有组件引擎 */
                let list = JSON.parse(JSON.stringify(ModuleConf.TEMPLATE_ENGINES));
                list.map(it => {
                    let idx = tpl.findIndex(oo => oo.key === it.def);
                    if (idx > -1) {
                        temp.push(it);
                    } else {
                        temp.push(it);
                    }
                });
                this.componentList = temp;

                /* 设置所有模块组数据 */
                let gl = JSON.parse(JSON.stringify(ModuleConf.COMPONENTS_GROUPS));
                tpl.map(it => {
                    let cg = gl.find(oo => oo.key === it.key);
                    if (!!cg) {
                        it.title = cg.title;
                        it.column = cg.column;
                        it.row = cg.row;
                    } else {
                        it.title = "";
                        it.column = "";
                        it.row = "";
                    }
                });

                this.componentGroup = tpl;

            }
        },
        created() {
            this.templateList.push(ModuleConf.DEFAULT_TEMPLATE_DATA);
            this.templateList.push(ModuleConf.BLACK_TEMPLATE_DATA);
            this.templateList.push(ModuleConf.HOLIDAY_TEMPLATE_DATA);
            this.templateList.push(ModuleConf.BRIGHT_TEMPLATE_DATA);
            this.templateList.push(ModuleConf.SKY_TEMPLATE_DATA);

            this.$root.eventBus.$emit(ConstConf.NAVIGATOR_PROPS, {type: 'show', show: false});
        }
    }
</script>