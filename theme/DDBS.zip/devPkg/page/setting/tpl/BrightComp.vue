/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="setting-component-container">
        <div class="top">
            <div class="bright-setting-item"
                 v-for="item of topList"
                 :style="{'width': `${item.width}%`, 'height': `${item.height}%`}"
                 :key="item.id">
                <div class="container">
                    <div class="setting-component-setting" @click="deleteEvent('top', item)">&#xe6b8;</div>
                    <div class="setting-component-block"
                         v-for="it of item.list"
                         :class="{'active': it.active}"
                         @click="pickItem('top', item, it)"
                         :key="`components_key_${it.id}`">
                        <i v-html="it.icon"></i>
                        <span class="text">{{it.myTitle}}</span>
                        <span class="setting-hover-box">{{it.myTitle}}</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="bottom">
            <div class="bright-setting-item"
                 v-for="item of bottomList"
                 :style="{'width': `${item.width}%`, 'height': `${item.height}%`}"
                 :key="item.id">
                <div class="container">
                    <div class="setting-component-setting" @click="deleteEvent('bottom', item)">&#xe6b8;</div>
                    <div class="setting-component-block"
                         v-for="it of item.list"
                         :class="{'active': it.active}"
                         @click="pickItem('bottom', item, it)"
                         :key="`components_key_${it.id}`">
                        <i v-html="it.icon"></i>{{it.myTitle}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import ConstConf from "../../../config/const.config";

    export default {
        props: {
            list: Array,
            group: Array
        },
        data() {
            return {
                topList: [
                    {id: 'bright_block_key_001', width: '42.650', type: 'center', height: '100', key: 'leftSideE', list: []},
                    {id: 'bright_block_key_002', width: '28.675', height: '50', key: 'leftSideA', list: []},
                    {id: 'bright_block_key_003', width: '28.675', height: '50', key: 'leftSideB', list: []},
                    {id: 'bright_block_key_004', width: '28.675', height: '50', key: 'leftSideF', list: []},
                    {id: 'bright_block_key_005', width: '28.675', height: '50', key: 'leftSideG', list: []}
                ],
                bottomList: [
                    {id: 'bright_block_key_006', width: '33.333', height: '100', key: 'leftSideC', list: []},
                    {id: 'bright_block_key_007', width: '33.333', type: 'top', height: '100', key: 'leftSideD', list: []},
                    {id: 'bright_block_key_008', width: '33.333', height: '100', key: 'leftSideH', list: []}
                ]
            }
        },
        methods: {
            /* 组建块删除方法 */
            deleteEvent(type, item) {
                let [temp, dist] = [[], []];
                /* 如果删除顶部元素 */
                if (type === 'top' && this.topList.length > 1) {
                    temp = JSON.parse(JSON.stringify(this.topList));
                    if (item.key === 'leftSideE') {
                        for (let i = 0;i < temp.length;i ++) {
                            let obj = temp[i];
                            if (obj.key !== item.key) {
                                obj.width = obj.width === '28.675' ? '50' : '100';
                                dist.push(obj);
                            }
                        }
                    } else {
                        let mapIdx = temp.findIndex(oo => oo.key === 'leftSideE');
                        let len = temp.length;
                        if (mapIdx > -1) {
                            for (let i = 0;i < temp.length;i ++) {
                                let obj = temp[i];
                                if (obj.key !== item.key) {
                                    if (obj.key === 'leftSideE') {
                                        obj.width = len > 2 ? '42.650' : '100';
                                    } else {
                                        if (len === 3) obj.height = '100';
                                        if (len === 4) obj.width = '57.35';
                                        if (len === 5) {
                                            if (item.key === 'leftSideA' || item.key === 'leftSideB') {
                                                if (obj.key === 'leftSideA' || obj.key === 'leftSideB') obj.width = '57.35';
                                            }
                                            if (item.key === 'leftSideF' || item.key === 'leftSideG') {
                                                if (obj.key === 'leftSideF' || obj.key === 'leftSideG') obj.width = '57.35';
                                            }
                                        }
                                    }
                                    dist.push(obj);
                                }
                            }
                        } else {
                            for (let i = 0;i < temp.length;i ++) {
                                let obj = temp[i];
                                if (obj.key !== item.key) {
                                    if (len === 2) obj.height = '100';
                                    if (len === 3) obj.width = '100';
                                    if (len === 4) {
                                        if (item.key === 'leftSideA' || item.key === 'leftSideB') {
                                            if (obj.key === 'leftSideA' || obj.key === 'leftSideB') obj.width = '100';
                                        } else {
                                            if (obj.key === 'leftSideF' || obj.key === 'leftSideG') obj.width = '100';
                                        }
                                    }
                                    dist.push(obj);
                                }
                            }
                        }
                    }
                    this.topList = dist;
                }

                /* 如果删除底部元素 */
                if (type === 'bottom' && this.bottomList.length > 1) {
                    temp = JSON.parse(JSON.stringify(this.bottomList));
                    for (let i = 0;i < temp.length;i ++) {
                        let obj = temp[i];
                        if (obj.key !== item.key) {
                            obj.width = (100 / (temp.length - 1)).toFixed(3);
                            dist.push(obj);
                        }
                    }
                    this.bottomList = dist;
                }
            },
            /* 选择组件方法 */
            pickItem(type, item, it) {
                let temp = [];
                if (type === 'top') {
                    temp = JSON.parse(JSON.stringify(this.topList));
                } else {
                    temp = JSON.parse(JSON.stringify(this.bottomList));
                }
                temp.map(oo => {
                    if (oo.key === item.key) {
                        oo.list.map(bb => {
                            if (bb.id === it.id) bb.active = !bb.active;
                        })
                    }
                });
                if (type === 'top') {
                    this.topList = temp;
                } else {
                    this.bottomList = temp;
                }
            },
            /* 组织页面数据 */
            assembleData() {
                /* 根据嫣红模板独有属性设置组件组行列样式 */
                let top = JSON.parse(JSON.stringify(this.topList));
                let bot = JSON.parse(JSON.stringify(this.bottomList));


                top.map(it => {
                    for (let i = 0;i < this.list.length;i ++) {
                        let item = JSON.parse(JSON.stringify(this.list[i]));
                        if (it.key === "leftSideE" && item.type === "center") {
                            item.active = it.key === item.def;
                            it.list.push(item);
                        }
                        if (it.key !== "leftSideD" && it.key !== "leftSideE") {
                            item.active = it.key === item.def;
                            it.list.push(item);
                        }
                    }
                });
                bot.map(it => {
                    for (let i = 0;i < this.list.length;i ++) {
                        let item = JSON.parse(JSON.stringify(this.list[i]));
                        if (it.key === "leftSideD" && item.type === "top") {
                            item.active = it.key === item.def;
                            it.list.push(item);
                        }
                        if (it.key !== "leftSideD" && it.key !== "leftSideE") {
                            item.active = it.key === item.def;
                            it.list.push(item);
                        }
                    }
                });

                this.topList = top;
                this.bottomList = bot;
            },

            /* 获取组件选择数据 */
            getActiveComponent() {
                console.log(this.list);
                console.log(this.group);

                let temp = [];
                this.group.map(item => {
                    let childObj = this.topList.find(oo => oo.key === item.key);
                    if (!childObj) childObj = this.bottomList.find(oo => oo.key === item.key);
                    if (childObj) {
                        let child = {
                            "key": childObj.key,
                            "pos": item.pos,
                            "type": item.type,
                            "title": item.title,
                            "column": childObj.width,
                            "row": childObj.height,
                            "compName": []
                        };
                        childObj.list.map(oo => {
                            if (oo.active) child.compName.push(oo);
                        });

                        temp.push(JSON.parse(JSON.stringify(child)));
                    }
                });


                return temp;
            }
        },
        created() {
            this.assembleData();
            this.$root.eventBus.$emit(ConstConf.NAVIGATOR_PROPS, {type: 'show', show: false});
        }
    }
</script>