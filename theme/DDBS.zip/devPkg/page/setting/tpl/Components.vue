/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <components :is="componentTheme" ref="compNode" :list="list" :group="group"></components>
</template>

<script>
    import DefaultComp from "./DefaltComp.vue";
    import BrightComp from "./BrightComp.vue";

    export default {
        components: {
            'default-comp': DefaultComp,
            'bright-comp': BrightComp,        },
        props: {
            theme: Object,
            list: Array,
            group: Array
        },
        data() {
            return {
                componentTheme: 'default-comp'
            }
        },
        methods: {
            /* 获取组件选择数据 */
            async getCurrentActiveComponent() {
                let result = await this.$refs.compNode.getActiveComponent();
                return result;
            }
        },
        created() {

            /* 根据不同的设置需要设置不同的组件设置规则和样式内容 */
            this.componentTheme = this.theme.mainThemeName === "bright-template" ? "bright-comp" : "default-comp";
        }
    }
</script>