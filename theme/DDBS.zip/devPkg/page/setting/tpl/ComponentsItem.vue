/*********************************************************************
* Created by deming-su on 2017/12/30
*********************************************************************/

<template>
    <div :class="cls">
        <div class="item"
             v-for="(item, i) in compList"
             :style="[{'height': `${(item.row / 12 * 100).toFixed(2)}%`}]"
             :key="`component_key_00${i}`">
            <div class="container">
                <div class="setting-component-setting" @click="deleteEvent(item)">&#xe6b8;</div>
                <div class="setting-component-block"
                     v-for="it in item.list"
                     :class="[{'active': it.active}]"
                     @click="pickItem(item, it)"
                     :key="it.id">
                    <i v-html="it.icon"></i>
                    <span class="text">{{it.myTitle}}</span>
                    <span class="setting-hover-box">{{it.myTitle}}</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    export default {
        props: {
            cls: String,
            list: Array
        },
        data() {
            return {
                resourceList: [],
                compList: []
            }
        },
        methods: {
            /* 组件块删除事件 */
            deleteEvent(item) {
                if (this.compList.length > 1) {
                    let temp = [];
                    let len = this.compList.length - 1;
                    for (let oo of this.compList) {
                        if (oo.key !== item.key) {
                            oo.row = 12 / len;
                            temp.push(oo);
                        }
                    }
                    this.compList = temp;
                }
            },
            /* 选择事件 */
            pickItem(parent, child) {
                let temp = [];
                for (let item of this.compList) {
                    if (parent.key === item.key) {
                        for (let it of item.list) {
                            if (it.id === child.id) {
                                it.active = !it.active;
                            }
                        }
                    }
                    temp.push(item);
                }
                return temp;
            },
            /* 获取选中数据 */
            getActiveData() {
                let temp = [];
                for (let item of this.compList) {
                    let child = [];
                    for (let it of item.list) {
                        if (it.active) {
                            child.push({
                                id: it.id,
                                icon: it.icon,
                                def: it.def,
                                type: it.type,
                                name: it.name,
                                mainTitle: it.mainTitle,
                                myTitle: it.myTitle,
                                title: it.title
                            });
                        }
                    }
                    temp.push({
                        key: item.key,
                        pos: item.pos,
                        type: item.type,
                        title: item.title,
                        column: item.column,
                        row: item.row,
                        compName: child
                    });
                }
                return temp;
            }
        },
        created() {
            this.resourceList = JSON.parse(JSON.stringify(this.list));
            this.compList = JSON.parse(JSON.stringify(this.list));
        }
    }
</script>