/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="setting-component-container">
        <item-node ref="leftNode" cls="left" :list="leftList"></item-node>
        <item-node ref="centerNode" cls="center" :list="centerList"></item-node>
        <item-node ref="rightNode" cls="right" :list="rightList"></item-node>
    </div>
</template>

<script>
    import ItemNode from "./ComponentsItem.vue";
    import ConstConf from "../../../config/const.config";

    export default {
        components: {
            ItemNode
        },
        props: {
            list: Array,
            group: Array
        },
        data() {
            return {
                leftList: [],
                centerList: [],
                rightList: []
            }
        },
        methods: {
            /* 组件块删除事件 */
            deleteEvent() {

            },
            /* 组织页面数据 */
            assembleData() {

                for (let item of this.group) {
                    item.list = this.getComponentList(item.type, item.key);
                    switch (item.pos) {
                        case 'left':
                            this.leftList.push(item);
                            break;
                        case 'center':
                            this.centerList.push(item);
                            break;
                        case 'right':
                            this.rightList.push(item);
                            break;
                        default:
                            break;
                    }
                }
            },
            /* 根据类型获取列表数据, 并设置默认选中状态 */
            getComponentList(type, key) {
                let temp = [];
                let distData = JSON.parse(JSON.stringify(this.list));
                for (let item of distData) {
                    if (item.type === type) {
                        item.active = item.def === key;
                        temp.push(item);
                    }
                }
                return temp;
            },
            /* 获取组件选择数据 */
            getActiveComponent() {
                let ll = this.$refs.leftNode.getActiveData();
                let cl = this.$refs.centerNode.getActiveData();
                let rl = this.$refs.rightNode.getActiveData();
                return ll.concat(cl, rl);
            }
        },
        created() {
            this.assembleData();
            this.$root.eventBus.$emit(ConstConf.NAVIGATOR_PROPS, {type: 'show', show: false});
        }
    }
</script>