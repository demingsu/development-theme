/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="setting-template-container">
        <div class="container">
            <div class="item" v-for="item in templateList" :key="item.id">
                <i class="icon" v-if="item.active"></i>
                <img :src="item.imgSrc" alt="">
                <div class="opt-layer" :class="[{'active': item.active}]">
                    <span class="desc">{{item.title}}</span>
                    <input type="text" v-model="item.name">
                    <span class="btn"
                          v-show="!item.active"
                          @click="pickItem(item)">选&nbsp;&nbsp;择</span>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import ConstConf from "../../../config/const.config";

    export default {
        props: {
            list: Array,
            currentName: String
        },
        data() {
            return {
                defaultImg: require('../../../images/common/default-tpl.png'),
                imgSrc: [
                    {key: 'default-template', img: require('../../../images/common/default-tpl.png')},
                    {key: 'black-template', img: require('../../../images/common/black-tpl.png')},
                    {key: 'holiday-template', img: require('../../../images/common/holiday-tpl.png')},
                    {key: 'bright-template', img: require('../../../images/common/bright-tpl.png')},
                    {key: 'sky-template', img: require('../../../images/common/sky-tpl.png')}
                ],
                templateList: []
            }
        },
        methods: {
            pickItem(item) {
                let temp = [];
                this.templateList.map(it => {
                    it.active = it.id === item.id;
                    temp.push(it);
                });
                this.templateList = temp;
                this.$emit('templatePick', item.key);
            }
        },
        created() {
            let temp = [];

            if (!!this.list) {
                this.list.map((it, i) => {
                    let img = this.imgSrc.find(oo => oo.key === it.mainThemeName);
                    let obj = {
                        id: `template_item_key_00${i}`,
                        key: it.mainThemeName,
                        title: it.themeDesc,
                        name: it.homeNavigator,
                        imgSrc: !!img ? img.img : this.defaultImg,
                        active: it.mainThemeName === this.currentName
                    };
                    temp.push(obj);
                    if (obj.active) {
                        this.$emit('templatePick', obj.key);
                    }
                });

                this.templateList = temp;
            }
            this.$root.eventBus.$emit(ConstConf.NAVIGATOR_PROPS, {type: 'show', show: false});
        }
    }
</script>