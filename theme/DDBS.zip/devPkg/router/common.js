/*********************************************************************
 * defined Home page router file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 错误路径页面 */
const NotFound = () => {
    return import(/* webpackChunkName: "NotFound"*/"../page/default/NotFound.vue");
};

const routes = [
    {path: "/not/found", component: NotFound, meta: { requestLogin: false }}
];

export default routes;