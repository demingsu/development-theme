/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/**
 * 状态数据库对象
 * @define {Object} personalizedCache 个性化页面缓存数据
 * @define {Object} systemCustomizedColors 页面个性化颜色数据
 * @define {Array} healthGridScoreData 网格健康分数数据
 */
const state = {
    personalizedCache: null,
    systemCustomizedColors: {},
	healthGridScoreData: []
};

/**
 * 状态数据库设值方法
 * @return {Function} personalizedCache 个性化页面数据
 * @return {Function} getSystemCustomizedColors 获取质差排行地图区域请求数据
 */
const getters = {
    getPersonalizedData: state => {
    	if (!!state.personalizedCache) {
    		return state.personalizedCache;
		} else {
    		return JSON.parse(sessionStorage.getItem('current_user_personalized_data') || '{}');
		}
    },
    getSystemCustomizedColors: state => state.systemCustomizedColors,
	getHealthGridScoreData: state => state.healthGridScoreData
};

/**
 * dispatch action 方法
 * @define {Function} setPersonalizedData 设置个性化数据
 * @define {Function} setSystemCustomizedColors 设置当前用户颜色个性化数据
 */
const actions = {
	setPersonalizedData({commit}, {data}) {
    	commit('mutationPersonalized', {data});
	},
    setSystemCustomizedColors({commit}, {data}) {
        commit('mutationSystemCustomizedColors', {data});
	},
    setHealthGridScoreData({commit}, {data}) {
        commit('mutationHealthGridScoreData', {data});
	}
};

const mutations = {
    mutationPersonalized(state, {data}) {

		/* 扭转数据状态 */
		state.personalizedCache = data;
	},
    mutationSystemCustomizedColors(state, {data}) {

		/* 扭转数据状态 */
		state.systemCustomizedColors = data;

	},
    mutationHealthGridScoreData(state, {data}) {

		/* 扭转数据状态 */
		state.healthGridScoreData = data;

	}
};

export default {
	state,
	getters,
	actions,
	mutations
};