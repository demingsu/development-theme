/*********************************************************************
 * user right file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 导入api接口 */
import ConstVariable from "../config/const.config";

/* 检查是否存在此路由 */
let isExistPath = (path, routers) => {
    for (let item of routers) {
        let flag = loopPath(path, item);
        if (flag) {
            return flag;
        }
    }
    return false;
};

let loopPath = (path, item) => {
    if (item.path === path) {
        return true;
    }
    if (!!item.children && item.children.length > 0) {
        for (let it of item.children) {
            path = path.replace(`${item.path}/`, "");
            if (loopPath(path, it)) {
                return true;
            }
        }
    }
    return false;
};

/* 是否是默认不要做任何校验的路由 */
let isDefaultRoute = (path) => {
    return ConstVariable.DEFAULT_ROUTES.findIndex(oo => oo.path === path) > -1;
};

/* 是否有用户信息过来，如果有需要缓存用户信息，如果用户信息不一致，则保存后来信息 */
let cacheUserInfo = () => {
    let search = window.location.search.replace('?', '');
    if (search.indexOf('user_id') > -1) {
        let list = search.split('&');
        let userId = "";
        list.map(it => {
            if (it.indexOf('user_id') > -1) userId = it.replace('user_id=', '');
        })
        sessionStorage.setItem(ConstVariable.USER_ID_STORAGE, userId);
    }
};

const validateRight = (to, from, next, routers) => {

    /* 缓存用户信息 */
    cacheUserInfo();

    /* 是否是默认路由 */
    if (!!isDefaultRoute(to.path)) {
        next();
        return;
    }

    /* 是否存在访问路由 */
    if (!isExistPath(to.path, routers)) {
        next('/not/found');
        return;
    }

    /* 通过校验则进入下一步路由 */
    next();
};

export default validateRight;