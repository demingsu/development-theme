/*********************************************************************
 * common util function file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 16进制颜色转rgba */
let hexToRgba = (val, opacity) => {
    if (!opacity) opacity = 1;
    if (/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/.test(val)) {
        /* 自动补全3位16进制字符串 */
        if (val.length === 4) {
            let str = "#";
            for (let i = 1; i < 4; i ++) {
                let char = val.slice(i, i + 1);
                str += char.concat(char);
            }
            val = str;
        }
        let res = [];
        /* 遍历字符串转为十进制rgb */
        for (let i = 1; i < 7; i += 2) {
            /* 两个方法都可以转 */
            res.push(parseInt(val.slice(i, i + 2), 16));
        }
        res.push(opacity);
        val = `rgba(${res.join(',')})`;
    }
    return val;
};

/* rgba颜色转16进制 */
let rgbToHex = (val) => {
    val = val.toLowerCase().replace(/\s/g, '');
    /* 测试提交的字符串 */
    if (/^rgb\([0-9]{1,3},[0-9]{1,3},[0-9]{1,3}\)$/.test(val)) {
        /* 拆分字符串 */
        let arr = val.replace(/rgb|\(|\)|\s/g, '').split(",");
        let str = "#";
        for (let i = 0;i < arr.length;i ++) {
            /* 编码数字到16进制 */
            let hex = Number(arr[i]).toString(16);
            str += hex.length < 2 ? "0" + hex : hex;
        }
        val = str;
    }
    return val;
};

/**
 *  日期转换方法
 *  @param YYYY-MM-DD hh:mm:ss
 */
let dateFormat = (type, val) => {
    let date = val ? new Date(/^[0-9]*$/g.test(val) ? val * 1 : val) : new Date();
    let YYYY = date.getFullYear() + '';
    let m = date.getMonth() + 1;
    let MM = m > 9 ? m + '' : '0' + m;
    let d = date.getDate();
    let DD = d > 9 ? d + '' : '0' + d;
    let h = date.getHours();
    let hh = h > 9 ? h + '' : '0' + h;
    let $m = date.getMinutes();
    let mm = $m > 9 ? $m + '' : '0' + $m;
    let s = date.getSeconds();
    let ss = s > 9 ? s + '' : '0' + s;
    let obj = { YYYY, MM, DD, hh, mm, ss};

    return type.replace(/(YYYY)|(MM)|(DD)|(hh)|(mm)|(ss)/g, (key) => obj[key]);
};

/**
 *  去掉字段的两端空格
 *  @param Object
 */
let trimObject = (obj) => {
    let res = {};
    for (let name in obj) {
        if (obj.hasOwnProperty(name)) {
            res[name] = obj[name].replace(/(^\s*)|(\s*$)/g, '');
        }
    }

    return res;
};

/**
 *  去掉字段的两端空格
 *  @param Object
 */
let fileSize = (size, count) => {
    if (!count) count = 0;
    if (isNaN(size)) return 0;
    var names = ['byte', 'KByte', 'MB', 'GB', 'TB'];
    if (size < 1024) {
        return size + names[count];
    } else {
        return fileSize(parseFloat((size / 1024).toFixed(2)), ++count);
    }
};

/**
 *  计算分页
 *  @param total      总数
 *  @param page       当前页码
 *  @param size       每页条数
 */
let pagingCount = (total, page, size) => {
    let res = ['1'];
    let tp = Math.ceil(total/size);
    if (tp > 7) {
        if (page < 4) {
            res = res.concat(['2', '3', '...', `${tp}`]);
        } else if (page > tp - 3) {
            res = res.concat(['...', `${tp - 2}`, `${tp - 1}`, `${tp}`]);
        } else {
            res = res.concat(['...', `${page - 1}`, `${page}`, `${page + 1}`, '...']);
        }
    } else {
        for (let i = 1;i < tp;i ++) {
            res.push(`${i + 1}`);
        }
    }
    return res;
};

/**
 * 在树形数据中查找对应数据对象
 *  @param item       需要查找的对象
 *  @param tree       树的数据列表
 *  @param key        查找对象的key，默认为id
 */
let findItemInTree = (item, tree, key) => {
    if (!key) key = 'id';
    let nodes = [];
    for (let node of tree) {
        if (loopTree(node, item, nodes, key)) {
            nodes.push(node);
            break;
        }
    }
    return nodes.reverse();
};
let loopTree = (list, item, newList, key) => {
    if (list[key] === item[key]) {
        return true;
    }
    if (list.children && list.children.length > 0) {
        for (let it of list.children) {
            if (loopTree(it, item, newList, key)) {
                newList.push(it);
                return true;
            }
        }
    }
    return false;
};

/**
 * 根据数据对象属性拷贝数据
 * @define {Object} dist 目标数据
 * @define {Object} resource 元数据
 */
let copyDataToDist = (dist, resource) => {
    let obj = JSON.parse(JSON.stringify(dist));
    for (let name in obj) {
        if (resource.hasOwnProperty(name)) obj[name] = resource[name];
    }
    return obj;
};

/**
 * 取小数，不四舍五入
 * @define {Number} dist 目标数据
 * @define {Number} dot 小数数据
 */
let numberFixed = (dist, dot) => {
    let str = dist + '';
    let idx = str.lastIndexOf('.') + 1;
    let dotLen = str.length - idx;
    if (idx > 0) str = str.substring(0, idx + dot);
    if (dotLen < dot) {
        str += '0'.repeat(dot - dotLen);
    }
    return str;
};

/**
 * 替换图片内不为透明的颜色为当前设置颜色
 * @define {String} img 图片base64字节码
 * @define {String} color 替换上的颜色，需要rgb
 */
let replaceImgColor = async (img, color) => {
    let result = await rewriteImageColor(img, color).catch(e => {
        return e;
    });
    if (!!result) return {code: 200, data: result};
};

/* 重写图片数据方法 */
let rewriteImageColor = (img, color) => {
    return new Promise(resolve => {
        let c = color.replace(/rgba|\(|\)|\s/g, '').split(',');

        let canvas = document.createElement('canvas');
        let ctx = canvas.getContext('2d');

        let image = new Image();
        image.src = img;

        image.onload = () => {
            let w = image.width;
            let h = image.height;
            canvas.width = w;
            canvas.height = h;
            ctx.drawImage(image, 0, 0, w, h, 0, 0, w, h);
            let data = ctx.getImageData(0, 0, w, h);

            /* 每四个数据中的alpha不用修改，alpha值为0~255 */
            for (let i = 0;i < data.data.length;i += 4) {
                if (data.data[i + 3] > 0) {
                    data.data[i] = c[0]*1;
                    data.data[i + 1] = c[1]*1;
                    data.data[i + 2] = c[2]*1;
                }
            }
            ctx.putImageData(data, 0, 0);
            let imageData = canvas.toDataURL();
            resolve(imageData);
        };
    })
};

/**
 * 制作千位分隔符
 * @define {Number} num 图片base64字节码
 */
let makeThousandsNum = num => {
    let str = `${num}`.split('');
    str.reverse();
    let res = [];
    for (let i = 0;i < str.length;i ++) {
        if (i !== 0 && i % 3 === 0) {
            res.push(',');
        }
        res.push(str[i]);
    }
    res.reverse();
    return res.join('');
};

export default {
    dateFormat,
    hexToRgba,
    copyDataToDist,
    trimObject,
    fileSize,
    pagingCount,
    findItemInTree,
    numberFixed,
    rgbToHex,
    replaceImgColor,
    makeThousandsNum
};