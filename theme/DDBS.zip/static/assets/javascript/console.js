/* 添加console在IE9下的支持，仅重写了常用的warn，log，error，assert，debug，info */
;(function() {
    if (!window.console) {
        window.console = {
            warn: function() {
                // 提示信息
            },
            log: function() {
                // 提示信息
            },
            error: function() {
                // 提示信息
            },
            assert: function() {
                // 提示信息
            },
            debug: function() {
                // 提示信息
            },
            info: function() {
                // 提示信息
            }
        };
    }
    if (!window.getSDMapData) {
        window.getSDMapData = function(name, cb) {
            var xhr = new XMLHttpRequest();
            // var url = '../qhbs/static/assets/mapjson/qhprovince/{name}.json';
            var url = '../static/assets/mapjson/qhprovince/{name}.json';
            url = url.replace('{name}', name);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        cb(xhr.responseText);
                    }
                }
            }
            xhr.open('get', url, true);
            xhr.send();
        }
    }
})(window);