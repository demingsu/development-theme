/*********************************************************************
 * Created by deming-su on 2018/12/17
 *********************************************************************/

/* 查看日志线程 */
importScripts('./assets/javascript/socket.io.js');

var socket = null;

self.addEventListener('message', function(e) {
	var data = e.data;
	switch(data.message) {
		case 'test': //socket请求
            self.postMessage({message: 'test', data: {a: 'test : ' + Math.random()}});
			break;
		case 'close':
			closeSocket();
			break;
		case 'destroy':
			closeThread();
			break;
		default:
			self.postMessage({message: 'test ... ...', data: null});
			break;
	}
}, false);

/**
 * 发起socket请求
 * @param url 请求url
 * @param params 请求参数
 * @param emitName 请求方法名称
 */
function startTh(url, params, emitName) {
	socket = io.connect(url, {"connect timeout": 15000});
	if (socket.connect) {
		socket.on("connect", function() {
            self.postMessage({message: 'connected'});
		});

		socket.on("disconnect", function() {
            self.postMessage({message: 'cocket is disconnected.'});
		});
		socket.on('message', function (resData) {
			self.postMessage({message: 'message', data: resData});
		});
	}
}

function closeThread() {
	closeSocket();
	self.close();
}

function closeSocket() {
	if (socket) {
        socket.disconnect();
        socket.close();
        socket = null;
	}
}
