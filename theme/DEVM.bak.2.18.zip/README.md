
# development package
Vue development package for developing large projects based on asynchronous loading module mechanism based on Routing.The development language is ES6/7.

# Vue前端构架-结构目录及使用说明

## 浏览器兼容说明

1. 整体架构支持 >= IE9;(因为Ajax方法使用了formdata对象，如需兼容IE９需要注释formdata对象代码)
2. 最佳体验 >= IE10+

## WEB技术栈

架构于 vue2.5+ && vue-router3.0+ && vuex3.0+ && axios0.17 && webpack3.9+ && gulp
1. vue2.5                      MVVM主体架构
2. vue-router                  路由控制器
3. vuex                        状态数据缓存器
4. axios                       数据异步请求库
5. webpack                     模块化架构工具
6. gulp                        代码检测及压缩、打码构建工具

## 项目结构说明：

1. 在进行项目开发前，请仔细阅读整体开发规则文件，表明不能修改、删除的文件一定需要保留；
2. 整个项目属于单页面开发，所有路由都在入口文件（router/index.js）中进行配置，单独页面功能自行创建新文件进行配置开发；
3. 编译后的文件都存放在dist文件夹，前端发包以dist为准；
4. 所有通用、多页面公用数据状态缓存在Vuex中，按功能进行文件管理，所有功能文件放在（store/**.js）文件夹下，在index.js中进行集成；
5. 所有页面功能开发按功能模块包管理方式并以.vue文件存在；
6. 所有私有组件、指令、过滤器都定义在components文件夹；

## 项目环境安装与运行

1. 安装开发库：
 `拷贝开发库文件到开发项目中`
2. 安装依赖：(需要跳转到对应的项目文件路径，开发环境依赖node8.X LTS版本，需要安装，不能用10.X版本，有node兼容性问题)
 `npm install`
3. 运行项目：(运行前确保依赖安装完成且无失败项)
 `npm run start`
3. 重启项目：(与运行一致，但不会打开首页)
 `npm run restart`
4. 打包发布命令：(发布规则为，只发布dist目录所有文件，nginx指向也指向文件所在目录)
 `npm run deploy`
5. 开发数据联调：(在进行数据联调的过程中，不需nginx代理，直接webpack devServer进行开发)
 `注意请求字段替代或则后端统一配置起始字段`


## 目录结构说明

```
├── file-dictionary/                  （项目名字）
├    ├── checkDir/                    （代码检查结果目录，无需改动，不允许删除）
├    ├── devPkg/                      （项目开发目录，存放vue、vuex开发文件的地方）
├    ├    ├── api/                    （存放本项目所有数据请求方法)
├    ├    ├    ├── login.js           （登陆数据请求接口）
├    ├    ├── components/             （存放本项目自定义的组件)
├    ├    ├    ├── directive.js       （定义本项目自定义指令）
├    ├    ├    ├── filter.js          （定义本项目自定义过滤器）
├    ├    ├    ├── index.js           （项目私有组件导出配置文件）
├    ├    ├    ├── common             （项目私有组件导出配置文件）
├    ├    ├    ├    ├── Menu.vue      （项目menu菜单树，不允许删除，可以不引用）
├    ├    ├    ├    ├── Navigator.vue （项目导航栏，不允许删除，根据自己项目的特性进行修改适配）
├    ├    ├── config/                 （配置文件存在路径，数据以 data.js)
├    ├    ├    ├── const.config.js    （项目静态变量配置文件，不允许删除）
├    ├    ├    ├── index.js           （项目静态资源导出文件，不允许删除）
├    ├    ├    ├── menu.data.js       （项目menu菜单数据，不允许删除）
├    ├    ├    ├── moke.data.js       （项目模拟数据，不允许删除）
├    ├    ├    ├── url.config.js      （项目url的配置文件，不允许删除）
├    ├    ├── images/                 （图片存放目录)
├    ├    ├    ├── common/            （通用图片，不允许删除）
├    ├    ├── pages/                  （业务页面目录)
├    ├    ├    ├── home/              （首页，项目自定义目录）
├    ├    ├    ├── layout/            （默认模板，不允许删除）
├    ├    ├    ├── login/             （默认登录，不允许删除，可以自定义修改或不使用）
├    ├    ├    ├── BaseView.vue       （基础视图组件，主要提供通用方法，不允许删除，可以自定义修改或不使用）
├    ├    ├    ├── Index.vue          （所有界面的入口，不允许删除，可以自定义修改或不使用）
├    ├    ├── router/                 （图片存放目录)
├    ├    ├    ├── Home.js            （项目自定义路由）
├    ├    ├    ├── index.js           （项目路由及菜单和用户权限管理文件，不允许删除，可以自定义修改或不使用）
├    ├    ├    ├── Login.js           （项目自定义登录路由，不允许删除，可以自定义修改或不使用）
├    ├    ├── store/                  （图片存放目录)
├    ├    ├    ├── common.js          （项目通用数据仓库）
├    ├    ├    ├── index.js           （项目数据仓库导出文件，不允许删除，可以自定义修改）
├    ├    ├── styles/                 （样式文件存放目录)
├    ├    ├    ├── common/            （项目通用样式库，不允许删除）
├    ├    ├    ├    ├── index.less    （项目通用样式定义，不允许删除，可以自定义修改）
├    ├    ├    ├    ├── index-media   （项目通用样式媒体定义，不允许删除，可以自定义修改）
├    ├    ├    ├── base.less          （项目基础样式，不允许删除和修改）
├    ├    ├    ├── common.less        （项目通用样式定义文件，不允许删除，可以自定义修改）
├    ├    ├    ├── component.less     （项目私有组件或组件样式重写，不允许删除，可以自定义修改）
├    ├    ├    ├── main.less          （项目样式导出文件，不允许删除，可以自定义修改）
├    ├    ├── util/                   （业务逻辑的目录）
├    ├    ├    ├── ...                （文件目录结构大致上对应componets目录结构）
├    ├    └── main.js                 （入口及样式、组件、路由、指令、过滤器导入文件，基础vue，不允许删除）
├    ├── static/                      （静态资源文件目录）
├    ├    ├── assets                  （所有图片文件，不允许私自添加图片到此目录）
├    ├    ├    ├── font               （所有字体库文件）
├    ├    ├    ├── font.css           （所有字体库字体定义文件，仅定义字体，不允许书写样式到此文件）
├    ├    ├── images                  （所有图片文件，不允许私自添加图片到此目录）
├    ├    ├── style                   （所有样式文件，不允许私自添加样式到此目录）
├    ├    ├── favicon.ico             （项目私有偏好图片，与页面的title图标一致）
├    ├── .babelrc                     （babel-loader依赖配置文件）
├    ├── .eslintrc.js                 （eslint文件检查规则配置文件）
├    ├── .gitignore                   （git提交忽略文件）
├    ├── .stylelintrc                 （样式eslint检查规则配置文件）
├    ├── ChunkCleanPlugin.js          （打包前删除static本地缓存文件插件）
├    ├── gulpfile.js                  （gulp压缩、合并、打码配置文件）
├    ├── index.html                   （项目首页主入口）
├    ├── package.json                 （项目所有依赖及执行命令配置文件）
├    ├── webpack.config.js            （webpack打包、语言解析、图片解析、样式编译配置文件）
```
