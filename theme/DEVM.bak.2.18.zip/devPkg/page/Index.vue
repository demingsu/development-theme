/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <view-box class="page-container" :class="[{'pt0': !showHeader}]">
        <x-header slot="header"
                  class="main-header"
                  :left-options="leftOptions" v-show="showHeader">This is a header</x-header>
        <router-view></router-view>
    </view-box>
</template>

<script>
    import { ViewBox, XHeader } from "vux";

    export default {
        components: {
            XHeader,
            ViewBox
        },
        data() {
            return {
                showHeader: false,
                leftOptions: {
                    showBack: false
                }
            }
        }
    };
</script>