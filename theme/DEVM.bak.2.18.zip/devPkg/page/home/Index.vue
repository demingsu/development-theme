/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div>
        <swiper :list="swiperList"
                :show-dots="true"
                dots-position="center"
                :auto="true"
                :loop="true"
                :interval="3800"
                height="180px"
                :duration="280"></swiper>
        <span class="home-form-label">业务开通进度查询</span>
        <group slot="content" class="home-form-p10">
            <x-input title="客户名称"></x-input>
            <x-address title="地址选择" v-model="addressValue" raw-value :list="addressData" value-text-align="left"></x-address>
            <x-input title="验证码">
                <img slot="right-full-height" src="https://ws1.sinaimg.cn/large/663d3650gy1fq684go3glj203m01hmwy.jpg">
            </x-input>
        </group>
        <x-button mini plain type="primary" style="border-radius: 99px; width: 80%; margin: 15px 10%; height: 36px;">查询</x-button>
    </div>
</template>

<script>
    import { Swiper, Card, Group, XInput, XAddress, ChinaAddressData, Flexbox, FlexboxItem, XButton } from "vux";

    export default {
        components: {
            Swiper,
            Card,
            Group,
            XInput,
            XAddress,
            Flexbox,
            FlexboxItem,
            XButton
        },
        /**
         * 所有参数变量说明
         * paging             boolean   是否需要分页
         */
        data() {
            return {
                swiperList: [],
                addressValue: [],
                addressData: ChinaAddressData
            }
        },
        methods: {

        },
        created() {
            for (let i = 1;i < 5;i ++) {
                this.swiperList.push({
                    url: "javascript:;",
                    img: require(`../../images/home/home_banner_00${i}.png`),
                    title: "",
                    fallbackImg: ""
                });
            }
        }
    }
</script>