/*********************************************************************
 * user right file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 导入api接口 */
import ConstVariable from "../config/const.config";

/* 检查是否存在此路由 */
let isExistPath = (path, routers) => {
    for (let item of routers) {
        let flag = loopPath(path, item);
        if (flag) {
            return flag;
        }
    }
    return false;
};

let loopPath = (path, item) => {
    if (item.path === path) {
        return true;
    }
    if (!!item.children && item.children.length > 0) {
        for (let it of item.children) {
            path = path.replace(`${item.path}/`, "");
            if (loopPath(path, it)) {
                return true;
            }
        }
    }
    return false;
};

/* 是否是默认不要做任何校验的路由 */
let isDefaultRoute = (path) => {
    return ConstVariable.DEFAULT_ROUTES.findIndex(oo => oo.path === path) > -1;
};

const validateRight = (to, from, next, routers) => {

    /* 是否是默认路由 */
    if (!!isDefaultRoute(to.path)) {
        next();
        return;
    }

    /* 是否存在访问路由 */
    if (!isExistPath(to.path, routers)) {
        next('/not/found');
        return;
    }

    /* 通过校验则进入下一步路由 */
    next();
};

export default validateRight;