/*********************************************************************
* Vue BaseLayout file
* Created by deming-su on 2019/1/31
*********************************************************************/

<template>
    <view-box class="layout-header-padding">
        <x-header v-if="showHeader" slot="header" :left-options="{showBack: false}">
            <span @click="backEvent()" v-if="showBack" class="layout-header-icon back" slot="left"></span>
            {{pageTitle}}
            <span @click="backEvent('/home')" v-if="showHome" class="layout-header-icon" slot="right"> </span>
        </x-header>
        <div class="layout-body-container" :style="{top: showHeader ? '46px' : 0}">
            <slot></slot>
        </div>
    </view-box>
</template>
<script>
    export default {
        /**
         * 属性参数释义
         * @param {Boolean} showFooter 是否显示底部按钮组
         * @param {Boolean} showBack 是否显示返回按钮
         * @param {Boolean} showHome 是否显示返回首页按钮
         */
        props: {
            title: String,
            showBack: {
                type: Boolean,
                default: true
            },
            showHome: {
                type: Boolean,
                default: true
            }
        },
        computed: {
            showHeader() {
                return this.pageTitle && this.pageTitle !== '';
            }
        },
        /**
         * 页面参数释义
         */
        data() {
            return {
                pageTitle: ''
            }
        },
        methods: {
            /* 返回事件 */
            backEvent(path) {
                if (path) {
                    this.$router.push({path: path});
                } else {
                    this.$router.go(-1);
                }
            }
        },
        /**
         * 页面初始化
         */
        created() {
            this.pageTitle = this.title;

            /* 动态修改标题方法 */
            this.$root.eventBus.$on('changeMainTitle', d => {
                if (d.type === 'text') {
                    this.pageTitle = d.title;
                }
            });
        }
    }
</script>