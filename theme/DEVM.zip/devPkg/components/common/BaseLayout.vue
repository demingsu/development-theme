/*********************************************************************
* Vue BaseLayout file
* Created by deming-su on 2019/1/31
*********************************************************************/

<template>
    <view-box>
        <x-header slot="header" :left-options="{showBack: false}">
            <span @click="backEvent()" v-if="showBack" class="layout-header-icon back" slot="left"></span>
            {{pageTitle}}
            <span @click="backEvent('/home')" v-if="showHome" class="layout-header-icon" slot="right"> </span>
        </x-header>
        <slot></slot>
    </view-box>
</template>
<script>
    export default {
        /**
         * 属性参数释义
         * @param {Boolean} showFooter 是否显示底部按钮组
         * @param {Boolean} showBack 是否显示返回按钮
         * @param {Boolean} showHome 是否显示返回首页按钮
         */
        props: {
            title: String,
            showBack: {
                type: Boolean,
                default: true
            },
            showHome: {
                type: Boolean,
                default: true
            }
        },
        /**
         * 页面参数释义
         */
        data() {
            return {
                pageTitle: '',
                tabList: [
                    {id: 'footer_tab_key_001', key: 'user', name: '客户查询', path: '/user', cls: 'user', active: true},
                    {id: 'footer_tab_key_002', key: 'coverage', name: '预覆盖', path: '/coverage', cls: 'coverage', active: false},
                    {id: 'footer_tab_key_003', key: 'order', name: '工单监控', path: '/order', cls: 'order', active: false},
                    {id: 'footer_tab_key_004', key: 'defend', name: '重保管理', path: '/defend', cls: 'defend', active: false},
                    {id: 'footer_tab_key_005', key: 'performance', name: '性能管理', path: '/performance', cls: 'performance', active: false},
                ]
            }
        },
        methods: {
            /* 标签点击切换事件 */
            tabChangeEvt(index) {
                let path = this.tabList[index];
                if (path && path.path) this.$router.push({path: path.path});
            },
            /* 返回事件 */
            backEvent(path) {
                if (path) {
                    this.$router.push({path: path});
                } else {
                    this.$router.go(-1);
                }
            }
        },
        /**
         * 页面初始化
         */
        created() {
            this.pageTitle = this.title;

            /* 初始菜单设置 */
            if (this.tabKey && this.tabKey !== "") {
                let temp = [];
                this.tabList.map(it => {
                    it.active = it.key === this.tabKey;
                    temp.push(it);
                });

                this.tabList = temp;
            }

            /* 动态修改标题方法 */
            this.$root.eventBus.$on('changeMainTitle', d => {
                if (d.type === 'text') {
                    this.pageTitle = d.title;
                }
            });
        }
    }
</script>