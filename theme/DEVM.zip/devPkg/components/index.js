/*********************************************************************
 * Vue directive & filter register file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import * as Filter from "./filter";
import * as Directive from "./directive";
import * as Components  from './components';

export default {
    install(Vue) {
        if (!Vue.prototype.$shuimo) {
            Vue.prototype.$shuimo = {};
        }
        this.registerFilter(Vue);
        this.registerDirective(Vue);
        this.registerProperty(Vue);
        this.registerComponents(Vue);
    },

    registerFilter(Vue) {
        Vue.filter("dateFormat", Filter.dateFormat);
        Vue.filter("hexToRgba", Filter.hexToRgba);
        Vue.filter("hexToRgba", Filter.fixNumber);
    },

    registerDirective(Vue) {
        Vue.directive("autofocus", Directive.Autofocus);
        Vue.directive("transfer-dom", Components.drt.TransferDom);
    },

    registerProperty(Vue) {
        let prop = Components.prop;
        for (let name in prop) {
            Vue.use(prop[name]);
        }
    },

    /* 注册组件 */
    registerComponents(Vue) {
        let comp = Components.component;
        for (let name in comp) {
            /* 生成组件key */
            let key = name.replace(/[A-Z]/g, (char, index) => {
                let res = char.toLowerCase();
                res = index > 0 ? `-${res}` : res;
                return res;
            });

            /* 注册组件 */
            Vue.component(key, comp[name]);
        }
    }
};