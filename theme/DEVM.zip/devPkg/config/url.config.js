/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 通用 ---start--- */
const BASE_URL = "/api";
// const BASE_URL = "";
/* 通用 ---end--- */

export default {
    BASE_URL,
    HOME_KPI_URL,
    HOME_BUSINESS_URL,
    HOME_AREA_URL,
    HOME_SERVICE_URL,
    DISPATCH_TOTAL_URL,
    DISPATCH_ANALYSIS_URL,
    DISPATCH_WARNING_URL,
    DISPATCH_PASSAGE_URL,
    DISPATCH_DREDGE_URL,
    DISPATCH_SATISFACTION_URL
};