/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 通用 ---start--- */
const BASE_URL = "/api";
// const BASE_URL = "";
/* 通用 ---end--- */

export default {
    BASE_URL
};