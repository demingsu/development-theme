/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-layout :showHome="false">
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
        <div style="height: 100px; border-bottom: solid 1px #eeee;">
            This is home page.
        </div>
    </base-layout>
</template>

<script>

    export default {
        /**
         * 所有参数变量说明
         * paging             boolean   是否需要分页
         */
        data() {
            return {}
        },
        created() {
            this.$vux.loading.show();

            setTimeout(() => {
                this.$vux.loading.hide();
            }, 1000);

            setTimeout(() => {
                this.$root.eventBus.$emit('changeMainTitle',{type: 'text', title: '首页'});
            }, 2600);
        }
    }
</script>