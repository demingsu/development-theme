/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-layout :showHome="false" title="首页">
        <div>
            This is home page.
        </div>
    </base-layout>
</template>

<script>

    export default {
        /**
         * 所有参数变量说明
         * paging             boolean   是否需要分页
         */
        data() {
            return {}
        },
        created() {
            this.$vux.loading.show();

            setTimeout(() => {
                this.$vux.loading.hide();
            }, 1000);
        }
    }
</script>