webpackJsonp([0],Array(432).concat([
/* 432 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue__ = __webpack_require__(491);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue__ = __webpack_require__(600);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_9611bf10_hasScoped_false_buble_transforms_node_modules_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_node_modules_vux_loader_1_2_9_vux_loader_src_template_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_Index_vue__ = __webpack_require__(601);
var disposed = false
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_node_modules_vux_loader_1_2_9_vux_loader_src_script_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_Index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__node_modules_vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_9611bf10_hasScoped_false_buble_transforms_node_modules_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_node_modules_vux_loader_1_2_9_vux_loader_src_template_loader_js_node_modules_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_Index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "devPkg/page/home/Index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-9611bf10", Component.options)
  } else {
    hotAPI.reload("data-v-9611bf10", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 433 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(495), __esModule: true };

/***/ }),
/* 434 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof2 = __webpack_require__(437);

var _typeof3 = _interopRequireDefault(_typeof2);

exports.go = go;
exports.getUrl = getUrl;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function go(url, $router) {
  if (/^javas/.test(url) || !url) return;
  var useRouter = (typeof url === 'undefined' ? 'undefined' : (0, _typeof3.default)(url)) === 'object' || $router && typeof url === 'string' && !/http/.test(url);
  if (useRouter) {
    if ((typeof url === 'undefined' ? 'undefined' : (0, _typeof3.default)(url)) === 'object' && url.replace === true) {
      $router.replace(url);
    } else {
      url === 'BACK' ? $router.go(-1) : $router.push(url);
    }
  } else {
    window.location.href = url;
  }
}

function getUrl(url, $router) {
  // Make sure the href is right in hash mode
  if ($router && !$router._history && typeof url === 'string' && !/http/.test(url)) {
    return '#!' + url;
  }
  return url && (typeof url === 'undefined' ? 'undefined' : (0, _typeof3.default)(url)) !== 'object' ? url : 'javascript:void(0);';
}

/***/ }),
/* 435 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(542);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(543);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_3f1f7b9e_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(544);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(540)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_3f1f7b9e_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/inline-desc/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-3f1f7b9e", Component.options)
  } else {
    hotAPI.reload("data-v-3f1f7b9e", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 436 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (value, list, delimiter) {
  if (value && !list.length) {
    return '';
  }
  if (!delimiter) {
    delimiter = ' ';
  }

  var rs = (0, _arrayMap2.default)(value, function (one, index) {
    if (list.length && Object.prototype.toString.call(list[0]) === '[object Array]') {
      return (0, _arrayFind2.default)(list[index], function (item) {
        return item.value === one;
      });
    } else {
      return (0, _arrayFind2.default)(list, function (item) {
        return item.value === one;
      });
    }
  });
  rs = rs.filter(function (one) {
    return typeof one !== 'undefined';
  });
  return (0, _arrayMap2.default)(rs, function (one) {
    return one.name;
  }).join(delimiter).replace('--', '');
};

var _arrayMap = __webpack_require__(468);

var _arrayMap2 = _interopRequireDefault(_arrayMap);

var _arrayFind = __webpack_require__(469);

var _arrayFind2 = _interopRequireDefault(_arrayFind);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/***/ }),
/* 437 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _iterator = __webpack_require__(499);

var _iterator2 = _interopRequireDefault(_iterator);

var _symbol = __webpack_require__(501);

var _symbol2 = _interopRequireDefault(_symbol);

var _typeof = typeof _symbol2.default === "function" && typeof _iterator2.default === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj; };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = typeof _symbol2.default === "function" && _typeof(_iterator2.default) === "symbol" ? function (obj) {
  return typeof obj === "undefined" ? "undefined" : _typeof(obj);
} : function (obj) {
  return obj && typeof _symbol2.default === "function" && obj.constructor === _symbol2.default && obj !== _symbol2.default.prototype ? "symbol" : typeof obj === "undefined" ? "undefined" : _typeof(obj);
};

/***/ }),
/* 438 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function () {
  var styles = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  for (var i in styles) {
    if (typeof styles[i] === 'undefined') {
      delete styles[i];
    }
  }
  return styles;
};

/***/ }),
/* 439 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(527), __esModule: true };

/***/ }),
/* 440 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = assertString;
function assertString(input) {
  var isString = typeof input === 'string' || input instanceof String;

  if (!isString) {
    throw new TypeError('This library (validator.js) validates strings only');
  }
}
module.exports = exports['default'];

/***/ }),
/* 441 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.FlexboxItem = exports.Flexbox = undefined;

var _flexbox = __webpack_require__(446);

var _flexbox2 = _interopRequireDefault(_flexbox);

var _flexboxItem = __webpack_require__(447);

var _flexboxItem2 = _interopRequireDefault(_flexboxItem);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.Flexbox = _flexbox2.default;
exports.FlexboxItem = _flexboxItem2.default;

/***/ }),
/* 442 */
/***/ (function(module, exports, __webpack_require__) {

exports.f = __webpack_require__(29);


/***/ }),
/* 443 */
/***/ (function(module, exports, __webpack_require__) {

var global = __webpack_require__(43);
var core = __webpack_require__(48);
var LIBRARY = __webpack_require__(112);
var wksExt = __webpack_require__(442);
var defineProperty = __webpack_require__(57).f;
module.exports = function (name) {
  var $Symbol = core.Symbol || (core.Symbol = LIBRARY ? {} : global.Symbol || {});
  if (name.charAt(0) != '_' && !(name in $Symbol)) defineProperty($Symbol, name, { value: wksExt.f(name) });
};


/***/ }),
/* 444 */
/***/ (function(module, exports) {

exports.f = {}.propertyIsEnumerable;


/***/ }),
/* 445 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  mounted: function mounted() {
    // fix for ssr
    if (false) {
      if (process.env.NODE_ENV === 'development') {
        console.warn('[VUX] 当前版本组件要求 vux-loader 更新到最新版本');
      }
    } else if (false) {
      // eslint-disable-line
      this.uuid = createId();
    }
  },
  data: function data() {
    return {
      uuid: createId()
    };
  }
};


function createId() {
  return Math.random().toString(36).substring(3, 8);
}

/***/ }),
/* 446 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue__ = __webpack_require__(562);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue__ = __webpack_require__(563);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_69417b2a_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_flexbox_vue__ = __webpack_require__(564);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(560)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_69417b2a_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_flexbox_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/flexbox/flexbox.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-69417b2a", Component.options)
  } else {
    hotAPI.reload("data-v-69417b2a", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 447 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue__ = __webpack_require__(565);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue__ = __webpack_require__(566);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_76256936_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_flexbox_item_vue__ = __webpack_require__(567);
var disposed = false
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_flexbox_item_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_76256936_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_flexbox_item_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/flexbox/flexbox-item.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-76256936", Component.options)
  } else {
    hotAPI.reload("data-v-76256936", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 448 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue__ = __webpack_require__(494);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue__ = __webpack_require__(512);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_7431ed85_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_swiper_vue__ = __webpack_require__(513);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(492)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_swiper_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_7431ed85_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_swiper_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/swiper/swiper.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-7431ed85", Component.options)
  } else {
    hotAPI.reload("data-v-7431ed85", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 449 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _classCallCheck2 = __webpack_require__(450);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(451);

var _createClass3 = _interopRequireDefault(_createClass2);

var _objectAssign = __webpack_require__(114);

var _objectAssign2 = _interopRequireDefault(_objectAssign);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var arrayFrom = function arrayFrom(nodeList) {
  return Array.prototype.slice.call(nodeList);
};

var Swiper = function () {
  function Swiper(options) {
    (0, _classCallCheck3.default)(this, Swiper);

    this._default = {
      container: '.vux-swiper',
      item: '.vux-swiper-item',
      direction: 'vertical',
      activeClass: 'active',
      threshold: 50,
      duration: 300,
      auto: false,
      loop: false,
      interval: 3000,
      height: 'auto',
      minMovingDistance: 0
    };
    this._options = (0, _objectAssign2.default)(this._default, options);
    this._options.height = this._options.height.replace('px', '');
    this._start = {};
    this._move = {};
    this._end = {};
    this._eventHandlers = {};
    this._prev = this._current = this._goto = 0;
    this._width = this._height = this._distance = 0;
    this._offset = [];
    this.$box = this._options.container;
    this.$container = this._options.container.querySelector('.vux-swiper');
    this.$items = this.$container.querySelectorAll(this._options.item);
    this.count = this.$items.length;
    this.realCount = this.$items.length; // real items length
    this._position = []; // used by go event
    this._firstItemIndex = 0;
    this._isMoved = false; // used by minMovingDistance #2773
    if (!this.count) {
      return;
    }
    this._init();
    this._auto();
    this._bind();
    this._onResize();
    return this;
  }

  (0, _createClass3.default)(Swiper, [{
    key: '_auto',
    value: function _auto() {
      var me = this;
      me.stop();
      if (me._options.auto) {
        me.timer = setTimeout(function () {
          me.next();
        }, me._options.interval);
      }
    }
  }, {
    key: 'updateItemWidth',
    value: function updateItemWidth() {
      this._width = this.$box.offsetWidth || document.documentElement.offsetWidth;
      this._distance = this._options.direction === 'horizontal' ? this._width : this._height;
    }
  }, {
    key: 'stop',
    value: function stop() {
      this.timer && clearTimeout(this.timer);
    }
  }, {
    key: '_loop',
    value: function _loop() {
      return this._options.loop && this.realCount >= 3;
    }
  }, {
    key: '_onResize',
    value: function _onResize() {
      var me = this;
      this.resizeHandler = function () {
        setTimeout(function () {
          me.updateItemWidth();
          me._setOffset();
          me._setTransform();
        }, 100);
      };
      window.addEventListener('orientationchange', this.resizeHandler, false);
    }
  }, {
    key: '_init',
    value: function _init() {
      this._height = this._options.height === 'auto' ? 'auto' : this._options.height - 0;
      this.updateItemWidth();
      this._initPosition();
      this._activate(this._current);
      this._setOffset();
      this._setTransform();
      if (this._loop()) {
        this._loopRender();
      }
    }
  }, {
    key: '_initPosition',
    value: function _initPosition() {
      for (var i = 0; i < this.realCount; i++) {
        this._position.push(i);
      }
    }
  }, {
    key: '_movePosition',
    value: function _movePosition(position) {
      var me = this;
      if (position > 0) {
        var firstIndex = me._position.splice(0, 1);
        me._position.push(firstIndex[0]);
      } else if (position < 0) {
        var lastIndex = me._position.pop();
        me._position.unshift(lastIndex);
      }
    }
  }, {
    key: '_setOffset',
    value: function _setOffset() {
      var me = this;
      var index = me._position.indexOf(me._current);
      me._offset = [];
      arrayFrom(me.$items).forEach(function ($item, key) {
        me._offset.push((key - index) * me._distance);
      });
    }
  }, {
    key: '_setTransition',
    value: function _setTransition(duration) {
      duration = duration || this._options.duration || 'none';
      var transition = duration === 'none' ? 'none' : duration + 'ms';
      arrayFrom(this.$items).forEach(function ($item, key) {
        $item.style.webkitTransition = transition;
        $item.style.transition = transition;
      });
    }
  }, {
    key: '_setTransform',
    value: function _setTransform(offset) {
      var me = this;
      offset = offset || 0;
      arrayFrom(me.$items).forEach(function ($item, key) {
        var distance = me._offset[key] + offset;
        var transform = 'translate3d(' + distance + 'px, 0, 0)';
        if (me._options.direction === 'vertical') {
          transform = 'translate3d(0, ' + distance + 'px, 0)';
        }
        $item.style.webkitTransform = transform;
        $item.style.transform = transform;
        me._isMoved = true;
      });
    }
  }, {
    key: '_bind',
    value: function _bind() {
      var _this = this;

      var me = this;
      me.touchstartHandler = function (e) {
        me.stop();
        me._start.x = e.changedTouches[0].pageX;
        me._start.y = e.changedTouches[0].pageY;
        me._setTransition('none');
        me._isMoved = false;
      };
      me.touchmoveHandler = function (e) {
        if (me.count === 1) {
          return;
        }
        me._move.x = e.changedTouches[0].pageX;
        me._move.y = e.changedTouches[0].pageY;
        var distanceX = me._move.x - me._start.x;
        var distanceY = me._move.y - me._start.y;
        var distance = distanceY;
        var noScrollerY = Math.abs(distanceX) > Math.abs(distanceY);
        if (me._options.direction === 'horizontal' && noScrollerY) {
          distance = distanceX;
        }
        /* set shorter distance for first and last item for better experience */
        if (!_this._options.loop && (_this._current === _this.count - 1 || _this._current === 0)) {
          distance = distance / 3;
        }
        if ((me._options.minMovingDistance && Math.abs(distance) >= me._options.minMovingDistance || !me._options.minMovingDistance) && noScrollerY || me._isMoved) {
          me._setTransform(distance);
        }

        noScrollerY && e.preventDefault();
      };

      me.touchendHandler = function (e) {
        if (me.count === 1) {
          return;
        }
        me._end.x = e.changedTouches[0].pageX;
        me._end.y = e.changedTouches[0].pageY;

        var distance = me._end.y - me._start.y;
        if (me._options.direction === 'horizontal') {
          distance = me._end.x - me._start.x;
        }

        distance = me.getDistance(distance);
        if (distance !== 0 && me._options.minMovingDistance && Math.abs(distance) < me._options.minMovingDistance && !me._isMoved) {
          return;
        }
        if (distance > me._options.threshold) {
          me.move(-1);
        } else if (distance < -me._options.threshold) {
          me.move(1);
        } else {
          me.move(0);
        }

        me._loopRender();
      };

      me.transitionEndHandler = function (e) {
        me._activate(me._current);
        var cb = me._eventHandlers.swiped;
        cb && cb.apply(me, [me._prev % me.count, me._current % me.count]);
        me._auto();
        me._loopRender();
        e.preventDefault();
      };
      me.$container.addEventListener('touchstart', me.touchstartHandler, false);
      me.$container.addEventListener('touchmove', me.touchmoveHandler, false);
      me.$container.addEventListener('touchend', me.touchendHandler, false);
      me.$items[1] && me.$items[1].addEventListener('webkitTransitionEnd', me.transitionEndHandler, false);
    }
  }, {
    key: '_loopRender',
    value: function _loopRender() {
      var me = this;
      if (me._loop()) {
        // issue #507 (delete cloneNode)
        if (me._offset[me._offset.length - 1] === 0) {
          me.$container.appendChild(me.$items[0]);
          me._loopEvent(1);
        } else if (me._offset[0] === 0) {
          me.$container.insertBefore(me.$items[me.$items.length - 1], me.$container.firstChild);
          me._loopEvent(-1);
        }
      }
    }
  }, {
    key: '_loopEvent',
    value: function _loopEvent(num) {
      var me = this;
      me._itemDestoy();
      me.$items = me.$container.querySelectorAll(me._options.item);
      me.$items[1] && me.$items[1].addEventListener('webkitTransitionEnd', me.transitionEndHandler, false);
      me._movePosition(num);
      me._setOffset();
      me._setTransform();
    }
  }, {
    key: 'getDistance',
    value: function getDistance(distance) {
      if (this._loop()) {
        return distance;
      } else {
        if (distance > 0 && this._current === 0) {
          return 0;
        } else if (distance < 0 && this._current === this.realCount - 1) {
          return 0;
        } else {
          return distance;
        }
      }
    }
  }, {
    key: '_moveIndex',
    value: function _moveIndex(num) {
      if (num !== 0) {
        this._prev = this._current;
        this._current += this.realCount;
        this._current += num;
        this._current %= this.realCount;
      }
    }
  }, {
    key: '_activate',
    value: function _activate(index) {
      var clazz = this._options.activeClass;
      Array.prototype.forEach.call(this.$items, function ($item, key) {
        $item.classList.remove(clazz);
        if (index === Number($item.dataset.index)) {
          $item.classList.add(clazz);
        }
      });
    }
  }, {
    key: 'go',
    value: function go(index) {
      var me = this;
      me.stop();

      index = index || 0;
      index += this.realCount;
      index = index % this.realCount;
      index = this._position.indexOf(index) - this._position.indexOf(this._current);

      me._moveIndex(index);
      me._setOffset();
      me._setTransition();
      me._setTransform();
      me._auto();
      return this;
    }
  }, {
    key: 'next',
    value: function next() {
      this.move(1);
      return this;
    }
  }, {
    key: 'move',
    value: function move(num) {
      this.go(this._current + num);
      return this;
    }
  }, {
    key: 'on',
    value: function on(event, callback) {
      if (this._eventHandlers[event]) {
        console.error('[swiper] event ' + event + ' is already register');
      }
      if (typeof callback !== 'function') {
        console.error('[swiper] parameter callback must be a function');
      }
      this._eventHandlers[event] = callback;
      return this;
    }
  }, {
    key: '_itemDestoy',
    value: function _itemDestoy() {
      var _this2 = this;

      this.$items.length && arrayFrom(this.$items).forEach(function (item) {
        item.removeEventListener('webkitTransitionEnd', _this2.transitionEndHandler, false);
      });
    }
  }, {
    key: 'destroy',
    value: function destroy() {
      this.stop();
      this._current = 0;
      this._setTransform(0);
      window.removeEventListener('orientationchange', this.resizeHandler, false);
      this.$container.removeEventListener('touchstart', this.touchstartHandler, false);
      this.$container.removeEventListener('touchmove', this.touchmoveHandler, false);
      this.$container.removeEventListener('touchend', this.touchendHandler, false);
      this._itemDestoy();
      // remove clone item (used by loop only 2)
      if (this._options.loop && this.count === 2) {
        var $item = this.$container.querySelector(this._options.item + '-clone');
        $item && this.$container.removeChild($item);
        $item = this.$container.querySelector(this._options.item + '-clone');
        $item && this.$container.removeChild($item);
      }
    }
  }]);
  return Swiper;
}();

exports.default = Swiper;

/***/ }),
/* 450 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

exports.default = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

/***/ }),
/* 451 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;

var _defineProperty = __webpack_require__(496);

var _defineProperty2 = _interopRequireDefault(_defineProperty);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      (0, _defineProperty2.default)(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();

/***/ }),
/* 452 */
/***/ (function(module, exports) {

exports.f = Object.getOwnPropertySymbols;


/***/ }),
/* 453 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.7 / 15.2.3.4 Object.getOwnPropertyNames(O)
var $keys = __webpack_require__(171);
var hiddenKeys = __webpack_require__(118).concat('length', 'prototype');

exports.f = Object.getOwnPropertyNames || function getOwnPropertyNames(O) {
  return $keys(O, hiddenKeys);
};


/***/ }),
/* 454 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(516);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(517);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_75c3ee6d_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(518);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(514)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_75c3ee6d_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/card/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-75c3ee6d", Component.options)
  } else {
    hotAPI.reload("data-v-75c3ee6d", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 455 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(521);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(522);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_a2b01a50_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(523);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(519)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_a2b01a50_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/group/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-a2b01a50", Component.options)
  } else {
    hotAPI.reload("data-v-a2b01a50", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 456 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(526);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(548);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_15a77b8e_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(549);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(524)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_15a77b8e_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/x-input/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-15a77b8e", Component.options)
  } else {
    hotAPI.reload("data-v-15a77b8e", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 457 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _mixin_uuid = __webpack_require__(445);

var _mixin_uuid2 = _interopRequireDefault(_mixin_uuid);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  mixins: [_mixin_uuid2.default],
  props: {
    required: {
      type: Boolean,
      default: false
    }
  },
  created: function created() {
    this.handleChangeEvent = false;
  },

  computed: {
    dirty: {
      get: function get() {
        return !this.pristine;
      },
      set: function set(newValue) {
        this.pristine = !newValue;
      }
    },
    invalid: function invalid() {
      return !this.valid;
    }
  },
  methods: {
    setTouched: function setTouched() {
      this.touched = true;
    }
  },
  watch: {
    value: function value(newVal) {
      if (this.pristine === true) {
        this.pristine = false;
      }
      if (!this.handleChangeEvent) {
        this.$emit('on-change', newVal);
        this.$emit('input', newVal);
      }
    }
  },
  data: function data() {
    return {
      errors: {},
      pristine: true,
      touched: false
    };
  }
};

/***/ }),
/* 458 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(532);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(533);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_57d6c096_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(534);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(530)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_57d6c096_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/icon/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-57d6c096", Component.options)
  } else {
    hotAPI.reload("data-v-57d6c096", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 459 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(537);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(538);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_5b8fbf00_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(539);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(535)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_5b8fbf00_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/toast/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-5b8fbf00", Component.options)
  } else {
    hotAPI.reload("data-v-5b8fbf00", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 460 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  mounted: function mounted() {
    this.$overflowScrollingList = document.querySelectorAll('.vux-fix-safari-overflow-scrolling');
  },

  methods: {
    fixSafariOverflowScrolling: function fixSafariOverflowScrolling(type) {
      if (!this.$overflowScrollingList.length) return;
      // if (!/iphone/i.test(navigator.userAgent)) return
      for (var i = 0; i < this.$overflowScrollingList.length; i++) {
        this.$overflowScrollingList[i].style.webkitOverflowScrolling = type;
      }
    }
  }
};

/***/ }),
/* 461 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = isEmail;

var _assertString = __webpack_require__(440);

var _assertString2 = _interopRequireDefault(_assertString);

var _merge = __webpack_require__(462);

var _merge2 = _interopRequireDefault(_merge);

var _isByteLength = __webpack_require__(545);

var _isByteLength2 = _interopRequireDefault(_isByteLength);

var _isFQDN = __webpack_require__(546);

var _isFQDN2 = _interopRequireDefault(_isFQDN);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var default_email_options = {
  allow_display_name: false,
  require_display_name: false,
  allow_utf8_local_part: true,
  require_tld: true
};

/* eslint-disable max-len */
/* eslint-disable no-control-regex */
var displayName = /^[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~\.\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~\,\.\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF\s]*<(.+)>$/i;
var emailUserPart = /^[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~]+$/i;
var quotedEmailUser = /^([\s\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e]|(\\[\x01-\x09\x0b\x0c\x0d-\x7f]))*$/i;
var emailUserUtf8Part = /^[a-z\d!#\$%&'\*\+\-\/=\?\^_`{\|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+$/i;
var quotedEmailUserUtf8 = /^([\s\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|(\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*$/i;
/* eslint-enable max-len */
/* eslint-enable no-control-regex */

function isEmail(str, options) {
  (0, _assertString2.default)(str);
  options = (0, _merge2.default)(options, default_email_options);

  if (options.require_display_name || options.allow_display_name) {
    var display_email = str.match(displayName);
    if (display_email) {
      str = display_email[1];
    } else if (options.require_display_name) {
      return false;
    }
  }

  var parts = str.split('@');
  var domain = parts.pop();
  var user = parts.join('@');

  var lower_domain = domain.toLowerCase();
  if (lower_domain === 'gmail.com' || lower_domain === 'googlemail.com') {
    user = user.replace(/\./g, '').toLowerCase();
  }

  if (!(0, _isByteLength2.default)(user, { max: 64 }) || !(0, _isByteLength2.default)(domain, { max: 254 })) {
    return false;
  }

  if (!(0, _isFQDN2.default)(domain, { require_tld: options.require_tld })) {
    return false;
  }

  if (user[0] === '"') {
    user = user.slice(1, user.length - 1);
    return options.allow_utf8_local_part ? quotedEmailUserUtf8.test(user) : quotedEmailUser.test(user);
  }

  var pattern = options.allow_utf8_local_part ? emailUserUtf8Part : emailUserPart;

  var user_parts = user.split('.');
  for (var i = 0; i < user_parts.length; i++) {
    if (!pattern.test(user_parts[i])) {
      return false;
    }
  }

  return true;
}
module.exports = exports['default'];

/***/ }),
/* 462 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = merge;
function merge() {
  var obj = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var defaults = arguments[1];

  for (var key in defaults) {
    if (typeof obj[key] === 'undefined') {
      obj[key] = defaults[key];
    }
  }
  return obj;
}
module.exports = exports['default'];

/***/ }),
/* 463 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = isMobilePhone;

var _assertString = __webpack_require__(440);

var _assertString2 = _interopRequireDefault(_assertString);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* eslint-disable max-len */
var phones = {
  'ar-AE': /^((\+?971)|0)?5[024568]\d{7}$/,
  'ar-DZ': /^(\+?213|0)(5|6|7)\d{8}$/,
  'ar-EG': /^((\+?20)|0)?1[012]\d{8}$/,
  'ar-JO': /^(\+?962|0)?7[789]\d{7}$/,
  'ar-SA': /^(!?(\+?966)|0)?5\d{8}$/,
  'ar-SY': /^(!?(\+?963)|0)?9\d{8}$/,
  'be-BY': /^(\+?375)?(24|25|29|33|44)\d{7}$/,
  'bg-BG': /^(\+?359|0)?8[789]\d{7}$/,
  'cs-CZ': /^(\+?420)? ?[1-9][0-9]{2} ?[0-9]{3} ?[0-9]{3}$/,
  'da-DK': /^(\+?45)?\s?\d{2}\s?\d{2}\s?\d{2}\s?\d{2}$/,
  'de-DE': /^(\+?49[ \.\-])?([\(]{1}[0-9]{1,6}[\)])?([0-9 \.\-\/]{3,20})((x|ext|extension)[ ]?[0-9]{1,4})?$/,
  'el-GR': /^(\+?30|0)?(69\d{8})$/,
  'en-AU': /^(\+?61|0)4\d{8}$/,
  'en-GB': /^(\+?44|0)7\d{9}$/,
  'en-HK': /^(\+?852\-?)?[456789]\d{3}\-?\d{4}$/,
  'en-IN': /^(\+?91|0)?[6789]\d{9}$/,
  'en-KE': /^(\+?254|0)?[7]\d{8}$/,
  'en-NG': /^(\+?234|0)?[789]\d{9}$/,
  'en-NZ': /^(\+?64|0)2\d{7,9}$/,
  'en-PK': /^((\+92)|(0092))-{0,1}\d{3}-{0,1}\d{7}$|^\d{11}$|^\d{4}-\d{7}$/,
  'en-RW': /^(\+?250|0)?[7]\d{8}$/,
  'en-SG': /^(\+65)?[89]\d{7}$/,
  'en-TZ': /^(\+?255|0)?[67]\d{8}$/,
  'en-UG': /^(\+?256|0)?[7]\d{8}$/,
  'en-US': /^(\+?1)?[2-9]\d{2}[2-9](?!11)\d{6}$/,
  'en-ZA': /^(\+?27|0)\d{9}$/,
  'en-ZM': /^(\+?26)?09[567]\d{7}$/,
  'es-ES': /^(\+?34)?(6\d{1}|7[1234])\d{7}$/,
  'et-EE': /^(\+?372)?\s?(5|8[1-4])\s?([0-9]\s?){6,7}$/,
  'fa-IR': /^(\+?98[\-\s]?|0)9[0-39]\d[\-\s]?\d{3}[\-\s]?\d{4}$/,
  'fi-FI': /^(\+?358|0)\s?(4(0|1|2|4|5|6)?|50)\s?(\d\s?){4,8}\d$/,
  'fo-FO': /^(\+?298)?\s?\d{2}\s?\d{2}\s?\d{2}$/,
  'fr-FR': /^(\+?33|0)[67]\d{8}$/,
  'he-IL': /^(\+972|0)([23489]|5[012345689]|77)[1-9]\d{6}/,
  'hu-HU': /^(\+?36)(20|30|70)\d{7}$/,
  'id-ID': /^(\+?62|0[1-9])[\s|\d]+$/,
  'it-IT': /^(\+?39)?\s?3\d{2} ?\d{6,7}$/,
  'ja-JP': /^(\+?81|0)[789]0[ \-]?[1-9]\d{2}[ \-]?\d{5}$/,
  'kk-KZ': /^(\+?7|8)?7\d{9}$/,
  'kl-GL': /^(\+?299)?\s?\d{2}\s?\d{2}\s?\d{2}$/,
  'ko-KR': /^((\+?82)[ \-]?)?0?1([0|1|6|7|8|9]{1})[ \-]?\d{3,4}[ \-]?\d{4}$/,
  'lt-LT': /^(\+370|8)\d{8}$/,
  'ms-MY': /^(\+?6?01){1}(([145]{1}(\-|\s)?\d{7,8})|([236789]{1}(\s|\-)?\d{7}))$/,
  'nb-NO': /^(\+?47)?[49]\d{7}$/,
  'nl-BE': /^(\+?32|0)4?\d{8}$/,
  'nn-NO': /^(\+?47)?[49]\d{7}$/,
  'pl-PL': /^(\+?48)? ?[5-8]\d ?\d{3} ?\d{2} ?\d{2}$/,
  'pt-BR': /^(\+?55|0)\-?[1-9]{2}\-?[2-9]{1}\d{3,4}\-?\d{4}$/,
  'pt-PT': /^(\+?351)?9[1236]\d{7}$/,
  'ro-RO': /^(\+?4?0)\s?7\d{2}(\/|\s|\.|\-)?\d{3}(\s|\.|\-)?\d{3}$/,
  'ru-RU': /^(\+?7|8)?9\d{9}$/,
  'sk-SK': /^(\+?421)? ?[1-9][0-9]{2} ?[0-9]{3} ?[0-9]{3}$/,
  'sr-RS': /^(\+3816|06)[- \d]{5,9}$/,
  'th-TH': /^(\+66|66|0)\d{9}$/,
  'tr-TR': /^(\+?90|0)?5\d{9}$/,
  'uk-UA': /^(\+?38|8)?0\d{9}$/,
  'vi-VN': /^(\+?84|0)?((1(2([0-9])|6([2-9])|88|99))|(9((?!5)[0-9])))([0-9]{7})$/,
  'zh-CN': /^(\+?0?86\-?)?1[3456789]\d{9}$/,
  'zh-TW': /^(\+?886\-?|0)?9\d{8}$/
};
/* eslint-enable max-len */

// aliases
phones['en-CA'] = phones['en-US'];
phones['fr-BE'] = phones['nl-BE'];
phones['zh-HK'] = phones['en-HK'];

function isMobilePhone(str, locale, options) {
  (0, _assertString2.default)(str);
  if (options && options.strictMode && !str.startsWith('+')) {
    return false;
  }
  if (locale in phones) {
    return phones[locale].test(str);
  } else if (locale === 'any') {
    for (var key in phones) {
      if (phones.hasOwnProperty(key)) {
        var phone = phones[key];
        if (phone.test(str)) {
          return true;
        }
      }
    }
    return false;
  }
  throw new Error('Invalid locale \'' + locale + '\'');
}
module.exports = exports['default'];

/***/ }),
/* 464 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lodash = __webpack_require__(547);

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = _lodash2.default;

/***/ }),
/* 465 */
/***/ (function(module, exports, __webpack_require__) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_RESULT__;(function(root, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
				__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
				(__WEBPACK_AMD_DEFINE_FACTORY__.call(exports, __webpack_require__, exports, module)) :
				__WEBPACK_AMD_DEFINE_FACTORY__),
				__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else if (typeof exports === 'object') {
    module.exports = factory();
  } else {
    root.VMasker = factory();
  }
}(this, function() {
  var DIGIT = "9",
      ALPHA = "A",
      ALPHANUM = "S",
      BY_PASS_KEYS = [9, 16, 17, 18, 36, 37, 38, 39, 40, 91, 92, 93],
      isAllowedKeyCode = function(keyCode) {
        for (var i = 0, len = BY_PASS_KEYS.length; i < len; i++) {
          if (keyCode == BY_PASS_KEYS[i]) {
            return false;
          }
        }
        return true;
      },
      mergeMoneyOptions = function(opts) {
        opts = opts || {};
        opts = {
          delimiter: opts.delimiter || ".",
          lastOutput: opts.lastOutput,
          precision: opts.hasOwnProperty("precision") ? opts.precision : 2,
          separator: opts.separator || ",",
          showSignal: opts.showSignal,
          suffixUnit: opts.suffixUnit && (" " + opts.suffixUnit.replace(/[\s]/g,'')) || "",
          unit: opts.unit && (opts.unit.replace(/[\s]/g,'') + " ") || "",
          zeroCents: opts.zeroCents
        };
        opts.moneyPrecision = opts.zeroCents ? 0 : opts.precision;
        return opts;
      },
      // Fill wildcards past index in output with placeholder
      addPlaceholdersToOutput = function(output, index, placeholder) {
        for (; index < output.length; index++) {
          if(output[index] === DIGIT || output[index] === ALPHA || output[index] === ALPHANUM) {
            output[index] = placeholder;
          }
        }
        return output;
      }
  ;

  var VanillaMasker = function(elements) {
    this.elements = elements;
  };

  VanillaMasker.prototype.unbindElementToMask = function() {
    for (var i = 0, len = this.elements.length; i < len; i++) {
      this.elements[i].lastOutput = "";
      this.elements[i].onkeyup = false;
      this.elements[i].onkeydown = false;

      if (this.elements[i].value.length) {
        this.elements[i].value = this.elements[i].value.replace(/\D/g, '');
      }
    }
  };

  VanillaMasker.prototype.bindElementToMask = function(maskFunction) {
    var that = this,
        onType = function(e) {
          e = e || window.event;
          var source = e.target || e.srcElement;

          if (isAllowedKeyCode(e.keyCode)) {
            setTimeout(function() {
              that.opts.lastOutput = source.lastOutput;
              source.value = VMasker[maskFunction](source.value, that.opts);
              source.lastOutput = source.value;
              if (source.setSelectionRange && that.opts.suffixUnit) {
                source.setSelectionRange(source.value.length, (source.value.length - that.opts.suffixUnit.length));
              }
            }, 0);
          }
        }
    ;
    for (var i = 0, len = this.elements.length; i < len; i++) {
      this.elements[i].lastOutput = "";
      this.elements[i].onkeyup = onType;
      if (this.elements[i].value.length) {
        this.elements[i].value = VMasker[maskFunction](this.elements[i].value, this.opts);
      }
    }
  };

  VanillaMasker.prototype.maskMoney = function(opts) {
    this.opts = mergeMoneyOptions(opts);
    this.bindElementToMask("toMoney");
  };

  VanillaMasker.prototype.maskNumber = function() {
    this.opts = {};
    this.bindElementToMask("toNumber");
  };
  
  VanillaMasker.prototype.maskAlphaNum = function() {
    this.opts = {};
    this.bindElementToMask("toAlphaNumeric");
  };

  VanillaMasker.prototype.maskPattern = function(pattern) {
    this.opts = {pattern: pattern};
    this.bindElementToMask("toPattern");
  };

  VanillaMasker.prototype.unMask = function() {
    this.unbindElementToMask();
  };

  var VMasker = function(el) {
    if (!el) {
      throw new Error("VanillaMasker: There is no element to bind.");
    }
    var elements = ("length" in el) ? (el.length ? el : []) : [el];
    return new VanillaMasker(elements);
  };

  VMasker.toMoney = function(value, opts) {
    opts = mergeMoneyOptions(opts);
    if (opts.zeroCents) {
      opts.lastOutput = opts.lastOutput || "";
      var zeroMatcher = ("("+ opts.separator +"[0]{0,"+ opts.precision +"})"),
          zeroRegExp = new RegExp(zeroMatcher, "g"),
          digitsLength = value.toString().replace(/[\D]/g, "").length || 0,
          lastDigitLength = opts.lastOutput.toString().replace(/[\D]/g, "").length || 0
      ;
      value = value.toString().replace(zeroRegExp, "");
      if (digitsLength < lastDigitLength) {
        value = value.slice(0, value.length - 1);
      }
    }
    var number = value.toString().replace(/[\D]/g, ""),
        clearDelimiter = new RegExp("^(0|\\"+ opts.delimiter +")"),
        clearSeparator = new RegExp("(\\"+ opts.separator +")$"),
        money = number.substr(0, number.length - opts.moneyPrecision),
        masked = money.substr(0, money.length % 3),
        cents = new Array(opts.precision + 1).join("0")
    ;
    money = money.substr(money.length % 3, money.length);
    for (var i = 0, len = money.length; i < len; i++) {
      if (i % 3 === 0) {
        masked += opts.delimiter;
      }
      masked += money[i];
    }
    masked = masked.replace(clearDelimiter, "");
    masked = masked.length ? masked : "0";
    var signal = "";
    if(opts.showSignal === true) {
      signal = value < 0 || (value.startsWith && value.startsWith('-')) ? "-" :  "";
    }
    if (!opts.zeroCents) {
      var beginCents = number.length - opts.precision,
          centsValue = number.substr(beginCents, opts.precision),
          centsLength = centsValue.length,
          centsSliced = (opts.precision > centsLength) ? opts.precision : centsLength
      ;
      cents = (cents + centsValue).slice(-centsSliced);
    }
    var output = opts.unit + signal + masked + opts.separator + cents;
    return output.replace(clearSeparator, "") + opts.suffixUnit;
  };

  VMasker.toPattern = function(value, opts) {
    var pattern = (typeof opts === 'object' ? opts.pattern : opts),
        patternChars = pattern.replace(/\W/g, ''),
        output = pattern.split(""),
        values = value.toString().replace(/\W/g, ""),
        charsValues = values.replace(/\W/g, ''),
        index = 0,
        i,
        outputLength = output.length,
        placeholder = (typeof opts === 'object' ? opts.placeholder : undefined)
    ;
    
    for (i = 0; i < outputLength; i++) {
      // Reached the end of input
      if (index >= values.length) {
        if (patternChars.length == charsValues.length) {
          return output.join("");
        }
        else if ((placeholder !== undefined) && (patternChars.length > charsValues.length)) {
          return addPlaceholdersToOutput(output, i, placeholder).join("");
        }
        else {
          break;
        }
      }
      // Remaining chars in input
      else{
        if ((output[i] === DIGIT && values[index].match(/[0-9]/)) ||
            (output[i] === ALPHA && values[index].match(/[a-zA-Z]/)) ||
            (output[i] === ALPHANUM && values[index].match(/[0-9a-zA-Z]/))) {
          output[i] = values[index++];
        } else if (output[i] === DIGIT || output[i] === ALPHA || output[i] === ALPHANUM) {
          if(placeholder !== undefined){
            return addPlaceholdersToOutput(output, i, placeholder).join("");
          }
          else{
            return output.slice(0, i).join("");
          }
        }
      }
    }
    return output.join("").substr(0, i);
  };

  VMasker.toNumber = function(value) {
    return value.toString().replace(/(?!^-)[^0-9]/g, "");
  };
  
  VMasker.toAlphaNumeric = function(value) {
    return value.toString().replace(/[^a-z0-9 ]+/i, "");
  };

  return VMasker;
}));


/***/ }),
/* 466 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(550);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(589);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_b5672610_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(590);
var disposed = false
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = null
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_b5672610_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/x-address/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-b5672610", Component.options)
  } else {
    hotAPI.reload("data-v-b5672610", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 467 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (name, list) {
  var rs = (0, _arrayMap2.default)(name, function (one, index) {
    var parent = '';
    if (index === 2) {
      // 可能存在区名一样的情况，比如南山区
      parent = (0, _arrayFind2.default)(list, function (item) {
        return item.name === name[1];
      }) || { value: '__' };

      if (specialMap[name[0]]) {
        parent = {
          value: specialMap[name[0]]
        };
      }
      return (0, _arrayFind2.default)(list, function (item) {
        return item.name === one && item.parent === parent.value;
      });
    } else {
      if (index === 1 && specialMap[name[0]]) {
        return {
          value: specialMap[name[0]]
        };
      }
      return (0, _arrayFind2.default)(list, function (item) {
        return item.name === one;
      });
    }
  });

  return (0, _arrayMap2.default)(rs, function (one) {
    return one ? one.value : '__';
  }).join(' ');
};

var _arrayMap = __webpack_require__(468);

var _arrayMap2 = _interopRequireDefault(_arrayMap);

var _arrayFind = __webpack_require__(469);

var _arrayFind2 = _interopRequireDefault(_arrayFind);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var specialMap = {
  '北京市': '110100',
  '天津市': '120100',
  '上海市': '310100',
  '重庆市': '500100'
};

/***/ }),
/* 468 */
/***/ (function(module, exports) {

module.exports = function (xs, f) {
    if (xs.map) return xs.map(f);
    var res = [];
    for (var i = 0; i < xs.length; i++) {
        var x = xs[i];
        if (hasOwn.call(xs, i)) res.push(f(x, i, xs));
    }
    return res;
};

var hasOwn = Object.prototype.hasOwnProperty;


/***/ }),
/* 469 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function find(array, predicate, context) {
  if (typeof Array.prototype.find === 'function') {
    return array.find(predicate, context);
  }

  context = context || this;
  var length = array.length;
  var i;

  if (typeof predicate !== 'function') {
    throw new TypeError(predicate + ' is not a function');
  }

  for (i = 0; i < length; i++) {
    if (predicate.call(context, array[i], i, array)) {
      return array[i];
    }
  }
}

module.exports = find;


/***/ }),
/* 470 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(553);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(587);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_c23b5128_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(588);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(551)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_c23b5128_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/popup-picker/index.vue"


/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-c23b5128", Component.options)
  } else {
    hotAPI.reload("data-v-c23b5128", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 471 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(557);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(569);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_26e72deb_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(570);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(554)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_26e72deb_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/picker/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-26e72deb", Component.options)
  } else {
    hotAPI.reload("data-v-26e72deb", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 472 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(433);

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = __webpack_require__(437);

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
* Anima Scroller
* Based Zynga Scroller (http://github.com/zynga/scroller)
* Copyright 2011, Zynga Inc.
* Licensed under the MIT License.
* https://raw.github.com/zynga/scroller/master/MIT-LICENSE.txt
*/

var isBrowser = (typeof window === 'undefined' ? 'undefined' : (0, _typeof3.default)(window)) === 'object';

var TEMPLATE = '\n<div class="scroller-component" data-role="component">\n  <div class="scroller-mask" data-role="mask"></div>\n  <div class="scroller-indicator" data-role="indicator"></div>\n  <div class="scroller-content" data-role="content"></div>\n</div>\n';

var Animate = __webpack_require__(558);

var _require = __webpack_require__(559),
    getElement = _require.getElement,
    getComputedStyle = _require.getComputedStyle,
    easeOutCubic = _require.easeOutCubic,
    easeInOutCubic = _require.easeInOutCubic;

var passiveSupported = __webpack_require__(473);

var getDpr = function getDpr() {
  var dpr = 1;
  if (isBrowser) {
    if (window.VUX_CONFIG && window.VUX_CONFIG.$picker && window.VUX_CONFIG.$picker.respectHtmlDataDpr) {
      dpr = document.documentElement.getAttribute('data-dpr') || 1;
    }
  }
  return dpr;
};

var Scroller = function Scroller(container, options) {
  var self = this;

  self.dpr = getDpr();

  options = options || {};

  self.options = {
    itemClass: 'scroller-item',
    onSelect: function onSelect() {},

    defaultValue: 0,
    data: []
  };

  for (var key in options) {
    if (options[key] !== undefined) {
      self.options[key] = options[key];
    }
  }

  self.__container = getElement(container);

  var tempContainer = document.createElement('div');
  tempContainer.innerHTML = options.template || TEMPLATE;

  var component = self.__component = tempContainer.querySelector('[data-role=component]');
  var content = self.__content = component.querySelector('[data-role=content]');
  var indicator = component.querySelector('[data-role=indicator]');

  var data = self.options.data;
  var html = '';
  if (data.length && data[0].constructor === Object) {
    data.forEach(function (row) {
      html += '<div class="' + self.options.itemClass + '" data-value=' + (0, _stringify2.default)({ value: encodeURI(row.value) }) + '>' + row.name + '</div>';
    });
  } else {
    data.forEach(function (val) {
      html += '<div class="' + self.options.itemClass + '" data-value=' + (0, _stringify2.default)({ value: encodeURI(val) }) + '>' + val + '</div>';
    });
  }
  content.innerHTML = html;

  self.__container.appendChild(component);

  self.__itemHeight = parseFloat(getComputedStyle(indicator, 'height'), 10);

  self.__callback = options.callback || function (top) {
    var distance = -top * self.dpr;
    content.style.webkitTransform = 'translate3d(0, ' + distance + 'px, 0)';
    content.style.transform = 'translate3d(0, ' + distance + 'px, 0)';
  };

  var rect = component.getBoundingClientRect();

  self.__clientTop = rect.top + component.clientTop || 0;

  self.__setDimensions(component.clientHeight, content.offsetHeight);

  if (component.clientHeight === 0) {
    self.__setDimensions(parseFloat(getComputedStyle(component, 'height'), 10), 204);
  }
  self.select(self.options.defaultValue, false);

  var touchStartHandler = function touchStartHandler(e) {
    if (e.target.tagName.match(/input|textarea|select/i)) {
      return;
    }
    e.preventDefault();
    self.__doTouchStart(e, e.timeStamp);
  };

  var touchMoveHandler = function touchMoveHandler(e) {
    self.__doTouchMove(e, e.timeStamp);
  };

  var touchEndHandler = function touchEndHandler(e) {
    self.__doTouchEnd(e.timeStamp);
  };

  var willPreventDefault = passiveSupported ? { passive: false } : false;
  var willNotPreventDefault = passiveSupported ? { passive: true } : false;

  component.addEventListener('touchstart', touchStartHandler, willPreventDefault);
  component.addEventListener('mousedown', touchStartHandler, willPreventDefault);

  component.addEventListener('touchmove', touchMoveHandler, willNotPreventDefault);
  component.addEventListener('mousemove', touchMoveHandler, willNotPreventDefault);

  component.addEventListener('touchend', touchEndHandler, willNotPreventDefault);
  component.addEventListener('mouseup', touchEndHandler, willNotPreventDefault);
};

var members = {
  value: null,
  __prevValue: null,
  __isSingleTouch: false,
  __isTracking: false,
  __didDecelerationComplete: false,
  __isGesturing: false,
  __isDragging: false,
  __isDecelerating: false,
  __isAnimating: false,
  __clientTop: 0,
  __clientHeight: 0,
  __contentHeight: 0,
  __itemHeight: 0,
  __scrollTop: 0,
  __minScrollTop: 0,
  __maxScrollTop: 0,
  __scheduledTop: 0,
  __lastTouchTop: null,
  __lastTouchMove: null,
  __positions: null,
  __minDecelerationScrollTop: null,
  __maxDecelerationScrollTop: null,
  __decelerationVelocityY: null,

  __setDimensions: function __setDimensions(clientHeight, contentHeight) {
    var self = this;

    self.__clientHeight = clientHeight;
    self.__contentHeight = contentHeight;

    var totalItemCount = self.options.data.length;
    var clientItemCount = Math.round(self.__clientHeight / self.__itemHeight);

    self.__minScrollTop = -self.__itemHeight * (clientItemCount / 2);
    self.__maxScrollTop = self.__minScrollTop + totalItemCount * self.__itemHeight - 0.1;
  },
  selectByIndex: function selectByIndex(index, animate) {
    var self = this;
    if (index < 0 || index > self.__content.childElementCount - 1) {
      return;
    }
    self.__scrollTop = self.__minScrollTop + index * self.__itemHeight;

    self.scrollTo(self.__scrollTop, animate);

    self.__selectItem(self.__content.children[index]);
  },
  select: function select(value, animate) {
    var self = this;

    var children = self.__content.children;
    for (var i = 0, len = children.length; i < len; i++) {
      if (decodeURI(JSON.parse(children[i].dataset.value).value) === value) {
        self.selectByIndex(i, animate);
        return;
      }
    }

    self.selectByIndex(0, animate);
  },
  getValue: function getValue() {
    return this.value;
  },
  scrollTo: function scrollTo(top, animate) {
    var self = this;

    animate = animate === undefined ? true : animate;

    if (self.__isDecelerating) {
      Animate.stop(self.__isDecelerating);
      self.__isDecelerating = false;
    }

    top = Math.round((top / self.__itemHeight).toFixed(5)) * self.__itemHeight;
    top = Math.max(Math.min(self.__maxScrollTop, top), self.__minScrollTop);

    if (top === self.__scrollTop || !animate) {
      self.__publish(top);
      self.__scrollingComplete();
      return;
    }
    self.__publish(top, 250);
  },
  destroy: function destroy() {
    this.__component.parentNode && this.__component.parentNode.removeChild(this.__component);
  },
  __selectItem: function __selectItem(selectedItem) {
    var self = this;

    var selectedItemClass = self.options.itemClass + '-selected';
    var lastSelectedElem = self.__content.querySelector('.' + selectedItemClass);
    if (lastSelectedElem) {
      lastSelectedElem.classList.remove(selectedItemClass);
    }
    selectedItem.classList.add(selectedItemClass);

    if (self.value !== null) {
      self.__prevValue = self.value;
    }

    self.value = decodeURI(JSON.parse(selectedItem.dataset.value).value);
  },
  __scrollingComplete: function __scrollingComplete() {
    var self = this;

    var index = Math.round((self.__scrollTop - self.__minScrollTop - self.__itemHeight / 2) / self.__itemHeight);

    self.__selectItem(self.__content.children[index]);

    if (self.__prevValue !== null && self.__prevValue !== self.value) {
      self.options.onSelect(self.value);
    }
  },
  __doTouchStart: function __doTouchStart(ev, timeStamp) {
    var touches = ev.touches;
    var self = this;
    var target = ev.touches ? ev.touches[0] : ev;
    var isMobile = !!ev.touches;

    if (ev.touches && touches.length == null) {
      throw new Error('Invalid touch list: ' + touches);
    }
    if (timeStamp instanceof Date) {
      timeStamp = timeStamp.valueOf();
    }
    if (typeof timeStamp !== 'number') {
      throw new Error('Invalid timestamp value: ' + timeStamp);
    }

    self.__interruptedAnimation = true;

    if (self.__isDecelerating) {
      Animate.stop(self.__isDecelerating);
      self.__isDecelerating = false;
      self.__interruptedAnimation = true;
    }

    if (self.__isAnimating) {
      Animate.stop(self.__isAnimating);
      self.__isAnimating = false;
      self.__interruptedAnimation = true;
    }

    // Use center point when dealing with two fingers
    var currentTouchTop;
    var isSingleTouch = isMobile && touches.length === 1 || !isMobile;
    if (isSingleTouch) {
      currentTouchTop = target.pageY;
    } else {
      currentTouchTop = Math.abs(target.pageY + touches[1].pageY) / 2;
    }

    self.__initialTouchTop = currentTouchTop;
    self.__lastTouchTop = currentTouchTop;
    self.__lastTouchMove = timeStamp;
    self.__lastScale = 1;
    self.__enableScrollY = !isSingleTouch;
    self.__isTracking = true;
    self.__didDecelerationComplete = false;
    self.__isDragging = !isSingleTouch;
    self.__isSingleTouch = isSingleTouch;
    self.__positions = [];
  },
  __doTouchMove: function __doTouchMove(ev, timeStamp, scale) {
    var self = this;
    var touches = ev.touches;
    var target = ev.touches ? ev.touches[0] : ev;
    var isMobile = !!ev.touches;

    if (touches && touches.length == null) {
      throw new Error('Invalid touch list: ' + touches);
    }
    if (timeStamp instanceof Date) {
      timeStamp = timeStamp.valueOf();
    }
    if (typeof timeStamp !== 'number') {
      throw new Error('Invalid timestamp value: ' + timeStamp);
    }

    // Ignore event when tracking is not enabled (event might be outside of element)
    if (!self.__isTracking) {
      return;
    }

    var currentTouchTop;

    // Compute move based around of center of fingers
    if (isMobile && touches.length === 2) {
      currentTouchTop = Math.abs(target.pageY + touches[1].pageY) / 2;
    } else {
      currentTouchTop = target.pageY;
    }

    var positions = self.__positions;

    // Are we already is dragging mode?
    if (self.__isDragging) {
      var moveY = currentTouchTop - self.__lastTouchTop;
      var scrollTop = self.__scrollTop;

      if (self.__enableScrollY) {
        scrollTop -= moveY;

        var minScrollTop = self.__minScrollTop;
        var maxScrollTop = self.__maxScrollTop;

        if (scrollTop > maxScrollTop || scrollTop < minScrollTop) {
          // Slow down on the edges
          if (scrollTop > maxScrollTop) {
            scrollTop = maxScrollTop;
          } else {
            scrollTop = minScrollTop;
          }
        }
      }

      // Keep list from growing infinitely (holding min 10, max 20 measure points)
      if (positions.length > 40) {
        positions.splice(0, 20);
      }

      // Track scroll movement for decleration
      positions.push(scrollTop, timeStamp);

      // Sync scroll position
      self.__publish(scrollTop);

      // Otherwise figure out whether we are switching into dragging mode now.
    } else {
      var minimumTrackingForScroll = 0;
      var minimumTrackingForDrag = 5;

      var distanceY = Math.abs(currentTouchTop - self.__initialTouchTop);

      self.__enableScrollY = distanceY >= minimumTrackingForScroll;

      positions.push(self.__scrollTop, timeStamp);

      self.__isDragging = self.__enableScrollY && distanceY >= minimumTrackingForDrag;

      if (self.__isDragging) {
        self.__interruptedAnimation = false;
      }
    }

    // Update last touch positions and time stamp for next event
    self.__lastTouchTop = currentTouchTop;
    self.__lastTouchMove = timeStamp;
    self.__lastScale = scale;
  },
  __doTouchEnd: function __doTouchEnd(timeStamp) {
    var self = this;

    if (timeStamp instanceof Date) {
      timeStamp = timeStamp.valueOf();
    }
    if (typeof timeStamp !== 'number') {
      throw new Error('Invalid timestamp value: ' + timeStamp);
    }

    // Ignore event when tracking is not enabled (no touchstart event on element)
    // This is required as this listener ('touchmove') sits on the document and not on the element itself.
    if (!self.__isTracking) {
      return;
    }

    // Not touching anymore (when two finger hit the screen there are two touch end events)
    self.__isTracking = false;

    // Be sure to reset the dragging flag now. Here we also detect whether
    // the finger has moved fast enough to switch into a deceleration animation.
    if (self.__isDragging) {
      // Reset dragging flag
      self.__isDragging = false;

      // Start deceleration
      // Verify that the last move detected was in some relevant time frame
      if (self.__isSingleTouch && timeStamp - self.__lastTouchMove <= 100) {
        // Then figure out what the scroll position was about 100ms ago
        var positions = self.__positions;
        var endPos = positions.length - 1;
        var startPos = endPos;

        // Move pointer to position measured 100ms ago
        for (var i = endPos; i > 0 && positions[i] > self.__lastTouchMove - 100; i -= 2) {
          startPos = i;
        }

        // If start and stop position is identical in a 100ms timeframe,
        // we cannot compute any useful deceleration.
        if (startPos !== endPos) {
          // Compute relative movement between these two points
          var timeOffset = positions[endPos] - positions[startPos];
          var movedTop = self.__scrollTop - positions[startPos - 1];

          // Based on 50ms compute the movement to apply for each render step
          self.__decelerationVelocityY = movedTop / timeOffset * (1000 / 60);

          // How much velocity is required to start the deceleration
          var minVelocityToStartDeceleration = 4;

          // Verify that we have enough velocity to start deceleration
          if (Math.abs(self.__decelerationVelocityY) > minVelocityToStartDeceleration) {
            self.__startDeceleration(timeStamp);
          }
        }
      }
    }

    if (!self.__isDecelerating) {
      self.scrollTo(self.__scrollTop);
    }

    // Fully cleanup list
    self.__positions.length = 0;
  },


  // Applies the scroll position to the content element
  __publish: function __publish(top, animationDuration) {
    var self = this;

    // Remember whether we had an animation, then we try to continue based on the current "drive" of the animation
    var wasAnimating = self.__isAnimating;
    if (wasAnimating) {
      Animate.stop(wasAnimating);
      self.__isAnimating = false;
    }

    if (animationDuration) {
      // Keep scheduled positions for scrollBy functionality
      self.__scheduledTop = top;

      var oldTop = self.__scrollTop;
      var diffTop = top - oldTop;

      var step = function step(percent, now, render) {
        self.__scrollTop = oldTop + diffTop * percent;
        // Push values out
        if (self.__callback) {
          self.__callback(self.__scrollTop);
        }
      };

      var verify = function verify(id) {
        return self.__isAnimating === id;
      };

      var completed = function completed(renderedFramesPerSecond, animationId, wasFinished) {
        if (animationId === self.__isAnimating) {
          self.__isAnimating = false;
        }
        if (self.__didDecelerationComplete || wasFinished) {
          self.__scrollingComplete();
        }
      };

      // When continuing based on previous animation we choose an ease-out animation instead of ease-in-out
      self.__isAnimating = Animate.start(step, verify, completed, animationDuration, wasAnimating ? easeOutCubic : easeInOutCubic);
    } else {
      self.__scheduledTop = self.__scrollTop = top;
      // Push values out
      if (self.__callback) {
        self.__callback(top);
      }
    }
  },


  // Called when a touch sequence end and the speed of the finger was high enough to switch into deceleration mode.
  __startDeceleration: function __startDeceleration(timeStamp) {
    var self = this;

    self.__minDecelerationScrollTop = self.__minScrollTop;
    self.__maxDecelerationScrollTop = self.__maxScrollTop;

    // Wrap class method
    var step = function step(percent, now, render) {
      self.__stepThroughDeceleration(render);
    };

    // How much velocity is required to keep the deceleration running
    var minVelocityToKeepDecelerating = 0.5;

    // Detect whether it's still worth to continue animating steps
    // If we are already slow enough to not being user perceivable anymore, we stop the whole process here.
    var verify = function verify() {
      var shouldContinue = Math.abs(self.__decelerationVelocityY) >= minVelocityToKeepDecelerating;
      if (!shouldContinue) {
        self.__didDecelerationComplete = true;
      }
      return shouldContinue;
    };

    var completed = function completed(renderedFramesPerSecond, animationId, wasFinished) {
      self.__isDecelerating = false;
      if (self.__scrollTop <= self.__minScrollTop || self.__scrollTop >= self.__maxScrollTop) {
        self.scrollTo(self.__scrollTop);
        return;
      }
      if (self.__didDecelerationComplete) {
        self.__scrollingComplete();
      }
    };

    // Start animation and switch on flag
    self.__isDecelerating = Animate.start(step, verify, completed);
  },


  // Called on every step of the animation
  __stepThroughDeceleration: function __stepThroughDeceleration(render) {
    var self = this;

    var scrollTop = self.__scrollTop + self.__decelerationVelocityY;

    var scrollTopFixed = Math.max(Math.min(self.__maxDecelerationScrollTop, scrollTop), self.__minDecelerationScrollTop);
    if (scrollTopFixed !== scrollTop) {
      scrollTop = scrollTopFixed;
      self.__decelerationVelocityY = 0;
    }

    if (Math.abs(self.__decelerationVelocityY) <= 1) {
      if (Math.abs(scrollTop % self.__itemHeight) < 1) {
        self.__decelerationVelocityY = 0;
      }
    } else {
      self.__decelerationVelocityY *= 0.95;
    }

    self.__publish(scrollTop);
  }
};

// Copy over members to prototype
for (var key in members) {
  Scroller.prototype[key] = members[key];
}

exports.default = Scroller;

/***/ }),
/* 473 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var passiveSupported = false;

try {
  var options = Object.defineProperty({}, 'passive', {
    get: function get() {
      passiveSupported = true;
    }
  });
  window.addEventListener('test', null, options);
} catch (err) {}

module.exports = passiveSupported;

/***/ }),
/* 474 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(433);

var _stringify2 = _interopRequireDefault(_stringify);

var _classCallCheck2 = __webpack_require__(450);

var _classCallCheck3 = _interopRequireDefault(_classCallCheck2);

var _createClass2 = __webpack_require__(451);

var _createClass3 = _interopRequireDefault(_createClass2);

var _arrayFilter = __webpack_require__(568);

var _arrayFilter2 = _interopRequireDefault(_arrayFilter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Manager = function () {
  function Manager(data, count, fixedColumns) {
    (0, _classCallCheck3.default)(this, Manager);

    if (process.env.NODE_ENV === 'development') {
      var notStringList = data.filter(function (item) {
        return item.parent && item.parent !== 0 && item.parent !== '0' && (typeof item.parent === 'number' || typeof item.value === 'number');
      });
      if (notStringList.length) {
        console.warn('[VUX] picker data\'s value and parent should be string:\n' + (0, _stringify2.default)(notStringList, null, 2));
      }
    }
    this.data = data;
    this.count = count;
    if (fixedColumns) {
      this.fixedColumns = fixedColumns;
    }
  }

  (0, _createClass3.default)(Manager, [{
    key: 'getChildren',
    value: function getChildren(value) {
      return (0, _arrayFilter2.default)(this.data, function (one) {
        return one.parent === value;
      });
    }
  }, {
    key: 'getFirstColumn',
    value: function getFirstColumn() {
      return (0, _arrayFilter2.default)(this.data, function (one) {
        return !one.parent || one.parent === 0 || one.parent === '0';
      });
    }
  }, {
    key: 'getPure',
    value: function getPure(obj) {
      return JSON.parse((0, _stringify2.default)(obj));
    }
  }, {
    key: 'getColumns',
    value: function getColumns(value) {
      var _this = this;

      // check is data contains the values
      if (value.length > 0) {
        var matchCount = this.getPure(this.data).filter(function (item) {
          return _this.getPure(value).indexOf(item.value) > -1;
        }).length;
        if (matchCount < this.getPure(value).length) {
          value = [];
        }
      }
      var datas = [];
      var max = this.fixedColumns || 8;
      for (var i = 0; i < max; i++) {
        if (i === 0) {
          datas.push(this.getFirstColumn());
        } else {
          // 没有数据时，取得上一级的第一个
          if (!value[i]) {
            if (typeof datas[i - 1][0] === 'undefined') {
              break;
            } else {
              var topValue = datas[i - 1][0].value;
              datas.push(this.getChildren(topValue));
            }
          } else {
            datas.push(this.getChildren(value[i - 1]));
          }
        }
      }
      var list = datas.filter(function (item) {
        return item.length > 0;
      });
      // correct the column
      this.count = list.length;
      return list;
    }
  }]);
  return Manager;
}();

exports.default = Manager;
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(56)))

/***/ }),
/* 475 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (value) {
  if (!value) {
    return false;
  }
  return Object.prototype.toString.call(value) === '[object Array]';
};

/***/ }),
/* 476 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(573);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(574);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_ae688382_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(575);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(571)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_ae688382_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/cell/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-ae688382", Component.options)
  } else {
    hotAPI.reload("data-v-ae688382", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 477 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function () {
  return {
    title: [String, Number],
    value: [String, Number, Array],
    isLink: Boolean,
    isLoading: Boolean,
    inlineDesc: [String, Number],
    primary: {
      type: String,
      default: 'title'
    },
    link: [String, Object],
    valueAlign: [String, Boolean, Number],
    borderIntent: {
      type: Boolean,
      default: true
    },
    disabled: Boolean,
    arrowDirection: String, // down or up
    alignItems: String
  };
};

/***/ }),
/* 478 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (self, name) {
  if (self.$parent && typeof self.$parent[name] !== 'undefined') {
    return self.$parent[name];
  }
  if (self.$parent && self.$parent.$parent && typeof self.$parent.$parent[name] !== 'undefined') {
    return self.$parent.$parent[name];
  }
};

/***/ }),
/* 479 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(579);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(580);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_204858c5_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(581);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(576)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_204858c5_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/popup/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-204858c5", Component.options)
  } else {
    hotAPI.reload("data-v-204858c5", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 480 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof2 = __webpack_require__(437);

var _typeof3 = _interopRequireDefault(_typeof2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var passiveSupported = __webpack_require__(473);
var isBrowser = (typeof window === 'undefined' ? 'undefined' : (0, _typeof3.default)(window)) === 'object';

// not a good way but works well
if (isBrowser) {
  window.__$vuxPopups = window.__$vuxPopups || {};
}

var popupDialog = function popupDialog(option) {
  var _this = this;

  if (!isBrowser) {
    return;
  }
  this.uuid = Math.random().toString(36).substring(3, 8);
  this.params = {};
  if (Object.prototype.toString.call(option) === '[object Object]') {
    this.params = {
      hideOnBlur: option.hideOnBlur,
      onOpen: option.onOpen || function () {},
      onClose: option.onClose || function () {},
      showMask: option.showMask
    };
  }
  if (!!document.querySelectorAll('.vux-popup-mask').length <= 0) {
    this.divMask = document.createElement('a');
    this.divMask.className = 'vux-popup-mask';
    this.divMask.dataset.uuid = '';
    this.divMask.href = 'javascript:void(0)';
    document.body.appendChild(this.divMask);
  }
  var div = void 0;
  if (!option.container) {
    div = document.createElement('div');
  } else {
    div = option.container;
  }

  div.className += ' vux-popup-dialog vux-popup-dialog-' + this.uuid;
  if (!this.params.hideOnBlur) {
    div.className += ' vux-popup-mask-disabled';
  }

  this.div = div;

  if (!option.container) {
    document.body.appendChild(div);
  }
  this.container = document.querySelector('.vux-popup-dialog-' + this.uuid);
  this.mask = document.querySelector('.vux-popup-mask');
  this.mask.dataset.uuid += ',' + this.uuid;
  this._bindEvents();
  option = null;
  this.containerHandler = function () {
    _this.mask && !/show/.test(_this.mask.className) && setTimeout(function () {
      !/show/.test(_this.mask.className) && (_this.mask.style['zIndex'] = -1);
    }, 200);
  };

  this.container && this.container.addEventListener('webkitTransitionEnd', this.containerHandler);
  this.container && this.container.addEventListener('transitionend', this.containerHandler);
};

popupDialog.prototype.onClickMask = function () {
  this.params.hideOnBlur && this.params.onClose();
};

popupDialog.prototype._bindEvents = function () {
  if (this.params.hideOnBlur) {
    this.mask.addEventListener('click', this.onClickMask.bind(this), false);
    this.mask.addEventListener('touchmove', function (e) {
      return e.preventDefault();
    }, passiveSupported ? { passive: false } : false);
  }
};

popupDialog.prototype.show = function () {
  if (this.params.showMask) {
    this.mask.classList.add('vux-popup-show');
    this.mask.style['zIndex'] = 500;
  }
  this.container.classList.add('vux-popup-show');
  this.params.onOpen && this.params.onOpen(this);
  if (isBrowser) {
    window.__$vuxPopups[this.uuid] = 1;
  }
};

popupDialog.prototype.hide = function () {
  var _this2 = this;

  var shouldCallback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;

  this.container.classList.remove('vux-popup-show');
  if (!document.querySelector('.vux-popup-dialog.vux-popup-show')) {
    this.mask.classList.remove('vux-popup-show');
    setTimeout(function () {
      _this2.mask && !/show/.test(_this2.mask.className) && (_this2.mask.style['zIndex'] = -1);
    }, 400);
  }
  shouldCallback === false && this.params.onClose && this.params.hideOnBlur && this.params.onClose(this);
  this.isShow = false;
  if (isBrowser) {
    delete window.__$vuxPopups[this.uuid];
  }
};

popupDialog.prototype.destroy = function () {
  this.mask.dataset.uuid = this.mask.dataset.uuid.replace(new RegExp(',' + this.uuid, 'g'), '');
  if (!this.mask.dataset.uuid) {
    this.mask.removeEventListener('click', this.onClickMask.bind(this), false);
    this.mask && this.mask.parentNode && this.mask.parentNode.removeChild(this.mask);
  } else {
    this.hide();
  }
  this.container.removeEventListener('webkitTransitionEnd', this.containerHandler);
  this.container.removeEventListener('transitionend', this.containerHandler);
  if (isBrowser) {
    delete window.__$vuxPopups[this.uuid];
  }
};

exports.default = popupDialog;

/***/ }),
/* 481 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = {
  hasClass: function hasClass(el, token) {
    return new RegExp('(\\s|^)' + token + '(\\s|$)').test(el.className);
  },
  addClass: function addClass(el, token) {
    if (!el) {
      return;
    }
    if (el.classList) {
      el.classList.add(token);
    } else if (!this.hasClass(el, token)) {
      el.className += '' + token;
    }
  },
  removeClass: function removeClass(el, token) {
    if (!el) {
      return;
    }
    if (el.classList) {
      el.classList.remove(token);
    } else if (this.hasClass(el, token)) {
      el.className = el.className.replace(new RegExp('(\\s|^)' + token + '(\\s|$)'), ' ').replace(/^\s+|\s+$/g, '');
    }
  }
};

/***/ }),
/* 482 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(584);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(585);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_3cd602aa_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(586);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(582)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_3cd602aa_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/popup-header/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-3cd602aa", Component.options)
  } else {
    hotAPI.reload("data-v-3cd602aa", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 483 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

exports.default = function (array) {
  return array.length === 1 ? array[0] : array.join(' ');
};

/***/ }),
/* 484 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
// Thanks to: https://github.com/calebroseland/vue-dom-portal

var objectAssign = __webpack_require__(114);
/**
 * Get target DOM Node
 * @param {(Node|string|Boolean)} [node=document.body] DOM Node, CSS selector, or Boolean
 * @return {Node} The target that the el will be appended to
 */
function getTarget(node) {
  if (node === void 0) {
    return document.body;
  }

  if (typeof node === 'string' && node.indexOf('?') === 0) {
    return document.body;
  } else if (typeof node === 'string' && node.indexOf('?') > 0) {
    node = node.split('?')[0];
  }

  if (node === 'body' || node === true) {
    return document.body;
  }

  return node instanceof window.Node ? node : document.querySelector(node);
}

function getShouldUpdate(node) {
  // do not updated by default
  if (!node) {
    return false;
  }
  if (typeof node === 'string' && node.indexOf('?') > 0) {
    try {
      var config = JSON.parse(node.split('?')[1]);
      return config.autoUpdate || false;
    } catch (e) {
      return false;
    }
  }
  return false;
}

var directive = {
  inserted: function inserted(el, _ref, vnode) {
    var value = _ref.value;

    el.className = el.className ? el.className + ' v-transfer-dom' : 'v-transfer-dom';
    var parentNode = el.parentNode;
    var home = document.createComment('');
    var hasMovedOut = false;

    if (value !== false) {
      parentNode.replaceChild(home, el); // moving out, el is no longer in the document
      getTarget(value).appendChild(el); // moving into new place
      hasMovedOut = true;
    }
    if (!el.__transferDomData) {
      el.__transferDomData = {
        parentNode: parentNode,
        home: home,
        target: getTarget(value),
        hasMovedOut: hasMovedOut
      };
    }
  },
  componentUpdated: function componentUpdated(el, _ref2) {
    var value = _ref2.value;

    var shouldUpdate = getShouldUpdate(value);
    if (!shouldUpdate) {
      return;
    }
    // need to make sure children are done updating (vs. `update`)
    var ref$1 = el.__transferDomData;
    // homes.get(el)
    var parentNode = ref$1.parentNode;
    var home = ref$1.home;
    var hasMovedOut = ref$1.hasMovedOut; // recall where home is

    if (!hasMovedOut && value) {
      // remove from document and leave placeholder
      parentNode.replaceChild(home, el);
      // append to target
      getTarget(value).appendChild(el);
      el.__transferDomData = objectAssign({}, el.__transferDomData, { hasMovedOut: true, target: getTarget(value) });
    } else if (hasMovedOut && value === false) {
      // previously moved, coming back home
      parentNode.replaceChild(el, home);
      el.__transferDomData = objectAssign({}, el.__transferDomData, { hasMovedOut: false, target: getTarget(value) });
    } else if (value) {
      // already moved, going somewhere else
      getTarget(value).appendChild(el);
    }
  },

  unbind: function unbind(el, binding) {
    el.className = el.className.replace('v-transfer-dom', '');
    if (el.__transferDomData && el.__transferDomData.hasMovedOut === true) {
      el.__transferDomData.parentNode && el.__transferDomData.parentNode.appendChild(el);
    }
    el.__transferDomData = null;
  }
};

exports.default = directive;

/***/ }),
/* 485 */
/***/ (function(module, exports) {

module.exports = [{"name":"北京市","value":"110000"},{"name":"天津市","value":"120000"},{"name":"河北省","value":"130000"},{"name":"山西省","value":"140000"},{"name":"内蒙古自治区","value":"150000"},{"name":"辽宁省","value":"210000"},{"name":"吉林省","value":"220000"},{"name":"黑龙江省","value":"230000"},{"name":"上海市","value":"310000"},{"name":"江苏省","value":"320000"},{"name":"浙江省","value":"330000"},{"name":"安徽省","value":"340000"},{"name":"福建省","value":"350000"},{"name":"江西省","value":"360000"},{"name":"山东省","value":"370000"},{"name":"河南省","value":"410000"},{"name":"湖北省","value":"420000"},{"name":"湖南省","value":"430000"},{"name":"广东省","value":"440000"},{"name":"广西壮族自治区","value":"450000"},{"name":"海南省","value":"460000"},{"name":"重庆市","value":"500000"},{"name":"四川省","value":"510000"},{"name":"贵州省","value":"520000"},{"name":"云南省","value":"530000"},{"name":"西藏自治区","value":"540000"},{"name":"陕西省","value":"610000"},{"name":"甘肃省","value":"620000"},{"name":"青海省","value":"630000"},{"name":"宁夏回族自治区","value":"640000"},{"name":"新疆维吾尔自治区","value":"650000"},{"name":"市辖区","value":"110100","parent":"110000"},{"name":"东城区","value":"110101","parent":"110100"},{"name":"西城区","value":"110102","parent":"110100"},{"name":"朝阳区","value":"110105","parent":"110100"},{"name":"丰台区","value":"110106","parent":"110100"},{"name":"石景山区","value":"110107","parent":"110100"},{"name":"海淀区","value":"110108","parent":"110100"},{"name":"门头沟区","value":"110109","parent":"110100"},{"name":"房山区","value":"110111","parent":"110100"},{"name":"通州区","value":"110112","parent":"110100"},{"name":"顺义区","value":"110113","parent":"110100"},{"name":"昌平区","value":"110114","parent":"110100"},{"name":"大兴区","value":"110115","parent":"110100"},{"name":"怀柔区","value":"110116","parent":"110100"},{"name":"平谷区","value":"110117","parent":"110100"},{"name":"密云县","value":"110228","parent":"110100"},{"name":"延庆县","value":"110229","parent":"110100"},{"name":"市辖区","value":"120100","parent":"120000"},{"name":"和平区","value":"120101","parent":"120100"},{"name":"河东区","value":"120102","parent":"120100"},{"name":"河西区","value":"120103","parent":"120100"},{"name":"南开区","value":"120104","parent":"120100"},{"name":"河北区","value":"120105","parent":"120100"},{"name":"红桥区","value":"120106","parent":"120100"},{"name":"东丽区","value":"120110","parent":"120100"},{"name":"西青区","value":"120111","parent":"120100"},{"name":"津南区","value":"120112","parent":"120100"},{"name":"北辰区","value":"120113","parent":"120100"},{"name":"武清区","value":"120114","parent":"120100"},{"name":"宝坻区","value":"120115","parent":"120100"},{"name":"滨海新区","value":"120116","parent":"120100"},{"name":"宁河区","value":"120117","parent":"120100"},{"name":"静海区","value":"120118","parent":"120100"},{"name":"蓟县","value":"120225","parent":"120100"},{"name":"石家庄市","value":"130100","parent":"130000"},{"name":"唐山市","value":"130200","parent":"130000"},{"name":"秦皇岛市","value":"130300","parent":"130000"},{"name":"邯郸市","value":"130400","parent":"130000"},{"name":"邢台市","value":"130500","parent":"130000"},{"name":"保定市","value":"130600","parent":"130000"},{"name":"张家口市","value":"130700","parent":"130000"},{"name":"承德市","value":"130800","parent":"130000"},{"name":"沧州市","value":"130900","parent":"130000"},{"name":"廊坊市","value":"131000","parent":"130000"},{"name":"衡水市","value":"131100","parent":"130000"},{"name":"定州市","value":"139001","parent":"130000"},{"name":"辛集市","value":"139002","parent":"130000"},{"name":"长安区","value":"130102","parent":"130100"},{"name":"桥西区","value":"130104","parent":"130100"},{"name":"新华区","value":"130105","parent":"130100"},{"name":"井陉矿区","value":"130107","parent":"130100"},{"name":"裕华区","value":"130108","parent":"130100"},{"name":"藁城区","value":"130109","parent":"130100"},{"name":"鹿泉区","value":"130110","parent":"130100"},{"name":"栾城区","value":"130111","parent":"130100"},{"name":"井陉县","value":"130121","parent":"130100"},{"name":"正定县","value":"130123","parent":"130100"},{"name":"行唐县","value":"130125","parent":"130100"},{"name":"灵寿县","value":"130126","parent":"130100"},{"name":"高邑县","value":"130127","parent":"130100"},{"name":"深泽县","value":"130128","parent":"130100"},{"name":"赞皇县","value":"130129","parent":"130100"},{"name":"无极县","value":"130130","parent":"130100"},{"name":"平山县","value":"130131","parent":"130100"},{"name":"元氏县","value":"130132","parent":"130100"},{"name":"赵县","value":"130133","parent":"130100"},{"name":"晋州市","value":"130183","parent":"130100"},{"name":"新乐市","value":"130184","parent":"130100"},{"name":"路南区","value":"130202","parent":"130200"},{"name":"路北区","value":"130203","parent":"130200"},{"name":"古冶区","value":"130204","parent":"130200"},{"name":"开平区","value":"130205","parent":"130200"},{"name":"丰南区","value":"130207","parent":"130200"},{"name":"丰润区","value":"130208","parent":"130200"},{"name":"曹妃甸区","value":"130209","parent":"130200"},{"name":"滦县","value":"130223","parent":"130200"},{"name":"滦南县","value":"130224","parent":"130200"},{"name":"乐亭县","value":"130225","parent":"130200"},{"name":"迁西县","value":"130227","parent":"130200"},{"name":"玉田县","value":"130229","parent":"130200"},{"name":"遵化市","value":"130281","parent":"130200"},{"name":"迁安市","value":"130283","parent":"130200"},{"name":"海港区","value":"130302","parent":"130300"},{"name":"山海关区","value":"130303","parent":"130300"},{"name":"北戴河区","value":"130304","parent":"130300"},{"name":"抚宁区","value":"130306","parent":"130300"},{"name":"青龙满族自治县","value":"130321","parent":"130300"},{"name":"昌黎县","value":"130322","parent":"130300"},{"name":"卢龙县","value":"130324","parent":"130300"},{"name":"邯山区","value":"130402","parent":"130400"},{"name":"丛台区","value":"130403","parent":"130400"},{"name":"复兴区","value":"130404","parent":"130400"},{"name":"峰峰矿区","value":"130406","parent":"130400"},{"name":"邯郸县","value":"130421","parent":"130400"},{"name":"临漳县","value":"130423","parent":"130400"},{"name":"成安县","value":"130424","parent":"130400"},{"name":"大名县","value":"130425","parent":"130400"},{"name":"涉县","value":"130426","parent":"130400"},{"name":"磁县","value":"130427","parent":"130400"},{"name":"肥乡县","value":"130428","parent":"130400"},{"name":"永年县","value":"130429","parent":"130400"},{"name":"邱县","value":"130430","parent":"130400"},{"name":"鸡泽县","value":"130431","parent":"130400"},{"name":"广平县","value":"130432","parent":"130400"},{"name":"馆陶县","value":"130433","parent":"130400"},{"name":"魏县","value":"130434","parent":"130400"},{"name":"曲周县","value":"130435","parent":"130400"},{"name":"武安市","value":"130481","parent":"130400"},{"name":"桥东区","value":"130502","parent":"130500"},{"name":"桥西区","value":"130503","parent":"130500"},{"name":"邢台县","value":"130521","parent":"130500"},{"name":"临城县","value":"130522","parent":"130500"},{"name":"内丘县","value":"130523","parent":"130500"},{"name":"柏乡县","value":"130524","parent":"130500"},{"name":"隆尧县","value":"130525","parent":"130500"},{"name":"任县","value":"130526","parent":"130500"},{"name":"南和县","value":"130527","parent":"130500"},{"name":"宁晋县","value":"130528","parent":"130500"},{"name":"巨鹿县","value":"130529","parent":"130500"},{"name":"新河县","value":"130530","parent":"130500"},{"name":"广宗县","value":"130531","parent":"130500"},{"name":"平乡县","value":"130532","parent":"130500"},{"name":"威县","value":"130533","parent":"130500"},{"name":"清河县","value":"130534","parent":"130500"},{"name":"临西县","value":"130535","parent":"130500"},{"name":"南宫市","value":"130581","parent":"130500"},{"name":"沙河市","value":"130582","parent":"130500"},{"name":"竞秀区","value":"130602","parent":"130600"},{"name":"莲池区","value":"130606","parent":"130600"},{"name":"满城区","value":"130607","parent":"130600"},{"name":"清苑区","value":"130608","parent":"130600"},{"name":"徐水区","value":"130609","parent":"130600"},{"name":"涞水县","value":"130623","parent":"130600"},{"name":"阜平县","value":"130624","parent":"130600"},{"name":"定兴县","value":"130626","parent":"130600"},{"name":"唐县","value":"130627","parent":"130600"},{"name":"高阳县","value":"130628","parent":"130600"},{"name":"容城县","value":"130629","parent":"130600"},{"name":"涞源县","value":"130630","parent":"130600"},{"name":"望都县","value":"130631","parent":"130600"},{"name":"安新县","value":"130632","parent":"130600"},{"name":"易县","value":"130633","parent":"130600"},{"name":"曲阳县","value":"130634","parent":"130600"},{"name":"蠡县","value":"130635","parent":"130600"},{"name":"顺平县","value":"130636","parent":"130600"},{"name":"博野县","value":"130637","parent":"130600"},{"name":"雄县","value":"130638","parent":"130600"},{"name":"涿州市","value":"130681","parent":"130600"},{"name":"安国市","value":"130683","parent":"130600"},{"name":"高碑店市","value":"130684","parent":"130600"},{"name":"桥东区","value":"130702","parent":"130700"},{"name":"桥西区","value":"130703","parent":"130700"},{"name":"宣化区","value":"130705","parent":"130700"},{"name":"下花园区","value":"130706","parent":"130700"},{"name":"宣化县","value":"130721","parent":"130700"},{"name":"张北县","value":"130722","parent":"130700"},{"name":"康保县","value":"130723","parent":"130700"},{"name":"沽源县","value":"130724","parent":"130700"},{"name":"尚义县","value":"130725","parent":"130700"},{"name":"蔚县","value":"130726","parent":"130700"},{"name":"阳原县","value":"130727","parent":"130700"},{"name":"怀安县","value":"130728","parent":"130700"},{"name":"万全县","value":"130729","parent":"130700"},{"name":"怀来县","value":"130730","parent":"130700"},{"name":"涿鹿县","value":"130731","parent":"130700"},{"name":"赤城县","value":"130732","parent":"130700"},{"name":"崇礼县","value":"130733","parent":"130700"},{"name":"双桥区","value":"130802","parent":"130800"},{"name":"双滦区","value":"130803","parent":"130800"},{"name":"鹰手营子矿区","value":"130804","parent":"130800"},{"name":"承德县","value":"130821","parent":"130800"},{"name":"兴隆县","value":"130822","parent":"130800"},{"name":"平泉县","value":"130823","parent":"130800"},{"name":"滦平县","value":"130824","parent":"130800"},{"name":"隆化县","value":"130825","parent":"130800"},{"name":"丰宁满族自治县","value":"130826","parent":"130800"},{"name":"宽城满族自治县","value":"130827","parent":"130800"},{"name":"围场满族蒙古族自治县","value":"130828","parent":"130800"},{"name":"新华区","value":"130902","parent":"130900"},{"name":"运河区","value":"130903","parent":"130900"},{"name":"沧县","value":"130921","parent":"130900"},{"name":"青县","value":"130922","parent":"130900"},{"name":"东光县","value":"130923","parent":"130900"},{"name":"海兴县","value":"130924","parent":"130900"},{"name":"盐山县","value":"130925","parent":"130900"},{"name":"肃宁县","value":"130926","parent":"130900"},{"name":"南皮县","value":"130927","parent":"130900"},{"name":"吴桥县","value":"130928","parent":"130900"},{"name":"献县","value":"130929","parent":"130900"},{"name":"孟村回族自治县","value":"130930","parent":"130900"},{"name":"泊头市","value":"130981","parent":"130900"},{"name":"任丘市","value":"130982","parent":"130900"},{"name":"黄骅市","value":"130983","parent":"130900"},{"name":"河间市","value":"130984","parent":"130900"},{"name":"安次区","value":"131002","parent":"131000"},{"name":"广阳区","value":"131003","parent":"131000"},{"name":"固安县","value":"131022","parent":"131000"},{"name":"永清县","value":"131023","parent":"131000"},{"name":"香河县","value":"131024","parent":"131000"},{"name":"大城县","value":"131025","parent":"131000"},{"name":"文安县","value":"131026","parent":"131000"},{"name":"大厂回族自治县","value":"131028","parent":"131000"},{"name":"霸州市","value":"131081","parent":"131000"},{"name":"三河市","value":"131082","parent":"131000"},{"name":"桃城区","value":"131102","parent":"131100"},{"name":"枣强县","value":"131121","parent":"131100"},{"name":"武邑县","value":"131122","parent":"131100"},{"name":"武强县","value":"131123","parent":"131100"},{"name":"饶阳县","value":"131124","parent":"131100"},{"name":"安平县","value":"131125","parent":"131100"},{"name":"故城县","value":"131126","parent":"131100"},{"name":"景县","value":"131127","parent":"131100"},{"name":"阜城县","value":"131128","parent":"131100"},{"name":"冀州市","value":"131181","parent":"131100"},{"name":"深州市","value":"131182","parent":"131100"},{"name":"太原市","value":"140100","parent":"140000"},{"name":"大同市","value":"140200","parent":"140000"},{"name":"阳泉市","value":"140300","parent":"140000"},{"name":"长治市","value":"140400","parent":"140000"},{"name":"晋城市","value":"140500","parent":"140000"},{"name":"朔州市","value":"140600","parent":"140000"},{"name":"晋中市","value":"140700","parent":"140000"},{"name":"运城市","value":"140800","parent":"140000"},{"name":"忻州市","value":"140900","parent":"140000"},{"name":"临汾市","value":"141000","parent":"140000"},{"name":"吕梁市","value":"141100","parent":"140000"},{"name":"小店区","value":"140105","parent":"140100"},{"name":"迎泽区","value":"140106","parent":"140100"},{"name":"杏花岭区","value":"140107","parent":"140100"},{"name":"尖草坪区","value":"140108","parent":"140100"},{"name":"万柏林区","value":"140109","parent":"140100"},{"name":"晋源区","value":"140110","parent":"140100"},{"name":"清徐县","value":"140121","parent":"140100"},{"name":"阳曲县","value":"140122","parent":"140100"},{"name":"娄烦县","value":"140123","parent":"140100"},{"name":"古交市","value":"140181","parent":"140100"},{"name":"城区","value":"140202","parent":"140200"},{"name":"矿区","value":"140203","parent":"140200"},{"name":"南郊区","value":"140211","parent":"140200"},{"name":"新荣区","value":"140212","parent":"140200"},{"name":"阳高县","value":"140221","parent":"140200"},{"name":"天镇县","value":"140222","parent":"140200"},{"name":"广灵县","value":"140223","parent":"140200"},{"name":"灵丘县","value":"140224","parent":"140200"},{"name":"浑源县","value":"140225","parent":"140200"},{"name":"左云县","value":"140226","parent":"140200"},{"name":"大同县","value":"140227","parent":"140200"},{"name":"城区","value":"140302","parent":"140300"},{"name":"矿区","value":"140303","parent":"140300"},{"name":"郊区","value":"140311","parent":"140300"},{"name":"平定县","value":"140321","parent":"140300"},{"name":"盂县","value":"140322","parent":"140300"},{"name":"城区","value":"140402","parent":"140400"},{"name":"郊区","value":"140411","parent":"140400"},{"name":"长治县","value":"140421","parent":"140400"},{"name":"襄垣县","value":"140423","parent":"140400"},{"name":"屯留县","value":"140424","parent":"140400"},{"name":"平顺县","value":"140425","parent":"140400"},{"name":"黎城县","value":"140426","parent":"140400"},{"name":"壶关县","value":"140427","parent":"140400"},{"name":"长子县","value":"140428","parent":"140400"},{"name":"武乡县","value":"140429","parent":"140400"},{"name":"沁县","value":"140430","parent":"140400"},{"name":"沁源县","value":"140431","parent":"140400"},{"name":"潞城市","value":"140481","parent":"140400"},{"name":"城区","value":"140502","parent":"140500"},{"name":"沁水县","value":"140521","parent":"140500"},{"name":"阳城县","value":"140522","parent":"140500"},{"name":"陵川县","value":"140524","parent":"140500"},{"name":"泽州县","value":"140525","parent":"140500"},{"name":"高平市","value":"140581","parent":"140500"},{"name":"朔城区","value":"140602","parent":"140600"},{"name":"平鲁区","value":"140603","parent":"140600"},{"name":"山阴县","value":"140621","parent":"140600"},{"name":"应县","value":"140622","parent":"140600"},{"name":"右玉县","value":"140623","parent":"140600"},{"name":"怀仁县","value":"140624","parent":"140600"},{"name":"榆次区","value":"140702","parent":"140700"},{"name":"榆社县","value":"140721","parent":"140700"},{"name":"左权县","value":"140722","parent":"140700"},{"name":"和顺县","value":"140723","parent":"140700"},{"name":"昔阳县","value":"140724","parent":"140700"},{"name":"寿阳县","value":"140725","parent":"140700"},{"name":"太谷县","value":"140726","parent":"140700"},{"name":"祁县","value":"140727","parent":"140700"},{"name":"平遥县","value":"140728","parent":"140700"},{"name":"灵石县","value":"140729","parent":"140700"},{"name":"介休市","value":"140781","parent":"140700"},{"name":"盐湖区","value":"140802","parent":"140800"},{"name":"临猗县","value":"140821","parent":"140800"},{"name":"万荣县","value":"140822","parent":"140800"},{"name":"闻喜县","value":"140823","parent":"140800"},{"name":"稷山县","value":"140824","parent":"140800"},{"name":"新绛县","value":"140825","parent":"140800"},{"name":"绛县","value":"140826","parent":"140800"},{"name":"垣曲县","value":"140827","parent":"140800"},{"name":"夏县","value":"140828","parent":"140800"},{"name":"平陆县","value":"140829","parent":"140800"},{"name":"芮城县","value":"140830","parent":"140800"},{"name":"永济市","value":"140881","parent":"140800"},{"name":"河津市","value":"140882","parent":"140800"},{"name":"忻府区","value":"140902","parent":"140900"},{"name":"定襄县","value":"140921","parent":"140900"},{"name":"五台县","value":"140922","parent":"140900"},{"name":"代县","value":"140923","parent":"140900"},{"name":"繁峙县","value":"140924","parent":"140900"},{"name":"宁武县","value":"140925","parent":"140900"},{"name":"静乐县","value":"140926","parent":"140900"},{"name":"神池县","value":"140927","parent":"140900"},{"name":"五寨县","value":"140928","parent":"140900"},{"name":"岢岚县","value":"140929","parent":"140900"},{"name":"河曲县","value":"140930","parent":"140900"},{"name":"保德县","value":"140931","parent":"140900"},{"name":"偏关县","value":"140932","parent":"140900"},{"name":"原平市","value":"140981","parent":"140900"},{"name":"尧都区","value":"141002","parent":"141000"},{"name":"曲沃县","value":"141021","parent":"141000"},{"name":"翼城县","value":"141022","parent":"141000"},{"name":"襄汾县","value":"141023","parent":"141000"},{"name":"洪洞县","value":"141024","parent":"141000"},{"name":"古县","value":"141025","parent":"141000"},{"name":"安泽县","value":"141026","parent":"141000"},{"name":"浮山县","value":"141027","parent":"141000"},{"name":"吉县","value":"141028","parent":"141000"},{"name":"乡宁县","value":"141029","parent":"141000"},{"name":"大宁县","value":"141030","parent":"141000"},{"name":"隰县","value":"141031","parent":"141000"},{"name":"永和县","value":"141032","parent":"141000"},{"name":"蒲县","value":"141033","parent":"141000"},{"name":"汾西县","value":"141034","parent":"141000"},{"name":"侯马市","value":"141081","parent":"141000"},{"name":"霍州市","value":"141082","parent":"141000"},{"name":"离石区","value":"141102","parent":"141100"},{"name":"文水县","value":"141121","parent":"141100"},{"name":"交城县","value":"141122","parent":"141100"},{"name":"兴县","value":"141123","parent":"141100"},{"name":"临县","value":"141124","parent":"141100"},{"name":"柳林县","value":"141125","parent":"141100"},{"name":"石楼县","value":"141126","parent":"141100"},{"name":"岚县","value":"141127","parent":"141100"},{"name":"方山县","value":"141128","parent":"141100"},{"name":"中阳县","value":"141129","parent":"141100"},{"name":"交口县","value":"141130","parent":"141100"},{"name":"孝义市","value":"141181","parent":"141100"},{"name":"汾阳市","value":"141182","parent":"141100"},{"name":"呼和浩特市","value":"150100","parent":"150000"},{"name":"包头市","value":"150200","parent":"150000"},{"name":"乌海市","value":"150300","parent":"150000"},{"name":"赤峰市","value":"150400","parent":"150000"},{"name":"通辽市","value":"150500","parent":"150000"},{"name":"鄂尔多斯市","value":"150600","parent":"150000"},{"name":"呼伦贝尔市","value":"150700","parent":"150000"},{"name":"巴彦淖尔市","value":"150800","parent":"150000"},{"name":"乌兰察布市","value":"150900","parent":"150000"},{"name":"兴安盟","value":"152200","parent":"150000"},{"name":"锡林郭勒盟","value":"152500","parent":"150000"},{"name":"阿拉善盟","value":"152900","parent":"150000"},{"name":"新城区","value":"150102","parent":"150100"},{"name":"回民区","value":"150103","parent":"150100"},{"name":"玉泉区","value":"150104","parent":"150100"},{"name":"赛罕区","value":"150105","parent":"150100"},{"name":"土默特左旗","value":"150121","parent":"150100"},{"name":"托克托县","value":"150122","parent":"150100"},{"name":"和林格尔县","value":"150123","parent":"150100"},{"name":"清水河县","value":"150124","parent":"150100"},{"name":"武川县","value":"150125","parent":"150100"},{"name":"东河区","value":"150202","parent":"150200"},{"name":"昆都仑区","value":"150203","parent":"150200"},{"name":"青山区","value":"150204","parent":"150200"},{"name":"石拐区","value":"150205","parent":"150200"},{"name":"白云鄂博矿区","value":"150206","parent":"150200"},{"name":"九原区","value":"150207","parent":"150200"},{"name":"土默特右旗","value":"150221","parent":"150200"},{"name":"固阳县","value":"150222","parent":"150200"},{"name":"达尔罕茂明安联合旗","value":"150223","parent":"150200"},{"name":"海勃湾区","value":"150302","parent":"150300"},{"name":"海南区","value":"150303","parent":"150300"},{"name":"乌达区","value":"150304","parent":"150300"},{"name":"红山区","value":"150402","parent":"150400"},{"name":"元宝山区","value":"150403","parent":"150400"},{"name":"松山区","value":"150404","parent":"150400"},{"name":"阿鲁科尔沁旗","value":"150421","parent":"150400"},{"name":"巴林左旗","value":"150422","parent":"150400"},{"name":"巴林右旗","value":"150423","parent":"150400"},{"name":"林西县","value":"150424","parent":"150400"},{"name":"克什克腾旗","value":"150425","parent":"150400"},{"name":"翁牛特旗","value":"150426","parent":"150400"},{"name":"喀喇沁旗","value":"150428","parent":"150400"},{"name":"宁城县","value":"150429","parent":"150400"},{"name":"敖汉旗","value":"150430","parent":"150400"},{"name":"科尔沁区","value":"150502","parent":"150500"},{"name":"科尔沁左翼中旗","value":"150521","parent":"150500"},{"name":"科尔沁左翼后旗","value":"150522","parent":"150500"},{"name":"开鲁县","value":"150523","parent":"150500"},{"name":"库伦旗","value":"150524","parent":"150500"},{"name":"奈曼旗","value":"150525","parent":"150500"},{"name":"扎鲁特旗","value":"150526","parent":"150500"},{"name":"霍林郭勒市","value":"150581","parent":"150500"},{"name":"东胜区","value":"150602","parent":"150600"},{"name":"达拉特旗","value":"150621","parent":"150600"},{"name":"准格尔旗","value":"150622","parent":"150600"},{"name":"鄂托克前旗","value":"150623","parent":"150600"},{"name":"鄂托克旗","value":"150624","parent":"150600"},{"name":"杭锦旗","value":"150625","parent":"150600"},{"name":"乌审旗","value":"150626","parent":"150600"},{"name":"伊金霍洛旗","value":"150627","parent":"150600"},{"name":"海拉尔区","value":"150702","parent":"150700"},{"name":"扎赉诺尔区","value":"150703","parent":"150700"},{"name":"阿荣旗","value":"150721","parent":"150700"},{"name":"莫力达瓦达斡尔族自治旗","value":"150722","parent":"150700"},{"name":"鄂伦春自治旗","value":"150723","parent":"150700"},{"name":"鄂温克族自治旗","value":"150724","parent":"150700"},{"name":"陈巴尔虎旗","value":"150725","parent":"150700"},{"name":"新巴尔虎左旗","value":"150726","parent":"150700"},{"name":"新巴尔虎右旗","value":"150727","parent":"150700"},{"name":"满洲里市","value":"150781","parent":"150700"},{"name":"牙克石市","value":"150782","parent":"150700"},{"name":"扎兰屯市","value":"150783","parent":"150700"},{"name":"额尔古纳市","value":"150784","parent":"150700"},{"name":"根河市","value":"150785","parent":"150700"},{"name":"临河区","value":"150802","parent":"150800"},{"name":"五原县","value":"150821","parent":"150800"},{"name":"磴口县","value":"150822","parent":"150800"},{"name":"乌拉特前旗","value":"150823","parent":"150800"},{"name":"乌拉特中旗","value":"150824","parent":"150800"},{"name":"乌拉特后旗","value":"150825","parent":"150800"},{"name":"杭锦后旗","value":"150826","parent":"150800"},{"name":"集宁区","value":"150902","parent":"150900"},{"name":"卓资县","value":"150921","parent":"150900"},{"name":"化德县","value":"150922","parent":"150900"},{"name":"商都县","value":"150923","parent":"150900"},{"name":"兴和县","value":"150924","parent":"150900"},{"name":"凉城县","value":"150925","parent":"150900"},{"name":"察哈尔右翼前旗","value":"150926","parent":"150900"},{"name":"察哈尔右翼中旗","value":"150927","parent":"150900"},{"name":"察哈尔右翼后旗","value":"150928","parent":"150900"},{"name":"四子王旗","value":"150929","parent":"150900"},{"name":"丰镇市","value":"150981","parent":"150900"},{"name":"乌兰浩特市","value":"152201","parent":"152200"},{"name":"阿尔山市","value":"152202","parent":"152200"},{"name":"科尔沁右翼前旗","value":"152221","parent":"152200"},{"name":"科尔沁右翼中旗","value":"152222","parent":"152200"},{"name":"扎赉特旗","value":"152223","parent":"152200"},{"name":"突泉县","value":"152224","parent":"152200"},{"name":"二连浩特市","value":"152501","parent":"152500"},{"name":"锡林浩特市","value":"152502","parent":"152500"},{"name":"阿巴嘎旗","value":"152522","parent":"152500"},{"name":"苏尼特左旗","value":"152523","parent":"152500"},{"name":"苏尼特右旗","value":"152524","parent":"152500"},{"name":"东乌珠穆沁旗","value":"152525","parent":"152500"},{"name":"西乌珠穆沁旗","value":"152526","parent":"152500"},{"name":"太仆寺旗","value":"152527","parent":"152500"},{"name":"镶黄旗","value":"152528","parent":"152500"},{"name":"正镶白旗","value":"152529","parent":"152500"},{"name":"正蓝旗","value":"152530","parent":"152500"},{"name":"多伦县","value":"152531","parent":"152500"},{"name":"阿拉善左旗","value":"152921","parent":"152900"},{"name":"阿拉善右旗","value":"152922","parent":"152900"},{"name":"额济纳旗","value":"152923","parent":"152900"},{"name":"沈阳市","value":"210100","parent":"210000"},{"name":"大连市","value":"210200","parent":"210000"},{"name":"鞍山市","value":"210300","parent":"210000"},{"name":"抚顺市","value":"210400","parent":"210000"},{"name":"本溪市","value":"210500","parent":"210000"},{"name":"丹东市","value":"210600","parent":"210000"},{"name":"锦州市","value":"210700","parent":"210000"},{"name":"营口市","value":"210800","parent":"210000"},{"name":"阜新市","value":"210900","parent":"210000"},{"name":"辽阳市","value":"211000","parent":"210000"},{"name":"盘锦市","value":"211100","parent":"210000"},{"name":"铁岭市","value":"211200","parent":"210000"},{"name":"朝阳市","value":"211300","parent":"210000"},{"name":"葫芦岛市","value":"211400","parent":"210000"},{"name":"和平区","value":"210102","parent":"210100"},{"name":"沈河区","value":"210103","parent":"210100"},{"name":"大东区","value":"210104","parent":"210100"},{"name":"皇姑区","value":"210105","parent":"210100"},{"name":"铁西区","value":"210106","parent":"210100"},{"name":"苏家屯区","value":"210111","parent":"210100"},{"name":"浑南区","value":"210112","parent":"210100"},{"name":"沈北新区","value":"210113","parent":"210100"},{"name":"于洪区","value":"210114","parent":"210100"},{"name":"辽中县","value":"210122","parent":"210100"},{"name":"康平县","value":"210123","parent":"210100"},{"name":"法库县","value":"210124","parent":"210100"},{"name":"新民市","value":"210181","parent":"210100"},{"name":"中山区","value":"210202","parent":"210200"},{"name":"西岗区","value":"210203","parent":"210200"},{"name":"沙河口区","value":"210204","parent":"210200"},{"name":"甘井子区","value":"210211","parent":"210200"},{"name":"旅顺口区","value":"210212","parent":"210200"},{"name":"金州区","value":"210213","parent":"210200"},{"name":"长海县","value":"210224","parent":"210200"},{"name":"瓦房店市","value":"210281","parent":"210200"},{"name":"普兰店市","value":"210282","parent":"210200"},{"name":"庄河市","value":"210283","parent":"210200"},{"name":"铁东区","value":"210302","parent":"210300"},{"name":"铁西区","value":"210303","parent":"210300"},{"name":"立山区","value":"210304","parent":"210300"},{"name":"千山区","value":"210311","parent":"210300"},{"name":"台安县","value":"210321","parent":"210300"},{"name":"岫岩满族自治县","value":"210323","parent":"210300"},{"name":"海城市","value":"210381","parent":"210300"},{"name":"新抚区","value":"210402","parent":"210400"},{"name":"东洲区","value":"210403","parent":"210400"},{"name":"望花区","value":"210404","parent":"210400"},{"name":"顺城区","value":"210411","parent":"210400"},{"name":"抚顺县","value":"210421","parent":"210400"},{"name":"新宾满族自治县","value":"210422","parent":"210400"},{"name":"清原满族自治县","value":"210423","parent":"210400"},{"name":"平山区","value":"210502","parent":"210500"},{"name":"溪湖区","value":"210503","parent":"210500"},{"name":"明山区","value":"210504","parent":"210500"},{"name":"南芬区","value":"210505","parent":"210500"},{"name":"本溪满族自治县","value":"210521","parent":"210500"},{"name":"桓仁满族自治县","value":"210522","parent":"210500"},{"name":"元宝区","value":"210602","parent":"210600"},{"name":"振兴区","value":"210603","parent":"210600"},{"name":"振安区","value":"210604","parent":"210600"},{"name":"宽甸满族自治县","value":"210624","parent":"210600"},{"name":"东港市","value":"210681","parent":"210600"},{"name":"凤城市","value":"210682","parent":"210600"},{"name":"古塔区","value":"210702","parent":"210700"},{"name":"凌河区","value":"210703","parent":"210700"},{"name":"太和区","value":"210711","parent":"210700"},{"name":"黑山县","value":"210726","parent":"210700"},{"name":"义县","value":"210727","parent":"210700"},{"name":"凌海市","value":"210781","parent":"210700"},{"name":"北镇市","value":"210782","parent":"210700"},{"name":"站前区","value":"210802","parent":"210800"},{"name":"西市区","value":"210803","parent":"210800"},{"name":"鲅鱼圈区","value":"210804","parent":"210800"},{"name":"老边区","value":"210811","parent":"210800"},{"name":"盖州市","value":"210881","parent":"210800"},{"name":"大石桥市","value":"210882","parent":"210800"},{"name":"海州区","value":"210902","parent":"210900"},{"name":"新邱区","value":"210903","parent":"210900"},{"name":"太平区","value":"210904","parent":"210900"},{"name":"清河门区","value":"210905","parent":"210900"},{"name":"细河区","value":"210911","parent":"210900"},{"name":"阜新蒙古族自治县","value":"210921","parent":"210900"},{"name":"彰武县","value":"210922","parent":"210900"},{"name":"白塔区","value":"211002","parent":"211000"},{"name":"文圣区","value":"211003","parent":"211000"},{"name":"宏伟区","value":"211004","parent":"211000"},{"name":"弓长岭区","value":"211005","parent":"211000"},{"name":"太子河区","value":"211011","parent":"211000"},{"name":"辽阳县","value":"211021","parent":"211000"},{"name":"灯塔市","value":"211081","parent":"211000"},{"name":"双台子区","value":"211102","parent":"211100"},{"name":"兴隆台区","value":"211103","parent":"211100"},{"name":"大洼县","value":"211121","parent":"211100"},{"name":"盘山县","value":"211122","parent":"211100"},{"name":"银州区","value":"211202","parent":"211200"},{"name":"清河区","value":"211204","parent":"211200"},{"name":"铁岭县","value":"211221","parent":"211200"},{"name":"西丰县","value":"211223","parent":"211200"},{"name":"昌图县","value":"211224","parent":"211200"},{"name":"调兵山市","value":"211281","parent":"211200"},{"name":"开原市","value":"211282","parent":"211200"},{"name":"双塔区","value":"211302","parent":"211300"},{"name":"龙城区","value":"211303","parent":"211300"},{"name":"朝阳县","value":"211321","parent":"211300"},{"name":"建平县","value":"211322","parent":"211300"},{"name":"喀喇沁左翼蒙古族自治县","value":"211324","parent":"211300"},{"name":"北票市","value":"211381","parent":"211300"},{"name":"凌源市","value":"211382","parent":"211300"},{"name":"连山区","value":"211402","parent":"211400"},{"name":"龙港区","value":"211403","parent":"211400"},{"name":"南票区","value":"211404","parent":"211400"},{"name":"绥中县","value":"211421","parent":"211400"},{"name":"建昌县","value":"211422","parent":"211400"},{"name":"兴城市","value":"211481","parent":"211400"},{"name":"长春市","value":"220100","parent":"220000"},{"name":"吉林市","value":"220200","parent":"220000"},{"name":"四平市","value":"220300","parent":"220000"},{"name":"辽源市","value":"220400","parent":"220000"},{"name":"通化市","value":"220500","parent":"220000"},{"name":"白山市","value":"220600","parent":"220000"},{"name":"松原市","value":"220700","parent":"220000"},{"name":"白城市","value":"220800","parent":"220000"},{"name":"延边朝鲜族自治州","value":"222400","parent":"220000"},{"name":"南关区","value":"220102","parent":"220100"},{"name":"宽城区","value":"220103","parent":"220100"},{"name":"朝阳区","value":"220104","parent":"220100"},{"name":"二道区","value":"220105","parent":"220100"},{"name":"绿园区","value":"220106","parent":"220100"},{"name":"双阳区","value":"220112","parent":"220100"},{"name":"九台区","value":"220113","parent":"220100"},{"name":"农安县","value":"220122","parent":"220100"},{"name":"榆树市","value":"220182","parent":"220100"},{"name":"德惠市","value":"220183","parent":"220100"},{"name":"昌邑区","value":"220202","parent":"220200"},{"name":"龙潭区","value":"220203","parent":"220200"},{"name":"船营区","value":"220204","parent":"220200"},{"name":"丰满区","value":"220211","parent":"220200"},{"name":"永吉县","value":"220221","parent":"220200"},{"name":"蛟河市","value":"220281","parent":"220200"},{"name":"桦甸市","value":"220282","parent":"220200"},{"name":"舒兰市","value":"220283","parent":"220200"},{"name":"磐石市","value":"220284","parent":"220200"},{"name":"铁西区","value":"220302","parent":"220300"},{"name":"铁东区","value":"220303","parent":"220300"},{"name":"梨树县","value":"220322","parent":"220300"},{"name":"伊通满族自治县","value":"220323","parent":"220300"},{"name":"公主岭市","value":"220381","parent":"220300"},{"name":"双辽市","value":"220382","parent":"220300"},{"name":"龙山区","value":"220402","parent":"220400"},{"name":"西安区","value":"220403","parent":"220400"},{"name":"东丰县","value":"220421","parent":"220400"},{"name":"东辽县","value":"220422","parent":"220400"},{"name":"东昌区","value":"220502","parent":"220500"},{"name":"二道江区","value":"220503","parent":"220500"},{"name":"通化县","value":"220521","parent":"220500"},{"name":"辉南县","value":"220523","parent":"220500"},{"name":"柳河县","value":"220524","parent":"220500"},{"name":"梅河口市","value":"220581","parent":"220500"},{"name":"集安市","value":"220582","parent":"220500"},{"name":"浑江区","value":"220602","parent":"220600"},{"name":"江源区","value":"220605","parent":"220600"},{"name":"抚松县","value":"220621","parent":"220600"},{"name":"靖宇县","value":"220622","parent":"220600"},{"name":"长白朝鲜族自治县","value":"220623","parent":"220600"},{"name":"临江市","value":"220681","parent":"220600"},{"name":"宁江区","value":"220702","parent":"220700"},{"name":"前郭尔罗斯蒙古族自治县","value":"220721","parent":"220700"},{"name":"长岭县","value":"220722","parent":"220700"},{"name":"乾安县","value":"220723","parent":"220700"},{"name":"扶余市","value":"220781","parent":"220700"},{"name":"洮北区","value":"220802","parent":"220800"},{"name":"镇赉县","value":"220821","parent":"220800"},{"name":"通榆县","value":"220822","parent":"220800"},{"name":"洮南市","value":"220881","parent":"220800"},{"name":"大安市","value":"220882","parent":"220800"},{"name":"延吉市","value":"222401","parent":"222400"},{"name":"图们市","value":"222402","parent":"222400"},{"name":"敦化市","value":"222403","parent":"222400"},{"name":"珲春市","value":"222404","parent":"222400"},{"name":"龙井市","value":"222405","parent":"222400"},{"name":"和龙市","value":"222406","parent":"222400"},{"name":"汪清县","value":"222424","parent":"222400"},{"name":"安图县","value":"222426","parent":"222400"},{"name":"哈尔滨市","value":"230100","parent":"230000"},{"name":"齐齐哈尔市","value":"230200","parent":"230000"},{"name":"鸡西市","value":"230300","parent":"230000"},{"name":"鹤岗市","value":"230400","parent":"230000"},{"name":"双鸭山市","value":"230500","parent":"230000"},{"name":"大庆市","value":"230600","parent":"230000"},{"name":"伊春市","value":"230700","parent":"230000"},{"name":"佳木斯市","value":"230800","parent":"230000"},{"name":"七台河市","value":"230900","parent":"230000"},{"name":"牡丹江市","value":"231000","parent":"230000"},{"name":"黑河市","value":"231100","parent":"230000"},{"name":"绥化市","value":"231200","parent":"230000"},{"name":"大兴安岭地区","value":"232700","parent":"230000"},{"name":"道里区","value":"230102","parent":"230100"},{"name":"南岗区","value":"230103","parent":"230100"},{"name":"道外区","value":"230104","parent":"230100"},{"name":"平房区","value":"230108","parent":"230100"},{"name":"松北区","value":"230109","parent":"230100"},{"name":"香坊区","value":"230110","parent":"230100"},{"name":"呼兰区","value":"230111","parent":"230100"},{"name":"阿城区","value":"230112","parent":"230100"},{"name":"双城区","value":"230113","parent":"230100"},{"name":"依兰县","value":"230123","parent":"230100"},{"name":"方正县","value":"230124","parent":"230100"},{"name":"宾县","value":"230125","parent":"230100"},{"name":"巴彦县","value":"230126","parent":"230100"},{"name":"木兰县","value":"230127","parent":"230100"},{"name":"通河县","value":"230128","parent":"230100"},{"name":"延寿县","value":"230129","parent":"230100"},{"name":"尚志市","value":"230183","parent":"230100"},{"name":"五常市","value":"230184","parent":"230100"},{"name":"龙沙区","value":"230202","parent":"230200"},{"name":"建华区","value":"230203","parent":"230200"},{"name":"铁锋区","value":"230204","parent":"230200"},{"name":"昂昂溪区","value":"230205","parent":"230200"},{"name":"富拉尔基区","value":"230206","parent":"230200"},{"name":"碾子山区","value":"230207","parent":"230200"},{"name":"梅里斯达斡尔族区","value":"230208","parent":"230200"},{"name":"龙江县","value":"230221","parent":"230200"},{"name":"依安县","value":"230223","parent":"230200"},{"name":"泰来县","value":"230224","parent":"230200"},{"name":"甘南县","value":"230225","parent":"230200"},{"name":"富裕县","value":"230227","parent":"230200"},{"name":"克山县","value":"230229","parent":"230200"},{"name":"克东县","value":"230230","parent":"230200"},{"name":"拜泉县","value":"230231","parent":"230200"},{"name":"讷河市","value":"230281","parent":"230200"},{"name":"鸡冠区","value":"230302","parent":"230300"},{"name":"恒山区","value":"230303","parent":"230300"},{"name":"滴道区","value":"230304","parent":"230300"},{"name":"梨树区","value":"230305","parent":"230300"},{"name":"城子河区","value":"230306","parent":"230300"},{"name":"麻山区","value":"230307","parent":"230300"},{"name":"鸡东县","value":"230321","parent":"230300"},{"name":"虎林市","value":"230381","parent":"230300"},{"name":"密山市","value":"230382","parent":"230300"},{"name":"向阳区","value":"230402","parent":"230400"},{"name":"工农区","value":"230403","parent":"230400"},{"name":"南山区","value":"230404","parent":"230400"},{"name":"兴安区","value":"230405","parent":"230400"},{"name":"东山区","value":"230406","parent":"230400"},{"name":"兴山区","value":"230407","parent":"230400"},{"name":"萝北县","value":"230421","parent":"230400"},{"name":"绥滨县","value":"230422","parent":"230400"},{"name":"尖山区","value":"230502","parent":"230500"},{"name":"岭东区","value":"230503","parent":"230500"},{"name":"四方台区","value":"230505","parent":"230500"},{"name":"宝山区","value":"230506","parent":"230500"},{"name":"集贤县","value":"230521","parent":"230500"},{"name":"友谊县","value":"230522","parent":"230500"},{"name":"宝清县","value":"230523","parent":"230500"},{"name":"饶河县","value":"230524","parent":"230500"},{"name":"萨尔图区","value":"230602","parent":"230600"},{"name":"龙凤区","value":"230603","parent":"230600"},{"name":"让胡路区","value":"230604","parent":"230600"},{"name":"红岗区","value":"230605","parent":"230600"},{"name":"大同区","value":"230606","parent":"230600"},{"name":"肇州县","value":"230621","parent":"230600"},{"name":"肇源县","value":"230622","parent":"230600"},{"name":"林甸县","value":"230623","parent":"230600"},{"name":"杜尔伯特蒙古族自治县","value":"230624","parent":"230600"},{"name":"伊春区","value":"230702","parent":"230700"},{"name":"南岔区","value":"230703","parent":"230700"},{"name":"友好区","value":"230704","parent":"230700"},{"name":"西林区","value":"230705","parent":"230700"},{"name":"翠峦区","value":"230706","parent":"230700"},{"name":"新青区","value":"230707","parent":"230700"},{"name":"美溪区","value":"230708","parent":"230700"},{"name":"金山屯区","value":"230709","parent":"230700"},{"name":"五营区","value":"230710","parent":"230700"},{"name":"乌马河区","value":"230711","parent":"230700"},{"name":"汤旺河区","value":"230712","parent":"230700"},{"name":"带岭区","value":"230713","parent":"230700"},{"name":"乌伊岭区","value":"230714","parent":"230700"},{"name":"红星区","value":"230715","parent":"230700"},{"name":"上甘岭区","value":"230716","parent":"230700"},{"name":"嘉荫县","value":"230722","parent":"230700"},{"name":"铁力市","value":"230781","parent":"230700"},{"name":"向阳区","value":"230803","parent":"230800"},{"name":"前进区","value":"230804","parent":"230800"},{"name":"东风区","value":"230805","parent":"230800"},{"name":"郊区","value":"230811","parent":"230800"},{"name":"桦南县","value":"230822","parent":"230800"},{"name":"桦川县","value":"230826","parent":"230800"},{"name":"汤原县","value":"230828","parent":"230800"},{"name":"抚远县","value":"230833","parent":"230800"},{"name":"同江市","value":"230881","parent":"230800"},{"name":"富锦市","value":"230882","parent":"230800"},{"name":"新兴区","value":"230902","parent":"230900"},{"name":"桃山区","value":"230903","parent":"230900"},{"name":"茄子河区","value":"230904","parent":"230900"},{"name":"勃利县","value":"230921","parent":"230900"},{"name":"东安区","value":"231002","parent":"231000"},{"name":"阳明区","value":"231003","parent":"231000"},{"name":"爱民区","value":"231004","parent":"231000"},{"name":"西安区","value":"231005","parent":"231000"},{"name":"东宁县","value":"231024","parent":"231000"},{"name":"林口县","value":"231025","parent":"231000"},{"name":"绥芬河市","value":"231081","parent":"231000"},{"name":"海林市","value":"231083","parent":"231000"},{"name":"宁安市","value":"231084","parent":"231000"},{"name":"穆棱市","value":"231085","parent":"231000"},{"name":"爱辉区","value":"231102","parent":"231100"},{"name":"嫩江县","value":"231121","parent":"231100"},{"name":"逊克县","value":"231123","parent":"231100"},{"name":"孙吴县","value":"231124","parent":"231100"},{"name":"北安市","value":"231181","parent":"231100"},{"name":"五大连池市","value":"231182","parent":"231100"},{"name":"北林区","value":"231202","parent":"231200"},{"name":"望奎县","value":"231221","parent":"231200"},{"name":"兰西县","value":"231222","parent":"231200"},{"name":"青冈县","value":"231223","parent":"231200"},{"name":"庆安县","value":"231224","parent":"231200"},{"name":"明水县","value":"231225","parent":"231200"},{"name":"绥棱县","value":"231226","parent":"231200"},{"name":"安达市","value":"231281","parent":"231200"},{"name":"肇东市","value":"231282","parent":"231200"},{"name":"海伦市","value":"231283","parent":"231200"},{"name":"呼玛县","value":"232721","parent":"232700"},{"name":"塔河县","value":"232722","parent":"232700"},{"name":"漠河县","value":"232723","parent":"232700"},{"name":"市辖区","value":"310100","parent":"310000"},{"name":"黄浦区","value":"310101","parent":"310100"},{"name":"徐汇区","value":"310104","parent":"310100"},{"name":"长宁区","value":"310105","parent":"310100"},{"name":"静安区","value":"310106","parent":"310100"},{"name":"普陀区","value":"310107","parent":"310100"},{"name":"闸北区","value":"310108","parent":"310100"},{"name":"虹口区","value":"310109","parent":"310100"},{"name":"杨浦区","value":"310110","parent":"310100"},{"name":"闵行区","value":"310112","parent":"310100"},{"name":"宝山区","value":"310113","parent":"310100"},{"name":"嘉定区","value":"310114","parent":"310100"},{"name":"浦东新区","value":"310115","parent":"310100"},{"name":"金山区","value":"310116","parent":"310100"},{"name":"松江区","value":"310117","parent":"310100"},{"name":"青浦区","value":"310118","parent":"310100"},{"name":"奉贤区","value":"310120","parent":"310100"},{"name":"崇明县","value":"310230","parent":"310100"},{"name":"南京市","value":"320100","parent":"320000"},{"name":"无锡市","value":"320200","parent":"320000"},{"name":"徐州市","value":"320300","parent":"320000"},{"name":"常州市","value":"320400","parent":"320000"},{"name":"苏州市","value":"320500","parent":"320000"},{"name":"南通市","value":"320600","parent":"320000"},{"name":"连云港市","value":"320700","parent":"320000"},{"name":"淮安市","value":"320800","parent":"320000"},{"name":"盐城市","value":"320900","parent":"320000"},{"name":"扬州市","value":"321000","parent":"320000"},{"name":"镇江市","value":"321100","parent":"320000"},{"name":"泰州市","value":"321200","parent":"320000"},{"name":"宿迁市","value":"321300","parent":"320000"},{"name":"玄武区","value":"320102","parent":"320100"},{"name":"秦淮区","value":"320104","parent":"320100"},{"name":"建邺区","value":"320105","parent":"320100"},{"name":"鼓楼区","value":"320106","parent":"320100"},{"name":"浦口区","value":"320111","parent":"320100"},{"name":"栖霞区","value":"320113","parent":"320100"},{"name":"雨花台区","value":"320114","parent":"320100"},{"name":"江宁区","value":"320115","parent":"320100"},{"name":"六合区","value":"320116","parent":"320100"},{"name":"溧水区","value":"320117","parent":"320100"},{"name":"高淳区","value":"320118","parent":"320100"},{"name":"崇安区","value":"320202","parent":"320200"},{"name":"南长区","value":"320203","parent":"320200"},{"name":"北塘区","value":"320204","parent":"320200"},{"name":"锡山区","value":"320205","parent":"320200"},{"name":"惠山区","value":"320206","parent":"320200"},{"name":"滨湖区","value":"320211","parent":"320200"},{"name":"江阴市","value":"320281","parent":"320200"},{"name":"宜兴市","value":"320282","parent":"320200"},{"name":"鼓楼区","value":"320302","parent":"320300"},{"name":"云龙区","value":"320303","parent":"320300"},{"name":"贾汪区","value":"320305","parent":"320300"},{"name":"泉山区","value":"320311","parent":"320300"},{"name":"铜山区","value":"320312","parent":"320300"},{"name":"丰县","value":"320321","parent":"320300"},{"name":"沛县","value":"320322","parent":"320300"},{"name":"睢宁县","value":"320324","parent":"320300"},{"name":"新沂市","value":"320381","parent":"320300"},{"name":"邳州市","value":"320382","parent":"320300"},{"name":"天宁区","value":"320402","parent":"320400"},{"name":"钟楼区","value":"320404","parent":"320400"},{"name":"新北区","value":"320411","parent":"320400"},{"name":"武进区","value":"320412","parent":"320400"},{"name":"金坛区","value":"320413","parent":"320400"},{"name":"溧阳市","value":"320481","parent":"320400"},{"name":"虎丘区","value":"320505","parent":"320500"},{"name":"吴中区","value":"320506","parent":"320500"},{"name":"相城区","value":"320507","parent":"320500"},{"name":"姑苏区","value":"320508","parent":"320500"},{"name":"吴江区","value":"320509","parent":"320500"},{"name":"常熟市","value":"320581","parent":"320500"},{"name":"张家港市","value":"320582","parent":"320500"},{"name":"昆山市","value":"320583","parent":"320500"},{"name":"太仓市","value":"320585","parent":"320500"},{"name":"崇川区","value":"320602","parent":"320600"},{"name":"港闸区","value":"320611","parent":"320600"},{"name":"通州区","value":"320612","parent":"320600"},{"name":"海安县","value":"320621","parent":"320600"},{"name":"如东县","value":"320623","parent":"320600"},{"name":"启东市","value":"320681","parent":"320600"},{"name":"如皋市","value":"320682","parent":"320600"},{"name":"海门市","value":"320684","parent":"320600"},{"name":"连云区","value":"320703","parent":"320700"},{"name":"海州区","value":"320706","parent":"320700"},{"name":"赣榆区","value":"320707","parent":"320700"},{"name":"东海县","value":"320722","parent":"320700"},{"name":"灌云县","value":"320723","parent":"320700"},{"name":"灌南县","value":"320724","parent":"320700"},{"name":"清河区","value":"320802","parent":"320800"},{"name":"淮安区","value":"320803","parent":"320800"},{"name":"淮阴区","value":"320804","parent":"320800"},{"name":"清浦区","value":"320811","parent":"320800"},{"name":"涟水县","value":"320826","parent":"320800"},{"name":"洪泽县","value":"320829","parent":"320800"},{"name":"盱眙县","value":"320830","parent":"320800"},{"name":"金湖县","value":"320831","parent":"320800"},{"name":"亭湖区","value":"320902","parent":"320900"},{"name":"盐都区","value":"320903","parent":"320900"},{"name":"大丰区","value":"320904","parent":"320900"},{"name":"响水县","value":"320921","parent":"320900"},{"name":"滨海县","value":"320922","parent":"320900"},{"name":"阜宁县","value":"320923","parent":"320900"},{"name":"射阳县","value":"320924","parent":"320900"},{"name":"建湖县","value":"320925","parent":"320900"},{"name":"东台市","value":"320981","parent":"320900"},{"name":"广陵区","value":"321002","parent":"321000"},{"name":"邗江区","value":"321003","parent":"321000"},{"name":"江都区","value":"321012","parent":"321000"},{"name":"宝应县","value":"321023","parent":"321000"},{"name":"仪征市","value":"321081","parent":"321000"},{"name":"高邮市","value":"321084","parent":"321000"},{"name":"京口区","value":"321102","parent":"321100"},{"name":"润州区","value":"321111","parent":"321100"},{"name":"丹徒区","value":"321112","parent":"321100"},{"name":"丹阳市","value":"321181","parent":"321100"},{"name":"扬中市","value":"321182","parent":"321100"},{"name":"句容市","value":"321183","parent":"321100"},{"name":"海陵区","value":"321202","parent":"321200"},{"name":"高港区","value":"321203","parent":"321200"},{"name":"姜堰区","value":"321204","parent":"321200"},{"name":"兴化市","value":"321281","parent":"321200"},{"name":"靖江市","value":"321282","parent":"321200"},{"name":"泰兴市","value":"321283","parent":"321200"},{"name":"宿城区","value":"321302","parent":"321300"},{"name":"宿豫区","value":"321311","parent":"321300"},{"name":"沭阳县","value":"321322","parent":"321300"},{"name":"泗阳县","value":"321323","parent":"321300"},{"name":"泗洪县","value":"321324","parent":"321300"},{"name":"杭州市","value":"330100","parent":"330000"},{"name":"宁波市","value":"330200","parent":"330000"},{"name":"温州市","value":"330300","parent":"330000"},{"name":"嘉兴市","value":"330400","parent":"330000"},{"name":"湖州市","value":"330500","parent":"330000"},{"name":"绍兴市","value":"330600","parent":"330000"},{"name":"金华市","value":"330700","parent":"330000"},{"name":"衢州市","value":"330800","parent":"330000"},{"name":"舟山市","value":"330900","parent":"330000"},{"name":"台州市","value":"331000","parent":"330000"},{"name":"丽水市","value":"331100","parent":"330000"},{"name":"上城区","value":"330102","parent":"330100"},{"name":"下城区","value":"330103","parent":"330100"},{"name":"江干区","value":"330104","parent":"330100"},{"name":"拱墅区","value":"330105","parent":"330100"},{"name":"西湖区","value":"330106","parent":"330100"},{"name":"滨江区","value":"330108","parent":"330100"},{"name":"萧山区","value":"330109","parent":"330100"},{"name":"余杭区","value":"330110","parent":"330100"},{"name":"富阳区","value":"330111","parent":"330100"},{"name":"桐庐县","value":"330122","parent":"330100"},{"name":"淳安县","value":"330127","parent":"330100"},{"name":"建德市","value":"330182","parent":"330100"},{"name":"临安市","value":"330185","parent":"330100"},{"name":"海曙区","value":"330203","parent":"330200"},{"name":"江东区","value":"330204","parent":"330200"},{"name":"江北区","value":"330205","parent":"330200"},{"name":"北仑区","value":"330206","parent":"330200"},{"name":"镇海区","value":"330211","parent":"330200"},{"name":"鄞州区","value":"330212","parent":"330200"},{"name":"象山县","value":"330225","parent":"330200"},{"name":"宁海县","value":"330226","parent":"330200"},{"name":"余姚市","value":"330281","parent":"330200"},{"name":"慈溪市","value":"330282","parent":"330200"},{"name":"奉化市","value":"330283","parent":"330200"},{"name":"鹿城区","value":"330302","parent":"330300"},{"name":"龙湾区","value":"330303","parent":"330300"},{"name":"瓯海区","value":"330304","parent":"330300"},{"name":"洞头区","value":"330305","parent":"330300"},{"name":"永嘉县","value":"330324","parent":"330300"},{"name":"平阳县","value":"330326","parent":"330300"},{"name":"苍南县","value":"330327","parent":"330300"},{"name":"文成县","value":"330328","parent":"330300"},{"name":"泰顺县","value":"330329","parent":"330300"},{"name":"瑞安市","value":"330381","parent":"330300"},{"name":"乐清市","value":"330382","parent":"330300"},{"name":"南湖区","value":"330402","parent":"330400"},{"name":"秀洲区","value":"330411","parent":"330400"},{"name":"嘉善县","value":"330421","parent":"330400"},{"name":"海盐县","value":"330424","parent":"330400"},{"name":"海宁市","value":"330481","parent":"330400"},{"name":"平湖市","value":"330482","parent":"330400"},{"name":"桐乡市","value":"330483","parent":"330400"},{"name":"吴兴区","value":"330502","parent":"330500"},{"name":"南浔区","value":"330503","parent":"330500"},{"name":"德清县","value":"330521","parent":"330500"},{"name":"长兴县","value":"330522","parent":"330500"},{"name":"安吉县","value":"330523","parent":"330500"},{"name":"越城区","value":"330602","parent":"330600"},{"name":"柯桥区","value":"330603","parent":"330600"},{"name":"上虞区","value":"330604","parent":"330600"},{"name":"新昌县","value":"330624","parent":"330600"},{"name":"诸暨市","value":"330681","parent":"330600"},{"name":"嵊州市","value":"330683","parent":"330600"},{"name":"婺城区","value":"330702","parent":"330700"},{"name":"金东区","value":"330703","parent":"330700"},{"name":"武义县","value":"330723","parent":"330700"},{"name":"浦江县","value":"330726","parent":"330700"},{"name":"磐安县","value":"330727","parent":"330700"},{"name":"兰溪市","value":"330781","parent":"330700"},{"name":"义乌市","value":"330782","parent":"330700"},{"name":"东阳市","value":"330783","parent":"330700"},{"name":"永康市","value":"330784","parent":"330700"},{"name":"柯城区","value":"330802","parent":"330800"},{"name":"衢江区","value":"330803","parent":"330800"},{"name":"常山县","value":"330822","parent":"330800"},{"name":"开化县","value":"330824","parent":"330800"},{"name":"龙游县","value":"330825","parent":"330800"},{"name":"江山市","value":"330881","parent":"330800"},{"name":"定海区","value":"330902","parent":"330900"},{"name":"普陀区","value":"330903","parent":"330900"},{"name":"岱山县","value":"330921","parent":"330900"},{"name":"嵊泗县","value":"330922","parent":"330900"},{"name":"椒江区","value":"331002","parent":"331000"},{"name":"黄岩区","value":"331003","parent":"331000"},{"name":"路桥区","value":"331004","parent":"331000"},{"name":"玉环县","value":"331021","parent":"331000"},{"name":"三门县","value":"331022","parent":"331000"},{"name":"天台县","value":"331023","parent":"331000"},{"name":"仙居县","value":"331024","parent":"331000"},{"name":"温岭市","value":"331081","parent":"331000"},{"name":"临海市","value":"331082","parent":"331000"},{"name":"莲都区","value":"331102","parent":"331100"},{"name":"青田县","value":"331121","parent":"331100"},{"name":"缙云县","value":"331122","parent":"331100"},{"name":"遂昌县","value":"331123","parent":"331100"},{"name":"松阳县","value":"331124","parent":"331100"},{"name":"云和县","value":"331125","parent":"331100"},{"name":"庆元县","value":"331126","parent":"331100"},{"name":"景宁畲族自治县","value":"331127","parent":"331100"},{"name":"龙泉市","value":"331181","parent":"331100"},{"name":"合肥市","value":"340100","parent":"340000"},{"name":"芜湖市","value":"340200","parent":"340000"},{"name":"蚌埠市","value":"340300","parent":"340000"},{"name":"淮南市","value":"340400","parent":"340000"},{"name":"马鞍山市","value":"340500","parent":"340000"},{"name":"淮北市","value":"340600","parent":"340000"},{"name":"铜陵市","value":"340700","parent":"340000"},{"name":"安庆市","value":"340800","parent":"340000"},{"name":"黄山市","value":"341000","parent":"340000"},{"name":"滁州市","value":"341100","parent":"340000"},{"name":"阜阳市","value":"341200","parent":"340000"},{"name":"宿州市","value":"341300","parent":"340000"},{"name":"六安市","value":"341500","parent":"340000"},{"name":"亳州市","value":"341600","parent":"340000"},{"name":"池州市","value":"341700","parent":"340000"},{"name":"宣城市","value":"341800","parent":"340000"},{"name":"瑶海区","value":"340102","parent":"340100"},{"name":"庐阳区","value":"340103","parent":"340100"},{"name":"蜀山区","value":"340104","parent":"340100"},{"name":"包河区","value":"340111","parent":"340100"},{"name":"长丰县","value":"340121","parent":"340100"},{"name":"肥东县","value":"340122","parent":"340100"},{"name":"肥西县","value":"340123","parent":"340100"},{"name":"庐江县","value":"340124","parent":"340100"},{"name":"巢湖市","value":"340181","parent":"340100"},{"name":"镜湖区","value":"340202","parent":"340200"},{"name":"弋江区","value":"340203","parent":"340200"},{"name":"鸠江区","value":"340207","parent":"340200"},{"name":"三山区","value":"340208","parent":"340200"},{"name":"芜湖县","value":"340221","parent":"340200"},{"name":"繁昌县","value":"340222","parent":"340200"},{"name":"南陵县","value":"340223","parent":"340200"},{"name":"无为县","value":"340225","parent":"340200"},{"name":"龙子湖区","value":"340302","parent":"340300"},{"name":"蚌山区","value":"340303","parent":"340300"},{"name":"禹会区","value":"340304","parent":"340300"},{"name":"淮上区","value":"340311","parent":"340300"},{"name":"怀远县","value":"340321","parent":"340300"},{"name":"五河县","value":"340322","parent":"340300"},{"name":"固镇县","value":"340323","parent":"340300"},{"name":"大通区","value":"340402","parent":"340400"},{"name":"田家庵区","value":"340403","parent":"340400"},{"name":"谢家集区","value":"340404","parent":"340400"},{"name":"八公山区","value":"340405","parent":"340400"},{"name":"潘集区","value":"340406","parent":"340400"},{"name":"凤台县","value":"340421","parent":"340400"},{"name":"花山区","value":"340503","parent":"340500"},{"name":"雨山区","value":"340504","parent":"340500"},{"name":"博望区","value":"340506","parent":"340500"},{"name":"当涂县","value":"340521","parent":"340500"},{"name":"含山县","value":"340522","parent":"340500"},{"name":"和县","value":"340523","parent":"340500"},{"name":"杜集区","value":"340602","parent":"340600"},{"name":"相山区","value":"340603","parent":"340600"},{"name":"烈山区","value":"340604","parent":"340600"},{"name":"濉溪县","value":"340621","parent":"340600"},{"name":"铜官山区","value":"340702","parent":"340700"},{"name":"狮子山区","value":"340703","parent":"340700"},{"name":"郊区","value":"340711","parent":"340700"},{"name":"铜陵县","value":"340721","parent":"340700"},{"name":"迎江区","value":"340802","parent":"340800"},{"name":"大观区","value":"340803","parent":"340800"},{"name":"宜秀区","value":"340811","parent":"340800"},{"name":"怀宁县","value":"340822","parent":"340800"},{"name":"枞阳县","value":"340823","parent":"340800"},{"name":"潜山县","value":"340824","parent":"340800"},{"name":"太湖县","value":"340825","parent":"340800"},{"name":"宿松县","value":"340826","parent":"340800"},{"name":"望江县","value":"340827","parent":"340800"},{"name":"岳西县","value":"340828","parent":"340800"},{"name":"桐城市","value":"340881","parent":"340800"},{"name":"屯溪区","value":"341002","parent":"341000"},{"name":"黄山区","value":"341003","parent":"341000"},{"name":"徽州区","value":"341004","parent":"341000"},{"name":"歙县","value":"341021","parent":"341000"},{"name":"休宁县","value":"341022","parent":"341000"},{"name":"黟县","value":"341023","parent":"341000"},{"name":"祁门县","value":"341024","parent":"341000"},{"name":"琅琊区","value":"341102","parent":"341100"},{"name":"南谯区","value":"341103","parent":"341100"},{"name":"来安县","value":"341122","parent":"341100"},{"name":"全椒县","value":"341124","parent":"341100"},{"name":"定远县","value":"341125","parent":"341100"},{"name":"凤阳县","value":"341126","parent":"341100"},{"name":"天长市","value":"341181","parent":"341100"},{"name":"明光市","value":"341182","parent":"341100"},{"name":"颍州区","value":"341202","parent":"341200"},{"name":"颍东区","value":"341203","parent":"341200"},{"name":"颍泉区","value":"341204","parent":"341200"},{"name":"临泉县","value":"341221","parent":"341200"},{"name":"太和县","value":"341222","parent":"341200"},{"name":"阜南县","value":"341225","parent":"341200"},{"name":"颍上县","value":"341226","parent":"341200"},{"name":"界首市","value":"341282","parent":"341200"},{"name":"埇桥区","value":"341302","parent":"341300"},{"name":"砀山县","value":"341321","parent":"341300"},{"name":"萧县","value":"341322","parent":"341300"},{"name":"灵璧县","value":"341323","parent":"341300"},{"name":"泗县","value":"341324","parent":"341300"},{"name":"金安区","value":"341502","parent":"341500"},{"name":"裕安区","value":"341503","parent":"341500"},{"name":"寿县","value":"341521","parent":"341500"},{"name":"霍邱县","value":"341522","parent":"341500"},{"name":"舒城县","value":"341523","parent":"341500"},{"name":"金寨县","value":"341524","parent":"341500"},{"name":"霍山县","value":"341525","parent":"341500"},{"name":"谯城区","value":"341602","parent":"341600"},{"name":"涡阳县","value":"341621","parent":"341600"},{"name":"蒙城县","value":"341622","parent":"341600"},{"name":"利辛县","value":"341623","parent":"341600"},{"name":"贵池区","value":"341702","parent":"341700"},{"name":"东至县","value":"341721","parent":"341700"},{"name":"石台县","value":"341722","parent":"341700"},{"name":"青阳县","value":"341723","parent":"341700"},{"name":"宣州区","value":"341802","parent":"341800"},{"name":"郎溪县","value":"341821","parent":"341800"},{"name":"广德县","value":"341822","parent":"341800"},{"name":"泾县","value":"341823","parent":"341800"},{"name":"绩溪县","value":"341824","parent":"341800"},{"name":"旌德县","value":"341825","parent":"341800"},{"name":"宁国市","value":"341881","parent":"341800"},{"name":"福州市","value":"350100","parent":"350000"},{"name":"厦门市","value":"350200","parent":"350000"},{"name":"莆田市","value":"350300","parent":"350000"},{"name":"三明市","value":"350400","parent":"350000"},{"name":"泉州市","value":"350500","parent":"350000"},{"name":"漳州市","value":"350600","parent":"350000"},{"name":"南平市","value":"350700","parent":"350000"},{"name":"龙岩市","value":"350800","parent":"350000"},{"name":"宁德市","value":"350900","parent":"350000"},{"name":"鼓楼区","value":"350102","parent":"350100"},{"name":"台江区","value":"350103","parent":"350100"},{"name":"仓山区","value":"350104","parent":"350100"},{"name":"马尾区","value":"350105","parent":"350100"},{"name":"晋安区","value":"350111","parent":"350100"},{"name":"闽侯县","value":"350121","parent":"350100"},{"name":"连江县","value":"350122","parent":"350100"},{"name":"罗源县","value":"350123","parent":"350100"},{"name":"闽清县","value":"350124","parent":"350100"},{"name":"永泰县","value":"350125","parent":"350100"},{"name":"平潭县","value":"350128","parent":"350100"},{"name":"福清市","value":"350181","parent":"350100"},{"name":"长乐市","value":"350182","parent":"350100"},{"name":"思明区","value":"350203","parent":"350200"},{"name":"海沧区","value":"350205","parent":"350200"},{"name":"湖里区","value":"350206","parent":"350200"},{"name":"集美区","value":"350211","parent":"350200"},{"name":"同安区","value":"350212","parent":"350200"},{"name":"翔安区","value":"350213","parent":"350200"},{"name":"城厢区","value":"350302","parent":"350300"},{"name":"涵江区","value":"350303","parent":"350300"},{"name":"荔城区","value":"350304","parent":"350300"},{"name":"秀屿区","value":"350305","parent":"350300"},{"name":"仙游县","value":"350322","parent":"350300"},{"name":"梅列区","value":"350402","parent":"350400"},{"name":"三元区","value":"350403","parent":"350400"},{"name":"明溪县","value":"350421","parent":"350400"},{"name":"清流县","value":"350423","parent":"350400"},{"name":"宁化县","value":"350424","parent":"350400"},{"name":"大田县","value":"350425","parent":"350400"},{"name":"尤溪县","value":"350426","parent":"350400"},{"name":"沙县","value":"350427","parent":"350400"},{"name":"将乐县","value":"350428","parent":"350400"},{"name":"泰宁县","value":"350429","parent":"350400"},{"name":"建宁县","value":"350430","parent":"350400"},{"name":"永安市","value":"350481","parent":"350400"},{"name":"鲤城区","value":"350502","parent":"350500"},{"name":"丰泽区","value":"350503","parent":"350500"},{"name":"洛江区","value":"350504","parent":"350500"},{"name":"泉港区","value":"350505","parent":"350500"},{"name":"惠安县","value":"350521","parent":"350500"},{"name":"安溪县","value":"350524","parent":"350500"},{"name":"永春县","value":"350525","parent":"350500"},{"name":"德化县","value":"350526","parent":"350500"},{"name":"金门县","value":"350527","parent":"350500"},{"name":"石狮市","value":"350581","parent":"350500"},{"name":"晋江市","value":"350582","parent":"350500"},{"name":"南安市","value":"350583","parent":"350500"},{"name":"芗城区","value":"350602","parent":"350600"},{"name":"龙文区","value":"350603","parent":"350600"},{"name":"云霄县","value":"350622","parent":"350600"},{"name":"漳浦县","value":"350623","parent":"350600"},{"name":"诏安县","value":"350624","parent":"350600"},{"name":"长泰县","value":"350625","parent":"350600"},{"name":"东山县","value":"350626","parent":"350600"},{"name":"南靖县","value":"350627","parent":"350600"},{"name":"平和县","value":"350628","parent":"350600"},{"name":"华安县","value":"350629","parent":"350600"},{"name":"龙海市","value":"350681","parent":"350600"},{"name":"延平区","value":"350702","parent":"350700"},{"name":"建阳区","value":"350703","parent":"350700"},{"name":"顺昌县","value":"350721","parent":"350700"},{"name":"浦城县","value":"350722","parent":"350700"},{"name":"光泽县","value":"350723","parent":"350700"},{"name":"松溪县","value":"350724","parent":"350700"},{"name":"政和县","value":"350725","parent":"350700"},{"name":"邵武市","value":"350781","parent":"350700"},{"name":"武夷山市","value":"350782","parent":"350700"},{"name":"建瓯市","value":"350783","parent":"350700"},{"name":"新罗区","value":"350802","parent":"350800"},{"name":"永定区","value":"350803","parent":"350800"},{"name":"长汀县","value":"350821","parent":"350800"},{"name":"上杭县","value":"350823","parent":"350800"},{"name":"武平县","value":"350824","parent":"350800"},{"name":"连城县","value":"350825","parent":"350800"},{"name":"漳平市","value":"350881","parent":"350800"},{"name":"蕉城区","value":"350902","parent":"350900"},{"name":"霞浦县","value":"350921","parent":"350900"},{"name":"古田县","value":"350922","parent":"350900"},{"name":"屏南县","value":"350923","parent":"350900"},{"name":"寿宁县","value":"350924","parent":"350900"},{"name":"周宁县","value":"350925","parent":"350900"},{"name":"柘荣县","value":"350926","parent":"350900"},{"name":"福安市","value":"350981","parent":"350900"},{"name":"福鼎市","value":"350982","parent":"350900"},{"name":"南昌市","value":"360100","parent":"360000"},{"name":"景德镇市","value":"360200","parent":"360000"},{"name":"萍乡市","value":"360300","parent":"360000"},{"name":"九江市","value":"360400","parent":"360000"},{"name":"新余市","value":"360500","parent":"360000"},{"name":"鹰潭市","value":"360600","parent":"360000"},{"name":"赣州市","value":"360700","parent":"360000"},{"name":"吉安市","value":"360800","parent":"360000"},{"name":"宜春市","value":"360900","parent":"360000"},{"name":"抚州市","value":"361000","parent":"360000"},{"name":"上饶市","value":"361100","parent":"360000"},{"name":"东湖区","value":"360102","parent":"360100"},{"name":"西湖区","value":"360103","parent":"360100"},{"name":"青云谱区","value":"360104","parent":"360100"},{"name":"湾里区","value":"360105","parent":"360100"},{"name":"青山湖区","value":"360111","parent":"360100"},{"name":"新建区","value":"360112","parent":"360100"},{"name":"南昌县","value":"360121","parent":"360100"},{"name":"安义县","value":"360123","parent":"360100"},{"name":"进贤县","value":"360124","parent":"360100"},{"name":"昌江区","value":"360202","parent":"360200"},{"name":"珠山区","value":"360203","parent":"360200"},{"name":"浮梁县","value":"360222","parent":"360200"},{"name":"乐平市","value":"360281","parent":"360200"},{"name":"安源区","value":"360302","parent":"360300"},{"name":"湘东区","value":"360313","parent":"360300"},{"name":"莲花县","value":"360321","parent":"360300"},{"name":"上栗县","value":"360322","parent":"360300"},{"name":"芦溪县","value":"360323","parent":"360300"},{"name":"庐山区","value":"360402","parent":"360400"},{"name":"浔阳区","value":"360403","parent":"360400"},{"name":"九江县","value":"360421","parent":"360400"},{"name":"武宁县","value":"360423","parent":"360400"},{"name":"修水县","value":"360424","parent":"360400"},{"name":"永修县","value":"360425","parent":"360400"},{"name":"德安县","value":"360426","parent":"360400"},{"name":"星子县","value":"360427","parent":"360400"},{"name":"都昌县","value":"360428","parent":"360400"},{"name":"湖口县","value":"360429","parent":"360400"},{"name":"彭泽县","value":"360430","parent":"360400"},{"name":"瑞昌市","value":"360481","parent":"360400"},{"name":"共青城市","value":"360482","parent":"360400"},{"name":"渝水区","value":"360502","parent":"360500"},{"name":"分宜县","value":"360521","parent":"360500"},{"name":"月湖区","value":"360602","parent":"360600"},{"name":"余江县","value":"360622","parent":"360600"},{"name":"贵溪市","value":"360681","parent":"360600"},{"name":"章贡区","value":"360702","parent":"360700"},{"name":"南康区","value":"360703","parent":"360700"},{"name":"赣县","value":"360721","parent":"360700"},{"name":"信丰县","value":"360722","parent":"360700"},{"name":"大余县","value":"360723","parent":"360700"},{"name":"上犹县","value":"360724","parent":"360700"},{"name":"崇义县","value":"360725","parent":"360700"},{"name":"安远县","value":"360726","parent":"360700"},{"name":"龙南县","value":"360727","parent":"360700"},{"name":"定南县","value":"360728","parent":"360700"},{"name":"全南县","value":"360729","parent":"360700"},{"name":"宁都县","value":"360730","parent":"360700"},{"name":"于都县","value":"360731","parent":"360700"},{"name":"兴国县","value":"360732","parent":"360700"},{"name":"会昌县","value":"360733","parent":"360700"},{"name":"寻乌县","value":"360734","parent":"360700"},{"name":"石城县","value":"360735","parent":"360700"},{"name":"瑞金市","value":"360781","parent":"360700"},{"name":"吉州区","value":"360802","parent":"360800"},{"name":"青原区","value":"360803","parent":"360800"},{"name":"吉安县","value":"360821","parent":"360800"},{"name":"吉水县","value":"360822","parent":"360800"},{"name":"峡江县","value":"360823","parent":"360800"},{"name":"新干县","value":"360824","parent":"360800"},{"name":"永丰县","value":"360825","parent":"360800"},{"name":"泰和县","value":"360826","parent":"360800"},{"name":"遂川县","value":"360827","parent":"360800"},{"name":"万安县","value":"360828","parent":"360800"},{"name":"安福县","value":"360829","parent":"360800"},{"name":"永新县","value":"360830","parent":"360800"},{"name":"井冈山市","value":"360881","parent":"360800"},{"name":"袁州区","value":"360902","parent":"360900"},{"name":"奉新县","value":"360921","parent":"360900"},{"name":"万载县","value":"360922","parent":"360900"},{"name":"上高县","value":"360923","parent":"360900"},{"name":"宜丰县","value":"360924","parent":"360900"},{"name":"靖安县","value":"360925","parent":"360900"},{"name":"铜鼓县","value":"360926","parent":"360900"},{"name":"丰城市","value":"360981","parent":"360900"},{"name":"樟树市","value":"360982","parent":"360900"},{"name":"高安市","value":"360983","parent":"360900"},{"name":"临川区","value":"361002","parent":"361000"},{"name":"南城县","value":"361021","parent":"361000"},{"name":"黎川县","value":"361022","parent":"361000"},{"name":"南丰县","value":"361023","parent":"361000"},{"name":"崇仁县","value":"361024","parent":"361000"},{"name":"乐安县","value":"361025","parent":"361000"},{"name":"宜黄县","value":"361026","parent":"361000"},{"name":"金溪县","value":"361027","parent":"361000"},{"name":"资溪县","value":"361028","parent":"361000"},{"name":"东乡县","value":"361029","parent":"361000"},{"name":"广昌县","value":"361030","parent":"361000"},{"name":"信州区","value":"361102","parent":"361100"},{"name":"广丰区","value":"361103","parent":"361100"},{"name":"上饶县","value":"361121","parent":"361100"},{"name":"玉山县","value":"361123","parent":"361100"},{"name":"铅山县","value":"361124","parent":"361100"},{"name":"横峰县","value":"361125","parent":"361100"},{"name":"弋阳县","value":"361126","parent":"361100"},{"name":"余干县","value":"361127","parent":"361100"},{"name":"鄱阳县","value":"361128","parent":"361100"},{"name":"万年县","value":"361129","parent":"361100"},{"name":"婺源县","value":"361130","parent":"361100"},{"name":"德兴市","value":"361181","parent":"361100"},{"name":"济南市","value":"370100","parent":"370000"},{"name":"青岛市","value":"370200","parent":"370000"},{"name":"淄博市","value":"370300","parent":"370000"},{"name":"枣庄市","value":"370400","parent":"370000"},{"name":"东营市","value":"370500","parent":"370000"},{"name":"烟台市","value":"370600","parent":"370000"},{"name":"潍坊市","value":"370700","parent":"370000"},{"name":"济宁市","value":"370800","parent":"370000"},{"name":"泰安市","value":"370900","parent":"370000"},{"name":"威海市","value":"371000","parent":"370000"},{"name":"日照市","value":"371100","parent":"370000"},{"name":"莱芜市","value":"371200","parent":"370000"},{"name":"临沂市","value":"371300","parent":"370000"},{"name":"德州市","value":"371400","parent":"370000"},{"name":"聊城市","value":"371500","parent":"370000"},{"name":"滨州市","value":"371600","parent":"370000"},{"name":"菏泽市","value":"371700","parent":"370000"},{"name":"历下区","value":"370102","parent":"370100"},{"name":"市中区","value":"370103","parent":"370100"},{"name":"槐荫区","value":"370104","parent":"370100"},{"name":"天桥区","value":"370105","parent":"370100"},{"name":"历城区","value":"370112","parent":"370100"},{"name":"长清区","value":"370113","parent":"370100"},{"name":"平阴县","value":"370124","parent":"370100"},{"name":"济阳县","value":"370125","parent":"370100"},{"name":"商河县","value":"370126","parent":"370100"},{"name":"章丘市","value":"370181","parent":"370100"},{"name":"市南区","value":"370202","parent":"370200"},{"name":"市北区","value":"370203","parent":"370200"},{"name":"黄岛区","value":"370211","parent":"370200"},{"name":"崂山区","value":"370212","parent":"370200"},{"name":"李沧区","value":"370213","parent":"370200"},{"name":"城阳区","value":"370214","parent":"370200"},{"name":"胶州市","value":"370281","parent":"370200"},{"name":"即墨市","value":"370282","parent":"370200"},{"name":"平度市","value":"370283","parent":"370200"},{"name":"莱西市","value":"370285","parent":"370200"},{"name":"淄川区","value":"370302","parent":"370300"},{"name":"张店区","value":"370303","parent":"370300"},{"name":"博山区","value":"370304","parent":"370300"},{"name":"临淄区","value":"370305","parent":"370300"},{"name":"周村区","value":"370306","parent":"370300"},{"name":"桓台县","value":"370321","parent":"370300"},{"name":"高青县","value":"370322","parent":"370300"},{"name":"沂源县","value":"370323","parent":"370300"},{"name":"市中区","value":"370402","parent":"370400"},{"name":"薛城区","value":"370403","parent":"370400"},{"name":"峄城区","value":"370404","parent":"370400"},{"name":"台儿庄区","value":"370405","parent":"370400"},{"name":"山亭区","value":"370406","parent":"370400"},{"name":"滕州市","value":"370481","parent":"370400"},{"name":"东营区","value":"370502","parent":"370500"},{"name":"河口区","value":"370503","parent":"370500"},{"name":"垦利县","value":"370521","parent":"370500"},{"name":"利津县","value":"370522","parent":"370500"},{"name":"广饶县","value":"370523","parent":"370500"},{"name":"芝罘区","value":"370602","parent":"370600"},{"name":"福山区","value":"370611","parent":"370600"},{"name":"牟平区","value":"370612","parent":"370600"},{"name":"莱山区","value":"370613","parent":"370600"},{"name":"长岛县","value":"370634","parent":"370600"},{"name":"龙口市","value":"370681","parent":"370600"},{"name":"莱阳市","value":"370682","parent":"370600"},{"name":"莱州市","value":"370683","parent":"370600"},{"name":"蓬莱市","value":"370684","parent":"370600"},{"name":"招远市","value":"370685","parent":"370600"},{"name":"栖霞市","value":"370686","parent":"370600"},{"name":"海阳市","value":"370687","parent":"370600"},{"name":"潍城区","value":"370702","parent":"370700"},{"name":"寒亭区","value":"370703","parent":"370700"},{"name":"坊子区","value":"370704","parent":"370700"},{"name":"奎文区","value":"370705","parent":"370700"},{"name":"临朐县","value":"370724","parent":"370700"},{"name":"昌乐县","value":"370725","parent":"370700"},{"name":"青州市","value":"370781","parent":"370700"},{"name":"诸城市","value":"370782","parent":"370700"},{"name":"寿光市","value":"370783","parent":"370700"},{"name":"安丘市","value":"370784","parent":"370700"},{"name":"高密市","value":"370785","parent":"370700"},{"name":"昌邑市","value":"370786","parent":"370700"},{"name":"任城区","value":"370811","parent":"370800"},{"name":"兖州区","value":"370812","parent":"370800"},{"name":"微山县","value":"370826","parent":"370800"},{"name":"鱼台县","value":"370827","parent":"370800"},{"name":"金乡县","value":"370828","parent":"370800"},{"name":"嘉祥县","value":"370829","parent":"370800"},{"name":"汶上县","value":"370830","parent":"370800"},{"name":"泗水县","value":"370831","parent":"370800"},{"name":"梁山县","value":"370832","parent":"370800"},{"name":"曲阜市","value":"370881","parent":"370800"},{"name":"邹城市","value":"370883","parent":"370800"},{"name":"泰山区","value":"370902","parent":"370900"},{"name":"岱岳区","value":"370911","parent":"370900"},{"name":"宁阳县","value":"370921","parent":"370900"},{"name":"东平县","value":"370923","parent":"370900"},{"name":"新泰市","value":"370982","parent":"370900"},{"name":"肥城市","value":"370983","parent":"370900"},{"name":"环翠区","value":"371002","parent":"371000"},{"name":"文登区","value":"371003","parent":"371000"},{"name":"荣成市","value":"371082","parent":"371000"},{"name":"乳山市","value":"371083","parent":"371000"},{"name":"东港区","value":"371102","parent":"371100"},{"name":"岚山区","value":"371103","parent":"371100"},{"name":"五莲县","value":"371121","parent":"371100"},{"name":"莒县","value":"371122","parent":"371100"},{"name":"莱城区","value":"371202","parent":"371200"},{"name":"钢城区","value":"371203","parent":"371200"},{"name":"兰山区","value":"371302","parent":"371300"},{"name":"罗庄区","value":"371311","parent":"371300"},{"name":"河东区","value":"371312","parent":"371300"},{"name":"沂南县","value":"371321","parent":"371300"},{"name":"郯城县","value":"371322","parent":"371300"},{"name":"沂水县","value":"371323","parent":"371300"},{"name":"兰陵县","value":"371324","parent":"371300"},{"name":"费县","value":"371325","parent":"371300"},{"name":"平邑县","value":"371326","parent":"371300"},{"name":"莒南县","value":"371327","parent":"371300"},{"name":"蒙阴县","value":"371328","parent":"371300"},{"name":"临沭县","value":"371329","parent":"371300"},{"name":"德城区","value":"371402","parent":"371400"},{"name":"陵城区","value":"371403","parent":"371400"},{"name":"宁津县","value":"371422","parent":"371400"},{"name":"庆云县","value":"371423","parent":"371400"},{"name":"临邑县","value":"371424","parent":"371400"},{"name":"齐河县","value":"371425","parent":"371400"},{"name":"平原县","value":"371426","parent":"371400"},{"name":"夏津县","value":"371427","parent":"371400"},{"name":"武城县","value":"371428","parent":"371400"},{"name":"乐陵市","value":"371481","parent":"371400"},{"name":"禹城市","value":"371482","parent":"371400"},{"name":"东昌府区","value":"371502","parent":"371500"},{"name":"阳谷县","value":"371521","parent":"371500"},{"name":"莘县","value":"371522","parent":"371500"},{"name":"茌平县","value":"371523","parent":"371500"},{"name":"东阿县","value":"371524","parent":"371500"},{"name":"冠县","value":"371525","parent":"371500"},{"name":"高唐县","value":"371526","parent":"371500"},{"name":"临清市","value":"371581","parent":"371500"},{"name":"滨城区","value":"371602","parent":"371600"},{"name":"沾化区","value":"371603","parent":"371600"},{"name":"惠民县","value":"371621","parent":"371600"},{"name":"阳信县","value":"371622","parent":"371600"},{"name":"无棣县","value":"371623","parent":"371600"},{"name":"博兴县","value":"371625","parent":"371600"},{"name":"邹平县","value":"371626","parent":"371600"},{"name":"牡丹区","value":"371702","parent":"371700"},{"name":"曹县","value":"371721","parent":"371700"},{"name":"单县","value":"371722","parent":"371700"},{"name":"成武县","value":"371723","parent":"371700"},{"name":"巨野县","value":"371724","parent":"371700"},{"name":"郓城县","value":"371725","parent":"371700"},{"name":"鄄城县","value":"371726","parent":"371700"},{"name":"定陶县","value":"371727","parent":"371700"},{"name":"东明县","value":"371728","parent":"371700"},{"name":"郑州市","value":"410100","parent":"410000"},{"name":"开封市","value":"410200","parent":"410000"},{"name":"洛阳市","value":"410300","parent":"410000"},{"name":"平顶山市","value":"410400","parent":"410000"},{"name":"安阳市","value":"410500","parent":"410000"},{"name":"鹤壁市","value":"410600","parent":"410000"},{"name":"新乡市","value":"410700","parent":"410000"},{"name":"焦作市","value":"410800","parent":"410000"},{"name":"濮阳市","value":"410900","parent":"410000"},{"name":"许昌市","value":"411000","parent":"410000"},{"name":"漯河市","value":"411100","parent":"410000"},{"name":"三门峡市","value":"411200","parent":"410000"},{"name":"南阳市","value":"411300","parent":"410000"},{"name":"商丘市","value":"411400","parent":"410000"},{"name":"信阳市","value":"411500","parent":"410000"},{"name":"周口市","value":"411600","parent":"410000"},{"name":"驻马店市","value":"411700","parent":"410000"},{"name":"济源市","value":"419001","parent":"410000"},{"name":"中原区","value":"410102","parent":"410100"},{"name":"二七区","value":"410103","parent":"410100"},{"name":"管城回族区","value":"410104","parent":"410100"},{"name":"金水区","value":"410105","parent":"410100"},{"name":"上街区","value":"410106","parent":"410100"},{"name":"惠济区","value":"410108","parent":"410100"},{"name":"中牟县","value":"410122","parent":"410100"},{"name":"巩义市","value":"410181","parent":"410100"},{"name":"荥阳市","value":"410182","parent":"410100"},{"name":"新密市","value":"410183","parent":"410100"},{"name":"新郑市","value":"410184","parent":"410100"},{"name":"登封市","value":"410185","parent":"410100"},{"name":"龙亭区","value":"410202","parent":"410200"},{"name":"顺河回族区","value":"410203","parent":"410200"},{"name":"鼓楼区","value":"410204","parent":"410200"},{"name":"禹王台区","value":"410205","parent":"410200"},{"name":"金明区","value":"410211","parent":"410200"},{"name":"祥符区","value":"410212","parent":"410200"},{"name":"杞县","value":"410221","parent":"410200"},{"name":"通许县","value":"410222","parent":"410200"},{"name":"尉氏县","value":"410223","parent":"410200"},{"name":"兰考县","value":"410225","parent":"410200"},{"name":"老城区","value":"410302","parent":"410300"},{"name":"西工区","value":"410303","parent":"410300"},{"name":"瀍河回族区","value":"410304","parent":"410300"},{"name":"涧西区","value":"410305","parent":"410300"},{"name":"吉利区","value":"410306","parent":"410300"},{"name":"洛龙区","value":"410311","parent":"410300"},{"name":"孟津县","value":"410322","parent":"410300"},{"name":"新安县","value":"410323","parent":"410300"},{"name":"栾川县","value":"410324","parent":"410300"},{"name":"嵩县","value":"410325","parent":"410300"},{"name":"汝阳县","value":"410326","parent":"410300"},{"name":"宜阳县","value":"410327","parent":"410300"},{"name":"洛宁县","value":"410328","parent":"410300"},{"name":"伊川县","value":"410329","parent":"410300"},{"name":"偃师市","value":"410381","parent":"410300"},{"name":"新华区","value":"410402","parent":"410400"},{"name":"卫东区","value":"410403","parent":"410400"},{"name":"石龙区","value":"410404","parent":"410400"},{"name":"湛河区","value":"410411","parent":"410400"},{"name":"宝丰县","value":"410421","parent":"410400"},{"name":"叶县","value":"410422","parent":"410400"},{"name":"鲁山县","value":"410423","parent":"410400"},{"name":"郏县","value":"410425","parent":"410400"},{"name":"舞钢市","value":"410481","parent":"410400"},{"name":"汝州市","value":"410482","parent":"410400"},{"name":"文峰区","value":"410502","parent":"410500"},{"name":"北关区","value":"410503","parent":"410500"},{"name":"殷都区","value":"410505","parent":"410500"},{"name":"龙安区","value":"410506","parent":"410500"},{"name":"安阳县","value":"410522","parent":"410500"},{"name":"汤阴县","value":"410523","parent":"410500"},{"name":"滑县","value":"410526","parent":"410500"},{"name":"内黄县","value":"410527","parent":"410500"},{"name":"林州市","value":"410581","parent":"410500"},{"name":"鹤山区","value":"410602","parent":"410600"},{"name":"山城区","value":"410603","parent":"410600"},{"name":"淇滨区","value":"410611","parent":"410600"},{"name":"浚县","value":"410621","parent":"410600"},{"name":"淇县","value":"410622","parent":"410600"},{"name":"红旗区","value":"410702","parent":"410700"},{"name":"卫滨区","value":"410703","parent":"410700"},{"name":"凤泉区","value":"410704","parent":"410700"},{"name":"牧野区","value":"410711","parent":"410700"},{"name":"新乡县","value":"410721","parent":"410700"},{"name":"获嘉县","value":"410724","parent":"410700"},{"name":"原阳县","value":"410725","parent":"410700"},{"name":"延津县","value":"410726","parent":"410700"},{"name":"封丘县","value":"410727","parent":"410700"},{"name":"长垣县","value":"410728","parent":"410700"},{"name":"卫辉市","value":"410781","parent":"410700"},{"name":"辉县市","value":"410782","parent":"410700"},{"name":"解放区","value":"410802","parent":"410800"},{"name":"中站区","value":"410803","parent":"410800"},{"name":"马村区","value":"410804","parent":"410800"},{"name":"山阳区","value":"410811","parent":"410800"},{"name":"修武县","value":"410821","parent":"410800"},{"name":"博爱县","value":"410822","parent":"410800"},{"name":"武陟县","value":"410823","parent":"410800"},{"name":"温县","value":"410825","parent":"410800"},{"name":"沁阳市","value":"410882","parent":"410800"},{"name":"孟州市","value":"410883","parent":"410800"},{"name":"华龙区","value":"410902","parent":"410900"},{"name":"清丰县","value":"410922","parent":"410900"},{"name":"南乐县","value":"410923","parent":"410900"},{"name":"范县","value":"410926","parent":"410900"},{"name":"台前县","value":"410927","parent":"410900"},{"name":"濮阳县","value":"410928","parent":"410900"},{"name":"魏都区","value":"411002","parent":"411000"},{"name":"许昌县","value":"411023","parent":"411000"},{"name":"鄢陵县","value":"411024","parent":"411000"},{"name":"襄城县","value":"411025","parent":"411000"},{"name":"禹州市","value":"411081","parent":"411000"},{"name":"长葛市","value":"411082","parent":"411000"},{"name":"源汇区","value":"411102","parent":"411100"},{"name":"郾城区","value":"411103","parent":"411100"},{"name":"召陵区","value":"411104","parent":"411100"},{"name":"舞阳县","value":"411121","parent":"411100"},{"name":"临颍县","value":"411122","parent":"411100"},{"name":"湖滨区","value":"411202","parent":"411200"},{"name":"渑池县","value":"411221","parent":"411200"},{"name":"陕县","value":"411222","parent":"411200"},{"name":"卢氏县","value":"411224","parent":"411200"},{"name":"义马市","value":"411281","parent":"411200"},{"name":"灵宝市","value":"411282","parent":"411200"},{"name":"宛城区","value":"411302","parent":"411300"},{"name":"卧龙区","value":"411303","parent":"411300"},{"name":"南召县","value":"411321","parent":"411300"},{"name":"方城县","value":"411322","parent":"411300"},{"name":"西峡县","value":"411323","parent":"411300"},{"name":"镇平县","value":"411324","parent":"411300"},{"name":"内乡县","value":"411325","parent":"411300"},{"name":"淅川县","value":"411326","parent":"411300"},{"name":"社旗县","value":"411327","parent":"411300"},{"name":"唐河县","value":"411328","parent":"411300"},{"name":"新野县","value":"411329","parent":"411300"},{"name":"桐柏县","value":"411330","parent":"411300"},{"name":"邓州市","value":"411381","parent":"411300"},{"name":"梁园区","value":"411402","parent":"411400"},{"name":"睢阳区","value":"411403","parent":"411400"},{"name":"民权县","value":"411421","parent":"411400"},{"name":"睢县","value":"411422","parent":"411400"},{"name":"宁陵县","value":"411423","parent":"411400"},{"name":"柘城县","value":"411424","parent":"411400"},{"name":"虞城县","value":"411425","parent":"411400"},{"name":"夏邑县","value":"411426","parent":"411400"},{"name":"永城市","value":"411481","parent":"411400"},{"name":"浉河区","value":"411502","parent":"411500"},{"name":"平桥区","value":"411503","parent":"411500"},{"name":"罗山县","value":"411521","parent":"411500"},{"name":"光山县","value":"411522","parent":"411500"},{"name":"新县","value":"411523","parent":"411500"},{"name":"商城县","value":"411524","parent":"411500"},{"name":"固始县","value":"411525","parent":"411500"},{"name":"潢川县","value":"411526","parent":"411500"},{"name":"淮滨县","value":"411527","parent":"411500"},{"name":"息县","value":"411528","parent":"411500"},{"name":"川汇区","value":"411602","parent":"411600"},{"name":"扶沟县","value":"411621","parent":"411600"},{"name":"西华县","value":"411622","parent":"411600"},{"name":"商水县","value":"411623","parent":"411600"},{"name":"沈丘县","value":"411624","parent":"411600"},{"name":"郸城县","value":"411625","parent":"411600"},{"name":"淮阳县","value":"411626","parent":"411600"},{"name":"太康县","value":"411627","parent":"411600"},{"name":"鹿邑县","value":"411628","parent":"411600"},{"name":"项城市","value":"411681","parent":"411600"},{"name":"驿城区","value":"411702","parent":"411700"},{"name":"西平县","value":"411721","parent":"411700"},{"name":"上蔡县","value":"411722","parent":"411700"},{"name":"平舆县","value":"411723","parent":"411700"},{"name":"正阳县","value":"411724","parent":"411700"},{"name":"确山县","value":"411725","parent":"411700"},{"name":"泌阳县","value":"411726","parent":"411700"},{"name":"汝南县","value":"411727","parent":"411700"},{"name":"遂平县","value":"411728","parent":"411700"},{"name":"新蔡县","value":"411729","parent":"411700"},{"name":"武汉市","value":"420100","parent":"420000"},{"name":"黄石市","value":"420200","parent":"420000"},{"name":"十堰市","value":"420300","parent":"420000"},{"name":"宜昌市","value":"420500","parent":"420000"},{"name":"襄阳市","value":"420600","parent":"420000"},{"name":"鄂州市","value":"420700","parent":"420000"},{"name":"荆门市","value":"420800","parent":"420000"},{"name":"孝感市","value":"420900","parent":"420000"},{"name":"荆州市","value":"421000","parent":"420000"},{"name":"黄冈市","value":"421100","parent":"420000"},{"name":"咸宁市","value":"421200","parent":"420000"},{"name":"随州市","value":"421300","parent":"420000"},{"name":"恩施土家族苗族自治州","value":"422800","parent":"420000"},{"name":"仙桃市","value":"429004","parent":"420000"},{"name":"潜江市","value":"429005","parent":"420000"},{"name":"天门市","value":"429006","parent":"420000"},{"name":"神农架林区","value":"429021","parent":"420000"},{"name":"江岸区","value":"420102","parent":"420100"},{"name":"江汉区","value":"420103","parent":"420100"},{"name":"硚口区","value":"420104","parent":"420100"},{"name":"汉阳区","value":"420105","parent":"420100"},{"name":"武昌区","value":"420106","parent":"420100"},{"name":"青山区","value":"420107","parent":"420100"},{"name":"洪山区","value":"420111","parent":"420100"},{"name":"东西湖区","value":"420112","parent":"420100"},{"name":"汉南区","value":"420113","parent":"420100"},{"name":"蔡甸区","value":"420114","parent":"420100"},{"name":"江夏区","value":"420115","parent":"420100"},{"name":"黄陂区","value":"420116","parent":"420100"},{"name":"新洲区","value":"420117","parent":"420100"},{"name":"黄石港区","value":"420202","parent":"420200"},{"name":"西塞山区","value":"420203","parent":"420200"},{"name":"下陆区","value":"420204","parent":"420200"},{"name":"铁山区","value":"420205","parent":"420200"},{"name":"阳新县","value":"420222","parent":"420200"},{"name":"大冶市","value":"420281","parent":"420200"},{"name":"茅箭区","value":"420302","parent":"420300"},{"name":"张湾区","value":"420303","parent":"420300"},{"name":"郧阳区","value":"420304","parent":"420300"},{"name":"郧西县","value":"420322","parent":"420300"},{"name":"竹山县","value":"420323","parent":"420300"},{"name":"竹溪县","value":"420324","parent":"420300"},{"name":"房县","value":"420325","parent":"420300"},{"name":"丹江口市","value":"420381","parent":"420300"},{"name":"西陵区","value":"420502","parent":"420500"},{"name":"伍家岗区","value":"420503","parent":"420500"},{"name":"点军区","value":"420504","parent":"420500"},{"name":"猇亭区","value":"420505","parent":"420500"},{"name":"夷陵区","value":"420506","parent":"420500"},{"name":"远安县","value":"420525","parent":"420500"},{"name":"兴山县","value":"420526","parent":"420500"},{"name":"秭归县","value":"420527","parent":"420500"},{"name":"长阳土家族自治县","value":"420528","parent":"420500"},{"name":"五峰土家族自治县","value":"420529","parent":"420500"},{"name":"宜都市","value":"420581","parent":"420500"},{"name":"当阳市","value":"420582","parent":"420500"},{"name":"枝江市","value":"420583","parent":"420500"},{"name":"襄城区","value":"420602","parent":"420600"},{"name":"樊城区","value":"420606","parent":"420600"},{"name":"襄州区","value":"420607","parent":"420600"},{"name":"南漳县","value":"420624","parent":"420600"},{"name":"谷城县","value":"420625","parent":"420600"},{"name":"保康县","value":"420626","parent":"420600"},{"name":"老河口市","value":"420682","parent":"420600"},{"name":"枣阳市","value":"420683","parent":"420600"},{"name":"宜城市","value":"420684","parent":"420600"},{"name":"梁子湖区","value":"420702","parent":"420700"},{"name":"华容区","value":"420703","parent":"420700"},{"name":"鄂城区","value":"420704","parent":"420700"},{"name":"东宝区","value":"420802","parent":"420800"},{"name":"掇刀区","value":"420804","parent":"420800"},{"name":"京山县","value":"420821","parent":"420800"},{"name":"沙洋县","value":"420822","parent":"420800"},{"name":"钟祥市","value":"420881","parent":"420800"},{"name":"孝南区","value":"420902","parent":"420900"},{"name":"孝昌县","value":"420921","parent":"420900"},{"name":"大悟县","value":"420922","parent":"420900"},{"name":"云梦县","value":"420923","parent":"420900"},{"name":"应城市","value":"420981","parent":"420900"},{"name":"安陆市","value":"420982","parent":"420900"},{"name":"汉川市","value":"420984","parent":"420900"},{"name":"沙市区","value":"421002","parent":"421000"},{"name":"荆州区","value":"421003","parent":"421000"},{"name":"公安县","value":"421022","parent":"421000"},{"name":"监利县","value":"421023","parent":"421000"},{"name":"江陵县","value":"421024","parent":"421000"},{"name":"石首市","value":"421081","parent":"421000"},{"name":"洪湖市","value":"421083","parent":"421000"},{"name":"松滋市","value":"421087","parent":"421000"},{"name":"黄州区","value":"421102","parent":"421100"},{"name":"团风县","value":"421121","parent":"421100"},{"name":"红安县","value":"421122","parent":"421100"},{"name":"罗田县","value":"421123","parent":"421100"},{"name":"英山县","value":"421124","parent":"421100"},{"name":"浠水县","value":"421125","parent":"421100"},{"name":"蕲春县","value":"421126","parent":"421100"},{"name":"黄梅县","value":"421127","parent":"421100"},{"name":"麻城市","value":"421181","parent":"421100"},{"name":"武穴市","value":"421182","parent":"421100"},{"name":"咸安区","value":"421202","parent":"421200"},{"name":"嘉鱼县","value":"421221","parent":"421200"},{"name":"通城县","value":"421222","parent":"421200"},{"name":"崇阳县","value":"421223","parent":"421200"},{"name":"通山县","value":"421224","parent":"421200"},{"name":"赤壁市","value":"421281","parent":"421200"},{"name":"曾都区","value":"421303","parent":"421300"},{"name":"随县","value":"421321","parent":"421300"},{"name":"广水市","value":"421381","parent":"421300"},{"name":"恩施市","value":"422801","parent":"422800"},{"name":"利川市","value":"422802","parent":"422800"},{"name":"建始县","value":"422822","parent":"422800"},{"name":"巴东县","value":"422823","parent":"422800"},{"name":"宣恩县","value":"422825","parent":"422800"},{"name":"咸丰县","value":"422826","parent":"422800"},{"name":"来凤县","value":"422827","parent":"422800"},{"name":"鹤峰县","value":"422828","parent":"422800"},{"name":"长沙市","value":"430100","parent":"430000"},{"name":"株洲市","value":"430200","parent":"430000"},{"name":"湘潭市","value":"430300","parent":"430000"},{"name":"衡阳市","value":"430400","parent":"430000"},{"name":"邵阳市","value":"430500","parent":"430000"},{"name":"岳阳市","value":"430600","parent":"430000"},{"name":"常德市","value":"430700","parent":"430000"},{"name":"张家界市","value":"430800","parent":"430000"},{"name":"益阳市","value":"430900","parent":"430000"},{"name":"郴州市","value":"431000","parent":"430000"},{"name":"永州市","value":"431100","parent":"430000"},{"name":"怀化市","value":"431200","parent":"430000"},{"name":"娄底市","value":"431300","parent":"430000"},{"name":"湘西土家族苗族自治州","value":"433100","parent":"430000"},{"name":"芙蓉区","value":"430102","parent":"430100"},{"name":"天心区","value":"430103","parent":"430100"},{"name":"岳麓区","value":"430104","parent":"430100"},{"name":"开福区","value":"430105","parent":"430100"},{"name":"雨花区","value":"430111","parent":"430100"},{"name":"望城区","value":"430112","parent":"430100"},{"name":"长沙县","value":"430121","parent":"430100"},{"name":"宁乡县","value":"430124","parent":"430100"},{"name":"浏阳市","value":"430181","parent":"430100"},{"name":"荷塘区","value":"430202","parent":"430200"},{"name":"芦淞区","value":"430203","parent":"430200"},{"name":"石峰区","value":"430204","parent":"430200"},{"name":"天元区","value":"430211","parent":"430200"},{"name":"株洲县","value":"430221","parent":"430200"},{"name":"攸县","value":"430223","parent":"430200"},{"name":"茶陵县","value":"430224","parent":"430200"},{"name":"炎陵县","value":"430225","parent":"430200"},{"name":"醴陵市","value":"430281","parent":"430200"},{"name":"雨湖区","value":"430302","parent":"430300"},{"name":"岳塘区","value":"430304","parent":"430300"},{"name":"湘潭县","value":"430321","parent":"430300"},{"name":"湘乡市","value":"430381","parent":"430300"},{"name":"韶山市","value":"430382","parent":"430300"},{"name":"珠晖区","value":"430405","parent":"430400"},{"name":"雁峰区","value":"430406","parent":"430400"},{"name":"石鼓区","value":"430407","parent":"430400"},{"name":"蒸湘区","value":"430408","parent":"430400"},{"name":"南岳区","value":"430412","parent":"430400"},{"name":"衡阳县","value":"430421","parent":"430400"},{"name":"衡南县","value":"430422","parent":"430400"},{"name":"衡山县","value":"430423","parent":"430400"},{"name":"衡东县","value":"430424","parent":"430400"},{"name":"祁东县","value":"430426","parent":"430400"},{"name":"耒阳市","value":"430481","parent":"430400"},{"name":"常宁市","value":"430482","parent":"430400"},{"name":"双清区","value":"430502","parent":"430500"},{"name":"大祥区","value":"430503","parent":"430500"},{"name":"北塔区","value":"430511","parent":"430500"},{"name":"邵东县","value":"430521","parent":"430500"},{"name":"新邵县","value":"430522","parent":"430500"},{"name":"邵阳县","value":"430523","parent":"430500"},{"name":"隆回县","value":"430524","parent":"430500"},{"name":"洞口县","value":"430525","parent":"430500"},{"name":"绥宁县","value":"430527","parent":"430500"},{"name":"新宁县","value":"430528","parent":"430500"},{"name":"城步苗族自治县","value":"430529","parent":"430500"},{"name":"武冈市","value":"430581","parent":"430500"},{"name":"岳阳楼区","value":"430602","parent":"430600"},{"name":"云溪区","value":"430603","parent":"430600"},{"name":"君山区","value":"430611","parent":"430600"},{"name":"岳阳县","value":"430621","parent":"430600"},{"name":"华容县","value":"430623","parent":"430600"},{"name":"湘阴县","value":"430624","parent":"430600"},{"name":"平江县","value":"430626","parent":"430600"},{"name":"汨罗市","value":"430681","parent":"430600"},{"name":"临湘市","value":"430682","parent":"430600"},{"name":"武陵区","value":"430702","parent":"430700"},{"name":"鼎城区","value":"430703","parent":"430700"},{"name":"安乡县","value":"430721","parent":"430700"},{"name":"汉寿县","value":"430722","parent":"430700"},{"name":"澧县","value":"430723","parent":"430700"},{"name":"临澧县","value":"430724","parent":"430700"},{"name":"桃源县","value":"430725","parent":"430700"},{"name":"石门县","value":"430726","parent":"430700"},{"name":"津市市","value":"430781","parent":"430700"},{"name":"永定区","value":"430802","parent":"430800"},{"name":"武陵源区","value":"430811","parent":"430800"},{"name":"慈利县","value":"430821","parent":"430800"},{"name":"桑植县","value":"430822","parent":"430800"},{"name":"资阳区","value":"430902","parent":"430900"},{"name":"赫山区","value":"430903","parent":"430900"},{"name":"南县","value":"430921","parent":"430900"},{"name":"桃江县","value":"430922","parent":"430900"},{"name":"安化县","value":"430923","parent":"430900"},{"name":"沅江市","value":"430981","parent":"430900"},{"name":"北湖区","value":"431002","parent":"431000"},{"name":"苏仙区","value":"431003","parent":"431000"},{"name":"桂阳县","value":"431021","parent":"431000"},{"name":"宜章县","value":"431022","parent":"431000"},{"name":"永兴县","value":"431023","parent":"431000"},{"name":"嘉禾县","value":"431024","parent":"431000"},{"name":"临武县","value":"431025","parent":"431000"},{"name":"汝城县","value":"431026","parent":"431000"},{"name":"桂东县","value":"431027","parent":"431000"},{"name":"安仁县","value":"431028","parent":"431000"},{"name":"资兴市","value":"431081","parent":"431000"},{"name":"零陵区","value":"431102","parent":"431100"},{"name":"冷水滩区","value":"431103","parent":"431100"},{"name":"祁阳县","value":"431121","parent":"431100"},{"name":"东安县","value":"431122","parent":"431100"},{"name":"双牌县","value":"431123","parent":"431100"},{"name":"道县","value":"431124","parent":"431100"},{"name":"江永县","value":"431125","parent":"431100"},{"name":"宁远县","value":"431126","parent":"431100"},{"name":"蓝山县","value":"431127","parent":"431100"},{"name":"新田县","value":"431128","parent":"431100"},{"name":"江华瑶族自治县","value":"431129","parent":"431100"},{"name":"鹤城区","value":"431202","parent":"431200"},{"name":"中方县","value":"431221","parent":"431200"},{"name":"沅陵县","value":"431222","parent":"431200"},{"name":"辰溪县","value":"431223","parent":"431200"},{"name":"溆浦县","value":"431224","parent":"431200"},{"name":"会同县","value":"431225","parent":"431200"},{"name":"麻阳苗族自治县","value":"431226","parent":"431200"},{"name":"新晃侗族自治县","value":"431227","parent":"431200"},{"name":"芷江侗族自治县","value":"431228","parent":"431200"},{"name":"靖州苗族侗族自治县","value":"431229","parent":"431200"},{"name":"通道侗族自治县","value":"431230","parent":"431200"},{"name":"洪江市","value":"431281","parent":"431200"},{"name":"娄星区","value":"431302","parent":"431300"},{"name":"双峰县","value":"431321","parent":"431300"},{"name":"新化县","value":"431322","parent":"431300"},{"name":"冷水江市","value":"431381","parent":"431300"},{"name":"涟源市","value":"431382","parent":"431300"},{"name":"吉首市","value":"433101","parent":"433100"},{"name":"泸溪县","value":"433122","parent":"433100"},{"name":"凤凰县","value":"433123","parent":"433100"},{"name":"花垣县","value":"433124","parent":"433100"},{"name":"保靖县","value":"433125","parent":"433100"},{"name":"古丈县","value":"433126","parent":"433100"},{"name":"永顺县","value":"433127","parent":"433100"},{"name":"龙山县","value":"433130","parent":"433100"},{"name":"广州市","value":"440100","parent":"440000"},{"name":"韶关市","value":"440200","parent":"440000"},{"name":"深圳市","value":"440300","parent":"440000"},{"name":"珠海市","value":"440400","parent":"440000"},{"name":"汕头市","value":"440500","parent":"440000"},{"name":"佛山市","value":"440600","parent":"440000"},{"name":"江门市","value":"440700","parent":"440000"},{"name":"湛江市","value":"440800","parent":"440000"},{"name":"茂名市","value":"440900","parent":"440000"},{"name":"肇庆市","value":"441200","parent":"440000"},{"name":"惠州市","value":"441300","parent":"440000"},{"name":"梅州市","value":"441400","parent":"440000"},{"name":"汕尾市","value":"441500","parent":"440000"},{"name":"河源市","value":"441600","parent":"440000"},{"name":"阳江市","value":"441700","parent":"440000"},{"name":"清远市","value":"441800","parent":"440000"},{"name":"东莞市","value":"441900","parent":"440000"},{"name":"中山市","value":"442000","parent":"440000"},{"name":"潮州市","value":"445100","parent":"440000"},{"name":"揭阳市","value":"445200","parent":"440000"},{"name":"云浮市","value":"445300","parent":"440000"},{"name":"荔湾区","value":"440103","parent":"440100"},{"name":"越秀区","value":"440104","parent":"440100"},{"name":"海珠区","value":"440105","parent":"440100"},{"name":"天河区","value":"440106","parent":"440100"},{"name":"白云区","value":"440111","parent":"440100"},{"name":"黄埔区","value":"440112","parent":"440100"},{"name":"番禺区","value":"440113","parent":"440100"},{"name":"花都区","value":"440114","parent":"440100"},{"name":"南沙区","value":"440115","parent":"440100"},{"name":"从化区","value":"440117","parent":"440100"},{"name":"增城区","value":"440118","parent":"440100"},{"name":"武江区","value":"440203","parent":"440200"},{"name":"浈江区","value":"440204","parent":"440200"},{"name":"曲江区","value":"440205","parent":"440200"},{"name":"始兴县","value":"440222","parent":"440200"},{"name":"仁化县","value":"440224","parent":"440200"},{"name":"翁源县","value":"440229","parent":"440200"},{"name":"乳源瑶族自治县","value":"440232","parent":"440200"},{"name":"新丰县","value":"440233","parent":"440200"},{"name":"乐昌市","value":"440281","parent":"440200"},{"name":"南雄市","value":"440282","parent":"440200"},{"name":"罗湖区","value":"440303","parent":"440300"},{"name":"福田区","value":"440304","parent":"440300"},{"name":"南山区","value":"440305","parent":"440300"},{"name":"宝安区","value":"440306","parent":"440300"},{"name":"龙岗区","value":"440307","parent":"440300"},{"name":"盐田区","value":"440308","parent":"440300"},{"name":"香洲区","value":"440402","parent":"440400"},{"name":"斗门区","value":"440403","parent":"440400"},{"name":"金湾区","value":"440404","parent":"440400"},{"name":"龙湖区","value":"440507","parent":"440500"},{"name":"金平区","value":"440511","parent":"440500"},{"name":"濠江区","value":"440512","parent":"440500"},{"name":"潮阳区","value":"440513","parent":"440500"},{"name":"潮南区","value":"440514","parent":"440500"},{"name":"澄海区","value":"440515","parent":"440500"},{"name":"南澳县","value":"440523","parent":"440500"},{"name":"禅城区","value":"440604","parent":"440600"},{"name":"南海区","value":"440605","parent":"440600"},{"name":"顺德区","value":"440606","parent":"440600"},{"name":"三水区","value":"440607","parent":"440600"},{"name":"高明区","value":"440608","parent":"440600"},{"name":"蓬江区","value":"440703","parent":"440700"},{"name":"江海区","value":"440704","parent":"440700"},{"name":"新会区","value":"440705","parent":"440700"},{"name":"台山市","value":"440781","parent":"440700"},{"name":"开平市","value":"440783","parent":"440700"},{"name":"鹤山市","value":"440784","parent":"440700"},{"name":"恩平市","value":"440785","parent":"440700"},{"name":"赤坎区","value":"440802","parent":"440800"},{"name":"霞山区","value":"440803","parent":"440800"},{"name":"坡头区","value":"440804","parent":"440800"},{"name":"麻章区","value":"440811","parent":"440800"},{"name":"遂溪县","value":"440823","parent":"440800"},{"name":"徐闻县","value":"440825","parent":"440800"},{"name":"廉江市","value":"440881","parent":"440800"},{"name":"雷州市","value":"440882","parent":"440800"},{"name":"吴川市","value":"440883","parent":"440800"},{"name":"茂南区","value":"440902","parent":"440900"},{"name":"电白区","value":"440904","parent":"440900"},{"name":"高州市","value":"440981","parent":"440900"},{"name":"化州市","value":"440982","parent":"440900"},{"name":"信宜市","value":"440983","parent":"440900"},{"name":"端州区","value":"441202","parent":"441200"},{"name":"鼎湖区","value":"441203","parent":"441200"},{"name":"高要区","value":"441204","parent":"441200"},{"name":"广宁县","value":"441223","parent":"441200"},{"name":"怀集县","value":"441224","parent":"441200"},{"name":"封开县","value":"441225","parent":"441200"},{"name":"德庆县","value":"441226","parent":"441200"},{"name":"四会市","value":"441284","parent":"441200"},{"name":"惠城区","value":"441302","parent":"441300"},{"name":"惠阳区","value":"441303","parent":"441300"},{"name":"博罗县","value":"441322","parent":"441300"},{"name":"惠东县","value":"441323","parent":"441300"},{"name":"龙门县","value":"441324","parent":"441300"},{"name":"梅江区","value":"441402","parent":"441400"},{"name":"梅县区","value":"441403","parent":"441400"},{"name":"大埔县","value":"441422","parent":"441400"},{"name":"丰顺县","value":"441423","parent":"441400"},{"name":"五华县","value":"441424","parent":"441400"},{"name":"平远县","value":"441426","parent":"441400"},{"name":"蕉岭县","value":"441427","parent":"441400"},{"name":"兴宁市","value":"441481","parent":"441400"},{"name":"城区","value":"441502","parent":"441500"},{"name":"海丰县","value":"441521","parent":"441500"},{"name":"陆河县","value":"441523","parent":"441500"},{"name":"陆丰市","value":"441581","parent":"441500"},{"name":"源城区","value":"441602","parent":"441600"},{"name":"紫金县","value":"441621","parent":"441600"},{"name":"龙川县","value":"441622","parent":"441600"},{"name":"连平县","value":"441623","parent":"441600"},{"name":"和平县","value":"441624","parent":"441600"},{"name":"东源县","value":"441625","parent":"441600"},{"name":"江城区","value":"441702","parent":"441700"},{"name":"阳东区","value":"441704","parent":"441700"},{"name":"阳西县","value":"441721","parent":"441700"},{"name":"阳春市","value":"441781","parent":"441700"},{"name":"清城区","value":"441802","parent":"441800"},{"name":"清新区","value":"441803","parent":"441800"},{"name":"佛冈县","value":"441821","parent":"441800"},{"name":"阳山县","value":"441823","parent":"441800"},{"name":"连山壮族瑶族自治县","value":"441825","parent":"441800"},{"name":"连南瑶族自治县","value":"441826","parent":"441800"},{"name":"英德市","value":"441881","parent":"441800"},{"name":"连州市","value":"441882","parent":"441800"},{"name":"湘桥区","value":"445102","parent":"445100"},{"name":"潮安区","value":"445103","parent":"445100"},{"name":"饶平县","value":"445122","parent":"445100"},{"name":"榕城区","value":"445202","parent":"445200"},{"name":"揭东区","value":"445203","parent":"445200"},{"name":"揭西县","value":"445222","parent":"445200"},{"name":"惠来县","value":"445224","parent":"445200"},{"name":"普宁市","value":"445281","parent":"445200"},{"name":"云城区","value":"445302","parent":"445300"},{"name":"云安区","value":"445303","parent":"445300"},{"name":"新兴县","value":"445321","parent":"445300"},{"name":"郁南县","value":"445322","parent":"445300"},{"name":"罗定市","value":"445381","parent":"445300"},{"name":"南宁市","value":"450100","parent":"450000"},{"name":"柳州市","value":"450200","parent":"450000"},{"name":"桂林市","value":"450300","parent":"450000"},{"name":"梧州市","value":"450400","parent":"450000"},{"name":"北海市","value":"450500","parent":"450000"},{"name":"防城港市","value":"450600","parent":"450000"},{"name":"钦州市","value":"450700","parent":"450000"},{"name":"贵港市","value":"450800","parent":"450000"},{"name":"玉林市","value":"450900","parent":"450000"},{"name":"百色市","value":"451000","parent":"450000"},{"name":"贺州市","value":"451100","parent":"450000"},{"name":"河池市","value":"451200","parent":"450000"},{"name":"来宾市","value":"451300","parent":"450000"},{"name":"崇左市","value":"451400","parent":"450000"},{"name":"兴宁区","value":"450102","parent":"450100"},{"name":"青秀区","value":"450103","parent":"450100"},{"name":"江南区","value":"450105","parent":"450100"},{"name":"西乡塘区","value":"450107","parent":"450100"},{"name":"良庆区","value":"450108","parent":"450100"},{"name":"邕宁区","value":"450109","parent":"450100"},{"name":"武鸣区","value":"450110","parent":"450100"},{"name":"隆安县","value":"450123","parent":"450100"},{"name":"马山县","value":"450124","parent":"450100"},{"name":"上林县","value":"450125","parent":"450100"},{"name":"宾阳县","value":"450126","parent":"450100"},{"name":"横县","value":"450127","parent":"450100"},{"name":"城中区","value":"450202","parent":"450200"},{"name":"鱼峰区","value":"450203","parent":"450200"},{"name":"柳南区","value":"450204","parent":"450200"},{"name":"柳北区","value":"450205","parent":"450200"},{"name":"柳江县","value":"450221","parent":"450200"},{"name":"柳城县","value":"450222","parent":"450200"},{"name":"鹿寨县","value":"450223","parent":"450200"},{"name":"融安县","value":"450224","parent":"450200"},{"name":"融水苗族自治县","value":"450225","parent":"450200"},{"name":"三江侗族自治县","value":"450226","parent":"450200"},{"name":"秀峰区","value":"450302","parent":"450300"},{"name":"叠彩区","value":"450303","parent":"450300"},{"name":"象山区","value":"450304","parent":"450300"},{"name":"七星区","value":"450305","parent":"450300"},{"name":"雁山区","value":"450311","parent":"450300"},{"name":"临桂区","value":"450312","parent":"450300"},{"name":"阳朔县","value":"450321","parent":"450300"},{"name":"灵川县","value":"450323","parent":"450300"},{"name":"全州县","value":"450324","parent":"450300"},{"name":"兴安县","value":"450325","parent":"450300"},{"name":"永福县","value":"450326","parent":"450300"},{"name":"灌阳县","value":"450327","parent":"450300"},{"name":"龙胜各族自治县","value":"450328","parent":"450300"},{"name":"资源县","value":"450329","parent":"450300"},{"name":"平乐县","value":"450330","parent":"450300"},{"name":"荔浦县","value":"450331","parent":"450300"},{"name":"恭城瑶族自治县","value":"450332","parent":"450300"},{"name":"万秀区","value":"450403","parent":"450400"},{"name":"长洲区","value":"450405","parent":"450400"},{"name":"龙圩区","value":"450406","parent":"450400"},{"name":"苍梧县","value":"450421","parent":"450400"},{"name":"藤县","value":"450422","parent":"450400"},{"name":"蒙山县","value":"450423","parent":"450400"},{"name":"岑溪市","value":"450481","parent":"450400"},{"name":"海城区","value":"450502","parent":"450500"},{"name":"银海区","value":"450503","parent":"450500"},{"name":"铁山港区","value":"450512","parent":"450500"},{"name":"合浦县","value":"450521","parent":"450500"},{"name":"港口区","value":"450602","parent":"450600"},{"name":"防城区","value":"450603","parent":"450600"},{"name":"上思县","value":"450621","parent":"450600"},{"name":"东兴市","value":"450681","parent":"450600"},{"name":"钦南区","value":"450702","parent":"450700"},{"name":"钦北区","value":"450703","parent":"450700"},{"name":"灵山县","value":"450721","parent":"450700"},{"name":"浦北县","value":"450722","parent":"450700"},{"name":"港北区","value":"450802","parent":"450800"},{"name":"港南区","value":"450803","parent":"450800"},{"name":"覃塘区","value":"450804","parent":"450800"},{"name":"平南县","value":"450821","parent":"450800"},{"name":"桂平市","value":"450881","parent":"450800"},{"name":"玉州区","value":"450902","parent":"450900"},{"name":"福绵区","value":"450903","parent":"450900"},{"name":"容县","value":"450921","parent":"450900"},{"name":"陆川县","value":"450922","parent":"450900"},{"name":"博白县","value":"450923","parent":"450900"},{"name":"兴业县","value":"450924","parent":"450900"},{"name":"北流市","value":"450981","parent":"450900"},{"name":"右江区","value":"451002","parent":"451000"},{"name":"田阳县","value":"451021","parent":"451000"},{"name":"田东县","value":"451022","parent":"451000"},{"name":"平果县","value":"451023","parent":"451000"},{"name":"德保县","value":"451024","parent":"451000"},{"name":"那坡县","value":"451026","parent":"451000"},{"name":"凌云县","value":"451027","parent":"451000"},{"name":"乐业县","value":"451028","parent":"451000"},{"name":"田林县","value":"451029","parent":"451000"},{"name":"西林县","value":"451030","parent":"451000"},{"name":"隆林各族自治县","value":"451031","parent":"451000"},{"name":"靖西市","value":"451081","parent":"451000"},{"name":"八步区","value":"451102","parent":"451100"},{"name":"昭平县","value":"451121","parent":"451100"},{"name":"钟山县","value":"451122","parent":"451100"},{"name":"富川瑶族自治县","value":"451123","parent":"451100"},{"name":"金城江区","value":"451202","parent":"451200"},{"name":"南丹县","value":"451221","parent":"451200"},{"name":"天峨县","value":"451222","parent":"451200"},{"name":"凤山县","value":"451223","parent":"451200"},{"name":"东兰县","value":"451224","parent":"451200"},{"name":"罗城仫佬族自治县","value":"451225","parent":"451200"},{"name":"环江毛南族自治县","value":"451226","parent":"451200"},{"name":"巴马瑶族自治县","value":"451227","parent":"451200"},{"name":"都安瑶族自治县","value":"451228","parent":"451200"},{"name":"大化瑶族自治县","value":"451229","parent":"451200"},{"name":"宜州市","value":"451281","parent":"451200"},{"name":"兴宾区","value":"451302","parent":"451300"},{"name":"忻城县","value":"451321","parent":"451300"},{"name":"象州县","value":"451322","parent":"451300"},{"name":"武宣县","value":"451323","parent":"451300"},{"name":"金秀瑶族自治县","value":"451324","parent":"451300"},{"name":"合山市","value":"451381","parent":"451300"},{"name":"江州区","value":"451402","parent":"451400"},{"name":"扶绥县","value":"451421","parent":"451400"},{"name":"宁明县","value":"451422","parent":"451400"},{"name":"龙州县","value":"451423","parent":"451400"},{"name":"大新县","value":"451424","parent":"451400"},{"name":"天等县","value":"451425","parent":"451400"},{"name":"凭祥市","value":"451481","parent":"451400"},{"name":"海口市","value":"460100","parent":"460000"},{"name":"三亚市","value":"460200","parent":"460000"},{"name":"三沙市","value":"460300","parent":"460000"},{"name":"五指山市","value":"469001","parent":"460000"},{"name":"琼海市","value":"469002","parent":"460000"},{"name":"儋州市","value":"469003","parent":"460000"},{"name":"文昌市","value":"469005","parent":"460000"},{"name":"万宁市","value":"469006","parent":"460000"},{"name":"东方市","value":"469007","parent":"460000"},{"name":"定安县","value":"469021","parent":"460000"},{"name":"屯昌县","value":"469022","parent":"460000"},{"name":"澄迈县","value":"469023","parent":"460000"},{"name":"临高县","value":"469024","parent":"460000"},{"name":"白沙黎族自治县","value":"469025","parent":"460000"},{"name":"昌江黎族自治县","value":"469026","parent":"460000"},{"name":"乐东黎族自治县","value":"469027","parent":"460000"},{"name":"陵水黎族自治县","value":"469028","parent":"460000"},{"name":"保亭黎族苗族自治县","value":"469029","parent":"460000"},{"name":"琼中黎族苗族自治县","value":"469030","parent":"460000"},{"name":"秀英区","value":"460105","parent":"460100"},{"name":"龙华区","value":"460106","parent":"460100"},{"name":"琼山区","value":"460107","parent":"460100"},{"name":"美兰区","value":"460108","parent":"460100"},{"name":"海棠区","value":"460202","parent":"460200"},{"name":"吉阳区","value":"460203","parent":"460200"},{"name":"天涯区","value":"460204","parent":"460200"},{"name":"崖州区","value":"460205","parent":"460200"},{"name":"西沙群岛","value":"460321","parent":"460300"},{"name":"南沙群岛","value":"460322","parent":"460300"},{"name":"中沙群岛的岛礁及其海域","value":"460323","parent":"460300"},{"name":"市辖区","value":"500100","parent":"500000"},{"name":"万州区","value":"500101","parent":"500100"},{"name":"涪陵区","value":"500102","parent":"500100"},{"name":"渝中区","value":"500103","parent":"500100"},{"name":"大渡口区","value":"500104","parent":"500100"},{"name":"江北区","value":"500105","parent":"500100"},{"name":"沙坪坝区","value":"500106","parent":"500100"},{"name":"九龙坡区","value":"500107","parent":"500100"},{"name":"南岸区","value":"500108","parent":"500100"},{"name":"北碚区","value":"500109","parent":"500100"},{"name":"綦江区","value":"500110","parent":"500100"},{"name":"大足区","value":"500111","parent":"500100"},{"name":"渝北区","value":"500112","parent":"500100"},{"name":"巴南区","value":"500113","parent":"500100"},{"name":"黔江区","value":"500114","parent":"500100"},{"name":"长寿区","value":"500115","parent":"500100"},{"name":"江津区","value":"500116","parent":"500100"},{"name":"合川区","value":"500117","parent":"500100"},{"name":"永川区","value":"500118","parent":"500100"},{"name":"南川区","value":"500119","parent":"500100"},{"name":"璧山区","value":"500120","parent":"500100"},{"name":"铜梁区","value":"500151","parent":"500100"},{"name":"潼南区","value":"500152","parent":"500100"},{"name":"荣昌区","value":"500153","parent":"500100"},{"name":"梁平县","value":"500228","parent":"500100"},{"name":"城口县","value":"500229","parent":"500100"},{"name":"丰都县","value":"500230","parent":"500100"},{"name":"垫江县","value":"500231","parent":"500100"},{"name":"武隆县","value":"500232","parent":"500100"},{"name":"忠县","value":"500233","parent":"500100"},{"name":"开县","value":"500234","parent":"500100"},{"name":"云阳县","value":"500235","parent":"500100"},{"name":"奉节县","value":"500236","parent":"500100"},{"name":"巫山县","value":"500237","parent":"500100"},{"name":"巫溪县","value":"500238","parent":"500100"},{"name":"石柱土家族自治县","value":"500240","parent":"500100"},{"name":"秀山土家族苗族自治县","value":"500241","parent":"500100"},{"name":"酉阳土家族苗族自治县","value":"500242","parent":"500100"},{"name":"彭水苗族土家族自治县","value":"500243","parent":"500100"},{"name":"成都市","value":"510100","parent":"510000"},{"name":"自贡市","value":"510300","parent":"510000"},{"name":"攀枝花市","value":"510400","parent":"510000"},{"name":"泸州市","value":"510500","parent":"510000"},{"name":"德阳市","value":"510600","parent":"510000"},{"name":"绵阳市","value":"510700","parent":"510000"},{"name":"广元市","value":"510800","parent":"510000"},{"name":"遂宁市","value":"510900","parent":"510000"},{"name":"内江市","value":"511000","parent":"510000"},{"name":"乐山市","value":"511100","parent":"510000"},{"name":"南充市","value":"511300","parent":"510000"},{"name":"眉山市","value":"511400","parent":"510000"},{"name":"宜宾市","value":"511500","parent":"510000"},{"name":"广安市","value":"511600","parent":"510000"},{"name":"达州市","value":"511700","parent":"510000"},{"name":"雅安市","value":"511800","parent":"510000"},{"name":"巴中市","value":"511900","parent":"510000"},{"name":"资阳市","value":"512000","parent":"510000"},{"name":"阿坝藏族羌族自治州","value":"513200","parent":"510000"},{"name":"甘孜藏族自治州","value":"513300","parent":"510000"},{"name":"凉山彝族自治州","value":"513400","parent":"510000"},{"name":"锦江区","value":"510104","parent":"510100"},{"name":"青羊区","value":"510105","parent":"510100"},{"name":"金牛区","value":"510106","parent":"510100"},{"name":"武侯区","value":"510107","parent":"510100"},{"name":"成华区","value":"510108","parent":"510100"},{"name":"龙泉驿区","value":"510112","parent":"510100"},{"name":"青白江区","value":"510113","parent":"510100"},{"name":"新都区","value":"510114","parent":"510100"},{"name":"温江区","value":"510115","parent":"510100"},{"name":"金堂县","value":"510121","parent":"510100"},{"name":"双流县","value":"510122","parent":"510100"},{"name":"郫县","value":"510124","parent":"510100"},{"name":"大邑县","value":"510129","parent":"510100"},{"name":"蒲江县","value":"510131","parent":"510100"},{"name":"新津县","value":"510132","parent":"510100"},{"name":"都江堰市","value":"510181","parent":"510100"},{"name":"彭州市","value":"510182","parent":"510100"},{"name":"邛崃市","value":"510183","parent":"510100"},{"name":"崇州市","value":"510184","parent":"510100"},{"name":"自流井区","value":"510302","parent":"510300"},{"name":"贡井区","value":"510303","parent":"510300"},{"name":"大安区","value":"510304","parent":"510300"},{"name":"沿滩区","value":"510311","parent":"510300"},{"name":"荣县","value":"510321","parent":"510300"},{"name":"富顺县","value":"510322","parent":"510300"},{"name":"东区","value":"510402","parent":"510400"},{"name":"西区","value":"510403","parent":"510400"},{"name":"仁和区","value":"510411","parent":"510400"},{"name":"米易县","value":"510421","parent":"510400"},{"name":"盐边县","value":"510422","parent":"510400"},{"name":"江阳区","value":"510502","parent":"510500"},{"name":"纳溪区","value":"510503","parent":"510500"},{"name":"龙马潭区","value":"510504","parent":"510500"},{"name":"泸县","value":"510521","parent":"510500"},{"name":"合江县","value":"510522","parent":"510500"},{"name":"叙永县","value":"510524","parent":"510500"},{"name":"古蔺县","value":"510525","parent":"510500"},{"name":"旌阳区","value":"510603","parent":"510600"},{"name":"中江县","value":"510623","parent":"510600"},{"name":"罗江县","value":"510626","parent":"510600"},{"name":"广汉市","value":"510681","parent":"510600"},{"name":"什邡市","value":"510682","parent":"510600"},{"name":"绵竹市","value":"510683","parent":"510600"},{"name":"涪城区","value":"510703","parent":"510700"},{"name":"游仙区","value":"510704","parent":"510700"},{"name":"三台县","value":"510722","parent":"510700"},{"name":"盐亭县","value":"510723","parent":"510700"},{"name":"安县","value":"510724","parent":"510700"},{"name":"梓潼县","value":"510725","parent":"510700"},{"name":"北川羌族自治县","value":"510726","parent":"510700"},{"name":"平武县","value":"510727","parent":"510700"},{"name":"江油市","value":"510781","parent":"510700"},{"name":"利州区","value":"510802","parent":"510800"},{"name":"昭化区","value":"510811","parent":"510800"},{"name":"朝天区","value":"510812","parent":"510800"},{"name":"旺苍县","value":"510821","parent":"510800"},{"name":"青川县","value":"510822","parent":"510800"},{"name":"剑阁县","value":"510823","parent":"510800"},{"name":"苍溪县","value":"510824","parent":"510800"},{"name":"船山区","value":"510903","parent":"510900"},{"name":"安居区","value":"510904","parent":"510900"},{"name":"蓬溪县","value":"510921","parent":"510900"},{"name":"射洪县","value":"510922","parent":"510900"},{"name":"大英县","value":"510923","parent":"510900"},{"name":"市中区","value":"511002","parent":"511000"},{"name":"东兴区","value":"511011","parent":"511000"},{"name":"威远县","value":"511024","parent":"511000"},{"name":"资中县","value":"511025","parent":"511000"},{"name":"隆昌县","value":"511028","parent":"511000"},{"name":"市中区","value":"511102","parent":"511100"},{"name":"沙湾区","value":"511111","parent":"511100"},{"name":"五通桥区","value":"511112","parent":"511100"},{"name":"金口河区","value":"511113","parent":"511100"},{"name":"犍为县","value":"511123","parent":"511100"},{"name":"井研县","value":"511124","parent":"511100"},{"name":"夹江县","value":"511126","parent":"511100"},{"name":"沐川县","value":"511129","parent":"511100"},{"name":"峨边彝族自治县","value":"511132","parent":"511100"},{"name":"马边彝族自治县","value":"511133","parent":"511100"},{"name":"峨眉山市","value":"511181","parent":"511100"},{"name":"顺庆区","value":"511302","parent":"511300"},{"name":"高坪区","value":"511303","parent":"511300"},{"name":"嘉陵区","value":"511304","parent":"511300"},{"name":"南部县","value":"511321","parent":"511300"},{"name":"营山县","value":"511322","parent":"511300"},{"name":"蓬安县","value":"511323","parent":"511300"},{"name":"仪陇县","value":"511324","parent":"511300"},{"name":"西充县","value":"511325","parent":"511300"},{"name":"阆中市","value":"511381","parent":"511300"},{"name":"东坡区","value":"511402","parent":"511400"},{"name":"彭山区","value":"511403","parent":"511400"},{"name":"仁寿县","value":"511421","parent":"511400"},{"name":"洪雅县","value":"511423","parent":"511400"},{"name":"丹棱县","value":"511424","parent":"511400"},{"name":"青神县","value":"511425","parent":"511400"},{"name":"翠屏区","value":"511502","parent":"511500"},{"name":"南溪区","value":"511503","parent":"511500"},{"name":"宜宾县","value":"511521","parent":"511500"},{"name":"江安县","value":"511523","parent":"511500"},{"name":"长宁县","value":"511524","parent":"511500"},{"name":"高县","value":"511525","parent":"511500"},{"name":"珙县","value":"511526","parent":"511500"},{"name":"筠连县","value":"511527","parent":"511500"},{"name":"兴文县","value":"511528","parent":"511500"},{"name":"屏山县","value":"511529","parent":"511500"},{"name":"广安区","value":"511602","parent":"511600"},{"name":"前锋区","value":"511603","parent":"511600"},{"name":"岳池县","value":"511621","parent":"511600"},{"name":"武胜县","value":"511622","parent":"511600"},{"name":"邻水县","value":"511623","parent":"511600"},{"name":"华蓥市","value":"511681","parent":"511600"},{"name":"通川区","value":"511702","parent":"511700"},{"name":"达川区","value":"511703","parent":"511700"},{"name":"宣汉县","value":"511722","parent":"511700"},{"name":"开江县","value":"511723","parent":"511700"},{"name":"大竹县","value":"511724","parent":"511700"},{"name":"渠县","value":"511725","parent":"511700"},{"name":"万源市","value":"511781","parent":"511700"},{"name":"雨城区","value":"511802","parent":"511800"},{"name":"名山区","value":"511803","parent":"511800"},{"name":"荥经县","value":"511822","parent":"511800"},{"name":"汉源县","value":"511823","parent":"511800"},{"name":"石棉县","value":"511824","parent":"511800"},{"name":"天全县","value":"511825","parent":"511800"},{"name":"芦山县","value":"511826","parent":"511800"},{"name":"宝兴县","value":"511827","parent":"511800"},{"name":"巴州区","value":"511902","parent":"511900"},{"name":"恩阳区","value":"511903","parent":"511900"},{"name":"通江县","value":"511921","parent":"511900"},{"name":"南江县","value":"511922","parent":"511900"},{"name":"平昌县","value":"511923","parent":"511900"},{"name":"雁江区","value":"512002","parent":"512000"},{"name":"安岳县","value":"512021","parent":"512000"},{"name":"乐至县","value":"512022","parent":"512000"},{"name":"简阳市","value":"512081","parent":"512000"},{"name":"汶川县","value":"513221","parent":"513200"},{"name":"理县","value":"513222","parent":"513200"},{"name":"茂县","value":"513223","parent":"513200"},{"name":"松潘县","value":"513224","parent":"513200"},{"name":"九寨沟县","value":"513225","parent":"513200"},{"name":"金川县","value":"513226","parent":"513200"},{"name":"小金县","value":"513227","parent":"513200"},{"name":"黑水县","value":"513228","parent":"513200"},{"name":"马尔康县","value":"513229","parent":"513200"},{"name":"壤塘县","value":"513230","parent":"513200"},{"name":"阿坝县","value":"513231","parent":"513200"},{"name":"若尔盖县","value":"513232","parent":"513200"},{"name":"红原县","value":"513233","parent":"513200"},{"name":"康定市","value":"513301","parent":"513300"},{"name":"泸定县","value":"513322","parent":"513300"},{"name":"丹巴县","value":"513323","parent":"513300"},{"name":"九龙县","value":"513324","parent":"513300"},{"name":"雅江县","value":"513325","parent":"513300"},{"name":"道孚县","value":"513326","parent":"513300"},{"name":"炉霍县","value":"513327","parent":"513300"},{"name":"甘孜县","value":"513328","parent":"513300"},{"name":"新龙县","value":"513329","parent":"513300"},{"name":"德格县","value":"513330","parent":"513300"},{"name":"白玉县","value":"513331","parent":"513300"},{"name":"石渠县","value":"513332","parent":"513300"},{"name":"色达县","value":"513333","parent":"513300"},{"name":"理塘县","value":"513334","parent":"513300"},{"name":"巴塘县","value":"513335","parent":"513300"},{"name":"乡城县","value":"513336","parent":"513300"},{"name":"稻城县","value":"513337","parent":"513300"},{"name":"得荣县","value":"513338","parent":"513300"},{"name":"西昌市","value":"513401","parent":"513400"},{"name":"木里藏族自治县","value":"513422","parent":"513400"},{"name":"盐源县","value":"513423","parent":"513400"},{"name":"德昌县","value":"513424","parent":"513400"},{"name":"会理县","value":"513425","parent":"513400"},{"name":"会东县","value":"513426","parent":"513400"},{"name":"宁南县","value":"513427","parent":"513400"},{"name":"普格县","value":"513428","parent":"513400"},{"name":"布拖县","value":"513429","parent":"513400"},{"name":"金阳县","value":"513430","parent":"513400"},{"name":"昭觉县","value":"513431","parent":"513400"},{"name":"喜德县","value":"513432","parent":"513400"},{"name":"冕宁县","value":"513433","parent":"513400"},{"name":"越西县","value":"513434","parent":"513400"},{"name":"甘洛县","value":"513435","parent":"513400"},{"name":"美姑县","value":"513436","parent":"513400"},{"name":"雷波县","value":"513437","parent":"513400"},{"name":"贵阳市","value":"520100","parent":"520000"},{"name":"六盘水市","value":"520200","parent":"520000"},{"name":"遵义市","value":"520300","parent":"520000"},{"name":"安顺市","value":"520400","parent":"520000"},{"name":"毕节市","value":"520500","parent":"520000"},{"name":"铜仁市","value":"520600","parent":"520000"},{"name":"黔西南布依族苗族自治州","value":"522300","parent":"520000"},{"name":"黔东南苗族侗族自治州","value":"522600","parent":"520000"},{"name":"黔南布依族苗族自治州","value":"522700","parent":"520000"},{"name":"南明区","value":"520102","parent":"520100"},{"name":"云岩区","value":"520103","parent":"520100"},{"name":"花溪区","value":"520111","parent":"520100"},{"name":"乌当区","value":"520112","parent":"520100"},{"name":"白云区","value":"520113","parent":"520100"},{"name":"观山湖区","value":"520115","parent":"520100"},{"name":"开阳县","value":"520121","parent":"520100"},{"name":"息烽县","value":"520122","parent":"520100"},{"name":"修文县","value":"520123","parent":"520100"},{"name":"清镇市","value":"520181","parent":"520100"},{"name":"钟山区","value":"520201","parent":"520200"},{"name":"六枝特区","value":"520203","parent":"520200"},{"name":"水城县","value":"520221","parent":"520200"},{"name":"盘县","value":"520222","parent":"520200"},{"name":"红花岗区","value":"520302","parent":"520300"},{"name":"汇川区","value":"520303","parent":"520300"},{"name":"遵义县","value":"520321","parent":"520300"},{"name":"桐梓县","value":"520322","parent":"520300"},{"name":"绥阳县","value":"520323","parent":"520300"},{"name":"正安县","value":"520324","parent":"520300"},{"name":"道真仡佬族苗族自治县","value":"520325","parent":"520300"},{"name":"务川仡佬族苗族自治县","value":"520326","parent":"520300"},{"name":"凤冈县","value":"520327","parent":"520300"},{"name":"湄潭县","value":"520328","parent":"520300"},{"name":"余庆县","value":"520329","parent":"520300"},{"name":"习水县","value":"520330","parent":"520300"},{"name":"赤水市","value":"520381","parent":"520300"},{"name":"仁怀市","value":"520382","parent":"520300"},{"name":"西秀区","value":"520402","parent":"520400"},{"name":"平坝区","value":"520403","parent":"520400"},{"name":"普定县","value":"520422","parent":"520400"},{"name":"镇宁布依族苗族自治县","value":"520423","parent":"520400"},{"name":"关岭布依族苗族自治县","value":"520424","parent":"520400"},{"name":"紫云苗族布依族自治县","value":"520425","parent":"520400"},{"name":"七星关区","value":"520502","parent":"520500"},{"name":"大方县","value":"520521","parent":"520500"},{"name":"黔西县","value":"520522","parent":"520500"},{"name":"金沙县","value":"520523","parent":"520500"},{"name":"织金县","value":"520524","parent":"520500"},{"name":"纳雍县","value":"520525","parent":"520500"},{"name":"威宁彝族回族苗族自治县","value":"520526","parent":"520500"},{"name":"赫章县","value":"520527","parent":"520500"},{"name":"碧江区","value":"520602","parent":"520600"},{"name":"万山区","value":"520603","parent":"520600"},{"name":"江口县","value":"520621","parent":"520600"},{"name":"玉屏侗族自治县","value":"520622","parent":"520600"},{"name":"石阡县","value":"520623","parent":"520600"},{"name":"思南县","value":"520624","parent":"520600"},{"name":"印江土家族苗族自治县","value":"520625","parent":"520600"},{"name":"德江县","value":"520626","parent":"520600"},{"name":"沿河土家族自治县","value":"520627","parent":"520600"},{"name":"松桃苗族自治县","value":"520628","parent":"520600"},{"name":"兴义市","value":"522301","parent":"522300"},{"name":"兴仁县","value":"522322","parent":"522300"},{"name":"普安县","value":"522323","parent":"522300"},{"name":"晴隆县","value":"522324","parent":"522300"},{"name":"贞丰县","value":"522325","parent":"522300"},{"name":"望谟县","value":"522326","parent":"522300"},{"name":"册亨县","value":"522327","parent":"522300"},{"name":"安龙县","value":"522328","parent":"522300"},{"name":"凯里市","value":"522601","parent":"522600"},{"name":"黄平县","value":"522622","parent":"522600"},{"name":"施秉县","value":"522623","parent":"522600"},{"name":"三穗县","value":"522624","parent":"522600"},{"name":"镇远县","value":"522625","parent":"522600"},{"name":"岑巩县","value":"522626","parent":"522600"},{"name":"天柱县","value":"522627","parent":"522600"},{"name":"锦屏县","value":"522628","parent":"522600"},{"name":"剑河县","value":"522629","parent":"522600"},{"name":"台江县","value":"522630","parent":"522600"},{"name":"黎平县","value":"522631","parent":"522600"},{"name":"榕江县","value":"522632","parent":"522600"},{"name":"从江县","value":"522633","parent":"522600"},{"name":"雷山县","value":"522634","parent":"522600"},{"name":"麻江县","value":"522635","parent":"522600"},{"name":"丹寨县","value":"522636","parent":"522600"},{"name":"都匀市","value":"522701","parent":"522700"},{"name":"福泉市","value":"522702","parent":"522700"},{"name":"荔波县","value":"522722","parent":"522700"},{"name":"贵定县","value":"522723","parent":"522700"},{"name":"瓮安县","value":"522725","parent":"522700"},{"name":"独山县","value":"522726","parent":"522700"},{"name":"平塘县","value":"522727","parent":"522700"},{"name":"罗甸县","value":"522728","parent":"522700"},{"name":"长顺县","value":"522729","parent":"522700"},{"name":"龙里县","value":"522730","parent":"522700"},{"name":"惠水县","value":"522731","parent":"522700"},{"name":"三都水族自治县","value":"522732","parent":"522700"},{"name":"昆明市","value":"530100","parent":"530000"},{"name":"曲靖市","value":"530300","parent":"530000"},{"name":"玉溪市","value":"530400","parent":"530000"},{"name":"保山市","value":"530500","parent":"530000"},{"name":"昭通市","value":"530600","parent":"530000"},{"name":"丽江市","value":"530700","parent":"530000"},{"name":"普洱市","value":"530800","parent":"530000"},{"name":"临沧市","value":"530900","parent":"530000"},{"name":"楚雄彝族自治州","value":"532300","parent":"530000"},{"name":"红河哈尼族彝族自治州","value":"532500","parent":"530000"},{"name":"文山壮族苗族自治州","value":"532600","parent":"530000"},{"name":"西双版纳傣族自治州","value":"532800","parent":"530000"},{"name":"大理白族自治州","value":"532900","parent":"530000"},{"name":"德宏傣族景颇族自治州","value":"533100","parent":"530000"},{"name":"怒江傈僳族自治州","value":"533300","parent":"530000"},{"name":"迪庆藏族自治州","value":"533400","parent":"530000"},{"name":"五华区","value":"530102","parent":"530100"},{"name":"盘龙区","value":"530103","parent":"530100"},{"name":"官渡区","value":"530111","parent":"530100"},{"name":"西山区","value":"530112","parent":"530100"},{"name":"东川区","value":"530113","parent":"530100"},{"name":"呈贡区","value":"530114","parent":"530100"},{"name":"晋宁县","value":"530122","parent":"530100"},{"name":"富民县","value":"530124","parent":"530100"},{"name":"宜良县","value":"530125","parent":"530100"},{"name":"石林彝族自治县","value":"530126","parent":"530100"},{"name":"嵩明县","value":"530127","parent":"530100"},{"name":"禄劝彝族苗族自治县","value":"530128","parent":"530100"},{"name":"寻甸回族彝族自治县","value":"530129","parent":"530100"},{"name":"安宁市","value":"530181","parent":"530100"},{"name":"麒麟区","value":"530302","parent":"530300"},{"name":"马龙县","value":"530321","parent":"530300"},{"name":"陆良县","value":"530322","parent":"530300"},{"name":"师宗县","value":"530323","parent":"530300"},{"name":"罗平县","value":"530324","parent":"530300"},{"name":"富源县","value":"530325","parent":"530300"},{"name":"会泽县","value":"530326","parent":"530300"},{"name":"沾益县","value":"530328","parent":"530300"},{"name":"宣威市","value":"530381","parent":"530300"},{"name":"红塔区","value":"530402","parent":"530400"},{"name":"江川县","value":"530421","parent":"530400"},{"name":"澄江县","value":"530422","parent":"530400"},{"name":"通海县","value":"530423","parent":"530400"},{"name":"华宁县","value":"530424","parent":"530400"},{"name":"易门县","value":"530425","parent":"530400"},{"name":"峨山彝族自治县","value":"530426","parent":"530400"},{"name":"新平彝族傣族自治县","value":"530427","parent":"530400"},{"name":"元江哈尼族彝族傣族自治县","value":"530428","parent":"530400"},{"name":"隆阳区","value":"530502","parent":"530500"},{"name":"施甸县","value":"530521","parent":"530500"},{"name":"龙陵县","value":"530523","parent":"530500"},{"name":"昌宁县","value":"530524","parent":"530500"},{"name":"腾冲市","value":"530581","parent":"530500"},{"name":"昭阳区","value":"530602","parent":"530600"},{"name":"鲁甸县","value":"530621","parent":"530600"},{"name":"巧家县","value":"530622","parent":"530600"},{"name":"盐津县","value":"530623","parent":"530600"},{"name":"大关县","value":"530624","parent":"530600"},{"name":"永善县","value":"530625","parent":"530600"},{"name":"绥江县","value":"530626","parent":"530600"},{"name":"镇雄县","value":"530627","parent":"530600"},{"name":"彝良县","value":"530628","parent":"530600"},{"name":"威信县","value":"530629","parent":"530600"},{"name":"水富县","value":"530630","parent":"530600"},{"name":"古城区","value":"530702","parent":"530700"},{"name":"玉龙纳西族自治县","value":"530721","parent":"530700"},{"name":"永胜县","value":"530722","parent":"530700"},{"name":"华坪县","value":"530723","parent":"530700"},{"name":"宁蒗彝族自治县","value":"530724","parent":"530700"},{"name":"思茅区","value":"530802","parent":"530800"},{"name":"宁洱哈尼族彝族自治县","value":"530821","parent":"530800"},{"name":"墨江哈尼族自治县","value":"530822","parent":"530800"},{"name":"景东彝族自治县","value":"530823","parent":"530800"},{"name":"景谷傣族彝族自治县","value":"530824","parent":"530800"},{"name":"镇沅彝族哈尼族拉祜族自治县","value":"530825","parent":"530800"},{"name":"江城哈尼族彝族自治县","value":"530826","parent":"530800"},{"name":"孟连傣族拉祜族佤族自治县","value":"530827","parent":"530800"},{"name":"澜沧拉祜族自治县","value":"530828","parent":"530800"},{"name":"西盟佤族自治县","value":"530829","parent":"530800"},{"name":"临翔区","value":"530902","parent":"530900"},{"name":"凤庆县","value":"530921","parent":"530900"},{"name":"云县","value":"530922","parent":"530900"},{"name":"永德县","value":"530923","parent":"530900"},{"name":"镇康县","value":"530924","parent":"530900"},{"name":"双江拉祜族佤族布朗族傣族自治县","value":"530925","parent":"530900"},{"name":"耿马傣族佤族自治县","value":"530926","parent":"530900"},{"name":"沧源佤族自治县","value":"530927","parent":"530900"},{"name":"楚雄市","value":"532301","parent":"532300"},{"name":"双柏县","value":"532322","parent":"532300"},{"name":"牟定县","value":"532323","parent":"532300"},{"name":"南华县","value":"532324","parent":"532300"},{"name":"姚安县","value":"532325","parent":"532300"},{"name":"大姚县","value":"532326","parent":"532300"},{"name":"永仁县","value":"532327","parent":"532300"},{"name":"元谋县","value":"532328","parent":"532300"},{"name":"武定县","value":"532329","parent":"532300"},{"name":"禄丰县","value":"532331","parent":"532300"},{"name":"个旧市","value":"532501","parent":"532500"},{"name":"开远市","value":"532502","parent":"532500"},{"name":"蒙自市","value":"532503","parent":"532500"},{"name":"弥勒市","value":"532504","parent":"532500"},{"name":"屏边苗族自治县","value":"532523","parent":"532500"},{"name":"建水县","value":"532524","parent":"532500"},{"name":"石屏县","value":"532525","parent":"532500"},{"name":"泸西县","value":"532527","parent":"532500"},{"name":"元阳县","value":"532528","parent":"532500"},{"name":"红河县","value":"532529","parent":"532500"},{"name":"金平苗族瑶族傣族自治县","value":"532530","parent":"532500"},{"name":"绿春县","value":"532531","parent":"532500"},{"name":"河口瑶族自治县","value":"532532","parent":"532500"},{"name":"文山市","value":"532601","parent":"532600"},{"name":"砚山县","value":"532622","parent":"532600"},{"name":"西畴县","value":"532623","parent":"532600"},{"name":"麻栗坡县","value":"532624","parent":"532600"},{"name":"马关县","value":"532625","parent":"532600"},{"name":"丘北县","value":"532626","parent":"532600"},{"name":"广南县","value":"532627","parent":"532600"},{"name":"富宁县","value":"532628","parent":"532600"},{"name":"景洪市","value":"532801","parent":"532800"},{"name":"勐海县","value":"532822","parent":"532800"},{"name":"勐腊县","value":"532823","parent":"532800"},{"name":"大理市","value":"532901","parent":"532900"},{"name":"漾濞彝族自治县","value":"532922","parent":"532900"},{"name":"祥云县","value":"532923","parent":"532900"},{"name":"宾川县","value":"532924","parent":"532900"},{"name":"弥渡县","value":"532925","parent":"532900"},{"name":"南涧彝族自治县","value":"532926","parent":"532900"},{"name":"巍山彝族回族自治县","value":"532927","parent":"532900"},{"name":"永平县","value":"532928","parent":"532900"},{"name":"云龙县","value":"532929","parent":"532900"},{"name":"洱源县","value":"532930","parent":"532900"},{"name":"剑川县","value":"532931","parent":"532900"},{"name":"鹤庆县","value":"532932","parent":"532900"},{"name":"瑞丽市","value":"533102","parent":"533100"},{"name":"芒市","value":"533103","parent":"533100"},{"name":"梁河县","value":"533122","parent":"533100"},{"name":"盈江县","value":"533123","parent":"533100"},{"name":"陇川县","value":"533124","parent":"533100"},{"name":"泸水县","value":"533321","parent":"533300"},{"name":"福贡县","value":"533323","parent":"533300"},{"name":"贡山独龙族怒族自治县","value":"533324","parent":"533300"},{"name":"兰坪白族普米族自治县","value":"533325","parent":"533300"},{"name":"香格里拉市","value":"533401","parent":"533400"},{"name":"德钦县","value":"533422","parent":"533400"},{"name":"维西傈僳族自治县","value":"533423","parent":"533400"},{"name":"拉萨市","value":"540100","parent":"540000"},{"name":"日喀则市","value":"540200","parent":"540000"},{"name":"昌都市","value":"540300","parent":"540000"},{"name":"林芝市","value":"540400","parent":"540000"},{"name":"山南地区","value":"542200","parent":"540000"},{"name":"那曲地区","value":"542400","parent":"540000"},{"name":"阿里地区","value":"542500","parent":"540000"},{"name":"城关区","value":"540102","parent":"540100"},{"name":"林周县","value":"540121","parent":"540100"},{"name":"当雄县","value":"540122","parent":"540100"},{"name":"尼木县","value":"540123","parent":"540100"},{"name":"曲水县","value":"540124","parent":"540100"},{"name":"堆龙德庆县","value":"540125","parent":"540100"},{"name":"达孜县","value":"540126","parent":"540100"},{"name":"墨竹工卡县","value":"540127","parent":"540100"},{"name":"桑珠孜区","value":"540202","parent":"540200"},{"name":"南木林县","value":"540221","parent":"540200"},{"name":"江孜县","value":"540222","parent":"540200"},{"name":"定日县","value":"540223","parent":"540200"},{"name":"萨迦县","value":"540224","parent":"540200"},{"name":"拉孜县","value":"540225","parent":"540200"},{"name":"昂仁县","value":"540226","parent":"540200"},{"name":"谢通门县","value":"540227","parent":"540200"},{"name":"白朗县","value":"540228","parent":"540200"},{"name":"仁布县","value":"540229","parent":"540200"},{"name":"康马县","value":"540230","parent":"540200"},{"name":"定结县","value":"540231","parent":"540200"},{"name":"仲巴县","value":"540232","parent":"540200"},{"name":"亚东县","value":"540233","parent":"540200"},{"name":"吉隆县","value":"540234","parent":"540200"},{"name":"聂拉木县","value":"540235","parent":"540200"},{"name":"萨嘎县","value":"540236","parent":"540200"},{"name":"岗巴县","value":"540237","parent":"540200"},{"name":"卡若区","value":"540302","parent":"540300"},{"name":"江达县","value":"540321","parent":"540300"},{"name":"贡觉县","value":"540322","parent":"540300"},{"name":"类乌齐县","value":"540323","parent":"540300"},{"name":"丁青县","value":"540324","parent":"540300"},{"name":"察雅县","value":"540325","parent":"540300"},{"name":"八宿县","value":"540326","parent":"540300"},{"name":"左贡县","value":"540327","parent":"540300"},{"name":"芒康县","value":"540328","parent":"540300"},{"name":"洛隆县","value":"540329","parent":"540300"},{"name":"边坝县","value":"540330","parent":"540300"},{"name":"巴宜区","value":"540402","parent":"540400"},{"name":"工布江达县","value":"540421","parent":"540400"},{"name":"米林县","value":"540422","parent":"540400"},{"name":"墨脱县","value":"540423","parent":"540400"},{"name":"波密县","value":"540424","parent":"540400"},{"name":"察隅县","value":"540425","parent":"540400"},{"name":"朗县","value":"540426","parent":"540400"},{"name":"乃东县","value":"542221","parent":"542200"},{"name":"扎囊县","value":"542222","parent":"542200"},{"name":"贡嘎县","value":"542223","parent":"542200"},{"name":"桑日县","value":"542224","parent":"542200"},{"name":"琼结县","value":"542225","parent":"542200"},{"name":"曲松县","value":"542226","parent":"542200"},{"name":"措美县","value":"542227","parent":"542200"},{"name":"洛扎县","value":"542228","parent":"542200"},{"name":"加查县","value":"542229","parent":"542200"},{"name":"隆子县","value":"542231","parent":"542200"},{"name":"错那县","value":"542232","parent":"542200"},{"name":"浪卡子县","value":"542233","parent":"542200"},{"name":"那曲县","value":"542421","parent":"542400"},{"name":"嘉黎县","value":"542422","parent":"542400"},{"name":"比如县","value":"542423","parent":"542400"},{"name":"聂荣县","value":"542424","parent":"542400"},{"name":"安多县","value":"542425","parent":"542400"},{"name":"申扎县","value":"542426","parent":"542400"},{"name":"索县","value":"542427","parent":"542400"},{"name":"班戈县","value":"542428","parent":"542400"},{"name":"巴青县","value":"542429","parent":"542400"},{"name":"尼玛县","value":"542430","parent":"542400"},{"name":"双湖县","value":"542431","parent":"542400"},{"name":"普兰县","value":"542521","parent":"542500"},{"name":"札达县","value":"542522","parent":"542500"},{"name":"噶尔县","value":"542523","parent":"542500"},{"name":"日土县","value":"542524","parent":"542500"},{"name":"革吉县","value":"542525","parent":"542500"},{"name":"改则县","value":"542526","parent":"542500"},{"name":"措勤县","value":"542527","parent":"542500"},{"name":"西安市","value":"610100","parent":"610000"},{"name":"铜川市","value":"610200","parent":"610000"},{"name":"宝鸡市","value":"610300","parent":"610000"},{"name":"咸阳市","value":"610400","parent":"610000"},{"name":"渭南市","value":"610500","parent":"610000"},{"name":"延安市","value":"610600","parent":"610000"},{"name":"汉中市","value":"610700","parent":"610000"},{"name":"榆林市","value":"610800","parent":"610000"},{"name":"安康市","value":"610900","parent":"610000"},{"name":"商洛市","value":"611000","parent":"610000"},{"name":"新城区","value":"610102","parent":"610100"},{"name":"碑林区","value":"610103","parent":"610100"},{"name":"莲湖区","value":"610104","parent":"610100"},{"name":"灞桥区","value":"610111","parent":"610100"},{"name":"未央区","value":"610112","parent":"610100"},{"name":"雁塔区","value":"610113","parent":"610100"},{"name":"阎良区","value":"610114","parent":"610100"},{"name":"临潼区","value":"610115","parent":"610100"},{"name":"长安区","value":"610116","parent":"610100"},{"name":"高陵区","value":"610117","parent":"610100"},{"name":"蓝田县","value":"610122","parent":"610100"},{"name":"周至县","value":"610124","parent":"610100"},{"name":"户县","value":"610125","parent":"610100"},{"name":"王益区","value":"610202","parent":"610200"},{"name":"印台区","value":"610203","parent":"610200"},{"name":"耀州区","value":"610204","parent":"610200"},{"name":"宜君县","value":"610222","parent":"610200"},{"name":"渭滨区","value":"610302","parent":"610300"},{"name":"金台区","value":"610303","parent":"610300"},{"name":"陈仓区","value":"610304","parent":"610300"},{"name":"凤翔县","value":"610322","parent":"610300"},{"name":"岐山县","value":"610323","parent":"610300"},{"name":"扶风县","value":"610324","parent":"610300"},{"name":"眉县","value":"610326","parent":"610300"},{"name":"陇县","value":"610327","parent":"610300"},{"name":"千阳县","value":"610328","parent":"610300"},{"name":"麟游县","value":"610329","parent":"610300"},{"name":"凤县","value":"610330","parent":"610300"},{"name":"太白县","value":"610331","parent":"610300"},{"name":"秦都区","value":"610402","parent":"610400"},{"name":"杨陵区","value":"610403","parent":"610400"},{"name":"渭城区","value":"610404","parent":"610400"},{"name":"三原县","value":"610422","parent":"610400"},{"name":"泾阳县","value":"610423","parent":"610400"},{"name":"乾县","value":"610424","parent":"610400"},{"name":"礼泉县","value":"610425","parent":"610400"},{"name":"永寿县","value":"610426","parent":"610400"},{"name":"彬县","value":"610427","parent":"610400"},{"name":"长武县","value":"610428","parent":"610400"},{"name":"旬邑县","value":"610429","parent":"610400"},{"name":"淳化县","value":"610430","parent":"610400"},{"name":"武功县","value":"610431","parent":"610400"},{"name":"兴平市","value":"610481","parent":"610400"},{"name":"临渭区","value":"610502","parent":"610500"},{"name":"华县","value":"610521","parent":"610500"},{"name":"潼关县","value":"610522","parent":"610500"},{"name":"大荔县","value":"610523","parent":"610500"},{"name":"合阳县","value":"610524","parent":"610500"},{"name":"澄城县","value":"610525","parent":"610500"},{"name":"蒲城县","value":"610526","parent":"610500"},{"name":"白水县","value":"610527","parent":"610500"},{"name":"富平县","value":"610528","parent":"610500"},{"name":"韩城市","value":"610581","parent":"610500"},{"name":"华阴市","value":"610582","parent":"610500"},{"name":"宝塔区","value":"610602","parent":"610600"},{"name":"延长县","value":"610621","parent":"610600"},{"name":"延川县","value":"610622","parent":"610600"},{"name":"子长县","value":"610623","parent":"610600"},{"name":"安塞县","value":"610624","parent":"610600"},{"name":"志丹县","value":"610625","parent":"610600"},{"name":"吴起县","value":"610626","parent":"610600"},{"name":"甘泉县","value":"610627","parent":"610600"},{"name":"富县","value":"610628","parent":"610600"},{"name":"洛川县","value":"610629","parent":"610600"},{"name":"宜川县","value":"610630","parent":"610600"},{"name":"黄龙县","value":"610631","parent":"610600"},{"name":"黄陵县","value":"610632","parent":"610600"},{"name":"汉台区","value":"610702","parent":"610700"},{"name":"南郑县","value":"610721","parent":"610700"},{"name":"城固县","value":"610722","parent":"610700"},{"name":"洋县","value":"610723","parent":"610700"},{"name":"西乡县","value":"610724","parent":"610700"},{"name":"勉县","value":"610725","parent":"610700"},{"name":"宁强县","value":"610726","parent":"610700"},{"name":"略阳县","value":"610727","parent":"610700"},{"name":"镇巴县","value":"610728","parent":"610700"},{"name":"留坝县","value":"610729","parent":"610700"},{"name":"佛坪县","value":"610730","parent":"610700"},{"name":"榆阳区","value":"610802","parent":"610800"},{"name":"神木县","value":"610821","parent":"610800"},{"name":"府谷县","value":"610822","parent":"610800"},{"name":"横山县","value":"610823","parent":"610800"},{"name":"靖边县","value":"610824","parent":"610800"},{"name":"定边县","value":"610825","parent":"610800"},{"name":"绥德县","value":"610826","parent":"610800"},{"name":"米脂县","value":"610827","parent":"610800"},{"name":"佳县","value":"610828","parent":"610800"},{"name":"吴堡县","value":"610829","parent":"610800"},{"name":"清涧县","value":"610830","parent":"610800"},{"name":"子洲县","value":"610831","parent":"610800"},{"name":"汉滨区","value":"610902","parent":"610900"},{"name":"汉阴县","value":"610921","parent":"610900"},{"name":"石泉县","value":"610922","parent":"610900"},{"name":"宁陕县","value":"610923","parent":"610900"},{"name":"紫阳县","value":"610924","parent":"610900"},{"name":"岚皋县","value":"610925","parent":"610900"},{"name":"平利县","value":"610926","parent":"610900"},{"name":"镇坪县","value":"610927","parent":"610900"},{"name":"旬阳县","value":"610928","parent":"610900"},{"name":"白河县","value":"610929","parent":"610900"},{"name":"商州区","value":"611002","parent":"611000"},{"name":"洛南县","value":"611021","parent":"611000"},{"name":"丹凤县","value":"611022","parent":"611000"},{"name":"商南县","value":"611023","parent":"611000"},{"name":"山阳县","value":"611024","parent":"611000"},{"name":"镇安县","value":"611025","parent":"611000"},{"name":"柞水县","value":"611026","parent":"611000"},{"name":"兰州市","value":"620100","parent":"620000"},{"name":"嘉峪关市","value":"620200","parent":"620000"},{"name":"金昌市","value":"620300","parent":"620000"},{"name":"白银市","value":"620400","parent":"620000"},{"name":"天水市","value":"620500","parent":"620000"},{"name":"武威市","value":"620600","parent":"620000"},{"name":"张掖市","value":"620700","parent":"620000"},{"name":"平凉市","value":"620800","parent":"620000"},{"name":"酒泉市","value":"620900","parent":"620000"},{"name":"庆阳市","value":"621000","parent":"620000"},{"name":"定西市","value":"621100","parent":"620000"},{"name":"陇南市","value":"621200","parent":"620000"},{"name":"临夏回族自治州","value":"622900","parent":"620000"},{"name":"甘南藏族自治州","value":"623000","parent":"620000"},{"name":"城关区","value":"620102","parent":"620100"},{"name":"七里河区","value":"620103","parent":"620100"},{"name":"西固区","value":"620104","parent":"620100"},{"name":"安宁区","value":"620105","parent":"620100"},{"name":"红古区","value":"620111","parent":"620100"},{"name":"永登县","value":"620121","parent":"620100"},{"name":"皋兰县","value":"620122","parent":"620100"},{"name":"榆中县","value":"620123","parent":"620100"},{"name":"金川区","value":"620302","parent":"620300"},{"name":"永昌县","value":"620321","parent":"620300"},{"name":"白银区","value":"620402","parent":"620400"},{"name":"平川区","value":"620403","parent":"620400"},{"name":"靖远县","value":"620421","parent":"620400"},{"name":"会宁县","value":"620422","parent":"620400"},{"name":"景泰县","value":"620423","parent":"620400"},{"name":"秦州区","value":"620502","parent":"620500"},{"name":"麦积区","value":"620503","parent":"620500"},{"name":"清水县","value":"620521","parent":"620500"},{"name":"秦安县","value":"620522","parent":"620500"},{"name":"甘谷县","value":"620523","parent":"620500"},{"name":"武山县","value":"620524","parent":"620500"},{"name":"张家川回族自治县","value":"620525","parent":"620500"},{"name":"凉州区","value":"620602","parent":"620600"},{"name":"民勤县","value":"620621","parent":"620600"},{"name":"古浪县","value":"620622","parent":"620600"},{"name":"天祝藏族自治县","value":"620623","parent":"620600"},{"name":"甘州区","value":"620702","parent":"620700"},{"name":"肃南裕固族自治县","value":"620721","parent":"620700"},{"name":"民乐县","value":"620722","parent":"620700"},{"name":"临泽县","value":"620723","parent":"620700"},{"name":"高台县","value":"620724","parent":"620700"},{"name":"山丹县","value":"620725","parent":"620700"},{"name":"崆峒区","value":"620802","parent":"620800"},{"name":"泾川县","value":"620821","parent":"620800"},{"name":"灵台县","value":"620822","parent":"620800"},{"name":"崇信县","value":"620823","parent":"620800"},{"name":"华亭县","value":"620824","parent":"620800"},{"name":"庄浪县","value":"620825","parent":"620800"},{"name":"静宁县","value":"620826","parent":"620800"},{"name":"肃州区","value":"620902","parent":"620900"},{"name":"金塔县","value":"620921","parent":"620900"},{"name":"瓜州县","value":"620922","parent":"620900"},{"name":"肃北蒙古族自治县","value":"620923","parent":"620900"},{"name":"阿克塞哈萨克族自治县","value":"620924","parent":"620900"},{"name":"玉门市","value":"620981","parent":"620900"},{"name":"敦煌市","value":"620982","parent":"620900"},{"name":"西峰区","value":"621002","parent":"621000"},{"name":"庆城县","value":"621021","parent":"621000"},{"name":"环县","value":"621022","parent":"621000"},{"name":"华池县","value":"621023","parent":"621000"},{"name":"合水县","value":"621024","parent":"621000"},{"name":"正宁县","value":"621025","parent":"621000"},{"name":"宁县","value":"621026","parent":"621000"},{"name":"镇原县","value":"621027","parent":"621000"},{"name":"安定区","value":"621102","parent":"621100"},{"name":"通渭县","value":"621121","parent":"621100"},{"name":"陇西县","value":"621122","parent":"621100"},{"name":"渭源县","value":"621123","parent":"621100"},{"name":"临洮县","value":"621124","parent":"621100"},{"name":"漳县","value":"621125","parent":"621100"},{"name":"岷县","value":"621126","parent":"621100"},{"name":"武都区","value":"621202","parent":"621200"},{"name":"成县","value":"621221","parent":"621200"},{"name":"文县","value":"621222","parent":"621200"},{"name":"宕昌县","value":"621223","parent":"621200"},{"name":"康县","value":"621224","parent":"621200"},{"name":"西和县","value":"621225","parent":"621200"},{"name":"礼县","value":"621226","parent":"621200"},{"name":"徽县","value":"621227","parent":"621200"},{"name":"两当县","value":"621228","parent":"621200"},{"name":"临夏市","value":"622901","parent":"622900"},{"name":"临夏县","value":"622921","parent":"622900"},{"name":"康乐县","value":"622922","parent":"622900"},{"name":"永靖县","value":"622923","parent":"622900"},{"name":"广河县","value":"622924","parent":"622900"},{"name":"和政县","value":"622925","parent":"622900"},{"name":"东乡族自治县","value":"622926","parent":"622900"},{"name":"积石山保安族东乡族撒拉族自治县","value":"622927","parent":"622900"},{"name":"合作市","value":"623001","parent":"623000"},{"name":"临潭县","value":"623021","parent":"623000"},{"name":"卓尼县","value":"623022","parent":"623000"},{"name":"舟曲县","value":"623023","parent":"623000"},{"name":"迭部县","value":"623024","parent":"623000"},{"name":"玛曲县","value":"623025","parent":"623000"},{"name":"碌曲县","value":"623026","parent":"623000"},{"name":"夏河县","value":"623027","parent":"623000"},{"name":"西宁市","value":"630100","parent":"630000"},{"name":"海东市","value":"630200","parent":"630000"},{"name":"海北藏族自治州","value":"632200","parent":"630000"},{"name":"黄南藏族自治州","value":"632300","parent":"630000"},{"name":"海南藏族自治州","value":"632500","parent":"630000"},{"name":"果洛藏族自治州","value":"632600","parent":"630000"},{"name":"玉树藏族自治州","value":"632700","parent":"630000"},{"name":"海西蒙古族藏族自治州","value":"632800","parent":"630000"},{"name":"城东区","value":"630102","parent":"630100"},{"name":"城中区","value":"630103","parent":"630100"},{"name":"城西区","value":"630104","parent":"630100"},{"name":"城北区","value":"630105","parent":"630100"},{"name":"大通回族土族自治县","value":"630121","parent":"630100"},{"name":"湟中县","value":"630122","parent":"630100"},{"name":"湟源县","value":"630123","parent":"630100"},{"name":"乐都区","value":"630202","parent":"630200"},{"name":"平安区","value":"630203","parent":"630200"},{"name":"民和回族土族自治县","value":"630222","parent":"630200"},{"name":"互助土族自治县","value":"630223","parent":"630200"},{"name":"化隆回族自治县","value":"630224","parent":"630200"},{"name":"循化撒拉族自治县","value":"630225","parent":"630200"},{"name":"门源回族自治县","value":"632221","parent":"632200"},{"name":"祁连县","value":"632222","parent":"632200"},{"name":"海晏县","value":"632223","parent":"632200"},{"name":"刚察县","value":"632224","parent":"632200"},{"name":"同仁县","value":"632321","parent":"632300"},{"name":"尖扎县","value":"632322","parent":"632300"},{"name":"泽库县","value":"632323","parent":"632300"},{"name":"河南蒙古族自治县","value":"632324","parent":"632300"},{"name":"共和县","value":"632521","parent":"632500"},{"name":"同德县","value":"632522","parent":"632500"},{"name":"贵德县","value":"632523","parent":"632500"},{"name":"兴海县","value":"632524","parent":"632500"},{"name":"贵南县","value":"632525","parent":"632500"},{"name":"玛沁县","value":"632621","parent":"632600"},{"name":"班玛县","value":"632622","parent":"632600"},{"name":"甘德县","value":"632623","parent":"632600"},{"name":"达日县","value":"632624","parent":"632600"},{"name":"久治县","value":"632625","parent":"632600"},{"name":"玛多县","value":"632626","parent":"632600"},{"name":"玉树市","value":"632701","parent":"632700"},{"name":"杂多县","value":"632722","parent":"632700"},{"name":"称多县","value":"632723","parent":"632700"},{"name":"治多县","value":"632724","parent":"632700"},{"name":"囊谦县","value":"632725","parent":"632700"},{"name":"曲麻莱县","value":"632726","parent":"632700"},{"name":"格尔木市","value":"632801","parent":"632800"},{"name":"德令哈市","value":"632802","parent":"632800"},{"name":"乌兰县","value":"632821","parent":"632800"},{"name":"都兰县","value":"632822","parent":"632800"},{"name":"天峻县","value":"632823","parent":"632800"},{"name":"银川市","value":"640100","parent":"640000"},{"name":"石嘴山市","value":"640200","parent":"640000"},{"name":"吴忠市","value":"640300","parent":"640000"},{"name":"固原市","value":"640400","parent":"640000"},{"name":"中卫市","value":"640500","parent":"640000"},{"name":"兴庆区","value":"640104","parent":"640100"},{"name":"西夏区","value":"640105","parent":"640100"},{"name":"金凤区","value":"640106","parent":"640100"},{"name":"永宁县","value":"640121","parent":"640100"},{"name":"贺兰县","value":"640122","parent":"640100"},{"name":"灵武市","value":"640181","parent":"640100"},{"name":"大武口区","value":"640202","parent":"640200"},{"name":"惠农区","value":"640205","parent":"640200"},{"name":"平罗县","value":"640221","parent":"640200"},{"name":"利通区","value":"640302","parent":"640300"},{"name":"红寺堡区","value":"640303","parent":"640300"},{"name":"盐池县","value":"640323","parent":"640300"},{"name":"同心县","value":"640324","parent":"640300"},{"name":"青铜峡市","value":"640381","parent":"640300"},{"name":"原州区","value":"640402","parent":"640400"},{"name":"西吉县","value":"640422","parent":"640400"},{"name":"隆德县","value":"640423","parent":"640400"},{"name":"泾源县","value":"640424","parent":"640400"},{"name":"彭阳县","value":"640425","parent":"640400"},{"name":"沙坡头区","value":"640502","parent":"640500"},{"name":"中宁县","value":"640521","parent":"640500"},{"name":"海原县","value":"640522","parent":"640500"},{"name":"乌鲁木齐市","value":"650100","parent":"650000"},{"name":"克拉玛依市","value":"650200","parent":"650000"},{"name":"吐鲁番市","value":"650400","parent":"650000"},{"name":"哈密地区","value":"652200","parent":"650000"},{"name":"昌吉回族自治州","value":"652300","parent":"650000"},{"name":"博尔塔拉蒙古自治州","value":"652700","parent":"650000"},{"name":"巴音郭楞蒙古自治州","value":"652800","parent":"650000"},{"name":"阿克苏地区","value":"652900","parent":"650000"},{"name":"克孜勒苏柯尔克孜自治州","value":"653000","parent":"650000"},{"name":"喀什地区","value":"653100","parent":"650000"},{"name":"和田地区","value":"653200","parent":"650000"},{"name":"伊犁哈萨克自治州","value":"654000","parent":"650000"},{"name":"塔城地区","value":"654200","parent":"650000"},{"name":"阿勒泰地区","value":"654300","parent":"650000"},{"name":"石河子市","value":"659001","parent":"650000"},{"name":"阿拉尔市","value":"659002","parent":"650000"},{"name":"图木舒克市","value":"659003","parent":"650000"},{"name":"五家渠市","value":"659004","parent":"650000"},{"name":"天山区","value":"650102","parent":"650100"},{"name":"沙依巴克区","value":"650103","parent":"650100"},{"name":"新市区","value":"650104","parent":"650100"},{"name":"水磨沟区","value":"650105","parent":"650100"},{"name":"头屯河区","value":"650106","parent":"650100"},{"name":"达坂城区","value":"650107","parent":"650100"},{"name":"米东区","value":"650109","parent":"650100"},{"name":"乌鲁木齐县","value":"650121","parent":"650100"},{"name":"独山子区","value":"650202","parent":"650200"},{"name":"克拉玛依区","value":"650203","parent":"650200"},{"name":"白碱滩区","value":"650204","parent":"650200"},{"name":"乌尔禾区","value":"650205","parent":"650200"},{"name":"高昌区","value":"650402","parent":"650400"},{"name":"鄯善县","value":"650421","parent":"650400"},{"name":"托克逊县","value":"650422","parent":"650400"},{"name":"哈密市","value":"652201","parent":"652200"},{"name":"巴里坤哈萨克自治县","value":"652222","parent":"652200"},{"name":"伊吾县","value":"652223","parent":"652200"},{"name":"昌吉市","value":"652301","parent":"652300"},{"name":"阜康市","value":"652302","parent":"652300"},{"name":"呼图壁县","value":"652323","parent":"652300"},{"name":"玛纳斯县","value":"652324","parent":"652300"},{"name":"奇台县","value":"652325","parent":"652300"},{"name":"吉木萨尔县","value":"652327","parent":"652300"},{"name":"木垒哈萨克自治县","value":"652328","parent":"652300"},{"name":"博乐市","value":"652701","parent":"652700"},{"name":"阿拉山口市","value":"652702","parent":"652700"},{"name":"精河县","value":"652722","parent":"652700"},{"name":"温泉县","value":"652723","parent":"652700"},{"name":"库尔勒市","value":"652801","parent":"652800"},{"name":"轮台县","value":"652822","parent":"652800"},{"name":"尉犁县","value":"652823","parent":"652800"},{"name":"若羌县","value":"652824","parent":"652800"},{"name":"且末县","value":"652825","parent":"652800"},{"name":"焉耆回族自治县","value":"652826","parent":"652800"},{"name":"和静县","value":"652827","parent":"652800"},{"name":"和硕县","value":"652828","parent":"652800"},{"name":"博湖县","value":"652829","parent":"652800"},{"name":"阿克苏市","value":"652901","parent":"652900"},{"name":"温宿县","value":"652922","parent":"652900"},{"name":"库车县","value":"652923","parent":"652900"},{"name":"沙雅县","value":"652924","parent":"652900"},{"name":"新和县","value":"652925","parent":"652900"},{"name":"拜城县","value":"652926","parent":"652900"},{"name":"乌什县","value":"652927","parent":"652900"},{"name":"阿瓦提县","value":"652928","parent":"652900"},{"name":"柯坪县","value":"652929","parent":"652900"},{"name":"阿图什市","value":"653001","parent":"653000"},{"name":"阿克陶县","value":"653022","parent":"653000"},{"name":"阿合奇县","value":"653023","parent":"653000"},{"name":"乌恰县","value":"653024","parent":"653000"},{"name":"喀什市","value":"653101","parent":"653100"},{"name":"疏附县","value":"653121","parent":"653100"},{"name":"疏勒县","value":"653122","parent":"653100"},{"name":"英吉沙县","value":"653123","parent":"653100"},{"name":"泽普县","value":"653124","parent":"653100"},{"name":"莎车县","value":"653125","parent":"653100"},{"name":"叶城县","value":"653126","parent":"653100"},{"name":"麦盖提县","value":"653127","parent":"653100"},{"name":"岳普湖县","value":"653128","parent":"653100"},{"name":"伽师县","value":"653129","parent":"653100"},{"name":"巴楚县","value":"653130","parent":"653100"},{"name":"塔什库尔干塔吉克自治县","value":"653131","parent":"653100"},{"name":"和田市","value":"653201","parent":"653200"},{"name":"和田县","value":"653221","parent":"653200"},{"name":"墨玉县","value":"653222","parent":"653200"},{"name":"皮山县","value":"653223","parent":"653200"},{"name":"洛浦县","value":"653224","parent":"653200"},{"name":"策勒县","value":"653225","parent":"653200"},{"name":"于田县","value":"653226","parent":"653200"},{"name":"民丰县","value":"653227","parent":"653200"},{"name":"伊宁市","value":"654002","parent":"654000"},{"name":"奎屯市","value":"654003","parent":"654000"},{"name":"霍尔果斯市","value":"654004","parent":"654000"},{"name":"伊宁县","value":"654021","parent":"654000"},{"name":"察布查尔锡伯自治县","value":"654022","parent":"654000"},{"name":"霍城县","value":"654023","parent":"654000"},{"name":"巩留县","value":"654024","parent":"654000"},{"name":"新源县","value":"654025","parent":"654000"},{"name":"昭苏县","value":"654026","parent":"654000"},{"name":"特克斯县","value":"654027","parent":"654000"},{"name":"尼勒克县","value":"654028","parent":"654000"},{"name":"塔城市","value":"654201","parent":"654200"},{"name":"乌苏市","value":"654202","parent":"654200"},{"name":"额敏县","value":"654221","parent":"654200"},{"name":"沙湾县","value":"654223","parent":"654200"},{"name":"托里县","value":"654224","parent":"654200"},{"name":"裕民县","value":"654225","parent":"654200"},{"name":"和布克赛尔蒙古自治县","value":"654226","parent":"654200"},{"name":"阿勒泰市","value":"654301","parent":"654300"},{"name":"布尔津县","value":"654321","parent":"654300"},{"name":"富蕴县","value":"654322","parent":"654300"},{"name":"福海县","value":"654323","parent":"654300"},{"name":"哈巴河县","value":"654324","parent":"654300"},{"name":"青河县","value":"654325","parent":"654300"},{"name":"吉木乃县","value":"654326","parent":"654300"},{"name":"中西區","value":"810001","parent":"810000"},{"name":"灣仔區","value":"810002","parent":"810000"},{"name":"東區","value":"810003","parent":"810000"},{"name":"南區","value":"810004","parent":"810000"},{"name":"油尖旺區","value":"810005","parent":"810000"},{"name":"深水埗區","value":"810006","parent":"810000"},{"name":"九龍城區","value":"810007","parent":"810000"},{"name":"黃大仙區","value":"810008","parent":"810000"},{"name":"觀塘區","value":"810009","parent":"810000"},{"name":"荃灣區","value":"810010","parent":"810000"},{"name":"屯門區","value":"810011","parent":"810000"},{"name":"元朗區","value":"810012","parent":"810000"},{"name":"北區","value":"810013","parent":"810000"},{"name":"大埔區","value":"810014","parent":"810000"},{"name":"西貢區","value":"810015","parent":"810000"},{"name":"沙田區","value":"810016","parent":"810000"},{"name":"葵青區","value":"810017","parent":"810000"},{"name":"離島區","value":"810018","parent":"810000"},{"name":"花地瑪堂區","value":"820001","parent":"820000"},{"name":"花王堂區","value":"820002","parent":"820000"},{"name":"望德堂區","value":"820003","parent":"820000"},{"name":"大堂區","value":"820004","parent":"820000"},{"name":"風順堂區","value":"820005","parent":"820000"},{"name":"嘉模堂區","value":"820006","parent":"820000"},{"name":"路氹填海區","value":"820007","parent":"820000"},{"name":"聖方濟各堂區","value":"820008","parent":"820000"},{"name":"--","value":"--","parent":"110200"},{"name":"--","value":"--","parent":"120200"},{"name":"--","value":"--","parent":"139000"},{"name":"--","value":"--","parent":"139001"},{"name":"--","value":"--","parent":"139002"},{"name":"--","value":"--","parent":"310200"},{"name":"--","value":"--","parent":"419000"},{"name":"--","value":"--","parent":"419001"},{"name":"--","value":"--","parent":"429000"},{"name":"--","value":"--","parent":"429004"},{"name":"--","value":"--","parent":"429005"},{"name":"--","value":"--","parent":"429006"},{"name":"--","value":"--","parent":"429021"},{"name":"--","value":"--","parent":"441900"},{"name":"--","value":"--","parent":"442000"},{"name":"--","value":"--","parent":"469000"},{"name":"--","value":"--","parent":"469001"},{"name":"--","value":"--","parent":"469002"},{"name":"--","value":"--","parent":"469003"},{"name":"--","value":"--","parent":"469005"},{"name":"--","value":"--","parent":"469006"},{"name":"--","value":"--","parent":"469007"},{"name":"--","value":"--","parent":"469021"},{"name":"--","value":"--","parent":"469022"},{"name":"--","value":"--","parent":"469023"},{"name":"--","value":"--","parent":"469024"},{"name":"--","value":"--","parent":"469025"},{"name":"--","value":"--","parent":"469026"},{"name":"--","value":"--","parent":"469027"},{"name":"--","value":"--","parent":"469028"},{"name":"--","value":"--","parent":"469029"},{"name":"--","value":"--","parent":"469030"},{"name":"--","value":"--","parent":"500200"},{"name":"--","value":"--","parent":"620200"},{"name":"--","value":"--","parent":"659000"},{"name":"--","value":"--","parent":"659001"},{"name":"--","value":"--","parent":"659002"},{"name":"--","value":"--","parent":"659003"},{"name":"--","value":"--","parent":"659004"}]

/***/ }),
/* 486 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(593);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony namespace reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__) if(__WEBPACK_IMPORT_KEY__ !== 'default') (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return __WEBPACK_IMPORTED_MODULE_0__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__[key]; }) }(__WEBPACK_IMPORT_KEY__));
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__ = __webpack_require__(594);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_7f806bc4_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__ = __webpack_require__(595);
var disposed = false
function injectStyle (ssrContext) {
  if (disposed) return
  __webpack_require__(591)
}
var normalizeComponent = __webpack_require__(75)
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = null
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  __WEBPACK_IMPORTED_MODULE_1__babel_loader_vux_loader_1_2_9_vux_loader_src_script_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_script_index_0_index_vue___default.a,
  __WEBPACK_IMPORTED_MODULE_2__vue_loader_13_7_3_vue_loader_lib_template_compiler_index_id_data_v_7f806bc4_hasScoped_false_buble_transforms_vux_loader_1_2_9_vux_loader_src_before_template_compiler_loader_js_vux_loader_1_2_9_vux_loader_src_template_loader_js_vue_loader_13_7_3_vue_loader_lib_selector_type_template_index_0_index_vue__["a" /* default */],
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)
Component.options.__file = "node_modules/_vux@2.9.2@vux/src/components/x-button/index.vue"

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-7f806bc4", Component.options)
  } else {
    hotAPI.reload("data-v-7f806bc4", Component.options)
  }
  module.hot.dispose(function (data) {
    disposed = true
  })
})()}

/* harmony default export */ __webpack_exports__["default"] = (Component.exports);


/***/ }),
/* 487 */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./home_banner_001.png": 596,
	"./home_banner_002.png": 597,
	"./home_banner_003.png": 598,
	"./home_banner_004.png": 599
};
function webpackContext(req) {
	return __webpack_require__(webpackContextResolve(req));
};
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) // check for number or string
		throw new Error("Cannot find module '" + req + "'.");
	return id;
};
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = 487;

/***/ }),
/* 488 */,
/* 489 */,
/* 490 */,
/* 491 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _swiper = __webpack_require__(448);

var _swiper2 = _interopRequireDefault(_swiper);

var _index = __webpack_require__(454);

var _index2 = _interopRequireDefault(_index);

var _index3 = __webpack_require__(455);

var _index4 = _interopRequireDefault(_index3);

var _index5 = __webpack_require__(456);

var _index6 = _interopRequireDefault(_index5);

var _index7 = __webpack_require__(466);

var _index8 = _interopRequireDefault(_index7);

var _china_address = __webpack_require__(485);

var _china_address2 = _interopRequireDefault(_china_address);

var _flexbox = __webpack_require__(446);

var _flexbox2 = _interopRequireDefault(_flexbox);

var _flexboxItem = __webpack_require__(447);

var _flexboxItem2 = _interopRequireDefault(_flexboxItem);

var _index9 = __webpack_require__(486);

var _index10 = _interopRequireDefault(_index9);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  components: {
    Swiper: _swiper2.default,
    Card: _index2.default,
    Group: _index4.default,
    XInput: _index6.default,
    XAddress: _index8.default,
    Flexbox: _flexbox2.default,
    FlexboxItem: _flexboxItem2.default,
    XButton: _index10.default
  },
  /**
  * 所有参数变量说明
  * paging             boolean   是否需要分页
  */
  data: function data() {
    return {
      swiperList: [],
      addressValue: [],
      addressData: _china_address2.default
    };
  },

  methods: {},
  created: function created() {
    for (var i = 1; i < 5; i++) {
      this.swiperList.push({
        url: "javascript:;",
        img: __webpack_require__(487)("./home_banner_00" + i + '.png'),
        title: "",
        fallbackImg: ""
      });
    }
  }
};

/***/ }),
/* 492 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(493);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("eb6ab1d4", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-7431ed85\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./swiper.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-7431ed85\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./swiper.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 493 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.vux-slider {\n  overflow: hidden;\n  position: relative;\n}\n.vux-slider > .vux-indicator,\n.vux-slider .vux-indicator-right {\n  position: absolute;\n  right: 15px;\n  bottom: 10px;\n}\n.vux-slider > .vux-indicator > a,\n.vux-slider .vux-indicator-right > a {\n  float: left;\n  margin-left: 6px;\n}\n.vux-slider > .vux-indicator > a > .vux-icon-dot,\n.vux-slider .vux-indicator-right > a > .vux-icon-dot {\n  display: inline-block;\n  vertical-align: middle;\n  width: 6px;\n  height: 6px;\n  border-radius: 3px;\n  background-color: #d0cdd1;\n}\n.vux-slider > .vux-indicator > a > .vux-icon-dot.active,\n.vux-slider .vux-indicator-right > a > .vux-icon-dot.active {\n  background-color: #04BE02;\n}\n.vux-slider > .vux-indicator-center {\n  right: 50%;\n  transform: translateX(50%);\n}\n.vux-slider > .vux-indicator-left {\n  left: 15px;\n  right: auto;\n}\n.vux-slider > .vux-swiper {\n  overflow: hidden;\n  position: relative;\n}\n.vux-slider > .vux-swiper > .vux-swiper-item {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n}\n.vux-slider > .vux-swiper > .vux-swiper-item > a {\n  display: block;\n  width: 100%;\n  height: 100%;\n}\n.vux-slider > .vux-swiper > .vux-swiper-item > a > .vux-img {\n  display: block;\n  width: 100%;\n  height: 100%;\n  background: center center no-repeat;\n  background-size: cover;\n}\n.vux-slider > .vux-swiper > .vux-swiper-item > a > .vux-swiper-desc {\n  position: absolute;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  height: 1.4em;\n  font-size: 16px;\n  padding: 20px 50px 12px 13px;\n  margin: 0;\n  background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0) 0, rgba(0, 0, 0, 0.7) 100%);\n  color: #fff;\n  text-shadow: 0 1px 0 rgba(0, 0, 0, 0.5);\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n  word-wrap: normal;\n}\n", ""]);

// exports


/***/ }),
/* 494 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(433);

var _stringify2 = _interopRequireDefault(_stringify);

var _swiper = __webpack_require__(449);

var _swiper2 = _interopRequireDefault(_swiper);

var _router = __webpack_require__(434);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'swiper',
  created: function created() {
    this.index = this.value || 0;
    if (this.index) {
      this.current = this.index;
    }
  },
  mounted: function mounted() {
    var _this2 = this;

    this.hasTwoLoopItem();
    this.$nextTick(function () {
      if (!(_this2.list && _this2.list.length === 0)) {
        _this2.render(_this2.index);
      }
      _this2.xheight = _this2.getHeight();
      _this2.$emit('on-get-height', _this2.xheight);
    });
  },

  methods: {
    hasTwoLoopItem: function hasTwoLoopItem() {
      if (this.list.length === 2 && this.loop) {
        this.listTwoLoopItem = this.list;
      } else {
        this.listTwoLoopItem = [];
      }
    },
    clickListItem: function clickListItem(item) {
      (0, _router.go)(item.url, this.$router);
      this.$emit('on-click-list-item', JSON.parse((0, _stringify2.default)(item)));
    },
    buildBackgroundUrl: function buildBackgroundUrl(item) {
      return item.fallbackImg ? 'url(' + item.img + '), url(' + item.fallbackImg + ')' : 'url(' + item.img + ')';
    },
    render: function render() {
      var _this3 = this;

      var index = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

      this.swiper && this.swiper.destroy();
      this.swiper = new _swiper2.default({
        container: this.$el,
        direction: this.direction,
        auto: this.auto,
        loop: this.loop,
        interval: this.interval,
        threshold: this.threshold,
        duration: this.duration,
        height: this.height || this._height,
        minMovingDistance: this.minMovingDistance,
        imgList: this.imgList
      }).on('swiped', function (prev, index) {
        _this3.current = index % _this3.length;
        _this3.index = index % _this3.length;
      });
      if (index > 0) {
        this.swiper.go(index);
      }
    },
    rerender: function rerender() {
      var _this4 = this;

      if (!this.$el || this.hasRender) {
        return;
      }
      this.hasRender = true;
      this.hasTwoLoopItem();
      this.$nextTick(function () {
        _this4.index = _this4.value || 0;
        _this4.current = _this4.value || 0;
        _this4.length = _this4.list.length || _this4.$children.length;
        _this4.destroy();
        _this4.render(_this4.value);
      });
    },
    destroy: function destroy() {
      this.hasRender = false;
      this.swiper && this.swiper.destroy();
    },
    getHeight: function getHeight() {
      var hasHeight = parseInt(this.height, 10);
      if (hasHeight) return this.height;
      if (!hasHeight) {
        if (this.aspectRatio) {
          return this.$el.offsetWidth * this.aspectRatio + 'px';
        }
        return '180px';
      }
    }
  },
  props: {
    list: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    direction: {
      type: String,
      default: 'horizontal'
    },
    showDots: {
      type: Boolean,
      default: true
    },
    showDescMask: {
      type: Boolean,
      default: true
    },
    dotsPosition: {
      type: String,
      default: 'right'
    },
    dotsClass: String,
    auto: Boolean,
    loop: Boolean,
    interval: {
      type: Number,
      default: 3000
    },
    threshold: {
      type: Number,
      default: 50
    },
    duration: {
      type: Number,
      default: 300
    },
    height: {
      type: String,
      default: 'auto'
    },
    aspectRatio: Number,
    minMovingDistance: {
      type: Number,
      default: 0
    },
    value: {
      type: Number,
      default: 0
    }
  },
  data: function data() {
    return {
      hasRender: false,
      current: this.index || 0,
      xheight: 'auto',
      length: this.list.length,
      index: 0,
      listTwoLoopItem: [] // issue #1484
    };
  },

  watch: {
    auto: function auto(val) {
      if (!val) {
        this.swiper && this.swiper.stop();
      } else {
        this.swiper && this.swiper._auto();
      }
    },
    list: function list(val, oldVal) {
      if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(oldVal)) {
        this.rerender();
      }
    },
    current: function current(currentIndex) {
      this.index = currentIndex;
      this.$emit('on-index-change', currentIndex);
    },
    index: function index(val) {
      var _this = this;
      if (val !== this.current) {
        this.$nextTick(function () {
          _this.swiper && _this.swiper.go(val);
        });
      }
      this.$emit('input', val);
    },
    value: function value(val) {
      this.index = val;
    }
  },
  beforeDestroy: function beforeDestroy() {
    this.destroy();
  }
};

/***/ }),
/* 495 */
/***/ (function(module, exports, __webpack_require__) {

var core = __webpack_require__(48);
var $JSON = core.JSON || (core.JSON = { stringify: JSON.stringify });
module.exports = function stringify(it) { // eslint-disable-line no-unused-vars
  return $JSON.stringify.apply($JSON, arguments);
};


/***/ }),
/* 496 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(497), __esModule: true };

/***/ }),
/* 497 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(498);
var $Object = __webpack_require__(48).Object;
module.exports = function defineProperty(it, key, desc) {
  return $Object.defineProperty(it, key, desc);
};


/***/ }),
/* 498 */
/***/ (function(module, exports, __webpack_require__) {

var $export = __webpack_require__(110);
// 19.1.2.4 / 15.2.3.6 Object.defineProperty(O, P, Attributes)
$export($export.S + $export.F * !__webpack_require__(58), 'Object', { defineProperty: __webpack_require__(57).f });


/***/ }),
/* 499 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(500), __esModule: true };

/***/ }),
/* 500 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(115);
__webpack_require__(172);
module.exports = __webpack_require__(442).f('iterator');


/***/ }),
/* 501 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = { "default": __webpack_require__(502), __esModule: true };

/***/ }),
/* 502 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(503);
__webpack_require__(509);
__webpack_require__(510);
__webpack_require__(511);
module.exports = __webpack_require__(48).Symbol;


/***/ }),
/* 503 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

// ECMAScript 6 symbols shim
var global = __webpack_require__(43);
var has = __webpack_require__(59);
var DESCRIPTORS = __webpack_require__(58);
var $export = __webpack_require__(110);
var redefine = __webpack_require__(169);
var META = __webpack_require__(504).KEY;
var $fails = __webpack_require__(111);
var shared = __webpack_require__(117);
var setToStringTag = __webpack_require__(119);
var uid = __webpack_require__(113);
var wks = __webpack_require__(29);
var wksExt = __webpack_require__(442);
var wksDefine = __webpack_require__(443);
var enumKeys = __webpack_require__(505);
var isArray = __webpack_require__(506);
var anObject = __webpack_require__(51);
var isObject = __webpack_require__(77);
var toIObject = __webpack_require__(76);
var toPrimitive = __webpack_require__(167);
var createDesc = __webpack_require__(78);
var _create = __webpack_require__(170);
var gOPNExt = __webpack_require__(507);
var $GOPD = __webpack_require__(508);
var $DP = __webpack_require__(57);
var $keys = __webpack_require__(166);
var gOPD = $GOPD.f;
var dP = $DP.f;
var gOPN = gOPNExt.f;
var $Symbol = global.Symbol;
var $JSON = global.JSON;
var _stringify = $JSON && $JSON.stringify;
var PROTOTYPE = 'prototype';
var HIDDEN = wks('_hidden');
var TO_PRIMITIVE = wks('toPrimitive');
var isEnum = {}.propertyIsEnumerable;
var SymbolRegistry = shared('symbol-registry');
var AllSymbols = shared('symbols');
var OPSymbols = shared('op-symbols');
var ObjectProto = Object[PROTOTYPE];
var USE_NATIVE = typeof $Symbol == 'function';
var QObject = global.QObject;
// Don't use setters in Qt Script, https://github.com/zloirock/core-js/issues/173
var setter = !QObject || !QObject[PROTOTYPE] || !QObject[PROTOTYPE].findChild;

// fallback for old Android, https://code.google.com/p/v8/issues/detail?id=687
var setSymbolDesc = DESCRIPTORS && $fails(function () {
  return _create(dP({}, 'a', {
    get: function () { return dP(this, 'a', { value: 7 }).a; }
  })).a != 7;
}) ? function (it, key, D) {
  var protoDesc = gOPD(ObjectProto, key);
  if (protoDesc) delete ObjectProto[key];
  dP(it, key, D);
  if (protoDesc && it !== ObjectProto) dP(ObjectProto, key, protoDesc);
} : dP;

var wrap = function (tag) {
  var sym = AllSymbols[tag] = _create($Symbol[PROTOTYPE]);
  sym._k = tag;
  return sym;
};

var isSymbol = USE_NATIVE && typeof $Symbol.iterator == 'symbol' ? function (it) {
  return typeof it == 'symbol';
} : function (it) {
  return it instanceof $Symbol;
};

var $defineProperty = function defineProperty(it, key, D) {
  if (it === ObjectProto) $defineProperty(OPSymbols, key, D);
  anObject(it);
  key = toPrimitive(key, true);
  anObject(D);
  if (has(AllSymbols, key)) {
    if (!D.enumerable) {
      if (!has(it, HIDDEN)) dP(it, HIDDEN, createDesc(1, {}));
      it[HIDDEN][key] = true;
    } else {
      if (has(it, HIDDEN) && it[HIDDEN][key]) it[HIDDEN][key] = false;
      D = _create(D, { enumerable: createDesc(0, false) });
    } return setSymbolDesc(it, key, D);
  } return dP(it, key, D);
};
var $defineProperties = function defineProperties(it, P) {
  anObject(it);
  var keys = enumKeys(P = toIObject(P));
  var i = 0;
  var l = keys.length;
  var key;
  while (l > i) $defineProperty(it, key = keys[i++], P[key]);
  return it;
};
var $create = function create(it, P) {
  return P === undefined ? _create(it) : $defineProperties(_create(it), P);
};
var $propertyIsEnumerable = function propertyIsEnumerable(key) {
  var E = isEnum.call(this, key = toPrimitive(key, true));
  if (this === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return false;
  return E || !has(this, key) || !has(AllSymbols, key) || has(this, HIDDEN) && this[HIDDEN][key] ? E : true;
};
var $getOwnPropertyDescriptor = function getOwnPropertyDescriptor(it, key) {
  it = toIObject(it);
  key = toPrimitive(key, true);
  if (it === ObjectProto && has(AllSymbols, key) && !has(OPSymbols, key)) return;
  var D = gOPD(it, key);
  if (D && has(AllSymbols, key) && !(has(it, HIDDEN) && it[HIDDEN][key])) D.enumerable = true;
  return D;
};
var $getOwnPropertyNames = function getOwnPropertyNames(it) {
  var names = gOPN(toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (!has(AllSymbols, key = names[i++]) && key != HIDDEN && key != META) result.push(key);
  } return result;
};
var $getOwnPropertySymbols = function getOwnPropertySymbols(it) {
  var IS_OP = it === ObjectProto;
  var names = gOPN(IS_OP ? OPSymbols : toIObject(it));
  var result = [];
  var i = 0;
  var key;
  while (names.length > i) {
    if (has(AllSymbols, key = names[i++]) && (IS_OP ? has(ObjectProto, key) : true)) result.push(AllSymbols[key]);
  } return result;
};

// 19.4.1.1 Symbol([description])
if (!USE_NATIVE) {
  $Symbol = function Symbol() {
    if (this instanceof $Symbol) throw TypeError('Symbol is not a constructor!');
    var tag = uid(arguments.length > 0 ? arguments[0] : undefined);
    var $set = function (value) {
      if (this === ObjectProto) $set.call(OPSymbols, value);
      if (has(this, HIDDEN) && has(this[HIDDEN], tag)) this[HIDDEN][tag] = false;
      setSymbolDesc(this, tag, createDesc(1, value));
    };
    if (DESCRIPTORS && setter) setSymbolDesc(ObjectProto, tag, { configurable: true, set: $set });
    return wrap(tag);
  };
  redefine($Symbol[PROTOTYPE], 'toString', function toString() {
    return this._k;
  });

  $GOPD.f = $getOwnPropertyDescriptor;
  $DP.f = $defineProperty;
  __webpack_require__(453).f = gOPNExt.f = $getOwnPropertyNames;
  __webpack_require__(444).f = $propertyIsEnumerable;
  __webpack_require__(452).f = $getOwnPropertySymbols;

  if (DESCRIPTORS && !__webpack_require__(112)) {
    redefine(ObjectProto, 'propertyIsEnumerable', $propertyIsEnumerable, true);
  }

  wksExt.f = function (name) {
    return wrap(wks(name));
  };
}

$export($export.G + $export.W + $export.F * !USE_NATIVE, { Symbol: $Symbol });

for (var es6Symbols = (
  // 19.4.2.2, 19.4.2.3, 19.4.2.4, 19.4.2.6, 19.4.2.8, 19.4.2.9, 19.4.2.10, 19.4.2.11, 19.4.2.12, 19.4.2.13, 19.4.2.14
  'hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables'
).split(','), j = 0; es6Symbols.length > j;)wks(es6Symbols[j++]);

for (var wellKnownSymbols = $keys(wks.store), k = 0; wellKnownSymbols.length > k;) wksDefine(wellKnownSymbols[k++]);

$export($export.S + $export.F * !USE_NATIVE, 'Symbol', {
  // 19.4.2.1 Symbol.for(key)
  'for': function (key) {
    return has(SymbolRegistry, key += '')
      ? SymbolRegistry[key]
      : SymbolRegistry[key] = $Symbol(key);
  },
  // 19.4.2.5 Symbol.keyFor(sym)
  keyFor: function keyFor(sym) {
    if (!isSymbol(sym)) throw TypeError(sym + ' is not a symbol!');
    for (var key in SymbolRegistry) if (SymbolRegistry[key] === sym) return key;
  },
  useSetter: function () { setter = true; },
  useSimple: function () { setter = false; }
});

$export($export.S + $export.F * !USE_NATIVE, 'Object', {
  // 19.1.2.2 Object.create(O [, Properties])
  create: $create,
  // 19.1.2.4 Object.defineProperty(O, P, Attributes)
  defineProperty: $defineProperty,
  // 19.1.2.3 Object.defineProperties(O, Properties)
  defineProperties: $defineProperties,
  // 19.1.2.6 Object.getOwnPropertyDescriptor(O, P)
  getOwnPropertyDescriptor: $getOwnPropertyDescriptor,
  // 19.1.2.7 Object.getOwnPropertyNames(O)
  getOwnPropertyNames: $getOwnPropertyNames,
  // 19.1.2.8 Object.getOwnPropertySymbols(O)
  getOwnPropertySymbols: $getOwnPropertySymbols
});

// 24.3.2 JSON.stringify(value [, replacer [, space]])
$JSON && $export($export.S + $export.F * (!USE_NATIVE || $fails(function () {
  var S = $Symbol();
  // MS Edge converts symbol values to JSON as {}
  // WebKit converts symbol values to JSON as null
  // V8 throws on boxed symbols
  return _stringify([S]) != '[null]' || _stringify({ a: S }) != '{}' || _stringify(Object(S)) != '{}';
})), 'JSON', {
  stringify: function stringify(it) {
    var args = [it];
    var i = 1;
    var replacer, $replacer;
    while (arguments.length > i) args.push(arguments[i++]);
    $replacer = replacer = args[1];
    if (!isObject(replacer) && it === undefined || isSymbol(it)) return; // IE8 returns string on undefined
    if (!isArray(replacer)) replacer = function (key, value) {
      if (typeof $replacer == 'function') value = $replacer.call(this, key, value);
      if (!isSymbol(value)) return value;
    };
    args[1] = replacer;
    return _stringify.apply($JSON, args);
  }
});

// 19.4.3.4 Symbol.prototype[@@toPrimitive](hint)
$Symbol[PROTOTYPE][TO_PRIMITIVE] || __webpack_require__(50)($Symbol[PROTOTYPE], TO_PRIMITIVE, $Symbol[PROTOTYPE].valueOf);
// 19.4.3.5 Symbol.prototype[@@toStringTag]
setToStringTag($Symbol, 'Symbol');
// 20.2.1.9 Math[@@toStringTag]
setToStringTag(Math, 'Math', true);
// 24.3.3 JSON[@@toStringTag]
setToStringTag(global.JSON, 'JSON', true);


/***/ }),
/* 504 */
/***/ (function(module, exports, __webpack_require__) {

var META = __webpack_require__(113)('meta');
var isObject = __webpack_require__(77);
var has = __webpack_require__(59);
var setDesc = __webpack_require__(57).f;
var id = 0;
var isExtensible = Object.isExtensible || function () {
  return true;
};
var FREEZE = !__webpack_require__(111)(function () {
  return isExtensible(Object.preventExtensions({}));
});
var setMeta = function (it) {
  setDesc(it, META, { value: {
    i: 'O' + ++id, // object ID
    w: {}          // weak collections IDs
  } });
};
var fastKey = function (it, create) {
  // return primitive with prefix
  if (!isObject(it)) return typeof it == 'symbol' ? it : (typeof it == 'string' ? 'S' : 'P') + it;
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return 'F';
    // not necessary to add metadata
    if (!create) return 'E';
    // add missing metadata
    setMeta(it);
  // return object ID
  } return it[META].i;
};
var getWeak = function (it, create) {
  if (!has(it, META)) {
    // can't set metadata to uncaught frozen object
    if (!isExtensible(it)) return true;
    // not necessary to add metadata
    if (!create) return false;
    // add missing metadata
    setMeta(it);
  // return hash weak collections IDs
  } return it[META].w;
};
// add metadata on freeze-family methods calling
var onFreeze = function (it) {
  if (FREEZE && meta.NEED && isExtensible(it) && !has(it, META)) setMeta(it);
  return it;
};
var meta = module.exports = {
  KEY: META,
  NEED: false,
  fastKey: fastKey,
  getWeak: getWeak,
  onFreeze: onFreeze
};


/***/ }),
/* 505 */
/***/ (function(module, exports, __webpack_require__) {

// all enumerable object keys, includes symbols
var getKeys = __webpack_require__(166);
var gOPS = __webpack_require__(452);
var pIE = __webpack_require__(444);
module.exports = function (it) {
  var result = getKeys(it);
  var getSymbols = gOPS.f;
  if (getSymbols) {
    var symbols = getSymbols(it);
    var isEnum = pIE.f;
    var i = 0;
    var key;
    while (symbols.length > i) if (isEnum.call(it, key = symbols[i++])) result.push(key);
  } return result;
};


/***/ }),
/* 506 */
/***/ (function(module, exports, __webpack_require__) {

// 7.2.2 IsArray(argument)
var cof = __webpack_require__(116);
module.exports = Array.isArray || function isArray(arg) {
  return cof(arg) == 'Array';
};


/***/ }),
/* 507 */
/***/ (function(module, exports, __webpack_require__) {

// fallback for IE11 buggy Object.getOwnPropertyNames with iframe and window
var toIObject = __webpack_require__(76);
var gOPN = __webpack_require__(453).f;
var toString = {}.toString;

var windowNames = typeof window == 'object' && window && Object.getOwnPropertyNames
  ? Object.getOwnPropertyNames(window) : [];

var getWindowNames = function (it) {
  try {
    return gOPN(it);
  } catch (e) {
    return windowNames.slice();
  }
};

module.exports.f = function getOwnPropertyNames(it) {
  return windowNames && toString.call(it) == '[object Window]' ? getWindowNames(it) : gOPN(toIObject(it));
};


/***/ }),
/* 508 */
/***/ (function(module, exports, __webpack_require__) {

var pIE = __webpack_require__(444);
var createDesc = __webpack_require__(78);
var toIObject = __webpack_require__(76);
var toPrimitive = __webpack_require__(167);
var has = __webpack_require__(59);
var IE8_DOM_DEFINE = __webpack_require__(168);
var gOPD = Object.getOwnPropertyDescriptor;

exports.f = __webpack_require__(58) ? gOPD : function getOwnPropertyDescriptor(O, P) {
  O = toIObject(O);
  P = toPrimitive(P, true);
  if (IE8_DOM_DEFINE) try {
    return gOPD(O, P);
  } catch (e) { /* empty */ }
  if (has(O, P)) return createDesc(!pIE.f.call(O, P), O[P]);
};


/***/ }),
/* 509 */
/***/ (function(module, exports) {



/***/ }),
/* 510 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(443)('asyncIterator');


/***/ }),
/* 511 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(443)('observable');


/***/ }),
/* 512 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(433);

var _stringify2 = _interopRequireDefault(_stringify);

var _swiper = __webpack_require__(449);

var _swiper2 = _interopRequireDefault(_swiper);

var _router = __webpack_require__(434);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'swiper',
  created: function created() {
    this.index = this.value || 0;
    if (this.index) {
      this.current = this.index;
    }
  },
  mounted: function mounted() {
    var _this2 = this;

    this.hasTwoLoopItem();
    this.$nextTick(function () {
      if (!(_this2.list && _this2.list.length === 0)) {
        _this2.render(_this2.index);
      }
      _this2.xheight = _this2.getHeight();
      _this2.$emit('on-get-height', _this2.xheight);
    });
  },

  methods: {
    hasTwoLoopItem: function hasTwoLoopItem() {
      if (this.list.length === 2 && this.loop) {
        this.listTwoLoopItem = this.list;
      } else {
        this.listTwoLoopItem = [];
      }
    },
    clickListItem: function clickListItem(item) {
      (0, _router.go)(item.url, this.$router);
      this.$emit('on-click-list-item', JSON.parse((0, _stringify2.default)(item)));
    },
    buildBackgroundUrl: function buildBackgroundUrl(item) {
      return item.fallbackImg ? 'url(' + item.img + '), url(' + item.fallbackImg + ')' : 'url(' + item.img + ')';
    },
    render: function render() {
      var _this3 = this;

      var index = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

      this.swiper && this.swiper.destroy();
      this.swiper = new _swiper2.default({
        container: this.$el,
        direction: this.direction,
        auto: this.auto,
        loop: this.loop,
        interval: this.interval,
        threshold: this.threshold,
        duration: this.duration,
        height: this.height || this._height,
        minMovingDistance: this.minMovingDistance,
        imgList: this.imgList
      }).on('swiped', function (prev, index) {
        _this3.current = index % _this3.length;
        _this3.index = index % _this3.length;
      });
      if (index > 0) {
        this.swiper.go(index);
      }
    },
    rerender: function rerender() {
      var _this4 = this;

      if (!this.$el || this.hasRender) {
        return;
      }
      this.hasRender = true;
      this.hasTwoLoopItem();
      this.$nextTick(function () {
        _this4.index = _this4.value || 0;
        _this4.current = _this4.value || 0;
        _this4.length = _this4.list.length || _this4.$children.length;
        _this4.destroy();
        _this4.render(_this4.value);
      });
    },
    destroy: function destroy() {
      this.hasRender = false;
      this.swiper && this.swiper.destroy();
    },
    getHeight: function getHeight() {
      var hasHeight = parseInt(this.height, 10);
      if (hasHeight) return this.height;
      if (!hasHeight) {
        if (this.aspectRatio) {
          return this.$el.offsetWidth * this.aspectRatio + 'px';
        }
        return '180px';
      }
    }
  },
  props: {
    list: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    direction: {
      type: String,
      default: 'horizontal'
    },
    showDots: {
      type: Boolean,
      default: true
    },
    showDescMask: {
      type: Boolean,
      default: true
    },
    dotsPosition: {
      type: String,
      default: 'right'
    },
    dotsClass: String,
    auto: Boolean,
    loop: Boolean,
    interval: {
      type: Number,
      default: 3000
    },
    threshold: {
      type: Number,
      default: 50
    },
    duration: {
      type: Number,
      default: 300
    },
    height: {
      type: String,
      default: 'auto'
    },
    aspectRatio: Number,
    minMovingDistance: {
      type: Number,
      default: 0
    },
    value: {
      type: Number,
      default: 0
    }
  },
  data: function data() {
    return {
      hasRender: false,
      current: this.index || 0,
      xheight: 'auto',
      length: this.list.length,
      index: 0,
      listTwoLoopItem: [] // issue #1484
    };
  },

  watch: {
    auto: function auto(val) {
      if (!val) {
        this.swiper && this.swiper.stop();
      } else {
        this.swiper && this.swiper._auto();
      }
    },
    list: function list(val, oldVal) {
      if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(oldVal)) {
        this.rerender();
      }
    },
    current: function current(currentIndex) {
      this.index = currentIndex;
      this.$emit('on-index-change', currentIndex);
    },
    index: function index(val) {
      var _this = this;
      if (val !== this.current) {
        this.$nextTick(function () {
          _this.swiper && _this.swiper.go(val);
        });
      }
      this.$emit('input', val);
    },
    value: function value(val) {
      this.index = val;
    }
  },
  beforeDestroy: function beforeDestroy() {
    this.destroy();
  }
};

/***/ }),
/* 513 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "vux-slider" }, [
    _c(
      "div",
      { staticClass: "vux-swiper", style: { height: _vm.xheight } },
      [
        _vm._t("default"),
        _vm._v(" "),
        _vm._l(_vm.list, function(item, index) {
          return _c(
            "div",
            {
              staticClass: "vux-swiper-item",
              attrs: { "data-index": index },
              on: {
                click: function($event) {
                  _vm.clickListItem(item)
                }
              }
            },
            [
              _c("a", { attrs: { href: "javascript:" } }, [
                _c("div", {
                  staticClass: "vux-img",
                  style: { backgroundImage: _vm.buildBackgroundUrl(item) }
                }),
                _vm._v(" "),
                _vm.showDescMask
                  ? _c("p", { staticClass: "vux-swiper-desc" }, [
                      _vm._v(_vm._s(item.title))
                    ])
                  : _vm._e()
              ])
            ]
          )
        }),
        _vm._v(" "),
        _vm._l(_vm.listTwoLoopItem, function(item, index) {
          return _vm.listTwoLoopItem.length > 0
            ? _c(
                "div",
                {
                  staticClass: "vux-swiper-item vux-swiper-item-clone",
                  attrs: { "data-index": index },
                  on: {
                    click: function($event) {
                      _vm.clickListItem(item)
                    }
                  }
                },
                [
                  _c("a", { attrs: { href: "javascript:" } }, [
                    _c("div", {
                      staticClass: "vux-img",
                      style: { backgroundImage: _vm.buildBackgroundUrl(item) }
                    }),
                    _vm._v(" "),
                    _vm.showDescMask
                      ? _c("p", { staticClass: "vux-swiper-desc" }, [
                          _vm._v(_vm._s(item.title))
                        ])
                      : _vm._e()
                  ])
                ]
              )
            : _vm._e()
        })
      ],
      2
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.showDots,
            expression: "showDots"
          }
        ],
        class: [
          _vm.dotsClass,
          "vux-indicator",
          "vux-indicator-" + _vm.dotsPosition
        ]
      },
      _vm._l(_vm.length, function(key) {
        return _c("a", { attrs: { href: "javascript:" } }, [
          _c("i", {
            staticClass: "vux-icon-dot",
            class: { active: key - 1 === _vm.current }
          })
        ])
      })
    )
  ])
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-7431ed85", esExports)
  }
}

/***/ }),
/* 514 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(515);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("0a4fbfff", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-75c3ee6d\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-75c3ee6d\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 515 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.weui-cells {\n  margin-top: 1.17647059em;\n  background-color: #FFFFFF;\n  line-height: 1.41176471;\n  font-size: 17px;\n  overflow: hidden;\n  position: relative;\n}\n.weui-cells:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.weui-cells:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.weui-cells__title {\n  margin-top: 0.77em;\n  margin-bottom: 0.3em;\n  padding-left: 15px;\n  padding-right: 15px;\n  color: #999999;\n  font-size: 14px;\n}\n.weui-cells__title + .weui-cells {\n  margin-top: 0;\n}\n.weui-cells__tips {\n  margin-top: .3em;\n  color: #999999;\n  padding-left: 15px;\n  padding-right: 15px;\n  font-size: 14px;\n}\n.weui-cell {\n  padding: 10px 15px;\n  position: relative;\n  display: flex;\n  align-items: center;\n}\n.weui-cell:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n  left: 15px;\n}\n.weui-cell:first-child:before {\n  display: none;\n}\n.weui-cell_primary {\n  align-items: flex-start;\n}\n.weui-cell__bd {\n  flex: 1;\n}\n.weui-cell__ft {\n  text-align: right;\n  color: #999999;\n}\n.vux-cell-justify {\n  height: 1.41176471em;\n}\n.vux-cell-justify.vux-cell-justify:after {\n  content: \".\";\n  display: inline-block;\n  width: 100%;\n  overflow: hidden;\n  height: 0;\n}\n.weui-cell_access {\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n  color: inherit;\n}\n.weui-cell_access:active {\n  background-color: #ECECEC;\n}\n.weui-cell_access .weui-cell__ft {\n  padding-right: 13px;\n  position: relative;\n}\n.weui-cell_access .weui-cell__ft:after {\n  content: \" \";\n  display: inline-block;\n  height: 6px;\n  width: 6px;\n  border-width: 2px 2px 0 0;\n  border-color: #C8C8CD;\n  border-style: solid;\n  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);\n  position: relative;\n  top: -2px;\n  position: absolute;\n  top: 50%;\n  margin-top: -4px;\n  right: 2px;\n}\n.weui-cell_link {\n  color: #586C94;\n  font-size: 14px;\n}\n.weui-cell_link.weui-cell:first-child:before {\n  display: block;\n}\n.weui-cell_access.vux-cell-box {\n  padding-right: 13px;\n  position: relative;\n}\n.weui-cell_access.vux-cell-box:after {\n  content: \" \";\n  display: inline-block;\n  height: 6px;\n  width: 6px;\n  border-width: 2px 2px 0 0;\n  border-color: #C8C8CD;\n  border-style: solid;\n  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);\n  position: relative;\n  top: -2px;\n  position: absolute;\n  top: 50%;\n  margin-top: -4px;\n  right: 17px;\n}\n.weui-panel {\n  background-color: #FFFFFF;\n  margin-top: 10px;\n  position: relative;\n  overflow: hidden;\n}\n.weui-panel:first-child {\n  margin-top: 0;\n}\n.weui-panel:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #E5E5E5;\n  color: #E5E5E5;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.weui-panel:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #E5E5E5;\n  color: #E5E5E5;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.weui-panel__hd {\n  padding: 14px 15px 10px;\n  color: #999999;\n  font-size: 13px;\n  position: relative;\n}\n.weui-panel__hd:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #E5E5E5;\n  color: #E5E5E5;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n  left: 15px;\n}\n", ""]);

// exports


/***/ }),
/* 516 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _router = __webpack_require__(434);

exports.default = {
  name: 'card',
  props: {
    header: Object,
    footer: Object
  },
  methods: {
    onClickFooter: function onClickFooter() {
      this.footer.link && (0, _router.go)(this.footer.link, this.$router);
      this.$emit('on-click-footer');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 517 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _router = __webpack_require__(434);

exports.default = {
  name: 'card',
  props: {
    header: Object,
    footer: Object
  },
  methods: {
    onClickFooter: function onClickFooter() {
      this.footer.link && (0, _router.go)(this.footer.link, this.$router);
      this.$emit('on-click-footer');
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 518 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "weui-panel weui-panel_access" },
    [
      _vm.header && _vm.header.title
        ? _c("div", {
            staticClass: "weui-panel__hd",
            domProps: { innerHTML: _vm._s(_vm.header.title) },
            on: {
              click: function($event) {
                _vm.$emit("on-click-header")
              }
            }
          })
        : _vm._e(),
      _vm._v(" "),
      _vm._t("header"),
      _vm._v(" "),
      _c("div", { staticClass: "weui-panel__bd" }, [
        _c("div", { staticClass: "vux-card-content" }, [_vm._t("content")], 2)
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "weui-panel__ft" }, [
        _vm.footer && _vm.footer.title
          ? _c(
              "a",
              {
                staticClass: "weui-cell weui-cell_access weui-cell_link",
                attrs: { href: "javascript:" },
                on: { click: _vm.onClickFooter }
              },
              [
                _c("div", {
                  staticClass: "weui-cell__bd",
                  domProps: { innerHTML: _vm._s(_vm.footer.title) }
                })
              ]
            )
          : _vm._e()
      ]),
      _vm._v(" "),
      _vm._t("footer")
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-75c3ee6d", esExports)
  }
}

/***/ }),
/* 519 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(520);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("d87a4984", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-a2b01a50\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-a2b01a50\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 520 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.weui-cell_access {\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n  color: inherit;\n}\n.weui-cell_access:active {\n  background-color: #ECECEC;\n}\n.weui-cell_access .weui-cell__ft {\n  padding-right: 13px;\n  position: relative;\n}\n.weui-cell_access .weui-cell__ft:after {\n  content: \" \";\n  display: inline-block;\n  height: 6px;\n  width: 6px;\n  border-width: 2px 2px 0 0;\n  border-color: #C8C8CD;\n  border-style: solid;\n  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);\n  position: relative;\n  top: -2px;\n  position: absolute;\n  top: 50%;\n  margin-top: -4px;\n  right: 2px;\n}\n.weui-cell_link {\n  color: #586C94;\n  font-size: 14px;\n}\n.weui-cell_link.weui-cell:first-child:before {\n  display: block;\n}\n.weui-cell_access.vux-cell-box {\n  padding-right: 13px;\n  position: relative;\n}\n.weui-cell_access.vux-cell-box:after {\n  content: \" \";\n  display: inline-block;\n  height: 6px;\n  width: 6px;\n  border-width: 2px 2px 0 0;\n  border-color: #C8C8CD;\n  border-style: solid;\n  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);\n  position: relative;\n  top: -2px;\n  position: absolute;\n  top: 50%;\n  margin-top: -4px;\n  right: 17px;\n}\n.weui-cells {\n  margin-top: 1.17647059em;\n  background-color: #FFFFFF;\n  line-height: 1.41176471;\n  font-size: 17px;\n  overflow: hidden;\n  position: relative;\n}\n.weui-cells:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.weui-cells:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.weui-cells__title {\n  margin-top: 0.77em;\n  margin-bottom: 0.3em;\n  padding-left: 15px;\n  padding-right: 15px;\n  color: #999999;\n  font-size: 14px;\n}\n.weui-cells__title + .weui-cells {\n  margin-top: 0;\n}\n.weui-cells__tips {\n  margin-top: .3em;\n  color: #999999;\n  padding-left: 15px;\n  padding-right: 15px;\n  font-size: 14px;\n}\n.weui-cell {\n  padding: 10px 15px;\n  position: relative;\n  display: flex;\n  align-items: center;\n}\n.weui-cell:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n  left: 15px;\n}\n.weui-cell:first-child:before {\n  display: none;\n}\n.weui-cell_primary {\n  align-items: flex-start;\n}\n.weui-cell__bd {\n  flex: 1;\n}\n.weui-cell__ft {\n  text-align: right;\n  color: #999999;\n}\n.vux-cell-justify {\n  height: 1.41176471em;\n}\n.vux-cell-justify.vux-cell-justify:after {\n  content: \".\";\n  display: inline-block;\n  width: 100%;\n  overflow: hidden;\n  height: 0;\n}\n/**\n* http://www.zhangxinxu.com/wordpress/2015/01/tips-blank-character-chinese-align/\n*/\n.vux-blank-half:before {\n  content: '\\2002';\n  speak: none;\n}\n.vux-blank-full:before {\n  content: '\\2003';\n  speak: none;\n}\n.vux-no-group-title {\n  margin-top: 0.77em;\n}\n.vux-group-footer-title.weui-cells__title {\n  margin-top: 0.3em;\n  margin-bottom: 0.77em;\n  padding-top: 0;\n  font-size: 12px;\n}\n/* global config for group items */\n.vux-cell-value {\n  color: #999;\n}\n.vux-cell-placeholder {\n  color: #999;\n}\n", ""]);

// exports


/***/ }),
/* 521 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _cleanStyle = __webpack_require__(438);

var _cleanStyle2 = _interopRequireDefault(_cleanStyle);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'group',
  methods: {
    cleanStyle: _cleanStyle2.default
  },
  props: {
    title: String,
    titleColor: String,
    labelWidth: String,
    labelAlign: String,
    labelMarginRight: String,
    gutter: [String, Number],
    footerTitle: String,
    footerTitleColor: String
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 522 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _cleanStyle = __webpack_require__(438);

var _cleanStyle2 = _interopRequireDefault(_cleanStyle);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'group',
  methods: {
    cleanStyle: _cleanStyle2.default
  },
  props: {
    title: String,
    titleColor: String,
    labelWidth: String,
    labelAlign: String,
    labelMarginRight: String,
    gutter: [String, Number],
    footerTitle: String,
    footerTitleColor: String
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 523 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _vm.title
        ? _c("div", {
            staticClass: "weui-cells__title",
            style: _vm.cleanStyle({
              color: _vm.titleColor
            }),
            domProps: { innerHTML: _vm._s(_vm.title) }
          })
        : _vm._e(),
      _vm._v(" "),
      _vm._t("title"),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "weui-cells",
          class: {
            "vux-no-group-title": !_vm.title
          },
          style: _vm.cleanStyle({
            marginTop:
              typeof _vm.gutter === "number" ? _vm.gutter + "px" : _vm.gutter
          })
        },
        [_vm._t("after-title"), _vm._v(" "), _vm._t("default")],
        2
      ),
      _vm._v(" "),
      _vm.footerTitle
        ? _c("div", {
            staticClass: "weui-cells__title vux-group-footer-title",
            style: _vm.cleanStyle({
              color: _vm.footerTitleColor
            }),
            domProps: { innerHTML: _vm._s(_vm.footerTitle) }
          })
        : _vm._e()
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-a2b01a50", esExports)
  }
}

/***/ }),
/* 524 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(525);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("7a7bddcc", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-15a77b8e\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-15a77b8e\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 525 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.weui-cell_access {\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n  color: inherit;\n}\n.weui-cell_access:active {\n  background-color: #ECECEC;\n}\n.weui-cell_access .weui-cell__ft {\n  padding-right: 13px;\n  position: relative;\n}\n.weui-cell_access .weui-cell__ft:after {\n  content: \" \";\n  display: inline-block;\n  height: 6px;\n  width: 6px;\n  border-width: 2px 2px 0 0;\n  border-color: #C8C8CD;\n  border-style: solid;\n  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);\n  position: relative;\n  top: -2px;\n  position: absolute;\n  top: 50%;\n  margin-top: -4px;\n  right: 2px;\n}\n.weui-cell_link {\n  color: #586C94;\n  font-size: 14px;\n}\n.weui-cell_link.weui-cell:first-child:before {\n  display: block;\n}\n.weui-cell_access.vux-cell-box {\n  padding-right: 13px;\n  position: relative;\n}\n.weui-cell_access.vux-cell-box:after {\n  content: \" \";\n  display: inline-block;\n  height: 6px;\n  width: 6px;\n  border-width: 2px 2px 0 0;\n  border-color: #C8C8CD;\n  border-style: solid;\n  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0);\n  position: relative;\n  top: -2px;\n  position: absolute;\n  top: 50%;\n  margin-top: -4px;\n  right: 17px;\n}\n.weui-cells {\n  margin-top: 1.17647059em;\n  background-color: #FFFFFF;\n  line-height: 1.41176471;\n  font-size: 17px;\n  overflow: hidden;\n  position: relative;\n}\n.weui-cells:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.weui-cells:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.weui-cells__title {\n  margin-top: 0.77em;\n  margin-bottom: 0.3em;\n  padding-left: 15px;\n  padding-right: 15px;\n  color: #999999;\n  font-size: 14px;\n}\n.weui-cells__title + .weui-cells {\n  margin-top: 0;\n}\n.weui-cells__tips {\n  margin-top: .3em;\n  color: #999999;\n  padding-left: 15px;\n  padding-right: 15px;\n  font-size: 14px;\n}\n.weui-cell {\n  padding: 10px 15px;\n  position: relative;\n  display: flex;\n  align-items: center;\n}\n.weui-cell:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n  left: 15px;\n}\n.weui-cell:first-child:before {\n  display: none;\n}\n.weui-cell_primary {\n  align-items: flex-start;\n}\n.weui-cell__bd {\n  flex: 1;\n}\n.weui-cell__ft {\n  text-align: right;\n  color: #999999;\n}\n.vux-cell-justify {\n  height: 1.41176471em;\n}\n.vux-cell-justify.vux-cell-justify:after {\n  content: \".\";\n  display: inline-block;\n  width: 100%;\n  overflow: hidden;\n  height: 0;\n}\n.weui-label {\n  display: block;\n  width: 105px;\n  word-wrap: break-word;\n  word-break: break-all;\n}\n.weui-input {\n  width: 100%;\n  border: 0;\n  outline: 0;\n  -webkit-appearance: none;\n  background-color: transparent;\n  font-size: inherit;\n  color: inherit;\n  height: 1.41176471em;\n  line-height: 1.41176471;\n}\n.weui-input::-webkit-outer-spin-button,\n.weui-input::-webkit-inner-spin-button {\n  -webkit-appearance: none;\n  margin: 0;\n}\n.weui-textarea {\n  display: block;\n  border: 0;\n  resize: none;\n  width: 100%;\n  color: inherit;\n  font-size: 1em;\n  line-height: inherit;\n  outline: 0;\n}\n.weui-textarea-counter {\n  color: #B2B2B2;\n  text-align: right;\n}\n.weui-cell_warn .weui-textarea-counter {\n  color: #E64340;\n}\n.weui-toptips {\n  display: none;\n  position: fixed;\n  transform: translateZ(0);\n  top: 0;\n  left: 0;\n  right: 0;\n  padding: 5px;\n  font-size: 14px;\n  text-align: center;\n  color: #FFF;\n  z-index: 5000;\n  word-wrap: break-word;\n  word-break: break-all;\n}\n.weui-toptips_warn {\n  background-color: #E64340;\n}\n.weui-cells_form .weui-cell__ft {\n  font-size: 0;\n}\n.weui-cells_form .weui-icon-warn {\n  display: none;\n}\n.weui-cells_form input,\n.weui-cells_form textarea,\n.weui-cells_form label[for] {\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n}\n.weui-cell_warn {\n  color: #E64340;\n}\n.weui-cell_warn .weui-icon-warn {\n  display: inline-block;\n}\n.weui-cell_vcode {\n  padding-top: 0;\n  padding-right: 0;\n  padding-bottom: 0;\n}\n.weui-vcode-img {\n  margin-left: 5px;\n  height: 44px;\n  vertical-align: middle;\n}\n.weui-vcode-btn {\n  display: inline-block;\n  height: 44px;\n  margin-left: 5px;\n  padding: 0 0.6em 0 0.7em;\n  border-left: 1px solid #E5E5E5;\n  line-height: 44px;\n  vertical-align: middle;\n  font-size: 17px;\n  color: #3CC51F;\n}\nbutton.weui-vcode-btn {\n  background-color: transparent;\n  border-top: 0;\n  border-right: 0;\n  border-bottom: 0;\n  outline: 0;\n}\n.weui-vcode-btn:active {\n  color: #52a341;\n}\n.vux-x-input .vux-x-input-placeholder-right input::-webkit-input-placeholder {\n  text-align: right;\n}\n.vux-x-input .vux-x-input-placeholder-center input::-webkit-input-placeholder {\n  text-align: center;\n}\n.vux-x-input .vux-input-icon {\n  font-size: 21px;\n}\n.vux-input-icon.weui-icon-warn:before,\n.vux-input-icon.weui-icon-success:before {\n  font-size: 21px;\n}\n.vux-x-input .weui-icon {\n  padding-left: 5px;\n}\n.vux-x-input.weui-cell_vcode {\n  padding-top: 0;\n  padding-right: 0;\n  padding-bottom: 0;\n}\n.vux-x-input.disabled .weui-input {\n  text-fill-color: #888;\n  -webkit-text-fill-color: #888;\n  /* Override iOS / Android font color change */\n  opacity: 1;\n  /* Override iOS opacity change affecting text & background color */\n}\n.vux-x-input-right-full {\n  margin-left: 5px;\n  height: 44px;\n  vertical-align: middle;\n}\n.vux-x-input-right-full img {\n  height: 44px;\n}\n.vux-x-input-has-right-full {\n  padding-top: 0;\n  padding-right: 0;\n  padding-bottom: 0;\n}\n", ""]);

// exports


/***/ }),
/* 526 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keys = __webpack_require__(439);

var _keys2 = _interopRequireDefault(_keys);

var _base = __webpack_require__(457);

var _base2 = _interopRequireDefault(_base);

var _icon = __webpack_require__(458);

var _icon2 = _interopRequireDefault(_icon);

var _toast = __webpack_require__(459);

var _toast2 = _interopRequireDefault(_toast);

var _inlineDesc = __webpack_require__(435);

var _inlineDesc2 = _interopRequireDefault(_inlineDesc);

var _isEmail = __webpack_require__(461);

var _isEmail2 = _interopRequireDefault(_isEmail);

var _isMobilePhone = __webpack_require__(463);

var _isMobilePhone2 = _interopRequireDefault(_isMobilePhone);

var _debounce = __webpack_require__(464);

var _debounce2 = _interopRequireDefault(_debounce);

var _vanillaMasker = __webpack_require__(465);

var _vanillaMasker2 = _interopRequireDefault(_vanillaMasker);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var validators = {
  'email': {
    fn: _isEmail2.default,
    msg: '邮箱格式'
  },
  'china-mobile': {
    fn: function fn(str) {
      return (0, _isMobilePhone2.default)(str, 'zh-CN');
    },

    msg: '手机号码'
  },
  'china-name': {
    fn: function fn(str) {
      return str.length >= 2 && str.length <= 6;
    },

    msg: '中文姓名'
  }
};
exports.default = {
  name: 'x-input',
  created: function created() {
    var _this = this;

    this.currentValue = this.value === undefined || this.value === null ? '' : this.mask ? this.maskValue(this.value) : this.value;
    /* istanbul ignore if */
    if (process.env.NODE_ENV === 'development') {
      if (!this.title && !this.placeholder && !this.currentValue) {
        console.warn('no title and no placeholder?');
      }
    }

    if (this.required && (typeof this.currentValue === 'undefined' || this.currentValue === '')) {
      this.valid = false;
    }
    this.handleChangeEvent = true;
    if (this.debounce) {
      this._debounce = (0, _debounce2.default)(function () {
        _this.$emit('on-change', _this.currentValue);
      }, this.debounce);
    }
  },
  beforeMount: function beforeMount() {
    if (this.$slots && this.$slots['restricted-label']) {
      this.hasRestrictedLabel = true;
    }
    if (this.$slots && this.$slots['right-full-height']) {
      this.hasRightFullHeightSlot = true;
    }
  },
  beforeDestroy: function beforeDestroy() {
    if (this._debounce) {
      this._debounce.cancel();
    }
    window.removeEventListener('resize', this.scrollIntoView);
  },

  mixins: [_base2.default],
  components: {
    Icon: _icon2.default,
    InlineDesc: _inlineDesc2.default,
    Toast: _toast2.default
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'text'
    },
    placeholder: String,
    value: [String, Number],
    name: String,
    readonly: Boolean,
    disabled: Boolean,
    keyboard: String,
    inlineDesc: String,
    isType: [String, Function],
    min: Number,
    max: Number,
    showClear: {
      type: Boolean,
      default: true
    },
    equalWith: String,
    textAlign: String,
    // https://github.com/yisibl/blog/issues/3
    autocomplete: {
      type: String,
      default: 'off'
    },
    autocapitalize: {
      type: String,
      default: 'off'
    },
    autocorrect: {
      type: String,
      default: 'off'
    },
    spellcheck: {
      type: String,
      default: 'false'
    },
    novalidate: {
      type: Boolean,
      default: false
    },
    iconType: String,
    debounce: Number,
    placeholderAlign: String,
    labelWidth: String,
    mask: String,
    shouldToastError: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    labelStyles: function labelStyles() {
      return {
        width: this.labelWidthComputed || this.$parent.labelWidth || this.labelWidthComputed,
        textAlign: this.$parent.labelAlign,
        marginRight: this.$parent.labelMarginRight
      };
    },
    labelClass: function labelClass() {
      return {
        'vux-cell-justify': this.$parent.labelAlign === 'justify' || this.$parent.$parent.labelAlign === 'justify'
      };
    },
    pattern: function pattern() {
      if (this.keyboard === 'number' || this.isType === 'china-mobile') {
        return '[0-9]*';
      }
    },
    labelWidthComputed: function labelWidthComputed() {
      var width = this.title.replace(/[^x00-xff]/g, '00').length / 2 + 1;
      if (width < 10) {
        return width + 'em';
      }
    },
    hasErrors: function hasErrors() {
      return (0, _keys2.default)(this.errors).length > 0;
    },
    inputStyle: function inputStyle() {
      if (this.textAlign) {
        return {
          textAlign: this.textAlign
        };
      }
    },
    showWarn: function showWarn() {
      return !this.novalidate && !this.equalWith && !this.valid && this.firstError && (this.touched || this.forceShowError);
    }
  },
  mounted: function mounted() {
    window.addEventListener('resize', this.scrollIntoView);
  },

  methods: {
    scrollIntoView: function scrollIntoView() {
      var _this2 = this;

      var time = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

      // alert('scroll into view')
      if (/iphone/i.test(navigator.userAgent)) {
        // return
      }
      if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') {
        // alert('will scroll')
        setTimeout(function () {
          // alert(this.$refs.input.length)
          _this2.$refs.input.scrollIntoViewIfNeeded(true);
        }, time);
      }
    },
    onClickErrorIcon: function onClickErrorIcon() {
      if (this.shouldToastError && this.firstError) {
        this.showErrorToast = true;
      }
      this.$emit('on-click-error-icon', this.firstError);
    },
    maskValue: function maskValue(val) {
      var val1 = this.mask ? _vanillaMasker2.default.toPattern(val, this.mask) : val;
      return val1;
    },
    reset: function reset() {
      var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';

      this.dirty = false;
      this.currentValue = value;
      this.firstError = '';
      this.valid = true;
    },
    clear: function clear() {
      this.currentValue = '';
      this.focus();
      this.$emit('on-click-clear-icon');
    },
    focus: function focus() {
      this.$refs.input.focus();
    },
    blur: function blur() {
      this.$refs.input.blur();
    },
    focusHandler: function focusHandler($event) {
      var _this3 = this;

      this.$emit('on-focus', this.currentValue, $event);
      this.isFocus = true;
      // this.scrollIntoView(500)
      // this.scrollIntoView(5000)
      setTimeout(function () {
        _this3.$refs.input.scrollIntoViewIfNeeded(false);
        // this.$refs.input.scrollIntoViewIfNeeded()
      }, 1000);
      // $event.target.
    },
    onBlur: function onBlur($event) {
      this.setTouched();
      this.validate();
      this.isFocus = false;
      this.$emit('on-blur', this.currentValue, $event);
    },
    onKeyUp: function onKeyUp(e) {
      if (e.key === 'Enter') {
        e.target.blur();
        this.$emit('on-enter', this.currentValue, e);
      }
    },
    getError: function getError() {
      var key = (0, _keys2.default)(this.errors)[0];
      this.firstError = this.errors[key];
    },
    validate: function validate() {
      if (typeof this.equalWith !== 'undefined') {
        this.validateEqual();
        return;
      }
      this.errors = {};

      if (!this.currentValue && !this.required) {
        this.valid = true;
        return;
      }

      if (!this.currentValue && this.required) {
        this.valid = false;
        this.errors.required = '必填哦';
        this.getError();
        return;
      }

      if (typeof this.isType === 'string') {
        var validator = validators[this.isType];
        if (validator) {
          var value = this.currentValue;

          if (this.isType === 'china-mobile' && this.mask === '999 9999 9999') {
            value = this.currentValue.replace(/\s+/g, '');
          }

          this.valid = validator['fn'](value);
          if (!this.valid) {
            this.forceShowError = true;
            this.errors.format = validator['msg'] + '格式不对哦~';
            this.getError();
            return;
          } else {
            delete this.errors.format;
          }
        }
      }

      if (typeof this.isType === 'function') {
        var validStatus = this.isType(this.currentValue);
        this.valid = validStatus.valid;
        if (!this.valid) {
          this.errors.format = validStatus.msg;
          this.forceShowError = true;
          this.getError();
          return;
        } else {
          delete this.errors.format;
        }
      }

      if (this.min) {
        if (this.currentValue.length < this.min) {
          this.errors.min = '\u6700\u5C11\u5E94\u8BE5\u8F93\u5165' + this.min + '\u4E2A\u5B57\u7B26\u54E6';
          this.valid = false;
          this.getError();
          return;
        } else {
          delete this.errors.min;
        }
      }

      if (this.max) {
        if (this.currentValue.length > this.max) {
          this.errors.max = '\u6700\u591A\u53EF\u4EE5\u8F93\u5165' + this.max + '\u4E2A\u5B57\u7B26\u54E6';
          this.valid = false;
          this.forceShowError = true;
          return;
        } else {
          this.forceShowError = false;
          delete this.errors.max;
        }
      }

      this.valid = true;
    },
    validateEqual: function validateEqual() {
      if (!this.equalWith && this.currentValue) {
        this.valid = false;
        this.errors.equal = '输入不一致';
        return;
      }
      var willCheck = this.dirty || this.currentValue.length >= this.equalWith.length;
      // 只在长度符合时显示正确与否
      if (willCheck && this.currentValue !== this.equalWith) {
        this.valid = false;
        this.errors.equal = '输入不一致';
        return;
      } else {
        if (!this.currentValue && this.required) {
          this.valid = false;
        } else {
          this.valid = true;
          delete this.errors.equal;
        }
      }
    },

    // #2810
    _getInputMaskSelection: function _getInputMaskSelection(selection, direction, maskVal, loop) {
      if (!this.mask || loop && direction === 0) {
        return selection;
      }
      if (direction === 0) {
        direction = this.lastDirection;
      }
      if (direction > 0) {
        var maskChar = this.mask.substr(selection - direction, 1);
        if (!maskChar.match(/[9SA]/)) {
          return this._getInputMaskSelection(selection + 1, direction, maskVal, true);
        }
      }
      return selection;
    }
  },
  data: function data() {
    return {
      hasRightFullHeightSlot: false,
      hasRestrictedLabel: false,
      firstError: '',
      forceShowError: false,
      hasLengthEqual: false,
      valid: true,
      currentValue: '',
      showErrorToast: false,
      isFocus: false
    };
  },

  watch: {
    mask: function mask(val) {
      if (val && this.currentValue) {
        this.currentValue = this.maskValue(this.currentValue);
      }
    },
    valid: function valid() {
      this.getError();
    },
    value: function value(val) {
      this.currentValue = val;
    },
    equalWith: function equalWith(newVal) {
      if (newVal && this.equalWith) {
        if (newVal.length === this.equalWith.length) {
          this.hasLengthEqual = true;
        }
        this.validateEqual();
      } else {
        this.validate();
      }
    },
    currentValue: function currentValue(newVal, oldVal) {
      var _this4 = this;

      if (!this.equalWith && newVal) {
        this.validateEqual();
      }
      if (newVal && this.equalWith) {
        if (newVal.length === this.equalWith.length) {
          this.hasLengthEqual = true;
        }
        this.validateEqual();
      } else {
        this.validate();
      }

      var selection = this.$refs.input.selectionStart;
      var direction = newVal.length - oldVal.length;
      selection = this._getInputMaskSelection(selection, direction, this.maskValue(newVal));
      this.lastDirection = direction;
      this.$emit('input', this.maskValue(newVal));
      // #2810
      this.$nextTick(function () {
        if (_this4.$refs.input.selectionStart !== selection) {
          _this4.$refs.input.selectionStart = selection;
          _this4.$refs.input.selectionEnd = selection;
        }
        if (_this4.currentValue !== _this4.maskValue(newVal)) {
          _this4.currentValue = _this4.maskValue(newVal);
        }
      });

      if (this._debounce) {
        this._debounce();
      } else {
        this.$emit('on-change', newVal);
      }
    }
  }
};
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(56)))

/***/ }),
/* 527 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(528);
module.exports = __webpack_require__(48).Object.keys;


/***/ }),
/* 528 */
/***/ (function(module, exports, __webpack_require__) {

// 19.1.2.14 Object.keys(O)
var toObject = __webpack_require__(120);
var $keys = __webpack_require__(166);

__webpack_require__(529)('keys', function () {
  return function keys(it) {
    return $keys(toObject(it));
  };
});


/***/ }),
/* 529 */
/***/ (function(module, exports, __webpack_require__) {

// most Object methods by ES6 should accept primitives
var $export = __webpack_require__(110);
var core = __webpack_require__(48);
var fails = __webpack_require__(111);
module.exports = function (KEY, exec) {
  var fn = (core.Object || {})[KEY] || Object[KEY];
  var exp = {};
  exp[KEY] = exec(fn);
  $export($export.S + $export.F * fails(function () { fn(1); }), 'Object', exp);
};


/***/ }),
/* 530 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(531);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("4e5f730a", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-57d6c096\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-57d6c096\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 531 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "\n@font-face {\n  font-weight: normal;\n  font-style: normal;\n  font-family: \"weui\";\n  src: url('data:application/octet-stream;base64,AAEAAAALAIAAAwAwR1NVQrD+s+0AAAE4AAAAQk9TLzJAKEx+AAABfAAAAFZjbWFw65cFHQAAAhwAAAJQZ2x5ZvCRR/EAAASUAAAKtGhlYWQMPROtAAAA4AAAADZoaGVhCCwD+gAAALwAAAAkaG10eEJo//8AAAHUAAAASGxvY2EYqhW4AAAEbAAAACZtYXhwASEAVQAAARgAAAAgbmFtZeNcHtgAAA9IAAAB5nBvc3T6bLhLAAARMAAAAOYAAQAAA+gAAABaA+j/////A+kAAQAAAAAAAAAAAAAAAAAAABIAAQAAAAEAACbZbxtfDzz1AAsD6AAAAADUm2dvAAAAANSbZ2///wAAA+kD6gAAAAgAAgAAAAAAAAABAAAAEgBJAAUAAAAAAAIAAAAKAAoAAAD/AAAAAAAAAAEAAAAKAB4ALAABREZMVAAIAAQAAAAAAAAAAQAAAAFsaWdhAAgAAAABAAAAAQAEAAQAAAABAAgAAQAGAAAAAQAAAAAAAQOwAZAABQAIAnoCvAAAAIwCegK8AAAB4AAxAQIAAAIABQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUGZFZABA6gHqEQPoAAAAWgPqAAAAAAABAAAAAAAAAAAAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+j//wPoAAAD6AAAAAAABQAAAAMAAAAsAAAABAAAAXQAAQAAAAAAbgADAAEAAAAsAAMACgAAAXQABABCAAAABAAEAAEAAOoR//8AAOoB//8AAAABAAQAAAABAAIAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQABEAAAEGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAAAANwAAAAAAAAAEQAA6gEAAOoBAAAAAQAA6gIAAOoCAAAAAgAA6gMAAOoDAAAAAwAA6gQAAOoEAAAABAAA6gUAAOoFAAAABQAA6gYAAOoGAAAABgAA6gcAAOoHAAAABwAA6ggAAOoIAAAACAAA6gkAAOoJAAAACQAA6goAAOoKAAAACgAA6gsAAOoLAAAACwAA6gwAAOoMAAAADAAA6g0AAOoNAAAADQAA6g4AAOoOAAAADgAA6g8AAOoPAAAADwAA6hAAAOoQAAAAEAAA6hEAAOoRAAAAEQAAAAAARgCMANIBJAF4AcQCMgJgAqgC/ANIA6YD/gROBKAE9AVaAAAAAgAAAAADrwOtABQAKQAAASIHBgcGFBcWFxYyNzY3NjQnJicmAyInJicmNDc2NzYyFxYXFhQHBgcGAfV4Z2Q7PDw7ZGfwZmQ7PDw7ZGZ4bl5bNjc3Nlte215bNjc3NlteA608O2Rn8GdjOzw8O2Nn8GdkOzz8rzc1W17bXlw1Nzc1XF7bXls1NwAAAAACAAAAAAOzA7MAFwAtAAABIgcGBwYVFBcWFxYzMjc2NzY1NCcmJyYTBwYiLwEmNjsBETQ2OwEyFhURMzIWAe52Z2Q7PT07ZGd2fGpmOz4+O2ZpIXYOKA52Dg0XXQsHJgcLXRcNA7M+O2ZqfHZnZDs9PTtkZ3Z9aWY7Pv3wmhISmhIaARcICwsI/ukaAAMAAAAAA+UD5QAXACMALAAAASIHBgcGFRQXFhcWMzI3Njc2NTQnJicmAxQrASI1AzQ7ATIHJyImNDYyFhQGAe6Ecm9BRERBb3KEiXZxQkREQnF1aQIxAwgCQgMBIxIZGSQZGQPkREJxdomEcm9BRERBb3KEinVxQkT9HQICAWICAjEZIxkZIxkAAAAAAgAAAAADsQPkABkALgAAAQYHBgc2BREUFxYXFhc2NzY3NjURJBcmJyYTAQYvASY/ATYyHwEWNjclNjIfARYB9VVVQk+v/tFHPmxebGxdbT1I/tGvT0JVo/7VBASKAwMSAQUBcQEFAgESAgUBEQQD4xMYEhk3YP6sjnVlSD8cHD9IZXWOAVRgNxkSGP62/tkDA48EBBkCAVYCAQHlAQIQBAAAAAADAAAAAAOxA+QAGwAqADMAAAEGBwYHBgcGNxEUFxYXFhc2NzY3NjURJBcmJyYHMzIWFQMUBisBIicDNDYTIiY0NjIWFAYB9UFBODssO38gRz5sXmxsXW09SP7YqFBBVW80BAYMAwImBQELBh4PFhYeFRUD5A8SDhIOEikK/q2PdWRJPh0dPklkdY8BU141GRIY/AYE/sYCAwUBOgQG/kAVHxUVHxUAAAACAAAAAAPkA+QAFwAtAAABIgcGBwYVFBcWFxYzMjc2NzY1NCcmJyYTAQYiLwEmPwE2Mh8BFjI3ATYyHwEWAe6Ecm9BQ0NCbnODiXVxQkREQnF1kf6gAQUBowMDFgEFAYUCBQEBQwIFARUEA+NEQnF1iYNzbkJDQ0FvcoSJdXFCRP6j/qUBAagEBR4CAWYBAQENAgIVBAAAAAQAAAAAA68DrQAUACkAPwBDAAABIgcGBwYUFxYXFjI3Njc2NCcmJyYDIicmJyY0NzY3NjIXFhcWFAcGBwYTBQ4BLwEmBg8BBhYfARYyNwE+ASYiFzAfAQH1eGdkOzw8O2Rn8GZkOzw8O2RmeG5eWzY3NzZbXtteWzY3NzZbXmn+9gYSBmAGDwUDBQEGfQUQBgElBQELEBUBAQOtPDtkZ/BnYzs8PDtjZ/BnZDs8/K83NVte215cNTc3NVxe215bNTcCJt0FAQVJBQIGBAcRBoAGBQEhBQ8LBAEBAAABAAAAAAO7AzoAFwAAEy4BPwE+AR8BFjY3ATYWFycWFAcBBiInPQoGBwUHGgzLDCELAh0LHwsNCgr9uQoeCgGzCyEOCw0HCZMJAQoBvgkCCg0LHQv9sQsKAAAAAAIAAAAAA+UD5gAXACwAAAEiBwYHBhUUFxYXFjMyNzY3NjU0JyYnJhMHBi8BJicmNRM0NjsBMhYVExceAQHvhHJvQUNDQm5zg4l1cUJEREJxdVcQAwT6AwIEEAMCKwIDDsUCAQPlREJxdYmDc25CQ0NBb3KEiXVxQkT9VhwEAncCAgMGAXoCAwMC/q2FAgQAAAQAAAAAA68DrQADABgALQAzAAABMB8BAyIHBgcGFBcWFxYyNzY3NjQnJicmAyInJicmNDc2NzYyFxYXFhQHBgcGAyMVMzUjAuUBAfJ4Z2Q7PDw7ZGfwZmQ7PDw7ZGZ4bl5bNjc3Nlte215bNjc3NltemyT92QKDAQEBLDw7ZGfwZ2M7PDw7Y2fwZ2Q7PPyvNzVbXtteXDU3NzVcXtteWzU3AjH9JAAAAAMAAAAAA+QD5AAXACcAMAAAASIHBgcGFRQXFhcWMzI3Njc2NTQnJicmAzMyFhUDFAYrASImNQM0NhMiJjQ2MhYUBgHuhHJvQUNDQm5zg4l1cUJEREJxdZ42BAYMAwInAwMMBh8PFhYeFhYD40RCcXWJg3NuQkNDQW9yhIl1cUJE/vYGBf7AAgMDAgFABQb+NhYfFhYfFgAABAAAAAADwAPAAAgAEgAoAD0AAAEyNjQmIgYUFhcjFTMRIxUzNSMDIgcGBwYVFBYXFjMyNzY3NjU0Jy4BAyInJicmNDc2NzYyFxYXFhQHBgcGAfQYISEwISFRjzk5yTorhG5rPT99am+DdmhlPD4+PMyFbV5bNTc3NVte2l5bNTc3NVteAqAiLyIiLyI5Hf7EHBwCsT89a26Ed8w8Pj48ZWh2g29qffyjNzVbXtpeWzU3NzVbXtpeWzU3AAADAAAAAAOoA6gACwAgADUAAAEHJwcXBxc3FzcnNwMiBwYHBhQXFhcWMjc2NzY0JyYnJgMiJyYnJjQ3Njc2MhcWFxYUBwYHBgKOmpocmpocmpocmpq2dmZiOjs7OmJm7GZiOjs7OmJmdmtdWTQ2NjRZXdZdWTQ2NjRZXQKqmpocmpocmpocmpoBGTs6YmbsZmI6Ozs6YmbsZmI6O/zCNjRZXdZdWTQ2NjRZXdZdWTQ2AAMAAAAAA+kD6gAaAC8AMAAAAQYHBiMiJyYnJjQ3Njc2MhcWFxYVFAcGBwEHATI3Njc2NCcmJyYiBwYHBhQXFhcWMwKONUBCR21dWjU3NzVaXdpdWzU2GBcrASM5/eBXS0grKysrSEuuSkkqLCwqSUpXASMrFxg2NVtd2l1aNTc3NVpdbUdCQDX+3jkBGSsrSEuuSkkqLCwqSUquS0grKwAC//8AAAPoA+gAFAAwAAABIgcGBwYQFxYXFiA3Njc2ECcmJyYTFg4BIi8BBwYuATQ/AScmPgEWHwE3Nh4BBg8BAfSIdHFDRERDcXQBEHRxQ0REQ3F0SQoBFBsKoqgKGxMKqKIKARQbCqKoChsUAQqoA+hEQ3F0/vB0cUNERENxdAEQdHFDRP1jChsTCqiiCgEUGwqiqAobFAEKqKIKARQbCqIAAAIAAAAAA+QD5AAXADQAAAEiBwYHBhUUFxYXFjMyNzY3NjU0JyYnJhMUBiMFFxYUDwEGLwEuAT8BNh8BFhQPAQUyFh0BAe6Ecm9BQ0NCbnODiXVxQkREQnF1fwQC/pGDAQEVAwTsAgEC7AQEFAIBhAFwAgMD40RCcXWJg3NuQkNDQW9yhIl1cUJE/fYCAwuVAgQCFAQE0AIFAtEEBBQCBQGVCwMDJwAAAAUAAAAAA9QD0wAjACcANwBHAEgAAAERFAYjISImNREjIiY9ATQ2MyE1NDYzITIWHQEhMhYdARQGIyERIREHIgYVERQWOwEyNjURNCYjISIGFREUFjsBMjY1ETQmKwEDeyYb/XYbJkMJDQ0JAQYZEgEvExkBBgkNDQn9CQJc0QkNDQktCQ0NCf7sCQ0NCS0JDQ0JLQMi/TQbJiYbAswMCiwJDS4SGRkSLg0JLAoM/UwCtGsNCf5NCQ0NCQGzCQ0NCf5NCQ0NCQGzCQ0AAAAAEADGAAEAAAAAAAEABAAAAAEAAAAAAAIABwAEAAEAAAAAAAMABAALAAEAAAAAAAQABAAPAAEAAAAAAAUACwATAAEAAAAAAAYABAAeAAEAAAAAAAoAKwAiAAEAAAAAAAsAEwBNAAMAAQQJAAEACABgAAMAAQQJAAIADgBoAAMAAQQJAAMACAB2AAMAAQQJAAQACAB+AAMAAQQJAAUAFgCGAAMAAQQJAAYACACcAAMAAQQJAAoAVgCkAAMAAQQJAAsAJgD6d2V1aVJlZ3VsYXJ3ZXVpd2V1aVZlcnNpb24gMS4wd2V1aUdlbmVyYXRlZCBieSBzdmcydHRmIGZyb20gRm9udGVsbG8gcHJvamVjdC5odHRwOi8vZm9udGVsbG8uY29tAHcAZQB1AGkAUgBlAGcAdQBsAGEAcgB3AGUAdQBpAHcAZQB1AGkAVgBlAHIAcwBpAG8AbgAgADEALgAwAHcAZQB1AGkARwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABzAHYAZwAyAHQAdABmACAAZgByAG8AbQAgAEYAbwBuAHQAZQBsAGwAbwAgAHAAcgBvAGoAZQBjAHQALgBoAHQAdABwADoALwAvAGYAbwBuAHQAZQBsAGwAbwAuAGMAbwBtAAAAAgAAAAAAAAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASAQIBAwEEAQUBBgEHAQgBCQEKAQsBDAENAQ4BDwEQAREBEgETAAZjaXJjbGUIZG93bmxvYWQEaW5mbwxzYWZlX3N1Y2Nlc3MJc2FmZV93YXJuB3N1Y2Nlc3MOc3VjY2Vzcy1jaXJjbGURc3VjY2Vzcy1uby1jaXJjbGUHd2FpdGluZw53YWl0aW5nLWNpcmNsZQR3YXJuC2luZm8tY2lyY2xlBmNhbmNlbAZzZWFyY2gFY2xlYXIEYmFjawZkZWxldGUAAAAA') format('truetype');\n}\n[class^=\"weui-icon-\"],\n[class*=\" weui-icon-\"] {\n  display: inline-block;\n  vertical-align: middle;\n  font: normal normal normal 14px/1 \"weui\";\n  font-size: inherit;\n  text-rendering: auto;\n  -webkit-font-smoothing: antialiased;\n}\n[class^=\"weui-icon-\"]:before,\n[class*=\" weui-icon-\"]:before {\n  display: inline-block;\n  margin-left: .2em;\n  margin-right: .2em;\n}\n.weui-icon-circle:before {\n  content: \"\\EA01\";\n}\n/* '' */\n.weui-icon-download:before {\n  content: \"\\EA02\";\n}\n/* '' */\n.weui-icon-info:before {\n  content: \"\\EA03\";\n}\n/* '' */\n.weui-icon-safe-success:before {\n  content: \"\\EA04\";\n}\n/* '' */\n.weui-icon-safe-warn:before {\n  content: \"\\EA05\";\n}\n/* '' */\n.weui-icon-success:before {\n  content: \"\\EA06\";\n}\n/* '' */\n.weui-icon-success-circle:before {\n  content: \"\\EA07\";\n}\n/* '' */\n.weui-icon-success-no-circle:before {\n  content: \"\\EA08\";\n}\n/* '' */\n.weui-icon-waiting:before {\n  content: \"\\EA09\";\n}\n/* '' */\n.weui-icon-waiting-circle:before {\n  content: \"\\EA0A\";\n}\n/* '' */\n.weui-icon-warn:before {\n  content: \"\\EA0B\";\n}\n/* '' */\n.weui-icon-info-circle:before {\n  content: \"\\EA0C\";\n}\n/* '' */\n.weui-icon-cancel:before {\n  content: \"\\EA0D\";\n}\n/* '' */\n.weui-icon-search:before {\n  content: \"\\EA0E\";\n}\n/* '' */\n.weui-icon-clear:before {\n  content: \"\\EA0F\";\n}\n/* '' */\n.weui-icon-back:before {\n  content: \"\\EA10\";\n}\n/* '' */\n.weui-icon-delete:before {\n  content: \"\\EA11\";\n}\n/* '' */\n/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n[class^=\"weui-icon_\"]:before,\n[class*=\" weui-icon_\"]:before {\n  margin: 0;\n}\n.weui-icon-success {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-waiting {\n  font-size: 23px;\n  color: #10AEFF;\n}\n.weui-icon-warn {\n  font-size: 23px;\n  color: #F43530;\n}\n.weui-icon-info {\n  font-size: 23px;\n  color: #10AEFF;\n}\n.weui-icon-success-circle {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-success-no-circle {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-waiting-circle {\n  font-size: 23px;\n  color: #10AEFF;\n}\n.weui-icon-circle {\n  font-size: 23px;\n  color: #C9C9C9;\n}\n.weui-icon-download {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-info-circle {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-safe-success {\n  color: #09BB07;\n}\n.weui-icon-safe-warn {\n  color: #FFBE00;\n}\n.weui-icon-cancel {\n  color: #F43530;\n  font-size: 22px;\n}\n.weui-icon-search {\n  color: #B2B2B2;\n  font-size: 14px;\n}\n.weui-icon-clear {\n  color: #B2B2B2;\n  font-size: 14px;\n}\n.weui-icon-delete.weui-icon_gallery-delete {\n  color: #FFFFFF;\n  font-size: 22px;\n}\n.weui-icon_msg {\n  font-size: 93px;\n}\n.weui-icon_msg.weui-icon-warn {\n  color: #F76260;\n}\n.weui-icon_msg-primary {\n  font-size: 93px;\n}\n.weui-icon_msg-primary.weui-icon-warn {\n  color: #FFBE00;\n}\n/**\nfollowing styles will be removed after v3.0.0\n*/\n.icon-big:before {\n  font-size: 93px;\n}\n", ""]);

// exports


/***/ }),
/* 532 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//

exports.default = {
  name: 'icon',
  props: {
    type: String,
    isMsg: Boolean
  },
  computed: {
    className: function className() {
      // compatible with old type param
      return 'weui-icon weui_icon_' + this.type + ' weui-icon-' + this.type.replace(/_/g, '-');
    }
  }
};

/***/ }),
/* 533 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//

exports.default = {
  name: 'icon',
  props: {
    type: String,
    isMsg: Boolean
  },
  computed: {
    className: function className() {
      // compatible with old type param
      return 'weui-icon weui_icon_' + this.type + ' weui-icon-' + this.type.replace(/_/g, '-');
    }
  }
};

/***/ }),
/* 534 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("i", { class: [_vm.className, _vm.isMsg ? "weui-icon_msg" : ""] })
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-57d6c096", esExports)
  }
}

/***/ }),
/* 535 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(536);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("487f46f1", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-5b8fbf00\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-5b8fbf00\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 536 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "\n.vux-fade-enter-active,\n.vux-fade-leave-active {\n  opacity: 1;\n  transition: opacity linear 0.2s;\n}\n.vux-fade-enter,\n.vux-fade-leave-to {\n  opacity: 0;\n}\n.vux-dialog-enter-active {\n  animation: vux-dialog-in 0.5s;\n}\n.vux-dialog-leave-active {\n  animation: vux-dialog-out 0.3s;\n}\n@keyframes vux-dialog-in {\n0% {\n    transform: scale(1.185);\n    opacity: 0;\n}\n100% {\n    transform: scale(1);\n    opacity: 1;\n}\n}\n@keyframes vux-dialog-out {\n0% {\n    transform: scale(1);\n    opacity: 1;\n}\n100% {\n    transform: scale(0.85);\n    opacity: 0;\n}\n}\n.vux-mask-enter,\n.vux-mask-leave-active {\n  opacity: 0;\n}\n.vux-mask-leave-active,\n.vux-mask-enter-active {\n  transition: opacity 300ms;\n}\n/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.weui-mask {\n  position: fixed;\n  z-index: 1000;\n  top: 0;\n  right: 0;\n  left: 0;\n  bottom: 0;\n  background: rgba(0, 0, 0, 0.6);\n}\n.weui-mask_transparent {\n  position: fixed;\n  z-index: 1000;\n  top: 0;\n  right: 0;\n  left: 0;\n  bottom: 0;\n}\n@font-face {\n  font-weight: normal;\n  font-style: normal;\n  font-family: \"weui\";\n  src: url('data:application/octet-stream;base64,AAEAAAALAIAAAwAwR1NVQrD+s+0AAAE4AAAAQk9TLzJAKEx+AAABfAAAAFZjbWFw65cFHQAAAhwAAAJQZ2x5ZvCRR/EAAASUAAAKtGhlYWQMPROtAAAA4AAAADZoaGVhCCwD+gAAALwAAAAkaG10eEJo//8AAAHUAAAASGxvY2EYqhW4AAAEbAAAACZtYXhwASEAVQAAARgAAAAgbmFtZeNcHtgAAA9IAAAB5nBvc3T6bLhLAAARMAAAAOYAAQAAA+gAAABaA+j/////A+kAAQAAAAAAAAAAAAAAAAAAABIAAQAAAAEAACbZbxtfDzz1AAsD6AAAAADUm2dvAAAAANSbZ2///wAAA+kD6gAAAAgAAgAAAAAAAAABAAAAEgBJAAUAAAAAAAIAAAAKAAoAAAD/AAAAAAAAAAEAAAAKAB4ALAABREZMVAAIAAQAAAAAAAAAAQAAAAFsaWdhAAgAAAABAAAAAQAEAAQAAAABAAgAAQAGAAAAAQAAAAAAAQOwAZAABQAIAnoCvAAAAIwCegK8AAAB4AAxAQIAAAIABQMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUGZFZABA6gHqEQPoAAAAWgPqAAAAAAABAAAAAAAAAAAAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+gAAAPoAAAD6AAAA+j//wPoAAAD6AAAAAAABQAAAAMAAAAsAAAABAAAAXQAAQAAAAAAbgADAAEAAAAsAAMACgAAAXQABABCAAAABAAEAAEAAOoR//8AAOoB//8AAAABAAQAAAABAAIAAwAEAAUABgAHAAgACQAKAAsADAANAA4ADwAQABEAAAEGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwAAAAAANwAAAAAAAAAEQAA6gEAAOoBAAAAAQAA6gIAAOoCAAAAAgAA6gMAAOoDAAAAAwAA6gQAAOoEAAAABAAA6gUAAOoFAAAABQAA6gYAAOoGAAAABgAA6gcAAOoHAAAABwAA6ggAAOoIAAAACAAA6gkAAOoJAAAACQAA6goAAOoKAAAACgAA6gsAAOoLAAAACwAA6gwAAOoMAAAADAAA6g0AAOoNAAAADQAA6g4AAOoOAAAADgAA6g8AAOoPAAAADwAA6hAAAOoQAAAAEAAA6hEAAOoRAAAAEQAAAAAARgCMANIBJAF4AcQCMgJgAqgC/ANIA6YD/gROBKAE9AVaAAAAAgAAAAADrwOtABQAKQAAASIHBgcGFBcWFxYyNzY3NjQnJicmAyInJicmNDc2NzYyFxYXFhQHBgcGAfV4Z2Q7PDw7ZGfwZmQ7PDw7ZGZ4bl5bNjc3Nlte215bNjc3NlteA608O2Rn8GdjOzw8O2Nn8GdkOzz8rzc1W17bXlw1Nzc1XF7bXls1NwAAAAACAAAAAAOzA7MAFwAtAAABIgcGBwYVFBcWFxYzMjc2NzY1NCcmJyYTBwYiLwEmNjsBETQ2OwEyFhURMzIWAe52Z2Q7PT07ZGd2fGpmOz4+O2ZpIXYOKA52Dg0XXQsHJgcLXRcNA7M+O2ZqfHZnZDs9PTtkZ3Z9aWY7Pv3wmhISmhIaARcICwsI/ukaAAMAAAAAA+UD5QAXACMALAAAASIHBgcGFRQXFhcWMzI3Njc2NTQnJicmAxQrASI1AzQ7ATIHJyImNDYyFhQGAe6Ecm9BRERBb3KEiXZxQkREQnF1aQIxAwgCQgMBIxIZGSQZGQPkREJxdomEcm9BRERBb3KEinVxQkT9HQICAWICAjEZIxkZIxkAAAAAAgAAAAADsQPkABkALgAAAQYHBgc2BREUFxYXFhc2NzY3NjURJBcmJyYTAQYvASY/ATYyHwEWNjclNjIfARYB9VVVQk+v/tFHPmxebGxdbT1I/tGvT0JVo/7VBASKAwMSAQUBcQEFAgESAgUBEQQD4xMYEhk3YP6sjnVlSD8cHD9IZXWOAVRgNxkSGP62/tkDA48EBBkCAVYCAQHlAQIQBAAAAAADAAAAAAOxA+QAGwAqADMAAAEGBwYHBgcGNxEUFxYXFhc2NzY3NjURJBcmJyYHMzIWFQMUBisBIicDNDYTIiY0NjIWFAYB9UFBODssO38gRz5sXmxsXW09SP7YqFBBVW80BAYMAwImBQELBh4PFhYeFRUD5A8SDhIOEikK/q2PdWRJPh0dPklkdY8BU141GRIY/AYE/sYCAwUBOgQG/kAVHxUVHxUAAAACAAAAAAPkA+QAFwAtAAABIgcGBwYVFBcWFxYzMjc2NzY1NCcmJyYTAQYiLwEmPwE2Mh8BFjI3ATYyHwEWAe6Ecm9BQ0NCbnODiXVxQkREQnF1kf6gAQUBowMDFgEFAYUCBQEBQwIFARUEA+NEQnF1iYNzbkJDQ0FvcoSJdXFCRP6j/qUBAagEBR4CAWYBAQENAgIVBAAAAAQAAAAAA68DrQAUACkAPwBDAAABIgcGBwYUFxYXFjI3Njc2NCcmJyYDIicmJyY0NzY3NjIXFhcWFAcGBwYTBQ4BLwEmBg8BBhYfARYyNwE+ASYiFzAfAQH1eGdkOzw8O2Rn8GZkOzw8O2RmeG5eWzY3NzZbXtteWzY3NzZbXmn+9gYSBmAGDwUDBQEGfQUQBgElBQELEBUBAQOtPDtkZ/BnYzs8PDtjZ/BnZDs8/K83NVte215cNTc3NVxe215bNTcCJt0FAQVJBQIGBAcRBoAGBQEhBQ8LBAEBAAABAAAAAAO7AzoAFwAAEy4BPwE+AR8BFjY3ATYWFycWFAcBBiInPQoGBwUHGgzLDCELAh0LHwsNCgr9uQoeCgGzCyEOCw0HCZMJAQoBvgkCCg0LHQv9sQsKAAAAAAIAAAAAA+UD5gAXACwAAAEiBwYHBhUUFxYXFjMyNzY3NjU0JyYnJhMHBi8BJicmNRM0NjsBMhYVExceAQHvhHJvQUNDQm5zg4l1cUJEREJxdVcQAwT6AwIEEAMCKwIDDsUCAQPlREJxdYmDc25CQ0NBb3KEiXVxQkT9VhwEAncCAgMGAXoCAwMC/q2FAgQAAAQAAAAAA68DrQADABgALQAzAAABMB8BAyIHBgcGFBcWFxYyNzY3NjQnJicmAyInJicmNDc2NzYyFxYXFhQHBgcGAyMVMzUjAuUBAfJ4Z2Q7PDw7ZGfwZmQ7PDw7ZGZ4bl5bNjc3Nlte215bNjc3NltemyT92QKDAQEBLDw7ZGfwZ2M7PDw7Y2fwZ2Q7PPyvNzVbXtteXDU3NzVcXtteWzU3AjH9JAAAAAMAAAAAA+QD5AAXACcAMAAAASIHBgcGFRQXFhcWMzI3Njc2NTQnJicmAzMyFhUDFAYrASImNQM0NhMiJjQ2MhYUBgHuhHJvQUNDQm5zg4l1cUJEREJxdZ42BAYMAwInAwMMBh8PFhYeFhYD40RCcXWJg3NuQkNDQW9yhIl1cUJE/vYGBf7AAgMDAgFABQb+NhYfFhYfFgAABAAAAAADwAPAAAgAEgAoAD0AAAEyNjQmIgYUFhcjFTMRIxUzNSMDIgcGBwYVFBYXFjMyNzY3NjU0Jy4BAyInJicmNDc2NzYyFxYXFhQHBgcGAfQYISEwISFRjzk5yTorhG5rPT99am+DdmhlPD4+PMyFbV5bNTc3NVte2l5bNTc3NVteAqAiLyIiLyI5Hf7EHBwCsT89a26Ed8w8Pj48ZWh2g29qffyjNzVbXtpeWzU3NzVbXtpeWzU3AAADAAAAAAOoA6gACwAgADUAAAEHJwcXBxc3FzcnNwMiBwYHBhQXFhcWMjc2NzY0JyYnJgMiJyYnJjQ3Njc2MhcWFxYUBwYHBgKOmpocmpocmpocmpq2dmZiOjs7OmJm7GZiOjs7OmJmdmtdWTQ2NjRZXdZdWTQ2NjRZXQKqmpocmpocmpocmpoBGTs6YmbsZmI6Ozs6YmbsZmI6O/zCNjRZXdZdWTQ2NjRZXdZdWTQ2AAMAAAAAA+kD6gAaAC8AMAAAAQYHBiMiJyYnJjQ3Njc2MhcWFxYVFAcGBwEHATI3Njc2NCcmJyYiBwYHBhQXFhcWMwKONUBCR21dWjU3NzVaXdpdWzU2GBcrASM5/eBXS0grKysrSEuuSkkqLCwqSUpXASMrFxg2NVtd2l1aNTc3NVpdbUdCQDX+3jkBGSsrSEuuSkkqLCwqSUquS0grKwAC//8AAAPoA+gAFAAwAAABIgcGBwYQFxYXFiA3Njc2ECcmJyYTFg4BIi8BBwYuATQ/AScmPgEWHwE3Nh4BBg8BAfSIdHFDRERDcXQBEHRxQ0REQ3F0SQoBFBsKoqgKGxMKqKIKARQbCqKoChsUAQqoA+hEQ3F0/vB0cUNERENxdAEQdHFDRP1jChsTCqiiCgEUGwqiqAobFAEKqKIKARQbCqIAAAIAAAAAA+QD5AAXADQAAAEiBwYHBhUUFxYXFjMyNzY3NjU0JyYnJhMUBiMFFxYUDwEGLwEuAT8BNh8BFhQPAQUyFh0BAe6Ecm9BQ0NCbnODiXVxQkREQnF1fwQC/pGDAQEVAwTsAgEC7AQEFAIBhAFwAgMD40RCcXWJg3NuQkNDQW9yhIl1cUJE/fYCAwuVAgQCFAQE0AIFAtEEBBQCBQGVCwMDJwAAAAUAAAAAA9QD0wAjACcANwBHAEgAAAERFAYjISImNREjIiY9ATQ2MyE1NDYzITIWHQEhMhYdARQGIyERIREHIgYVERQWOwEyNjURNCYjISIGFREUFjsBMjY1ETQmKwEDeyYb/XYbJkMJDQ0JAQYZEgEvExkBBgkNDQn9CQJc0QkNDQktCQ0NCf7sCQ0NCS0JDQ0JLQMi/TQbJiYbAswMCiwJDS4SGRkSLg0JLAoM/UwCtGsNCf5NCQ0NCQGzCQ0NCf5NCQ0NCQGzCQ0AAAAAEADGAAEAAAAAAAEABAAAAAEAAAAAAAIABwAEAAEAAAAAAAMABAALAAEAAAAAAAQABAAPAAEAAAAAAAUACwATAAEAAAAAAAYABAAeAAEAAAAAAAoAKwAiAAEAAAAAAAsAEwBNAAMAAQQJAAEACABgAAMAAQQJAAIADgBoAAMAAQQJAAMACAB2AAMAAQQJAAQACAB+AAMAAQQJAAUAFgCGAAMAAQQJAAYACACcAAMAAQQJAAoAVgCkAAMAAQQJAAsAJgD6d2V1aVJlZ3VsYXJ3ZXVpd2V1aVZlcnNpb24gMS4wd2V1aUdlbmVyYXRlZCBieSBzdmcydHRmIGZyb20gRm9udGVsbG8gcHJvamVjdC5odHRwOi8vZm9udGVsbG8uY29tAHcAZQB1AGkAUgBlAGcAdQBsAGEAcgB3AGUAdQBpAHcAZQB1AGkAVgBlAHIAcwBpAG8AbgAgADEALgAwAHcAZQB1AGkARwBlAG4AZQByAGEAdABlAGQAIABiAHkAIABzAHYAZwAyAHQAdABmACAAZgByAG8AbQAgAEYAbwBuAHQAZQBsAGwAbwAgAHAAcgBvAGoAZQBjAHQALgBoAHQAdABwADoALwAvAGYAbwBuAHQAZQBsAGwAbwAuAGMAbwBtAAAAAgAAAAAAAAAKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASAQIBAwEEAQUBBgEHAQgBCQEKAQsBDAENAQ4BDwEQAREBEgETAAZjaXJjbGUIZG93bmxvYWQEaW5mbwxzYWZlX3N1Y2Nlc3MJc2FmZV93YXJuB3N1Y2Nlc3MOc3VjY2Vzcy1jaXJjbGURc3VjY2Vzcy1uby1jaXJjbGUHd2FpdGluZw53YWl0aW5nLWNpcmNsZQR3YXJuC2luZm8tY2lyY2xlBmNhbmNlbAZzZWFyY2gFY2xlYXIEYmFjawZkZWxldGUAAAAA') format('truetype');\n}\n[class^=\"weui-icon-\"],\n[class*=\" weui-icon-\"] {\n  display: inline-block;\n  vertical-align: middle;\n  font: normal normal normal 14px/1 \"weui\";\n  font-size: inherit;\n  text-rendering: auto;\n  -webkit-font-smoothing: antialiased;\n}\n[class^=\"weui-icon-\"]:before,\n[class*=\" weui-icon-\"]:before {\n  display: inline-block;\n  margin-left: .2em;\n  margin-right: .2em;\n}\n.weui-icon-circle:before {\n  content: \"\\EA01\";\n}\n/* '' */\n.weui-icon-download:before {\n  content: \"\\EA02\";\n}\n/* '' */\n.weui-icon-info:before {\n  content: \"\\EA03\";\n}\n/* '' */\n.weui-icon-safe-success:before {\n  content: \"\\EA04\";\n}\n/* '' */\n.weui-icon-safe-warn:before {\n  content: \"\\EA05\";\n}\n/* '' */\n.weui-icon-success:before {\n  content: \"\\EA06\";\n}\n/* '' */\n.weui-icon-success-circle:before {\n  content: \"\\EA07\";\n}\n/* '' */\n.weui-icon-success-no-circle:before {\n  content: \"\\EA08\";\n}\n/* '' */\n.weui-icon-waiting:before {\n  content: \"\\EA09\";\n}\n/* '' */\n.weui-icon-waiting-circle:before {\n  content: \"\\EA0A\";\n}\n/* '' */\n.weui-icon-warn:before {\n  content: \"\\EA0B\";\n}\n/* '' */\n.weui-icon-info-circle:before {\n  content: \"\\EA0C\";\n}\n/* '' */\n.weui-icon-cancel:before {\n  content: \"\\EA0D\";\n}\n/* '' */\n.weui-icon-search:before {\n  content: \"\\EA0E\";\n}\n/* '' */\n.weui-icon-clear:before {\n  content: \"\\EA0F\";\n}\n/* '' */\n.weui-icon-back:before {\n  content: \"\\EA10\";\n}\n/* '' */\n.weui-icon-delete:before {\n  content: \"\\EA11\";\n}\n/* '' */\n[class^=\"weui-icon_\"]:before,\n[class*=\" weui-icon_\"]:before {\n  margin: 0;\n}\n.weui-icon-success {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-waiting {\n  font-size: 23px;\n  color: #10AEFF;\n}\n.weui-icon-warn {\n  font-size: 23px;\n  color: #F43530;\n}\n.weui-icon-info {\n  font-size: 23px;\n  color: #10AEFF;\n}\n.weui-icon-success-circle {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-success-no-circle {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-waiting-circle {\n  font-size: 23px;\n  color: #10AEFF;\n}\n.weui-icon-circle {\n  font-size: 23px;\n  color: #C9C9C9;\n}\n.weui-icon-download {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-info-circle {\n  font-size: 23px;\n  color: #09BB07;\n}\n.weui-icon-safe-success {\n  color: #09BB07;\n}\n.weui-icon-safe-warn {\n  color: #FFBE00;\n}\n.weui-icon-cancel {\n  color: #F43530;\n  font-size: 22px;\n}\n.weui-icon-search {\n  color: #B2B2B2;\n  font-size: 14px;\n}\n.weui-icon-clear {\n  color: #B2B2B2;\n  font-size: 14px;\n}\n.weui-icon-delete.weui-icon_gallery-delete {\n  color: #FFFFFF;\n  font-size: 22px;\n}\n.weui-icon_msg {\n  font-size: 93px;\n}\n.weui-icon_msg.weui-icon-warn {\n  color: #F76260;\n}\n.weui-icon_msg-primary {\n  font-size: 93px;\n}\n.weui-icon_msg-primary.weui-icon-warn {\n  color: #FFBE00;\n}\n.weui-toast {\n  position: fixed;\n  z-index: 5001;\n  width: 7.6em;\n  min-height: 7.6em;\n  top: 180px;\n  left: 50%;\n  margin-left: -3.8em;\n  background: rgba(17, 17, 17, 0.7);\n  text-align: center;\n  border-radius: 5px;\n  color: #FFFFFF;\n}\n.weui-icon_toast {\n  margin: 22px 0 0;\n  display: block;\n}\n.weui-icon_toast.weui-icon-success-no-circle:before {\n  color: #FFFFFF;\n  font-size: 55px;\n}\n.weui-icon_toast.weui-loading {\n  margin: 30px 0 0;\n  width: 38px;\n  height: 38px;\n  vertical-align: baseline;\n}\n.weui-toast__content {\n  margin: 0 0 15px;\n}\n.weui-toast.vux-toast-top {\n  top: 10px;\n}\n.weui-toast.vux-toast-bottom {\n  top: auto;\n  bottom: 10px;\n  transform: translateX(-50%);\n}\n.weui-toast.vux-toast-middle {\n  top: 50%;\n  transform: translateX(-50%) translateY(-50%);\n}\n.vux-slide-from-top-enter,\n.vux-slide-from-top-leave-active {\n  opacity: 0;\n  transform: translateX(-50%) translateY(-100%) !important;\n}\n.vux-slide-from-bottom-enter,\n.vux-slide-from-bottom-leave-active {\n  opacity: 0;\n  transform: translateX(-50%) translateY(100%) !important;\n}\n.vux-slide-from-top-enter-active,\n.vux-slide-from-top-leave-active,\n.vux-slide-from-bottom-enter-active,\n.vux-slide-from-bottom-leave-active {\n  transition: all 400ms cubic-bezier(0.36, 0.66, 0.04, 1);\n}\n.weui-toast {\n  transform: translateX(-50%);\n  margin-left: 0!important;\n}\n.weui-toast.weui-toast_forbidden {\n  color: #F76260;\n}\n.weui-toast.weui-toast_forbidden .weui-toast__content {\n  margin-top: 10px;\n}\n.weui-toast.weui-toast_text {\n  min-height: 0;\n}\n.weui-toast_text .weui-toast__content {\n  margin: 0;\n  padding-top: 10px;\n  padding-bottom: 10px;\n  border-radius: 15px;\n}\n.weui-toast__content {\n  font-size: 16px;\n}\n.weui-loading_toast .weui-toast__content {\n  margin-top: 0;\n}\n.weui-toast_success .weui-icon_toast:before {\n  content: \"\\EA08\";\n}\n.weui-toast_cancel .weui-icon_toast:before {\n  content: \"\\EA0D\";\n}\n.weui-toast_forbidden .weui-icon_toast.weui-icon-success-no-circle:before {\n  content: \"\\EA0B\";\n  color: #F76260;\n}\n", ""]);

// exports


/***/ }),
/* 537 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _safariFix = __webpack_require__(460);

var _safariFix2 = _interopRequireDefault(_safariFix);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'toast',
  mixins: [_safariFix2.default],
  props: {
    value: Boolean,
    time: {
      type: Number,
      default: 2000
    },
    type: {
      type: String,
      default: 'success'
    },
    transition: String,
    width: {
      type: String,
      default: '7.6em'
    },
    isShowMask: {
      type: Boolean,
      default: false
    },
    text: String,
    position: String
  },
  data: function data() {
    return {
      show: false
    };
  },
  created: function created() {
    if (this.value) {
      this.show = true;
    }
  },

  computed: {
    currentTransition: function currentTransition() {
      if (this.transition) {
        return this.transition;
      }
      if (this.position === 'top') {
        return 'vux-slide-from-top';
      }
      if (this.position === 'bottom') {
        return 'vux-slide-from-bottom';
      }
      return 'vux-fade';
    },
    toastClass: function toastClass() {
      return {
        'weui-toast_forbidden': this.type === 'warn',
        'weui-toast_cancel': this.type === 'cancel',
        'weui-toast_success': this.type === 'success',
        'weui-toast_text': this.type === 'text',
        'vux-toast-top': this.position === 'top',
        'vux-toast-bottom': this.position === 'bottom',
        'vux-toast-middle': this.position === 'middle'
      };
    },
    style: function style() {
      if (this.type === 'text' && this.width === 'auto') {
        return { padding: '10px' };
      }
    }
  },
  watch: {
    show: function show(val) {
      var _this = this;

      if (val) {
        this.$emit('input', true);
        this.$emit('on-show');
        this.fixSafariOverflowScrolling('auto');

        clearTimeout(this.timeout);
        this.timeout = setTimeout(function () {
          _this.show = false;
          _this.$emit('input', false);
          _this.$emit('on-hide');
          _this.fixSafariOverflowScrolling('touch');
        }, this.time);
      }
    },
    value: function value(val) {
      this.show = val;
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 538 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _safariFix = __webpack_require__(460);

var _safariFix2 = _interopRequireDefault(_safariFix);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'toast',
  mixins: [_safariFix2.default],
  props: {
    value: Boolean,
    time: {
      type: Number,
      default: 2000
    },
    type: {
      type: String,
      default: 'success'
    },
    transition: String,
    width: {
      type: String,
      default: '7.6em'
    },
    isShowMask: {
      type: Boolean,
      default: false
    },
    text: String,
    position: String
  },
  data: function data() {
    return {
      show: false
    };
  },
  created: function created() {
    if (this.value) {
      this.show = true;
    }
  },

  computed: {
    currentTransition: function currentTransition() {
      if (this.transition) {
        return this.transition;
      }
      if (this.position === 'top') {
        return 'vux-slide-from-top';
      }
      if (this.position === 'bottom') {
        return 'vux-slide-from-bottom';
      }
      return 'vux-fade';
    },
    toastClass: function toastClass() {
      return {
        'weui-toast_forbidden': this.type === 'warn',
        'weui-toast_cancel': this.type === 'cancel',
        'weui-toast_success': this.type === 'success',
        'weui-toast_text': this.type === 'text',
        'vux-toast-top': this.position === 'top',
        'vux-toast-bottom': this.position === 'bottom',
        'vux-toast-middle': this.position === 'middle'
      };
    },
    style: function style() {
      if (this.type === 'text' && this.width === 'auto') {
        return { padding: '10px' };
      }
    }
  },
  watch: {
    show: function show(val) {
      var _this = this;

      if (val) {
        this.$emit('input', true);
        this.$emit('on-show');
        this.fixSafariOverflowScrolling('auto');

        clearTimeout(this.timeout);
        this.timeout = setTimeout(function () {
          _this.show = false;
          _this.$emit('input', false);
          _this.$emit('on-hide');
          _this.fixSafariOverflowScrolling('touch');
        }, this.time);
      }
    },
    value: function value(val) {
      this.show = val;
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 539 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "vux-toast" },
    [
      _c("div", {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.isShowMask && _vm.show,
            expression: "isShowMask && show"
          }
        ],
        staticClass: "weui-mask_transparent"
      }),
      _vm._v(" "),
      _c("transition", { attrs: { name: _vm.currentTransition } }, [
        _c(
          "div",
          {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.show,
                expression: "show"
              }
            ],
            staticClass: "weui-toast",
            class: _vm.toastClass,
            style: { width: _vm.width }
          },
          [
            _c("i", {
              directives: [
                {
                  name: "show",
                  rawName: "v-show",
                  value: _vm.type !== "text",
                  expression: "type !== 'text'"
                }
              ],
              staticClass: "weui-icon-success-no-circle weui-icon_toast"
            }),
            _vm._v(" "),
            _vm.text
              ? _c("p", {
                  staticClass: "weui-toast__content",
                  style: _vm.style,
                  domProps: { innerHTML: _vm._s(_vm.text) }
                })
              : _c(
                  "p",
                  { staticClass: "weui-toast__content", style: _vm.style },
                  [_vm._t("default")],
                  2
                )
          ]
        )
      ])
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-5b8fbf00", esExports)
  }
}

/***/ }),
/* 540 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(541);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("6258dba0", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-3f1f7b9e\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-3f1f7b9e\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 541 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "\n.vux-label-desc {\n  font-size:14px;\n  color:#666;\n}\n", ""]);

// exports


/***/ }),
/* 542 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//

exports.default = {
  name: 'inline-desc'
};

/***/ }),
/* 543 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//

exports.default = {
  name: 'inline-desc'
};

/***/ }),
/* 544 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("span", { staticClass: "vux-label-desc" }, [_vm._t("default")], 2)
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-3f1f7b9e", esExports)
  }
}

/***/ }),
/* 545 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.default = isByteLength;

var _assertString = __webpack_require__(440);

var _assertString2 = _interopRequireDefault(_assertString);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/* eslint-disable prefer-rest-params */
function isByteLength(str, options) {
  (0, _assertString2.default)(str);
  var min = void 0;
  var max = void 0;
  if ((typeof options === 'undefined' ? 'undefined' : _typeof(options)) === 'object') {
    min = options.min || 0;
    max = options.max;
  } else {
    // backwards compatibility: isByteLength(str, min [, max])
    min = arguments[1];
    max = arguments[2];
  }
  var len = encodeURI(str).split(/%..|./).length - 1;
  return len >= min && (typeof max === 'undefined' || len <= max);
}
module.exports = exports['default'];

/***/ }),
/* 546 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = isFQDN;

var _assertString = __webpack_require__(440);

var _assertString2 = _interopRequireDefault(_assertString);

var _merge = __webpack_require__(462);

var _merge2 = _interopRequireDefault(_merge);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var default_fqdn_options = {
  require_tld: true,
  allow_underscores: false,
  allow_trailing_dot: false
};

function isFQDN(str, options) {
  (0, _assertString2.default)(str);
  options = (0, _merge2.default)(options, default_fqdn_options);

  /* Remove the optional trailing dot before checking validity */
  if (options.allow_trailing_dot && str[str.length - 1] === '.') {
    str = str.substring(0, str.length - 1);
  }
  var parts = str.split('.');
  if (options.require_tld) {
    var tld = parts.pop();
    if (!parts.length || !/^([a-z\u00a1-\uffff]{2,}|xn[a-z0-9-]{2,})$/i.test(tld)) {
      return false;
    }
    // disallow spaces
    if (/[\s\u2002-\u200B\u202F\u205F\u3000\uFEFF\uDB40\uDC20]/.test(tld)) {
      return false;
    }
  }
  for (var part, i = 0; i < parts.length; i++) {
    part = parts[i];
    if (options.allow_underscores) {
      part = part.replace(/_/g, '');
    }
    if (!/^[a-z\u00a1-\uffff0-9-]+$/i.test(part)) {
      return false;
    }
    // disallow full-width chars
    if (/[\uff01-\uff5e]/.test(part)) {
      return false;
    }
    if (part[0] === '-' || part[part.length - 1] === '-') {
      return false;
    }
  }
  return true;
}
module.exports = exports['default'];

/***/ }),
/* 547 */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(global) {/**
 * lodash (Custom Build) <https://lodash.com/>
 * Build: `lodash modularize exports="npm" -o ./`
 * Copyright jQuery Foundation and other contributors <https://jquery.org/>
 * Released under MIT license <https://lodash.com/license>
 * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
 * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
 */

/** Used as the `TypeError` message for "Functions" methods. */
var FUNC_ERROR_TEXT = 'Expected a function';

/** Used as references for various `Number` constants. */
var NAN = 0 / 0;

/** `Object#toString` result references. */
var symbolTag = '[object Symbol]';

/** Used to match leading and trailing whitespace. */
var reTrim = /^\s+|\s+$/g;

/** Used to detect bad signed hexadecimal string values. */
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;

/** Used to detect binary string values. */
var reIsBinary = /^0b[01]+$/i;

/** Used to detect octal string values. */
var reIsOctal = /^0o[0-7]+$/i;

/** Built-in method references without a dependency on `root`. */
var freeParseInt = parseInt;

/** Detect free variable `global` from Node.js. */
var freeGlobal = typeof global == 'object' && global && global.Object === Object && global;

/** Detect free variable `self`. */
var freeSelf = typeof self == 'object' && self && self.Object === Object && self;

/** Used as a reference to the global object. */
var root = freeGlobal || freeSelf || Function('return this')();

/** Used for built-in method references. */
var objectProto = Object.prototype;

/**
 * Used to resolve the
 * [`toStringTag`](http://ecma-international.org/ecma-262/7.0/#sec-object.prototype.tostring)
 * of values.
 */
var objectToString = objectProto.toString;

/* Built-in method references for those with the same name as other `lodash` methods. */
var nativeMax = Math.max,
    nativeMin = Math.min;

/**
 * Gets the timestamp of the number of milliseconds that have elapsed since
 * the Unix epoch (1 January 1970 00:00:00 UTC).
 *
 * @static
 * @memberOf _
 * @since 2.4.0
 * @category Date
 * @returns {number} Returns the timestamp.
 * @example
 *
 * _.defer(function(stamp) {
 *   console.log(_.now() - stamp);
 * }, _.now());
 * // => Logs the number of milliseconds it took for the deferred invocation.
 */
var now = function() {
  return root.Date.now();
};

/**
 * Creates a debounced function that delays invoking `func` until after `wait`
 * milliseconds have elapsed since the last time the debounced function was
 * invoked. The debounced function comes with a `cancel` method to cancel
 * delayed `func` invocations and a `flush` method to immediately invoke them.
 * Provide `options` to indicate whether `func` should be invoked on the
 * leading and/or trailing edge of the `wait` timeout. The `func` is invoked
 * with the last arguments provided to the debounced function. Subsequent
 * calls to the debounced function return the result of the last `func`
 * invocation.
 *
 * **Note:** If `leading` and `trailing` options are `true`, `func` is
 * invoked on the trailing edge of the timeout only if the debounced function
 * is invoked more than once during the `wait` timeout.
 *
 * If `wait` is `0` and `leading` is `false`, `func` invocation is deferred
 * until to the next tick, similar to `setTimeout` with a timeout of `0`.
 *
 * See [David Corbacho's article](https://css-tricks.com/debouncing-throttling-explained-examples/)
 * for details over the differences between `_.debounce` and `_.throttle`.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Function
 * @param {Function} func The function to debounce.
 * @param {number} [wait=0] The number of milliseconds to delay.
 * @param {Object} [options={}] The options object.
 * @param {boolean} [options.leading=false]
 *  Specify invoking on the leading edge of the timeout.
 * @param {number} [options.maxWait]
 *  The maximum time `func` is allowed to be delayed before it's invoked.
 * @param {boolean} [options.trailing=true]
 *  Specify invoking on the trailing edge of the timeout.
 * @returns {Function} Returns the new debounced function.
 * @example
 *
 * // Avoid costly calculations while the window size is in flux.
 * jQuery(window).on('resize', _.debounce(calculateLayout, 150));
 *
 * // Invoke `sendMail` when clicked, debouncing subsequent calls.
 * jQuery(element).on('click', _.debounce(sendMail, 300, {
 *   'leading': true,
 *   'trailing': false
 * }));
 *
 * // Ensure `batchLog` is invoked once after 1 second of debounced calls.
 * var debounced = _.debounce(batchLog, 250, { 'maxWait': 1000 });
 * var source = new EventSource('/stream');
 * jQuery(source).on('message', debounced);
 *
 * // Cancel the trailing debounced invocation.
 * jQuery(window).on('popstate', debounced.cancel);
 */
function debounce(func, wait, options) {
  var lastArgs,
      lastThis,
      maxWait,
      result,
      timerId,
      lastCallTime,
      lastInvokeTime = 0,
      leading = false,
      maxing = false,
      trailing = true;

  if (typeof func != 'function') {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = 'maxWait' in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = 'trailing' in options ? !!options.trailing : trailing;
  }

  function invokeFunc(time) {
    var args = lastArgs,
        thisArg = lastThis;

    lastArgs = lastThis = undefined;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }

  function leadingEdge(time) {
    // Reset any `maxWait` timer.
    lastInvokeTime = time;
    // Start the timer for the trailing edge.
    timerId = setTimeout(timerExpired, wait);
    // Invoke the leading edge.
    return leading ? invokeFunc(time) : result;
  }

  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime,
        result = wait - timeSinceLastCall;

    return maxing ? nativeMin(result, maxWait - timeSinceLastInvoke) : result;
  }

  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime,
        timeSinceLastInvoke = time - lastInvokeTime;

    // Either this is the first call, activity has stopped and we're at the
    // trailing edge, the system time has gone backwards and we're treating
    // it as the trailing edge, or we've hit the `maxWait` limit.
    return (lastCallTime === undefined || (timeSinceLastCall >= wait) ||
      (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait));
  }

  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    // Restart the timer.
    timerId = setTimeout(timerExpired, remainingWait(time));
  }

  function trailingEdge(time) {
    timerId = undefined;

    // Only invoke if we have `lastArgs` which means `func` has been
    // debounced at least once.
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = undefined;
    return result;
  }

  function cancel() {
    if (timerId !== undefined) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = undefined;
  }

  function flush() {
    return timerId === undefined ? result : trailingEdge(now());
  }

  function debounced() {
    var time = now(),
        isInvoking = shouldInvoke(time);

    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;

    if (isInvoking) {
      if (timerId === undefined) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        // Handle invocations in a tight loop.
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === undefined) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}

/**
 * Checks if `value` is the
 * [language type](http://www.ecma-international.org/ecma-262/7.0/#sec-ecmascript-language-types)
 * of `Object`. (e.g. arrays, functions, objects, regexes, `new Number(0)`, and `new String('')`)
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an object, else `false`.
 * @example
 *
 * _.isObject({});
 * // => true
 *
 * _.isObject([1, 2, 3]);
 * // => true
 *
 * _.isObject(_.noop);
 * // => true
 *
 * _.isObject(null);
 * // => false
 */
function isObject(value) {
  var type = typeof value;
  return !!value && (type == 'object' || type == 'function');
}

/**
 * Checks if `value` is object-like. A value is object-like if it's not `null`
 * and has a `typeof` result of "object".
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is object-like, else `false`.
 * @example
 *
 * _.isObjectLike({});
 * // => true
 *
 * _.isObjectLike([1, 2, 3]);
 * // => true
 *
 * _.isObjectLike(_.noop);
 * // => false
 *
 * _.isObjectLike(null);
 * // => false
 */
function isObjectLike(value) {
  return !!value && typeof value == 'object';
}

/**
 * Checks if `value` is classified as a `Symbol` primitive or object.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is a symbol, else `false`.
 * @example
 *
 * _.isSymbol(Symbol.iterator);
 * // => true
 *
 * _.isSymbol('abc');
 * // => false
 */
function isSymbol(value) {
  return typeof value == 'symbol' ||
    (isObjectLike(value) && objectToString.call(value) == symbolTag);
}

/**
 * Converts `value` to a number.
 *
 * @static
 * @memberOf _
 * @since 4.0.0
 * @category Lang
 * @param {*} value The value to process.
 * @returns {number} Returns the number.
 * @example
 *
 * _.toNumber(3.2);
 * // => 3.2
 *
 * _.toNumber(Number.MIN_VALUE);
 * // => 5e-324
 *
 * _.toNumber(Infinity);
 * // => Infinity
 *
 * _.toNumber('3.2');
 * // => 3.2
 */
function toNumber(value) {
  if (typeof value == 'number') {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject(value)) {
    var other = typeof value.valueOf == 'function' ? value.valueOf() : value;
    value = isObject(other) ? (other + '') : other;
  }
  if (typeof value != 'string') {
    return value === 0 ? value : +value;
  }
  value = value.replace(reTrim, '');
  var isBinary = reIsBinary.test(value);
  return (isBinary || reIsOctal.test(value))
    ? freeParseInt(value.slice(2), isBinary ? 2 : 8)
    : (reIsBadHex.test(value) ? NAN : +value);
}

module.exports = debounce;

/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(49)))

/***/ }),
/* 548 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keys = __webpack_require__(439);

var _keys2 = _interopRequireDefault(_keys);

var _base = __webpack_require__(457);

var _base2 = _interopRequireDefault(_base);

var _icon = __webpack_require__(458);

var _icon2 = _interopRequireDefault(_icon);

var _toast = __webpack_require__(459);

var _toast2 = _interopRequireDefault(_toast);

var _inlineDesc = __webpack_require__(435);

var _inlineDesc2 = _interopRequireDefault(_inlineDesc);

var _isEmail = __webpack_require__(461);

var _isEmail2 = _interopRequireDefault(_isEmail);

var _isMobilePhone = __webpack_require__(463);

var _isMobilePhone2 = _interopRequireDefault(_isMobilePhone);

var _debounce = __webpack_require__(464);

var _debounce2 = _interopRequireDefault(_debounce);

var _vanillaMasker = __webpack_require__(465);

var _vanillaMasker2 = _interopRequireDefault(_vanillaMasker);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var validators = {
  'email': {
    fn: _isEmail2.default,
    msg: '邮箱格式'
  },
  'china-mobile': {
    fn: function fn(str) {
      return (0, _isMobilePhone2.default)(str, 'zh-CN');
    },

    msg: '手机号码'
  },
  'china-name': {
    fn: function fn(str) {
      return str.length >= 2 && str.length <= 6;
    },

    msg: '中文姓名'
  }
};
exports.default = {
  name: 'x-input',
  created: function created() {
    var _this = this;

    this.currentValue = this.value === undefined || this.value === null ? '' : this.mask ? this.maskValue(this.value) : this.value;
    /* istanbul ignore if */
    if (process.env.NODE_ENV === 'development') {
      if (!this.title && !this.placeholder && !this.currentValue) {
        console.warn('no title and no placeholder?');
      }
    }

    if (this.required && (typeof this.currentValue === 'undefined' || this.currentValue === '')) {
      this.valid = false;
    }
    this.handleChangeEvent = true;
    if (this.debounce) {
      this._debounce = (0, _debounce2.default)(function () {
        _this.$emit('on-change', _this.currentValue);
      }, this.debounce);
    }
  },
  beforeMount: function beforeMount() {
    if (this.$slots && this.$slots['restricted-label']) {
      this.hasRestrictedLabel = true;
    }
    if (this.$slots && this.$slots['right-full-height']) {
      this.hasRightFullHeightSlot = true;
    }
  },
  beforeDestroy: function beforeDestroy() {
    if (this._debounce) {
      this._debounce.cancel();
    }
    window.removeEventListener('resize', this.scrollIntoView);
  },

  mixins: [_base2.default],
  components: {
    Icon: _icon2.default,
    InlineDesc: _inlineDesc2.default,
    Toast: _toast2.default
  },
  props: {
    title: {
      type: String,
      default: ''
    },
    type: {
      type: String,
      default: 'text'
    },
    placeholder: String,
    value: [String, Number],
    name: String,
    readonly: Boolean,
    disabled: Boolean,
    keyboard: String,
    inlineDesc: String,
    isType: [String, Function],
    min: Number,
    max: Number,
    showClear: {
      type: Boolean,
      default: true
    },
    equalWith: String,
    textAlign: String,
    // https://github.com/yisibl/blog/issues/3
    autocomplete: {
      type: String,
      default: 'off'
    },
    autocapitalize: {
      type: String,
      default: 'off'
    },
    autocorrect: {
      type: String,
      default: 'off'
    },
    spellcheck: {
      type: String,
      default: 'false'
    },
    novalidate: {
      type: Boolean,
      default: false
    },
    iconType: String,
    debounce: Number,
    placeholderAlign: String,
    labelWidth: String,
    mask: String,
    shouldToastError: {
      type: Boolean,
      default: true
    }
  },
  computed: {
    labelStyles: function labelStyles() {
      return {
        width: this.labelWidthComputed || this.$parent.labelWidth || this.labelWidthComputed,
        textAlign: this.$parent.labelAlign,
        marginRight: this.$parent.labelMarginRight
      };
    },
    labelClass: function labelClass() {
      return {
        'vux-cell-justify': this.$parent.labelAlign === 'justify' || this.$parent.$parent.labelAlign === 'justify'
      };
    },
    pattern: function pattern() {
      if (this.keyboard === 'number' || this.isType === 'china-mobile') {
        return '[0-9]*';
      }
    },
    labelWidthComputed: function labelWidthComputed() {
      var width = this.title.replace(/[^x00-xff]/g, '00').length / 2 + 1;
      if (width < 10) {
        return width + 'em';
      }
    },
    hasErrors: function hasErrors() {
      return (0, _keys2.default)(this.errors).length > 0;
    },
    inputStyle: function inputStyle() {
      if (this.textAlign) {
        return {
          textAlign: this.textAlign
        };
      }
    },
    showWarn: function showWarn() {
      return !this.novalidate && !this.equalWith && !this.valid && this.firstError && (this.touched || this.forceShowError);
    }
  },
  mounted: function mounted() {
    window.addEventListener('resize', this.scrollIntoView);
  },

  methods: {
    scrollIntoView: function scrollIntoView() {
      var _this2 = this;

      var time = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;

      // alert('scroll into view')
      if (/iphone/i.test(navigator.userAgent)) {
        // return
      }
      if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') {
        // alert('will scroll')
        setTimeout(function () {
          // alert(this.$refs.input.length)
          _this2.$refs.input.scrollIntoViewIfNeeded(true);
        }, time);
      }
    },
    onClickErrorIcon: function onClickErrorIcon() {
      if (this.shouldToastError && this.firstError) {
        this.showErrorToast = true;
      }
      this.$emit('on-click-error-icon', this.firstError);
    },
    maskValue: function maskValue(val) {
      var val1 = this.mask ? _vanillaMasker2.default.toPattern(val, this.mask) : val;
      return val1;
    },
    reset: function reset() {
      var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '';

      this.dirty = false;
      this.currentValue = value;
      this.firstError = '';
      this.valid = true;
    },
    clear: function clear() {
      this.currentValue = '';
      this.focus();
      this.$emit('on-click-clear-icon');
    },
    focus: function focus() {
      this.$refs.input.focus();
    },
    blur: function blur() {
      this.$refs.input.blur();
    },
    focusHandler: function focusHandler($event) {
      var _this3 = this;

      this.$emit('on-focus', this.currentValue, $event);
      this.isFocus = true;
      // this.scrollIntoView(500)
      // this.scrollIntoView(5000)
      setTimeout(function () {
        _this3.$refs.input.scrollIntoViewIfNeeded(false);
        // this.$refs.input.scrollIntoViewIfNeeded()
      }, 1000);
      // $event.target.
    },
    onBlur: function onBlur($event) {
      this.setTouched();
      this.validate();
      this.isFocus = false;
      this.$emit('on-blur', this.currentValue, $event);
    },
    onKeyUp: function onKeyUp(e) {
      if (e.key === 'Enter') {
        e.target.blur();
        this.$emit('on-enter', this.currentValue, e);
      }
    },
    getError: function getError() {
      var key = (0, _keys2.default)(this.errors)[0];
      this.firstError = this.errors[key];
    },
    validate: function validate() {
      if (typeof this.equalWith !== 'undefined') {
        this.validateEqual();
        return;
      }
      this.errors = {};

      if (!this.currentValue && !this.required) {
        this.valid = true;
        return;
      }

      if (!this.currentValue && this.required) {
        this.valid = false;
        this.errors.required = '必填哦';
        this.getError();
        return;
      }

      if (typeof this.isType === 'string') {
        var validator = validators[this.isType];
        if (validator) {
          var value = this.currentValue;

          if (this.isType === 'china-mobile' && this.mask === '999 9999 9999') {
            value = this.currentValue.replace(/\s+/g, '');
          }

          this.valid = validator['fn'](value);
          if (!this.valid) {
            this.forceShowError = true;
            this.errors.format = validator['msg'] + '格式不对哦~';
            this.getError();
            return;
          } else {
            delete this.errors.format;
          }
        }
      }

      if (typeof this.isType === 'function') {
        var validStatus = this.isType(this.currentValue);
        this.valid = validStatus.valid;
        if (!this.valid) {
          this.errors.format = validStatus.msg;
          this.forceShowError = true;
          this.getError();
          return;
        } else {
          delete this.errors.format;
        }
      }

      if (this.min) {
        if (this.currentValue.length < this.min) {
          this.errors.min = '\u6700\u5C11\u5E94\u8BE5\u8F93\u5165' + this.min + '\u4E2A\u5B57\u7B26\u54E6';
          this.valid = false;
          this.getError();
          return;
        } else {
          delete this.errors.min;
        }
      }

      if (this.max) {
        if (this.currentValue.length > this.max) {
          this.errors.max = '\u6700\u591A\u53EF\u4EE5\u8F93\u5165' + this.max + '\u4E2A\u5B57\u7B26\u54E6';
          this.valid = false;
          this.forceShowError = true;
          return;
        } else {
          this.forceShowError = false;
          delete this.errors.max;
        }
      }

      this.valid = true;
    },
    validateEqual: function validateEqual() {
      if (!this.equalWith && this.currentValue) {
        this.valid = false;
        this.errors.equal = '输入不一致';
        return;
      }
      var willCheck = this.dirty || this.currentValue.length >= this.equalWith.length;
      // 只在长度符合时显示正确与否
      if (willCheck && this.currentValue !== this.equalWith) {
        this.valid = false;
        this.errors.equal = '输入不一致';
        return;
      } else {
        if (!this.currentValue && this.required) {
          this.valid = false;
        } else {
          this.valid = true;
          delete this.errors.equal;
        }
      }
    },

    // #2810
    _getInputMaskSelection: function _getInputMaskSelection(selection, direction, maskVal, loop) {
      if (!this.mask || loop && direction === 0) {
        return selection;
      }
      if (direction === 0) {
        direction = this.lastDirection;
      }
      if (direction > 0) {
        var maskChar = this.mask.substr(selection - direction, 1);
        if (!maskChar.match(/[9SA]/)) {
          return this._getInputMaskSelection(selection + 1, direction, maskVal, true);
        }
      }
      return selection;
    }
  },
  data: function data() {
    return {
      hasRightFullHeightSlot: false,
      hasRestrictedLabel: false,
      firstError: '',
      forceShowError: false,
      hasLengthEqual: false,
      valid: true,
      currentValue: '',
      showErrorToast: false,
      isFocus: false
    };
  },

  watch: {
    mask: function mask(val) {
      if (val && this.currentValue) {
        this.currentValue = this.maskValue(this.currentValue);
      }
    },
    valid: function valid() {
      this.getError();
    },
    value: function value(val) {
      this.currentValue = val;
    },
    equalWith: function equalWith(newVal) {
      if (newVal && this.equalWith) {
        if (newVal.length === this.equalWith.length) {
          this.hasLengthEqual = true;
        }
        this.validateEqual();
      } else {
        this.validate();
      }
    },
    currentValue: function currentValue(newVal, oldVal) {
      var _this4 = this;

      if (!this.equalWith && newVal) {
        this.validateEqual();
      }
      if (newVal && this.equalWith) {
        if (newVal.length === this.equalWith.length) {
          this.hasLengthEqual = true;
        }
        this.validateEqual();
      } else {
        this.validate();
      }

      var selection = this.$refs.input.selectionStart;
      var direction = newVal.length - oldVal.length;
      selection = this._getInputMaskSelection(selection, direction, this.maskValue(newVal));
      this.lastDirection = direction;
      this.$emit('input', this.maskValue(newVal));
      // #2810
      this.$nextTick(function () {
        if (_this4.$refs.input.selectionStart !== selection) {
          _this4.$refs.input.selectionStart = selection;
          _this4.$refs.input.selectionEnd = selection;
        }
        if (_this4.currentValue !== _this4.maskValue(newVal)) {
          _this4.currentValue = _this4.maskValue(newVal);
        }
      });

      if (this._debounce) {
        this._debounce();
      } else {
        this.$emit('on-change', newVal);
      }
    }
  }
};
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(56)))

/***/ }),
/* 549 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "vux-x-input weui-cell",
      class: {
        "weui-cell_warn": _vm.showWarn,
        disabled: _vm.disabled,
        "vux-x-input-has-right-full": _vm.hasRightFullHeightSlot
      }
    },
    [
      _c(
        "div",
        { staticClass: "weui-cell__hd" },
        [
          _vm.hasRestrictedLabel
            ? _c(
                "div",
                { style: _vm.labelStyles },
                [_vm._t("restricted-label")],
                2
              )
            : _vm._e(),
          _vm._v(" "),
          _vm._t("label", [
            _vm.title
              ? _c("label", {
                  staticClass: "weui-label",
                  class: _vm.labelClass,
                  style: {
                    width:
                      _vm.labelWidth ||
                      _vm.$parent.labelWidth ||
                      _vm.labelWidthComputed,
                    textAlign: _vm.$parent.labelAlign,
                    marginRight: _vm.$parent.labelMarginRight
                  },
                  attrs: { for: "vux-x-input-" + _vm.uuid },
                  domProps: { innerHTML: _vm._s(_vm.title) }
                })
              : _vm._e(),
            _vm._v(" "),
            _vm.inlineDesc
              ? _c("inline-desc", [_vm._v(_vm._s(_vm.inlineDesc))])
              : _vm._e()
          ])
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "weui-cell__bd weui-cell__primary",
          class: _vm.placeholderAlign
            ? "vux-x-input-placeholder-" + _vm.placeholderAlign
            : ""
        },
        [
          !_vm.type || _vm.type === "text"
            ? _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.currentValue,
                    expression: "currentValue"
                  }
                ],
                ref: "input",
                staticClass: "weui-input",
                style: _vm.inputStyle,
                attrs: {
                  id: "vux-x-input-" + _vm.uuid,
                  maxlength: _vm.max,
                  autocomplete: _vm.autocomplete,
                  autocapitalize: _vm.autocapitalize,
                  autocorrect: _vm.autocorrect,
                  spellcheck: _vm.spellcheck,
                  type: "text",
                  name: _vm.name,
                  pattern: _vm.pattern,
                  placeholder: _vm.placeholder,
                  readonly: _vm.readonly,
                  disabled: _vm.disabled
                },
                domProps: { value: _vm.currentValue },
                on: {
                  focus: _vm.focusHandler,
                  blur: _vm.onBlur,
                  keyup: _vm.onKeyUp,
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.currentValue = $event.target.value
                  }
                }
              })
            : _vm._e(),
          _vm._v(" "),
          _vm.type === "number"
            ? _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.currentValue,
                    expression: "currentValue"
                  }
                ],
                ref: "input",
                staticClass: "weui-input",
                style: _vm.inputStyle,
                attrs: {
                  id: "vux-x-input-" + _vm.uuid,
                  maxlength: _vm.max,
                  autocomplete: _vm.autocomplete,
                  autocapitalize: _vm.autocapitalize,
                  autocorrect: _vm.autocorrect,
                  spellcheck: _vm.spellcheck,
                  type: "number",
                  name: _vm.name,
                  pattern: _vm.pattern,
                  placeholder: _vm.placeholder,
                  readonly: _vm.readonly,
                  disabled: _vm.disabled
                },
                domProps: { value: _vm.currentValue },
                on: {
                  focus: _vm.focusHandler,
                  blur: _vm.onBlur,
                  keyup: _vm.onKeyUp,
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.currentValue = $event.target.value
                  }
                }
              })
            : _vm._e(),
          _vm._v(" "),
          _vm.type === "email"
            ? _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.currentValue,
                    expression: "currentValue"
                  }
                ],
                ref: "input",
                staticClass: "weui-input",
                style: _vm.inputStyle,
                attrs: {
                  id: "vux-x-input-" + _vm.uuid,
                  maxlength: _vm.max,
                  autocomplete: _vm.autocomplete,
                  autocapitalize: _vm.autocapitalize,
                  autocorrect: _vm.autocorrect,
                  spellcheck: _vm.spellcheck,
                  type: "email",
                  name: _vm.name,
                  pattern: _vm.pattern,
                  placeholder: _vm.placeholder,
                  readonly: _vm.readonly,
                  disabled: _vm.disabled
                },
                domProps: { value: _vm.currentValue },
                on: {
                  focus: _vm.focusHandler,
                  blur: _vm.onBlur,
                  keyup: _vm.onKeyUp,
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.currentValue = $event.target.value
                  }
                }
              })
            : _vm._e(),
          _vm._v(" "),
          _vm.type === "password"
            ? _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.currentValue,
                    expression: "currentValue"
                  }
                ],
                ref: "input",
                staticClass: "weui-input",
                style: _vm.inputStyle,
                attrs: {
                  id: "vux-x-input-" + _vm.uuid,
                  maxlength: _vm.max,
                  autocomplete: _vm.autocomplete,
                  autocapitalize: _vm.autocapitalize,
                  autocorrect: _vm.autocorrect,
                  spellcheck: _vm.spellcheck,
                  type: "password",
                  name: _vm.name,
                  pattern: _vm.pattern,
                  placeholder: _vm.placeholder,
                  readonly: _vm.readonly,
                  disabled: _vm.disabled
                },
                domProps: { value: _vm.currentValue },
                on: {
                  focus: _vm.focusHandler,
                  blur: _vm.onBlur,
                  keyup: _vm.onKeyUp,
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.currentValue = $event.target.value
                  }
                }
              })
            : _vm._e(),
          _vm._v(" "),
          _vm.type === "tel"
            ? _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.currentValue,
                    expression: "currentValue"
                  }
                ],
                ref: "input",
                staticClass: "weui-input",
                style: _vm.inputStyle,
                attrs: {
                  id: "vux-x-input-" + _vm.uuid,
                  maxlength: _vm.max,
                  autocomplete: _vm.autocomplete,
                  autocapitalize: _vm.autocapitalize,
                  autocorrect: _vm.autocorrect,
                  spellcheck: _vm.spellcheck,
                  type: "tel",
                  name: _vm.name,
                  pattern: _vm.pattern,
                  placeholder: _vm.placeholder,
                  readonly: _vm.readonly,
                  disabled: _vm.disabled
                },
                domProps: { value: _vm.currentValue },
                on: {
                  focus: _vm.focusHandler,
                  blur: _vm.onBlur,
                  keyup: _vm.onKeyUp,
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.currentValue = $event.target.value
                  }
                }
              })
            : _vm._e()
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "weui-cell__ft" },
        [
          _c("icon", {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value:
                  !_vm.hasRightFullHeightSlot &&
                  !_vm.equalWith &&
                  _vm.showClear &&
                  _vm.currentValue !== "" &&
                  !_vm.readonly &&
                  !_vm.disabled &&
                  _vm.isFocus,
                expression:
                  "!hasRightFullHeightSlot && !equalWith && showClear && currentValue !== '' && !readonly && !disabled && isFocus"
              }
            ],
            attrs: { type: "clear" },
            nativeOn: {
              click: function($event) {
                return _vm.clear($event)
              }
            }
          }),
          _vm._v(" "),
          _c("icon", {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.showWarn,
                expression: "showWarn"
              }
            ],
            staticClass: "vux-input-icon",
            attrs: { type: "warn", title: !_vm.valid ? _vm.firstError : "" },
            nativeOn: {
              click: function($event) {
                return _vm.onClickErrorIcon($event)
              }
            }
          }),
          _vm._v(" "),
          !_vm.novalidate &&
          _vm.hasLengthEqual &&
          _vm.dirty &&
          _vm.equalWith &&
          !_vm.valid
            ? _c("icon", {
                staticClass: "vux-input-icon",
                attrs: { type: "warn" },
                nativeOn: {
                  click: function($event) {
                    return _vm.onClickErrorIcon($event)
                  }
                }
              })
            : _vm._e(),
          _vm._v(" "),
          _c("icon", {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value:
                  !_vm.novalidate &&
                  _vm.equalWith &&
                  _vm.equalWith === _vm.currentValue &&
                  _vm.valid,
                expression:
                  "!novalidate && equalWith && equalWith === currentValue && valid"
              }
            ],
            attrs: { type: "success" }
          }),
          _vm._v(" "),
          _c("icon", {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.novalidate && _vm.iconType === "success",
                expression: "novalidate && iconType === 'success'"
              }
            ],
            staticClass: "vux-input-icon",
            attrs: { type: "success" }
          }),
          _vm._v(" "),
          _c("icon", {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.novalidate && _vm.iconType === "error",
                expression: "novalidate && iconType === 'error'"
              }
            ],
            staticClass: "vux-input-icon",
            attrs: { type: "warn" }
          }),
          _vm._v(" "),
          _vm._t("right"),
          _vm._v(" "),
          _vm.hasRightFullHeightSlot
            ? _c(
                "div",
                { staticClass: "vux-x-input-right-full" },
                [_vm._t("right-full-height")],
                2
              )
            : _vm._e()
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "toast",
        {
          attrs: { type: "text", width: "auto", time: 600 },
          model: {
            value: _vm.showErrorToast,
            callback: function($$v) {
              _vm.showErrorToast = $$v
            },
            expression: "showErrorToast"
          }
        },
        [_vm._v(_vm._s(_vm.firstError))]
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-15a77b8e", esExports)
  }
}

/***/ }),
/* 550 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _name2value = __webpack_require__(467);

var _name2value2 = _interopRequireDefault(_name2value);

var _value2name = __webpack_require__(436);

var _value2name2 = _interopRequireDefault(_value2name);

var _popupPicker = __webpack_require__(470);

var _popupPicker2 = _interopRequireDefault(_popupPicker);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'x-address',
  components: {
    PopupPicker: _popupPicker2.default
  },
  props: {
    title: {
      type: String,
      required: true
    },
    value: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    rawValue: Boolean,
    list: {
      type: Array,
      required: true
    },
    labelWidth: String,
    inlineDesc: String,
    placeholder: String,
    hideDistrict: Boolean,
    valueTextAlign: String,
    confirmText: String,
    cancelText: String,
    displayFormat: {
      type: Function,
      default: function _default(val, names) {
        return names;
      }
    },
    popupStyle: Object,
    popupTitle: String,
    show: Boolean,
    disabled: Boolean
  },
  created: function created() {
    if (this.currentValue.length && this.rawValue) {
      var parsedVal = (0, _name2value2.default)(this.currentValue, this.list);
      if (/__/.test(parsedVal)) {
        console.error('[VUX] Wrong address value', this.currentValue);
        this.currentValue = [];
      } else {
        this.currentValue = parsedVal.split(' ');
      }
    }
    if (this.show) {
      this.showValue = true;
    }
  },

  methods: {
    emitHide: function emitHide(val) {
      this.$emit('on-hide', val);
    },
    getAddressName: function getAddressName() {
      return (0, _value2name2.default)(this.value, this.list);
    },
    onShadowChange: function onShadowChange(ids, names) {
      this.$emit('on-shadow-change', ids, names);
    }
  },
  data: function data() {
    return {
      currentValue: this.value,
      showValue: false
    };
  },

  computed: {
    nameValue: function nameValue() {
      return (0, _value2name2.default)(this.currentValue, this.list);
    },
    labelClass: function labelClass() {
      return {
        'vux-cell-justify': this.$parent.labelAlign === 'justify' || this.$parent.$parent.labelAlign === 'justify'
      };
    }
  },
  watch: {
    currentValue: function currentValue(val) {
      this.$emit('input', val);
    },
    value: function value(val) {
      if (val.length && !/\d+/.test(val[0])) {
        var id = (0, _name2value2.default)(val, this.list).split(' ');
        if (id[0] !== '__' && id[1] !== '__') {
          this.currentValue = id;
          return;
        }
      }
      this.currentValue = val;
    },
    show: function show(val) {
      this.showValue = val;
    },
    showValue: function showValue(val) {
      this.$emit('update:show', val);
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 551 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(552);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("0cf2be7c", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-c23b5128\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-c23b5128\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 552 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.vux-1px,\n.vux-1px-t,\n.vux-1px-b,\n.vux-1px-tb,\n.vux-1px-l,\n.vux-1px-r {\n  position: relative;\n}\n.vux-1px:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 200%;\n  border: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  height: 200%;\n  transform-origin: left top;\n  transform: scale(0.5);\n}\n.vux-1px-t:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.vux-1px-b:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.vux-1px-tb:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.vux-1px-tb:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.vux-1px-l:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 1px;\n  bottom: 0;\n  border-left: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 0;\n  transform: scaleX(0.5);\n}\n.vux-1px-r:after {\n  content: \" \";\n  position: absolute;\n  right: 0;\n  top: 0;\n  width: 1px;\n  bottom: 0;\n  border-right: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 100% 0;\n  transform: scaleX(0.5);\n}\n.vux-cell-primary {\n  flex: 1;\n}\n.vux-cell-box {\n  position: relative;\n}\n.vux-cell-box:not(:first-child):before {\n  content: \" \";\n  position: absolute;\n  top: 0;\n  width: 100%;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n  left: 15px;\n}\n.vux-popup-picker-header {\n  height: 44px;\n  color: #04BE02;\n  background-color: #fbf9fe;\n  font-size: 16px;\n  position: relative;\n}\n.vux-popup-picker-header:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #e5e5e5;\n  color: #e5e5e5;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.vux-popup-picker-value {\n  /* display: inline-block; */\n}\n.vux-popup-picker-header-menu {\n  text-align: left;\n  padding-left: 15px;\n  line-height: 44px;\n}\n.vux-popup-picker-header-menu-right {\n  text-align: right;\n  padding-right: 15px;\n}\n.vux-popup-picker-select {\n  width: 100%;\n  position: relative;\n}\n.vux-popup-picker-select-box.weui-cell__bd:after {\n  content: \" \";\n  display: inline-block;\n  transform: rotate(45deg);\n  height: 6px;\n  width: 6px;\n  border-width: 2px 2px 0 0;\n  border-color: #C8C8CD;\n  border-style: solid;\n  position: relative;\n  top: -2px;\n  position: absolute;\n  top: 50%;\n  right: 15px;\n  margin-top: -3px;\n}\n.vux-popup-picker-cancel {\n  color: #828282;\n}\n.vux-popup-picker-placeholder {\n  color: #999;\n}\n", ""]);

// exports


/***/ }),
/* 553 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(433);

var _stringify2 = _interopRequireDefault(_stringify);

var _picker = __webpack_require__(471);

var _picker2 = _interopRequireDefault(_picker);

var _cell = __webpack_require__(476);

var _cell2 = _interopRequireDefault(_cell);

var _popup = __webpack_require__(479);

var _popup2 = _interopRequireDefault(_popup);

var _popupHeader = __webpack_require__(482);

var _popupHeader2 = _interopRequireDefault(_popupHeader);

var _inlineDesc = __webpack_require__(435);

var _inlineDesc2 = _interopRequireDefault(_inlineDesc);

var _flexbox = __webpack_require__(441);

var _array2String = __webpack_require__(483);

var _array2String2 = _interopRequireDefault(_array2String);

var _value2name = __webpack_require__(436);

var _value2name2 = _interopRequireDefault(_value2name);

var _mixin_uuid = __webpack_require__(445);

var _mixin_uuid2 = _interopRequireDefault(_mixin_uuid);

var _transferDom = __webpack_require__(484);

var _transferDom2 = _interopRequireDefault(_transferDom);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var getObject = function getObject(obj) {
  return JSON.parse((0, _stringify2.default)(obj));
};

exports.default = {
  name: 'popup-picker',
  directives: {
    TransferDom: _transferDom2.default
  },
  created: function created() {
    if (typeof this.show !== 'undefined') {
      this.showValue = this.show;
    }
  },

  mixins: [_mixin_uuid2.default],
  components: {
    Picker: _picker2.default,
    Cell: _cell2.default,
    Popup: _popup2.default,
    PopupHeader: _popupHeader2.default,
    Flexbox: _flexbox.Flexbox,
    FlexboxItem: _flexbox.FlexboxItem,
    InlineDesc: _inlineDesc2.default
  },
  filters: {
    array2string: _array2String2.default,
    value2name: _value2name2.default
  },
  props: {
    valueTextAlign: {
      type: String,
      default: 'right'
    },
    title: String,
    cancelText: String,
    confirmText: String,
    data: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    placeholder: String,
    columns: {
      type: Number,
      default: 0
    },
    fixedColumns: {
      type: Number,
      default: 0
    },
    value: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    showName: Boolean,
    inlineDesc: [String, Number, Array, Object, Boolean],
    showCell: {
      type: Boolean,
      default: true
    },
    show: Boolean,
    displayFormat: Function,
    isTransferDom: {
      type: Boolean,
      default: true
    },
    columnWidth: Array,
    popupStyle: Object,
    popupTitle: String,
    disabled: Boolean
  },
  computed: {
    labelStyles: function labelStyles() {
      return {
        display: 'block',
        width: this.$parent.labelWidth || this.$parent.$parent.labelWidth || 'auto',
        textAlign: this.$parent.labelAlign || this.$parent.$parent.labelAlign,
        marginRight: this.$parent.labelMarginRight || this.$parent.$parent.labelMarginRight
      };
    },
    labelClass: function labelClass() {
      return {
        'vux-cell-justify': this.$parent.labelAlign === 'justify' || this.$parent.$parent.labelAlign === 'justify'
      };
    }
  },
  methods: {
    value2name: _value2name2.default,
    getNameValues: function getNameValues() {
      return (0, _value2name2.default)(this.currentValue, this.data);
    },
    onClick: function onClick() {
      if (!this.disabled) {
        this.showValue = true;
      }
    },
    onHide: function onHide(type) {
      this.showValue = false;
      if (type) {
        this.closeType = true;
        this.currentValue = getObject(this.tempValue);
      }
      if (!type) {
        this.closeType = false;
        if (this.value.length > 0) {
          this.tempValue = getObject(this.currentValue);
        }
      }
    },
    onPopupShow: function onPopupShow() {
      // reset close type to false
      this.closeType = false;
      this.$emit('on-show');
    },
    onPopupHide: function onPopupHide(val) {
      if (this.value.length > 0) {
        this.tempValue = getObject(this.currentValue);
      }
      this.$emit('on-hide', this.closeType);
    },
    onPickerChange: function onPickerChange(val) {
      if ((0, _stringify2.default)(this.currentValue) !== (0, _stringify2.default)(val)) {
        // if has value, replace it
        if (this.value.length) {
          var nowData = (0, _stringify2.default)(this.data);
          if (nowData !== this.currentData && this.currentData !== '[]') {
            this.tempValue = getObject(val);
          }
          this.currentData = nowData;
        } else {// if no value, stay quiet
          // if set to auto update, do update the value
        }
      }
      var _val = getObject(val);
      this.$emit('on-shadow-change', _val, (0, _value2name2.default)(_val, this.data).split(' '));
    }
  },
  watch: {
    value: function value(val) {
      if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(this.tempValue)) {
        this.tempValue = getObject(val);
        this.currentValue = getObject(val);
      }
    },
    currentValue: function currentValue(val) {
      this.$emit('input', getObject(val));
      this.$emit('on-change', getObject(val));
    },
    show: function show(val) {
      this.showValue = val;
    },
    showValue: function showValue(val) {
      this.$emit('update:show', val);
    }
  },
  data: function data() {
    return {
      onShowProcess: false,
      tempValue: getObject(this.value),
      closeType: false,
      currentData: (0, _stringify2.default)(this.data), // used for detecting if it is after data change
      showValue: false,
      currentValue: this.value
    };
  }
};

/***/ }),
/* 554 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(555);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("6ca7a899", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-26e72deb\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-26e72deb\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 555 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports
exports.i(__webpack_require__(556), "");

// module
exports.push([module.i, "\n", ""]);

// exports


/***/ }),
/* 556 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, ".scroller-component {\n  display: block;\n  position: relative;\n  height: 238px;\n  overflow: hidden;\n  width: 100%;\n}\n\n.scroller-content {\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 100%;\n  z-index: 1;\n}\n\n.scroller-mask {\n  position: absolute;\n  left: 0;\n  top: 0;\n  height: 100%;\n  margin: 0 auto;\n  width: 100%;\n  z-index: 3;\n  transform: translateZ(0px);\n  background-image:\n    -webkit-linear-gradient(top, rgba(255,255,255,0.95), rgba(255,255,255,0.6)),\n    -webkit-linear-gradient(bottom, rgba(255,255,255,0.95), rgba(255,255,255,0.6));\n  background-image:\n    linear-gradient(to bottom, rgba(255,255,255,0.95), rgba(255,255,255,0.6)),\n    linear-gradient(to top, rgba(255,255,255,0.95), rgba(255,255,255,0.6));\n  background-position: top, bottom;\n  background-size: 100% 102px;\n  background-repeat: no-repeat;\n}\n\n.scroller-item {\n  text-align: center;\n  font-size: 16px;\n  height: 34px;\n  line-height: 34px;\n  color: #000;\n}\n\n.scroller-indicator {\n  width: 100%;\n  height: 34px;\n  position: absolute;\n  left: 0;\n  top: 102px;\n  z-index: 3;\n  background-image:\n    -webkit-linear-gradient(top, #d0d0d0, #d0d0d0, transparent, transparent),\n    -webkit-linear-gradient(bottom, #d0d0d0, #d0d0d0, transparent, transparent);\n  background-image:\n    linear-gradient(to bottom, #d0d0d0, #d0d0d0, transparent, transparent),\n    linear-gradient(to top, #d0d0d0, #d0d0d0, transparent, transparent);\n  background-position: top, bottom;\n  background-size: 100% 1px;\n  background-repeat: no-repeat;\n}\n.scroller-item {\n  line-clamp: 1;\n  -webkit-line-clamp: 1;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}", ""]);

// exports


/***/ }),
/* 557 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(433);

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = __webpack_require__(437);

var _typeof3 = _interopRequireDefault(_typeof2);

var _scroller = __webpack_require__(472);

var _scroller2 = _interopRequireDefault(_scroller);

var _flexbox = __webpack_require__(441);

var _chain = __webpack_require__(474);

var _chain2 = _interopRequireDefault(_chain);

var _value2name = __webpack_require__(436);

var _value2name2 = _interopRequireDefault(_value2name);

var _isArray = __webpack_require__(475);

var _isArray2 = _interopRequireDefault(_isArray);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'picker',
  components: {
    Flexbox: _flexbox.Flexbox,
    FlexboxItem: _flexbox.FlexboxItem
  },
  created: function created() {
    if (this.columns !== 0) {
      var length = this.columns;
      this.store = new _chain2.default(this.data, length, this.fixedColumns || this.columns);
      this.currentData = this.store.getColumns(this.value);
    }
  },
  mounted: function mounted() {
    var _this2 = this;

    this.uuid = Math.random().toString(36).substring(3, 8);
    this.$nextTick(function () {
      _this2.render(_this2.currentData, _this2.currentValue);
    });
  },

  props: {
    data: Array,
    columns: {
      type: Number,
      default: 0
    },
    fixedColumns: {
      type: Number,
      default: 0
    },
    value: Array,
    itemClass: {
      type: String,
      default: 'scroller-item'
    },
    columnWidth: Array
  },
  methods: {
    getNameValues: function getNameValues() {
      return (0, _value2name2.default)(this.currentValue, this.data);
    },
    getId: function getId(i) {
      return '#vux-picker-' + this.uuid + '-' + i;
    },
    render: function render(data, value) {
      this.count = this.currentData.length;
      var _this = this;
      if (!data || !data.length) {
        return;
      }
      var count = this.currentData.length;
      // set first item as value
      if (value.length < count) {
        for (var i = 0; i < count; i++) {
          if (process.env.NODE_ENV === 'development' && typeof data[i][0] === 'undefined' && (0, _isArray2.default)(this.data) && this.data[0] && typeof this.data[0].value !== 'undefined' && !this.columns) {
            console.error('[VUX error] 渲染出错，如果为联动模式，需要指定 columns(列数)');
          }
          this.$set(_this.currentValue, i, data[i][0].value || data[i][0]);
        }
      }

      var _loop = function _loop(_i) {
        /**
        * Still don't know why this happens
        */
        if (!document.querySelector(_this.getId(_i))) {
          return {
            v: void 0
          };
        }

        _this.scroller[_i] && _this.scroller[_i].destroy();
        _this.scroller[_i] = new _scroller2.default(_this.getId(_i), {
          data: data[_i],
          defaultValue: value[_i] || data[_i][0].value,
          itemClass: _this.itemClass,
          onSelect: function onSelect(value) {
            _this.$set(_this.currentValue, _i, value);
            if (!this.columns || this.columns && _this.getValue().length === _this.store.count) {
              _this.$nextTick(function () {
                _this.$emit('on-change', _this.getValue());
              });
            }
            if (_this.columns !== 0) {
              _this.renderChain(_i + 1);
            }
          }
        });
        if (_this.currentValue) {
          _this.scroller[_i].select(value[_i]);
        }
      };

      for (var _i = 0; _i < data.length; _i++) {
        var _ret = _loop(_i);

        if ((typeof _ret === 'undefined' ? 'undefined' : (0, _typeof3.default)(_ret)) === "object") return _ret.v;
      }
    },
    renderChain: function renderChain(i) {
      if (!this.columns) {
        return;
      }

      // do not render for last scroller
      if (i > this.count - 1) {
        return;
      }

      var _this = this;
      var ID = this.getId(i);
      // destroy old one
      this.scroller[i].destroy();
      var list = this.store.getChildren(_this.getValue()[i - 1]);
      this.scroller[i] = new _scroller2.default(ID, {
        data: list,
        itemClass: _this.item_class,
        onSelect: function onSelect(value) {
          _this.$set(_this.currentValue, i, value);
          _this.$nextTick(function () {
            _this.$emit('on-change', _this.getValue());
          });
          _this.renderChain(i + 1);
        }
      });
      // list is Array(empty) as maybe
      if (list.length) {
        this.$set(this.currentValue, i, list[0].value);
        this.renderChain(i + 1);
      } else {
        this.$set(this.currentValue, i, null);
      }
    },
    getValue: function getValue() {
      var data = [];
      for (var i = 0; i < this.currentData.length; i++) {
        if (this.scroller[i]) {
          data.push(this.scroller[i].value);
        } else {
          return [];
        }
      }
      return data;
    },
    emitValueChange: function emitValueChange(val) {
      if (!this.columns || this.columns && val.length === this.store.count) {
        this.$emit('on-change', val);
      }
    }
  },
  data: function data() {
    return {
      scroller: [],
      count: 0,
      uuid: '',
      currentData: this.data,
      currentValue: this.value
    };
  },

  watch: {
    value: function value(val) {
      if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(this.currentValue)) {
        this.currentValue = val;
      }
    },
    currentValue: function currentValue(val, oldVal) {
      this.$emit('input', val);
      // render all the scroller for chain datas
      if (this.columns !== 0) {
        if (val.length > 0) {
          if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(oldVal)) {
            this.currentData = this.store.getColumns(val);
            this.$nextTick(function () {
              this.render(this.currentData, val);
            });
          }
        }
      } else {
        if (val.length) {
          for (var i = 0; i < val.length; i++) {
            if (this.scroller[i] && this.scroller[i].value !== val[i]) {
              this.scroller[i].select(val[i]);
            }
          }
        } else {
          this.render(this.currentData, []);
        }
      }
    },
    data: function data(val) {
      if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(this.currentData)) {
        this.currentData = val;
      }
    },
    currentData: function currentData(newData) {
      var _this3 = this;

      if (Object.prototype.toString.call(newData[0]) === '[object Array]') {
        this.$nextTick(function () {
          _this3.render(newData, _this3.currentValue);
          // emit on-change after rerender
          _this3.$nextTick(function () {
            _this3.emitValueChange(_this3.getValue());

            if ((0, _stringify2.default)(_this3.getValue()) !== (0, _stringify2.default)(_this3.currentValue)) {
              if (!_this3.columns || _this3.columns && _this3.getValue().length === _this3.store.count) {
                _this3.currentValue = _this3.getValue();
              }
            }
          });
        });
      } else {
        if (this.columns !== 0) {
          if (!newData.length) {
            return;
          }
          var length = this.columns;
          this.store = new _chain2.default(newData, length, this.fixedColumns || this.columns);
          this.currentData = this.store.getColumns(this.currentValue);
        }
      }
    }
  },
  beforeDestroy: function beforeDestroy() {
    for (var i = 0; i < this.count; i++) {
      this.scroller[i] && this.scroller[i].destroy();
      this.scroller[i] = null;
    }
  }
}; //
//
//
//
//
//
//
//
//
//
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(56)))

/***/ }),
/* 558 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var time = Date.now || function () {
  return +new Date();
};

var running = {};
var counter = 1;
var desiredFrames = 60;
var millisecondsPerSecond = 1000;

// http://paulirish.com/2011/requestanimationframe-for-smart-animating/
// http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating

// requestAnimationFrame polyfill by Erik Möller
// fixes from Paul Irish and Tino Zijdel
if (typeof window !== 'undefined') {
  ;(function () {
    var lastTime = 0;
    var vendors = ['ms', 'moz', 'webkit', 'o'];
    for (var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
      window.requestAnimationFrame = window[vendors[x] + 'RequestAnimationFrame'];
      window.cancelAnimationFrame = window[vendors[x] + 'CancelAnimationFrame'] || window[vendors[x] + 'CancelRequestAnimationFrame'];
    }

    if (!window.requestAnimationFrame) {
      window.requestAnimationFrame = function (callback, element) {
        var currTime = new Date().getTime();
        var timeToCall = Math.max(0, 16 - (currTime - lastTime));
        var id = window.setTimeout(function () {
          callback(currTime + timeToCall);
        }, timeToCall);
        lastTime = currTime + timeToCall;
        return id;
      };
    }
    if (!window.cancelAnimationFrame) {
      window.cancelAnimationFrame = function (id) {
        clearTimeout(id);
      };
    }
  })();
}

module.exports = {

  // A requestAnimationFrame wrapper / polyfill.
  requestAnimationFrame: function () {
    if (typeof window !== 'undefined') {
      var requestFrame = window.requestAnimationFrame;
      return function (callback, root) {
        requestFrame(callback, root);
      };
    }
  }(),

  // Stops the given animation.
  stop: function stop(id) {
    var cleared = running[id] != null;
    if (cleared) {
      running[id] = null;
    }
    return cleared;
  },


  // Whether the given animation is still running.
  isRunning: function isRunning(id) {
    return running[id] != null;
  },


  // Start the animation.
  start: function start(stepCallback, verifyCallback, completedCallback, duration, easingMethod, root) {
    var _this = this;
    var start = time();
    var lastFrame = start;
    var percent = 0;
    var dropCounter = 0;
    var id = counter++;

    if (!root) {
      root = document.body;
    }

    // Compacting running db automatically every few new animations
    if (id % 20 === 0) {
      var newRunning = {};
      for (var usedId in running) {
        newRunning[usedId] = true;
      }
      running = newRunning;
    }

    // This is the internal step method which is called every few milliseconds
    var step = function step(virtual) {
      // Normalize virtual value
      var render = virtual !== true;
      // Get current time
      var now = time();

      // Verification is executed before next animation step
      if (!running[id] || verifyCallback && !verifyCallback(id)) {
        running[id] = null;
        completedCallback && completedCallback(desiredFrames - dropCounter / ((now - start) / millisecondsPerSecond), id, false);
        return;
      }

      // For the current rendering to apply let's update omitted steps in memory.
      // This is important to bring internal state variables up-to-date with progress in time.
      if (render) {
        var droppedFrames = Math.round((now - lastFrame) / (millisecondsPerSecond / desiredFrames)) - 1;
        for (var j = 0; j < Math.min(droppedFrames, 4); j++) {
          step(true);
          dropCounter++;
        }
      }

      // Compute percent value
      if (duration) {
        percent = (now - start) / duration;
        if (percent > 1) {
          percent = 1;
        }
      }

      // Execute step callback, then...
      var value = easingMethod ? easingMethod(percent) : percent;
      if ((stepCallback(value, now, render) === false || percent === 1) && render) {
        running[id] = null;
        completedCallback && completedCallback(desiredFrames - dropCounter / ((now - start) / millisecondsPerSecond), id, percent === 1 || duration == null);
      } else if (render) {
        lastFrame = now;
        _this.requestAnimationFrame(step, root);
      }
    };

    // Mark as running
    running[id] = true;
    // Init first step
    _this.requestAnimationFrame(step, root);
    // Return unique animation ID
    return id;
  }
};

/***/ }),
/* 559 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getElement = getElement;
exports.getComputedStyle = getComputedStyle;
exports.easeOutCubic = easeOutCubic;
exports.easeInOutCubic = easeInOutCubic;
function getElement(expr) {
  return typeof expr === 'string' ? document.querySelector(expr) : expr;
}

function getComputedStyle(el, key) {
  var computedStyle = window.getComputedStyle(el);
  return computedStyle[key] || '';
}

// Easing Equations (c) 2003 Robert Penner, all rights reserved.
// Open source under the BSD License.
function easeOutCubic(pos) {
  return Math.pow(pos - 1, 3) + 1;
}

function easeInOutCubic(pos) {
  if ((pos /= 0.5) < 1) {
    return 0.5 * Math.pow(pos, 3);
  }
  return 0.5 * (Math.pow(pos - 2, 3) + 2);
}

/***/ }),
/* 560 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(561);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("3342313e", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-69417b2a\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./flexbox.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-69417b2a\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./flexbox.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 561 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "\n.vux-flexbox {\n  width: 100%;\n  text-align: left;\n  display: flex;\n  display: -webkit-flex;\n  box-align: center;\n  align-items: center;\n}\n.vux-flexbox .vux-flexbox-item {\n  flex: 1;\n  -webkit-flex: 1;\n  min-width: 20px;\n  width: 0%;\n}\n.vux-flexbox .vux-flexbox-item:first-child {\n  margin-left: 0!important;\n  margin-top: 0!important;\n}\n.vux-flex-row {\n  box-direction: row;\n  box-orient: horizontal;\n  flex-direction: row;\n}\n.vux-flex-col {\n  box-orient: vertical;\n  flex-direction: column;\n}\n.vux-flex-col > .vux-flexbox-item {\n  width: 100%;\n}\n", ""]);

// exports


/***/ }),
/* 562 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'flexbox',
  props: {
    gutter: {
      type: Number,
      default: 8
    },
    orient: {
      type: String,
      default: 'horizontal'
    },
    justify: String,
    align: String,
    wrap: String,
    direction: String
  },
  computed: {
    styles: function styles() {
      var styles = {
        'justify-content': this.justify,
        '-webkit-justify-content': this.justify,
        'align-items': this.align,
        '-webkit-align-items': this.align,
        'flex-wrap': this.wrap,
        '-webkit-flex-wrap': this.wrap,
        'flex-direction': this.direction,
        '-webkit-flex-direction': this.direction
      };
      return styles;
    }
  }
};

/***/ }),
/* 563 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'flexbox',
  props: {
    gutter: {
      type: Number,
      default: 8
    },
    orient: {
      type: String,
      default: 'horizontal'
    },
    justify: String,
    align: String,
    wrap: String,
    direction: String
  },
  computed: {
    styles: function styles() {
      var styles = {
        'justify-content': this.justify,
        '-webkit-justify-content': this.justify,
        'align-items': this.align,
        '-webkit-align-items': this.align,
        'flex-wrap': this.wrap,
        '-webkit-flex-wrap': this.wrap,
        'flex-direction': this.direction,
        '-webkit-flex-direction': this.direction
      };
      return styles;
    }
  }
};

/***/ }),
/* 564 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "vux-flexbox",
      class: {
        "vux-flex-col": _vm.orient === "vertical",
        "vux-flex-row": _vm.orient === "horizontal"
      },
      style: _vm.styles
    },
    [_vm._t("default")],
    2
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-69417b2a", esExports)
  }
}

/***/ }),
/* 565 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//

var prefixList = ['-moz-box-', '-webkit-box-', ''];

exports.default = {
  name: 'flexbox-item',
  props: {
    span: [Number, String],
    order: [Number, String]
  },
  beforeMount: function beforeMount() {
    this.bodyWidth = document.documentElement.offsetWidth;
  },

  methods: {
    buildWidth: function buildWidth(width) {
      if (typeof width === 'number') {
        if (width < 1) {
          return width;
        } else {
          return width / 12;
        }
      } else if (typeof width === 'string') {
        return width.replace('px', '') / this.bodyWidth;
      }
    }
  },
  computed: {
    style: function style() {
      var styles = {};
      var marginName = this.$parent.orient === 'horizontal' ? 'marginLeft' : 'marginTop';

      if (this.$parent.gutter * 1 !== 0) {
        styles[marginName] = this.$parent.gutter + 'px';
      }

      if (this.span) {
        for (var i = 0; i < prefixList.length; i++) {
          styles[prefixList[i] + 'flex'] = '0 0 ' + this.buildWidth(this.span) * 100 + '%';
        }
      }
      if (typeof this.order !== 'undefined') {
        styles.order = this.order;
      }
      return styles;
    }
  },
  data: function data() {
    return {
      bodyWidth: 0
    };
  }
};

/***/ }),
/* 566 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//

var prefixList = ['-moz-box-', '-webkit-box-', ''];

exports.default = {
  name: 'flexbox-item',
  props: {
    span: [Number, String],
    order: [Number, String]
  },
  beforeMount: function beforeMount() {
    this.bodyWidth = document.documentElement.offsetWidth;
  },

  methods: {
    buildWidth: function buildWidth(width) {
      if (typeof width === 'number') {
        if (width < 1) {
          return width;
        } else {
          return width / 12;
        }
      } else if (typeof width === 'string') {
        return width.replace('px', '') / this.bodyWidth;
      }
    }
  },
  computed: {
    style: function style() {
      var styles = {};
      var marginName = this.$parent.orient === 'horizontal' ? 'marginLeft' : 'marginTop';

      if (this.$parent.gutter * 1 !== 0) {
        styles[marginName] = this.$parent.gutter + 'px';
      }

      if (this.span) {
        for (var i = 0; i < prefixList.length; i++) {
          styles[prefixList[i] + 'flex'] = '0 0 ' + this.buildWidth(this.span) * 100 + '%';
        }
      }
      if (typeof this.order !== 'undefined') {
        styles.order = this.order;
      }
      return styles;
    }
  },
  data: function data() {
    return {
      bodyWidth: 0
    };
  }
};

/***/ }),
/* 567 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "vux-flexbox-item", style: _vm.style },
    [_vm._t("default")],
    2
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-76256936", esExports)
  }
}

/***/ }),
/* 568 */
/***/ (function(module, exports) {


/**
 * Array#filter.
 *
 * @param {Array} arr
 * @param {Function} fn
 * @param {Object=} self
 * @return {Array}
 * @throw TypeError
 */

module.exports = function (arr, fn, self) {
  if (arr.filter) return arr.filter(fn, self);
  if (void 0 === arr || null === arr) throw new TypeError;
  if ('function' != typeof fn) throw new TypeError;
  var ret = [];
  for (var i = 0; i < arr.length; i++) {
    if (!hasOwn.call(arr, i)) continue;
    var val = arr[i];
    if (fn.call(self, val, i, arr)) ret.push(val);
  }
  return ret;
};

var hasOwn = Object.prototype.hasOwnProperty;


/***/ }),
/* 569 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(433);

var _stringify2 = _interopRequireDefault(_stringify);

var _typeof2 = __webpack_require__(437);

var _typeof3 = _interopRequireDefault(_typeof2);

var _scroller = __webpack_require__(472);

var _scroller2 = _interopRequireDefault(_scroller);

var _flexbox = __webpack_require__(441);

var _chain = __webpack_require__(474);

var _chain2 = _interopRequireDefault(_chain);

var _value2name = __webpack_require__(436);

var _value2name2 = _interopRequireDefault(_value2name);

var _isArray = __webpack_require__(475);

var _isArray2 = _interopRequireDefault(_isArray);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'picker',
  components: {
    Flexbox: _flexbox.Flexbox,
    FlexboxItem: _flexbox.FlexboxItem
  },
  created: function created() {
    if (this.columns !== 0) {
      var length = this.columns;
      this.store = new _chain2.default(this.data, length, this.fixedColumns || this.columns);
      this.currentData = this.store.getColumns(this.value);
    }
  },
  mounted: function mounted() {
    var _this2 = this;

    this.uuid = Math.random().toString(36).substring(3, 8);
    this.$nextTick(function () {
      _this2.render(_this2.currentData, _this2.currentValue);
    });
  },

  props: {
    data: Array,
    columns: {
      type: Number,
      default: 0
    },
    fixedColumns: {
      type: Number,
      default: 0
    },
    value: Array,
    itemClass: {
      type: String,
      default: 'scroller-item'
    },
    columnWidth: Array
  },
  methods: {
    getNameValues: function getNameValues() {
      return (0, _value2name2.default)(this.currentValue, this.data);
    },
    getId: function getId(i) {
      return '#vux-picker-' + this.uuid + '-' + i;
    },
    render: function render(data, value) {
      this.count = this.currentData.length;
      var _this = this;
      if (!data || !data.length) {
        return;
      }
      var count = this.currentData.length;
      // set first item as value
      if (value.length < count) {
        for (var i = 0; i < count; i++) {
          if (process.env.NODE_ENV === 'development' && typeof data[i][0] === 'undefined' && (0, _isArray2.default)(this.data) && this.data[0] && typeof this.data[0].value !== 'undefined' && !this.columns) {
            console.error('[VUX error] 渲染出错，如果为联动模式，需要指定 columns(列数)');
          }
          this.$set(_this.currentValue, i, data[i][0].value || data[i][0]);
        }
      }

      var _loop = function _loop(_i) {
        /**
        * Still don't know why this happens
        */
        if (!document.querySelector(_this.getId(_i))) {
          return {
            v: void 0
          };
        }

        _this.scroller[_i] && _this.scroller[_i].destroy();
        _this.scroller[_i] = new _scroller2.default(_this.getId(_i), {
          data: data[_i],
          defaultValue: value[_i] || data[_i][0].value,
          itemClass: _this.itemClass,
          onSelect: function onSelect(value) {
            _this.$set(_this.currentValue, _i, value);
            if (!this.columns || this.columns && _this.getValue().length === _this.store.count) {
              _this.$nextTick(function () {
                _this.$emit('on-change', _this.getValue());
              });
            }
            if (_this.columns !== 0) {
              _this.renderChain(_i + 1);
            }
          }
        });
        if (_this.currentValue) {
          _this.scroller[_i].select(value[_i]);
        }
      };

      for (var _i = 0; _i < data.length; _i++) {
        var _ret = _loop(_i);

        if ((typeof _ret === 'undefined' ? 'undefined' : (0, _typeof3.default)(_ret)) === "object") return _ret.v;
      }
    },
    renderChain: function renderChain(i) {
      if (!this.columns) {
        return;
      }

      // do not render for last scroller
      if (i > this.count - 1) {
        return;
      }

      var _this = this;
      var ID = this.getId(i);
      // destroy old one
      this.scroller[i].destroy();
      var list = this.store.getChildren(_this.getValue()[i - 1]);
      this.scroller[i] = new _scroller2.default(ID, {
        data: list,
        itemClass: _this.item_class,
        onSelect: function onSelect(value) {
          _this.$set(_this.currentValue, i, value);
          _this.$nextTick(function () {
            _this.$emit('on-change', _this.getValue());
          });
          _this.renderChain(i + 1);
        }
      });
      // list is Array(empty) as maybe
      if (list.length) {
        this.$set(this.currentValue, i, list[0].value);
        this.renderChain(i + 1);
      } else {
        this.$set(this.currentValue, i, null);
      }
    },
    getValue: function getValue() {
      var data = [];
      for (var i = 0; i < this.currentData.length; i++) {
        if (this.scroller[i]) {
          data.push(this.scroller[i].value);
        } else {
          return [];
        }
      }
      return data;
    },
    emitValueChange: function emitValueChange(val) {
      if (!this.columns || this.columns && val.length === this.store.count) {
        this.$emit('on-change', val);
      }
    }
  },
  data: function data() {
    return {
      scroller: [],
      count: 0,
      uuid: '',
      currentData: this.data,
      currentValue: this.value
    };
  },

  watch: {
    value: function value(val) {
      if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(this.currentValue)) {
        this.currentValue = val;
      }
    },
    currentValue: function currentValue(val, oldVal) {
      this.$emit('input', val);
      // render all the scroller for chain datas
      if (this.columns !== 0) {
        if (val.length > 0) {
          if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(oldVal)) {
            this.currentData = this.store.getColumns(val);
            this.$nextTick(function () {
              this.render(this.currentData, val);
            });
          }
        }
      } else {
        if (val.length) {
          for (var i = 0; i < val.length; i++) {
            if (this.scroller[i] && this.scroller[i].value !== val[i]) {
              this.scroller[i].select(val[i]);
            }
          }
        } else {
          this.render(this.currentData, []);
        }
      }
    },
    data: function data(val) {
      if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(this.currentData)) {
        this.currentData = val;
      }
    },
    currentData: function currentData(newData) {
      var _this3 = this;

      if (Object.prototype.toString.call(newData[0]) === '[object Array]') {
        this.$nextTick(function () {
          _this3.render(newData, _this3.currentValue);
          // emit on-change after rerender
          _this3.$nextTick(function () {
            _this3.emitValueChange(_this3.getValue());

            if ((0, _stringify2.default)(_this3.getValue()) !== (0, _stringify2.default)(_this3.currentValue)) {
              if (!_this3.columns || _this3.columns && _this3.getValue().length === _this3.store.count) {
                _this3.currentValue = _this3.getValue();
              }
            }
          });
        });
      } else {
        if (this.columns !== 0) {
          if (!newData.length) {
            return;
          }
          var length = this.columns;
          this.store = new _chain2.default(newData, length, this.fixedColumns || this.columns);
          this.currentData = this.store.getColumns(this.currentValue);
        }
      }
    }
  },
  beforeDestroy: function beforeDestroy() {
    for (var i = 0; i < this.count; i++) {
      this.scroller[i] && this.scroller[i].destroy();
      this.scroller[i] = null;
    }
  }
}; //
//
//
//
//
//
//
//
//
//
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(56)))

/***/ }),
/* 570 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { staticClass: "vux-picker" },
    [
      _c(
        "flexbox",
        { attrs: { gutter: 0 } },
        _vm._l(_vm.currentData, function(one, index) {
          return _c(
            "flexbox-item",
            {
              key: index,
              staticStyle: { "margin-left": "0" },
              attrs: { span: _vm.columnWidth && _vm.columnWidth[index] }
            },
            [
              _c("div", {
                staticClass: "vux-picker-item",
                attrs: { id: "vux-picker-" + _vm.uuid + "-" + index }
              })
            ]
          )
        })
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-26e72deb", esExports)
  }
}

/***/ }),
/* 571 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(572);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("9f5788e0", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-ae688382\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-ae688382\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 572 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.vux-tap-active {\n  tap-highlight-color: rgba(0, 0, 0, 0);\n  user-select: none;\n}\n.vux-tap-active:active {\n  background-color: #ECECEC;\n}\n.weui-cells {\n  margin-top: 1.17647059em;\n  background-color: #FFFFFF;\n  line-height: 1.41176471;\n  font-size: 17px;\n  overflow: hidden;\n  position: relative;\n}\n.weui-cells:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.weui-cells:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.weui-cells__title {\n  margin-top: 0.77em;\n  margin-bottom: 0.3em;\n  padding-left: 15px;\n  padding-right: 15px;\n  color: #999999;\n  font-size: 14px;\n}\n.weui-cells__title + .weui-cells {\n  margin-top: 0;\n}\n.weui-cells__tips {\n  margin-top: .3em;\n  color: #999999;\n  padding-left: 15px;\n  padding-right: 15px;\n  font-size: 14px;\n}\n.weui-cell {\n  padding: 10px 15px;\n  position: relative;\n  display: flex;\n  align-items: center;\n}\n.weui-cell:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #D9D9D9;\n  color: #D9D9D9;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n  left: 15px;\n}\n.weui-cell:first-child:before {\n  display: none;\n}\n.weui-cell_primary {\n  align-items: flex-start;\n}\n.weui-cell__bd {\n  flex: 1;\n}\n.weui-cell__ft {\n  text-align: right;\n  color: #999999;\n}\n.vux-cell-justify {\n  height: 1.41176471em;\n}\n.vux-cell-justify.vux-cell-justify:after {\n  content: \".\";\n  display: inline-block;\n  width: 100%;\n  overflow: hidden;\n  height: 0;\n}\n.weui-loading {\n  width: 20px;\n  height: 20px;\n  display: inline-block;\n  vertical-align: middle;\n  animation: weuiLoading 1s steps(12, end) infinite;\n  background: transparent url(\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAiIGhlaWdodD0iMTIwIiB2aWV3Qm94PSIwIDAgMTAwIDEwMCI+PHBhdGggZmlsbD0ibm9uZSIgZD0iTTAgMGgxMDB2MTAwSDB6Ii8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjRTlFOUU5IiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTMwKSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iIzk4OTY5NyIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgzMCAxMDUuOTggNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjOUI5OTlBIiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKDYwIDc1Ljk4IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0EzQTFBMiIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSg5MCA2NSA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNBQkE5QUEiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoMTIwIDU4LjY2IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0IyQjJCMiIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgxNTAgNTQuMDIgNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjQkFCOEI5IiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKDE4MCA1MCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNDMkMwQzEiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTE1MCA0NS45OCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNDQkNCQ0IiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTEyMCA0MS4zNCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNEMkQyRDIiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM1IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0RBREFEQSIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgtNjAgMjQuMDIgNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjRTJFMkUyIiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKC0zMCAtNS45OCA2NSkiLz48L3N2Zz4=\") no-repeat;\n  background-size: 100%;\n}\n.weui-loading.weui-loading_transparent {\n  background-image: url(\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHdpZHRoPScxMjAnIGhlaWdodD0nMTIwJyB2aWV3Qm94PScwIDAgMTAwIDEwMCc+PHBhdGggZmlsbD0nbm9uZScgZD0nTTAgMGgxMDB2MTAwSDB6Jy8+PHJlY3QgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjU2KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgwIC0zMCknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjUpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKDMwIDEwNS45OCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjQzKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSg2MCA3NS45OCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjM4KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSg5MCA2NSA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjMyKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgxMjAgNTguNjYgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4yOCknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoMTUwIDU0LjAyIDY1KScvPjxyZWN0IHdpZHRoPSc3JyBoZWlnaHQ9JzIwJyB4PSc0Ni41JyB5PSc0MCcgZmlsbD0ncmdiYSgyNTUsMjU1LDI1NSwuMjUpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKDE4MCA1MCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjIpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKC0xNTAgNDUuOTggNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4xNyknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoLTEyMCA0MS4zNCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjE0KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgtOTAgMzUgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4xKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgtNjAgMjQuMDIgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4wMyknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoLTMwIC01Ljk4IDY1KScvPjwvc3ZnPgo=\");\n}\n@-webkit-keyframes weuiLoading {\n0% {\n    transform: rotate3d(0, 0, 1, 0deg);\n}\n100% {\n    transform: rotate3d(0, 0, 1, 360deg);\n}\n}\n@keyframes weuiLoading {\n0% {\n    transform: rotate3d(0, 0, 1, 0deg);\n}\n100% {\n    transform: rotate3d(0, 0, 1, 360deg);\n}\n}\n.vux-cell-primary {\n  flex: 1;\n}\n.vux-label {\n  display: inline-block;\n  word-wrap: break-word;\n  word-break: break-all;\n}\n.weui-cell__ft .weui-loading {\n  display: inline-block;\n}\n.weui-cell__ft.vux-cell-align-left {\n  text-align: left;\n}\n.weui-cell.vux-cell-no-border-intent:before {\n  left: 0;\n}\n.weui-cell_access .weui-cell__ft.vux-cell-arrow-down:after {\n  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0) rotate(90deg);\n}\n.weui-cell_access .weui-cell__ft.vux-cell-arrow-up:after {\n  transform: matrix(0.71, 0.71, -0.71, 0.71, 0, 0) rotate(-90deg);\n}\n.vux-cell-arrow-transition:after {\n  transition: transform 300ms;\n}\n.vux-cell-disabled .vux-label {\n  color: #b2b2b2;\n}\n.vux-cell-disabled.weui-cell_access .weui-cell__ft:after {\n  border-color: #e2e2e2;\n}\n", ""]);

// exports


/***/ }),
/* 573 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _inlineDesc = __webpack_require__(435);

var _inlineDesc2 = _interopRequireDefault(_inlineDesc);

var _router = __webpack_require__(434);

var _props = __webpack_require__(477);

var _props2 = _interopRequireDefault(_props);

var _cleanStyle = __webpack_require__(438);

var _cleanStyle2 = _interopRequireDefault(_cleanStyle);

var _getParentProp = __webpack_require__(478);

var _getParentProp2 = _interopRequireDefault(_getParentProp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'cell',
  components: {
    InlineDesc: _inlineDesc2.default
  },
  props: (0, _props2.default)(),
  created: function created() {
    /* istanbul ignore if */
    if (false) {
      console.warn('[VUX] 抱歉，当前组件[cell]要求更新依赖 vux-loader@latest');
    }
  },
  beforeMount: function beforeMount() {
    this.hasTitleSlot = !!this.$slots.title;
    /* istanbul ignore if */
    if (this.$slots.value && process.env.NODE_ENV === 'development') {
      console.warn('[VUX] [cell] slot=value 已经废弃，请使用默认 slot 替代');
    }
  },

  computed: {
    labelStyles: function labelStyles() {
      return (0, _cleanStyle2.default)({
        width: (0, _getParentProp2.default)(this, 'labelWidth'),
        textAlign: (0, _getParentProp2.default)(this, 'labelAlign'),
        marginRight: (0, _getParentProp2.default)(this, 'labelMarginRight')
      });
    },
    valueClass: function valueClass() {
      return {
        'vux-cell-primary': this.primary === 'content' || this.valueAlign === 'left',
        'vux-cell-align-left': this.valueAlign === 'left',
        'vux-cell-arrow-transition': !!this.arrowDirection,
        'vux-cell-arrow-up': this.arrowDirection === 'up',
        'vux-cell-arrow-down': this.arrowDirection === 'down'
      };
    },
    labelClass: function labelClass() {
      return {
        'vux-cell-justify': this.$parent.labelAlign === 'justify' || this.$parent.$parent.labelAlign === 'justify'
      };
    },
    style: function style() {
      if (this.alignItems) {
        return {
          alignItems: this.alignItems
        };
      }
    }
  },
  methods: {
    onClick: function onClick() {
      /* istanbul ignore next */
      !this.disabled && (0, _router.go)(this.link, this.$router);
    }
  },
  data: function data() {
    return {
      hasTitleSlot: true,
      hasMounted: false
    };
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(56)))

/***/ }),
/* 574 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _inlineDesc = __webpack_require__(435);

var _inlineDesc2 = _interopRequireDefault(_inlineDesc);

var _router = __webpack_require__(434);

var _props = __webpack_require__(477);

var _props2 = _interopRequireDefault(_props);

var _cleanStyle = __webpack_require__(438);

var _cleanStyle2 = _interopRequireDefault(_cleanStyle);

var _getParentProp = __webpack_require__(478);

var _getParentProp2 = _interopRequireDefault(_getParentProp);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'cell',
  components: {
    InlineDesc: _inlineDesc2.default
  },
  props: (0, _props2.default)(),
  created: function created() {
    /* istanbul ignore if */
    if (false) {
      console.warn('[VUX] 抱歉，当前组件[cell]要求更新依赖 vux-loader@latest');
    }
  },
  beforeMount: function beforeMount() {
    this.hasTitleSlot = !!this.$slots.title;
    /* istanbul ignore if */
    if (this.$slots.value && process.env.NODE_ENV === 'development') {
      console.warn('[VUX] [cell] slot=value 已经废弃，请使用默认 slot 替代');
    }
  },

  computed: {
    labelStyles: function labelStyles() {
      return (0, _cleanStyle2.default)({
        width: (0, _getParentProp2.default)(this, 'labelWidth'),
        textAlign: (0, _getParentProp2.default)(this, 'labelAlign'),
        marginRight: (0, _getParentProp2.default)(this, 'labelMarginRight')
      });
    },
    valueClass: function valueClass() {
      return {
        'vux-cell-primary': this.primary === 'content' || this.valueAlign === 'left',
        'vux-cell-align-left': this.valueAlign === 'left',
        'vux-cell-arrow-transition': !!this.arrowDirection,
        'vux-cell-arrow-up': this.arrowDirection === 'up',
        'vux-cell-arrow-down': this.arrowDirection === 'down'
      };
    },
    labelClass: function labelClass() {
      return {
        'vux-cell-justify': this.$parent.labelAlign === 'justify' || this.$parent.$parent.labelAlign === 'justify'
      };
    },
    style: function style() {
      if (this.alignItems) {
        return {
          alignItems: this.alignItems
        };
      }
    }
  },
  methods: {
    onClick: function onClick() {
      /* istanbul ignore next */
      !this.disabled && (0, _router.go)(this.link, this.$router);
    }
  },
  data: function data() {
    return {
      hasTitleSlot: true,
      hasMounted: false
    };
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(56)))

/***/ }),
/* 575 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "weui-cell",
      class: {
        "vux-tap-active": _vm.isLink || !!_vm.link,
        "weui-cell_access": _vm.isLink || !!_vm.link,
        "vux-cell-no-border-intent": !_vm.borderIntent,
        "vux-cell-disabled": _vm.disabled
      },
      style: _vm.style,
      on: { click: _vm.onClick }
    },
    [
      _c("div", { staticClass: "weui-cell__hd" }, [_vm._t("icon")], 2),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "vux-cell-bd",
          class: {
            "vux-cell-primary":
              _vm.primary === "title" && _vm.valueAlign !== "left"
          }
        },
        [
          _c(
            "p",
            [
              _vm.title || _vm.hasTitleSlot
                ? _c(
                    "label",
                    {
                      staticClass: "vux-label",
                      class: _vm.labelClass,
                      style: _vm.labelStyles
                    },
                    [_vm._t("title", [_vm._v(_vm._s(_vm.title))])],
                    2
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm._t("after-title")
            ],
            2
          ),
          _vm._v(" "),
          _c(
            "inline-desc",
            [_vm._t("inline-desc", [_vm._v(_vm._s(_vm.inlineDesc))])],
            2
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "weui-cell__ft", class: _vm.valueClass },
        [
          _vm._t("value"),
          _vm._v(" "),
          _vm._t("default", [_vm._v(_vm._s(_vm.value))]),
          _vm._v(" "),
          _vm.isLoading ? _c("i", { staticClass: "weui-loading" }) : _vm._e()
        ],
        2
      ),
      _vm._v(" "),
      _vm._t("child")
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-ae688382", esExports)
  }
}

/***/ }),
/* 576 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(577);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("6d19c45e", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-204858c5\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-204858c5\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 577 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports
exports.i(__webpack_require__(578), "");

// module
exports.push([module.i, "/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.vux-popup-dialog {\n  position: fixed;\n  left: 0;\n  bottom: 0;\n  width: 100%;\n  background: #eee;\n  z-index: 501;\n  transition-property: transform;\n  transition-duration: 300ms;\n  max-height: 100%;\n  overflow-y: auto;\n  -webkit-overflow-scrolling: touch;\n}\n.vux-popup-dialog.vux-popup-left {\n  width: auto;\n  height: 100%;\n  top: 0;\n  right: auto;\n  bottom: auto;\n  left: 0;\n}\n.vux-popup-dialog.vux-popup-right {\n  width: auto;\n  height: 100%;\n  top: 0;\n  right: 0;\n  bottom: auto;\n  left: auto;\n}\n.vux-popup-dialog.vux-popup-top {\n  width: 100%;\n  top: 0;\n  right: auto;\n  bottom: auto;\n  left: 0;\n}\n.vux-popup-mask {\n  display: block;\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background: rgba(0, 0, 0, 0.5);\n  opacity: 0;\n  tap-highlight-color: rgba(0, 0, 0, 0);\n  z-index: -1;\n  transition: opacity 400ms;\n}\n.vux-popup-mask.vux-popup-show {\n  opacity: 1;\n}\n.vux-popup-animate-bottom-enter,\n.vux-popup-animate-bottom-leave-active {\n  transform: translate3d(0, 100%, 0);\n}\n.vux-popup-animate-left-enter,\n.vux-popup-animate-left-leave-active {\n  transform: translate3d(-100%, 0, 0);\n}\n.vux-popup-animate-right-enter,\n.vux-popup-animate-right-leave-active {\n  transform: translate3d(100%, 0, 0);\n}\n.vux-popup-animate-top-enter,\n.vux-popup-animate-top-leave-active {\n  transform: translate3d(0, -100%, 0);\n}\n", ""]);

// exports


/***/ }),
/* 578 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, ".vux-modal-open {\n  overflow: hidden;\n  position: fixed;\n  width: 100%;\n}\n.vux-modal-open-for-container {\n  overflow: hidden!important;\n}\n", ""]);

// exports


/***/ }),
/* 579 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keys = __webpack_require__(439);

var _keys2 = _interopRequireDefault(_keys);

var _popup = __webpack_require__(480);

var _popup2 = _interopRequireDefault(_popup);

var _dom = __webpack_require__(481);

var _dom2 = _interopRequireDefault(_dom);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'popup',
  props: {
    value: Boolean,
    height: {
      type: String,
      default: 'auto'
    },
    width: {
      type: String,
      default: 'auto'
    },
    showMask: {
      type: Boolean,
      default: true
    },
    isTransparent: Boolean,
    hideOnBlur: {
      type: Boolean,
      default: true
    },
    position: {
      type: String,
      default: 'bottom'
    },
    maxHeight: String,
    popupStyle: Object,
    hideOnDeactivated: {
      type: Boolean,
      default: true
    },
    shouldRerenderOnShow: {
      type: Boolean,
      default: false
    },
    shouldScrollTopOnShow: {
      type: Boolean,
      default: false
    }
  },
  created: function created() {
    // get global layout config
    if (this.$vux && this.$vux.config && this.$vux.config.$layout === 'VIEW_BOX') {
      this.layout = 'VIEW_BOX';
    }
  },
  mounted: function mounted() {
    var _this2 = this;

    this.$overflowScrollingList = document.querySelectorAll('.vux-fix-safari-overflow-scrolling');
    this.$nextTick(function () {
      var _this = _this2;
      _this2.popup = new _popup2.default({
        showMask: _this.showMask,
        container: _this.$el,
        hideOnBlur: _this.hideOnBlur,
        onOpen: function onOpen() {
          _this.fixSafariOverflowScrolling('auto');
          _this.show = true;
        },
        onClose: function onClose() {
          _this.show = false;
          if (window.__$vuxPopups && (0, _keys2.default)(window.__$vuxPopups).length > 1) return;
          if (document.querySelector('.vux-popup-dialog.vux-popup-mask-disabled')) return;
          setTimeout(function () {
            _this.fixSafariOverflowScrolling('touch');
          }, 300);
        }
      });
      if (_this2.value) {
        _this2.popup.show();
      }
      _this2.initialShow = false;
    });
  },
  deactivated: function deactivated() {
    if (this.hideOnDeactivated) {
      this.show = false;
    }
    this.removeModalClassName();
  },

  methods: {
    /**
    * https://github.com/airyland/vux/issues/311
    * https://benfrain.com/z-index-stacking-contexts-experimental-css-and-ios-safari/
    */
    fixSafariOverflowScrolling: function fixSafariOverflowScrolling(type) {
      if (!this.$overflowScrollingList.length) return;
      // if (!/iphone/i.test(navigator.userAgent)) return
      for (var i = 0; i < this.$overflowScrollingList.length; i++) {
        this.$overflowScrollingList[i].style.webkitOverflowScrolling = type;
      }
    },
    removeModalClassName: function removeModalClassName() {
      this.layout === 'VIEW_BOX' && _dom2.default.removeClass(document.body, 'vux-modal-open');
    },
    doShow: function doShow() {
      this.popup && this.popup.show();
      this.$emit('on-show');
      this.fixSafariOverflowScrolling('auto');
      this.layout === 'VIEW_BOX' && _dom2.default.addClass(document.body, 'vux-modal-open');
      if (!this.hasFirstShow) {
        this.$emit('on-first-show');
        this.hasFirstShow = true;
      }
    },
    scrollTop: function scrollTop() {
      var _this3 = this;

      this.$nextTick(function () {
        _this3.$el.scrollTop = 0;
        var box = _this3.$el.querySelectorAll('.vux-scrollable');
        if (box.length) {
          for (var i = 0; i < box.length; i++) {
            box[i].scrollTop = 0;
          }
        }
      });
    }
  },
  data: function data() {
    return {
      layout: '',
      initialShow: true,
      hasFirstShow: false,
      shouldRenderBody: true,
      show: this.value
    };
  },

  computed: {
    styles: function styles() {
      var styles = {};
      if (!this.position || this.position === 'bottom' || this.position === 'top') {
        styles.height = this.height;
      } else {
        styles.width = this.width;
      }

      if (this.maxHeight) {
        styles['max-height'] = this.maxHeight;
      }

      this.isTransparent && (styles['background'] = 'transparent');
      if (this.popupStyle) {
        for (var i in this.popupStyle) {
          styles[i] = this.popupStyle[i];
        }
      }
      return styles;
    }
  },
  watch: {
    value: function value(val) {
      this.show = val;
    },
    show: function show(val) {
      var _this4 = this;

      this.$emit('input', val);
      if (val) {
        // rerender body
        if (this.shouldRerenderOnShow) {
          this.shouldRenderBody = false;
          this.$nextTick(function () {
            _this4.scrollTop();
            _this4.shouldRenderBody = true;
            _this4.doShow();
          });
        } else {
          if (this.shouldScrollTopOnShow) {
            this.scrollTop();
          }
          this.doShow();
        }
      } else {
        this.$emit('on-hide');
        this.show = false;
        this.popup.hide(false);
        setTimeout(function () {
          if (!document.querySelector('.vux-popup-dialog.vux-popup-show')) {
            _this4.fixSafariOverflowScrolling('touch');
          }
          _this4.removeModalClassName();
        }, 200);
      }
    }
  },
  beforeDestroy: function beforeDestroy() {
    this.popup && this.popup.destroy();
    this.fixSafariOverflowScrolling('touch');
    this.removeModalClassName();
  }
};

/***/ }),
/* 580 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _keys = __webpack_require__(439);

var _keys2 = _interopRequireDefault(_keys);

var _popup = __webpack_require__(480);

var _popup2 = _interopRequireDefault(_popup);

var _dom = __webpack_require__(481);

var _dom2 = _interopRequireDefault(_dom);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'popup',
  props: {
    value: Boolean,
    height: {
      type: String,
      default: 'auto'
    },
    width: {
      type: String,
      default: 'auto'
    },
    showMask: {
      type: Boolean,
      default: true
    },
    isTransparent: Boolean,
    hideOnBlur: {
      type: Boolean,
      default: true
    },
    position: {
      type: String,
      default: 'bottom'
    },
    maxHeight: String,
    popupStyle: Object,
    hideOnDeactivated: {
      type: Boolean,
      default: true
    },
    shouldRerenderOnShow: {
      type: Boolean,
      default: false
    },
    shouldScrollTopOnShow: {
      type: Boolean,
      default: false
    }
  },
  created: function created() {
    // get global layout config
    if (this.$vux && this.$vux.config && this.$vux.config.$layout === 'VIEW_BOX') {
      this.layout = 'VIEW_BOX';
    }
  },
  mounted: function mounted() {
    var _this2 = this;

    this.$overflowScrollingList = document.querySelectorAll('.vux-fix-safari-overflow-scrolling');
    this.$nextTick(function () {
      var _this = _this2;
      _this2.popup = new _popup2.default({
        showMask: _this.showMask,
        container: _this.$el,
        hideOnBlur: _this.hideOnBlur,
        onOpen: function onOpen() {
          _this.fixSafariOverflowScrolling('auto');
          _this.show = true;
        },
        onClose: function onClose() {
          _this.show = false;
          if (window.__$vuxPopups && (0, _keys2.default)(window.__$vuxPopups).length > 1) return;
          if (document.querySelector('.vux-popup-dialog.vux-popup-mask-disabled')) return;
          setTimeout(function () {
            _this.fixSafariOverflowScrolling('touch');
          }, 300);
        }
      });
      if (_this2.value) {
        _this2.popup.show();
      }
      _this2.initialShow = false;
    });
  },
  deactivated: function deactivated() {
    if (this.hideOnDeactivated) {
      this.show = false;
    }
    this.removeModalClassName();
  },

  methods: {
    /**
    * https://github.com/airyland/vux/issues/311
    * https://benfrain.com/z-index-stacking-contexts-experimental-css-and-ios-safari/
    */
    fixSafariOverflowScrolling: function fixSafariOverflowScrolling(type) {
      if (!this.$overflowScrollingList.length) return;
      // if (!/iphone/i.test(navigator.userAgent)) return
      for (var i = 0; i < this.$overflowScrollingList.length; i++) {
        this.$overflowScrollingList[i].style.webkitOverflowScrolling = type;
      }
    },
    removeModalClassName: function removeModalClassName() {
      this.layout === 'VIEW_BOX' && _dom2.default.removeClass(document.body, 'vux-modal-open');
    },
    doShow: function doShow() {
      this.popup && this.popup.show();
      this.$emit('on-show');
      this.fixSafariOverflowScrolling('auto');
      this.layout === 'VIEW_BOX' && _dom2.default.addClass(document.body, 'vux-modal-open');
      if (!this.hasFirstShow) {
        this.$emit('on-first-show');
        this.hasFirstShow = true;
      }
    },
    scrollTop: function scrollTop() {
      var _this3 = this;

      this.$nextTick(function () {
        _this3.$el.scrollTop = 0;
        var box = _this3.$el.querySelectorAll('.vux-scrollable');
        if (box.length) {
          for (var i = 0; i < box.length; i++) {
            box[i].scrollTop = 0;
          }
        }
      });
    }
  },
  data: function data() {
    return {
      layout: '',
      initialShow: true,
      hasFirstShow: false,
      shouldRenderBody: true,
      show: this.value
    };
  },

  computed: {
    styles: function styles() {
      var styles = {};
      if (!this.position || this.position === 'bottom' || this.position === 'top') {
        styles.height = this.height;
      } else {
        styles.width = this.width;
      }

      if (this.maxHeight) {
        styles['max-height'] = this.maxHeight;
      }

      this.isTransparent && (styles['background'] = 'transparent');
      if (this.popupStyle) {
        for (var i in this.popupStyle) {
          styles[i] = this.popupStyle[i];
        }
      }
      return styles;
    }
  },
  watch: {
    value: function value(val) {
      this.show = val;
    },
    show: function show(val) {
      var _this4 = this;

      this.$emit('input', val);
      if (val) {
        // rerender body
        if (this.shouldRerenderOnShow) {
          this.shouldRenderBody = false;
          this.$nextTick(function () {
            _this4.scrollTop();
            _this4.shouldRenderBody = true;
            _this4.doShow();
          });
        } else {
          if (this.shouldScrollTopOnShow) {
            this.scrollTop();
          }
          this.doShow();
        }
      } else {
        this.$emit('on-hide');
        this.show = false;
        this.popup.hide(false);
        setTimeout(function () {
          if (!document.querySelector('.vux-popup-dialog.vux-popup-show')) {
            _this4.fixSafariOverflowScrolling('touch');
          }
          _this4.removeModalClassName();
        }, 200);
      }
    }
  },
  beforeDestroy: function beforeDestroy() {
    this.popup && this.popup.destroy();
    this.fixSafariOverflowScrolling('touch');
    this.removeModalClassName();
  }
};

/***/ }),
/* 581 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "transition",
    { attrs: { name: "vux-popup-animate-" + _vm.position } },
    [
      _c(
        "div",
        {
          directives: [
            {
              name: "show",
              rawName: "v-show",
              value: _vm.show && !_vm.initialShow,
              expression: "show && !initialShow"
            }
          ],
          staticClass: "vux-popup-dialog",
          class: [
            "vux-popup-" + _vm.position,
            _vm.show ? "vux-popup-show" : ""
          ],
          style: _vm.styles
        },
        [_vm.shouldRenderBody ? _vm._t("default") : _vm._e()],
        2
      )
    ]
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-204858c5", esExports)
  }
}

/***/ }),
/* 582 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(583);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("002ca2a5", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-3cd602aa\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-3cd602aa\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 583 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "\n.vux-1px,\n.vux-1px-t,\n.vux-1px-b,\n.vux-1px-tb,\n.vux-1px-l,\n.vux-1px-r {\n  position: relative;\n}\n.vux-1px:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 200%;\n  border: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  height: 200%;\n  transform-origin: left top;\n  transform: scale(0.5);\n}\n.vux-1px-t:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.vux-1px-b:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.vux-1px-tb:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  right: 0;\n  height: 1px;\n  border-top: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 0;\n  transform: scaleY(0.5);\n}\n.vux-1px-tb:after {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  bottom: 0;\n  right: 0;\n  height: 1px;\n  border-bottom: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 100%;\n  transform: scaleY(0.5);\n}\n.vux-1px-l:before {\n  content: \" \";\n  position: absolute;\n  left: 0;\n  top: 0;\n  width: 1px;\n  bottom: 0;\n  border-left: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 0 0;\n  transform: scaleX(0.5);\n}\n.vux-1px-r:after {\n  content: \" \";\n  position: absolute;\n  right: 0;\n  top: 0;\n  width: 1px;\n  bottom: 0;\n  border-right: 1px solid #C7C7C7;\n  color: #C7C7C7;\n  transform-origin: 100% 0;\n  transform: scaleX(0.5);\n}\n/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.vux-popup-header {\n  display: flex;\n  height: 44px;\n  line-height: 44px;\n  font-size: 16px;\n  background-color: #fbf9fe;\n}\n.vux-popup-header-title {\n  flex: 1;\n  text-align: center;\n  color: #222;\n}\n.vux-popup-header-left {\n  padding-left: 15px;\n  color: #828282;\n}\n.vux-popup-header-right {\n  padding-right: 15px;\n  color: #04BE02;\n}\n.vux-popup-header.vux-1px-b:after {\n  border-color: #D9D9D9;\n}\n", ""]);

// exports


/***/ }),
/* 584 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'popup-header',
  props: {
    leftText: String,
    rightText: String,
    title: String,
    showBottomBorder: {
      type: Boolean,
      default: true
    }
  }
};

/***/ }),
/* 585 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  name: 'popup-header',
  props: {
    leftText: String,
    rightText: String,
    title: String,
    showBottomBorder: {
      type: Boolean,
      default: true
    }
  }
};

/***/ }),
/* 586 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    {
      staticClass: "vux-popup-header",
      class: _vm.showBottomBorder ? "vux-1px-b" : ""
    },
    [
      _c(
        "div",
        {
          staticClass: "vux-popup-header-left",
          on: {
            click: function($event) {
              _vm.$emit("on-click-left")
            }
          }
        },
        [_vm._t("left-text", [_vm._v(_vm._s(_vm.leftText))])],
        2
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "vux-popup-header-title" },
        [_vm._t("title", [_vm._v(_vm._s(_vm.title))])],
        2
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "vux-popup-header-right",
          on: {
            click: function($event) {
              _vm.$emit("on-click-right")
            }
          }
        },
        [_vm._t("right-text", [_vm._v(_vm._s(_vm.rightText))])],
        2
      )
    ]
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-3cd602aa", esExports)
  }
}

/***/ }),
/* 587 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _stringify = __webpack_require__(433);

var _stringify2 = _interopRequireDefault(_stringify);

var _picker = __webpack_require__(471);

var _picker2 = _interopRequireDefault(_picker);

var _cell = __webpack_require__(476);

var _cell2 = _interopRequireDefault(_cell);

var _popup = __webpack_require__(479);

var _popup2 = _interopRequireDefault(_popup);

var _popupHeader = __webpack_require__(482);

var _popupHeader2 = _interopRequireDefault(_popupHeader);

var _inlineDesc = __webpack_require__(435);

var _inlineDesc2 = _interopRequireDefault(_inlineDesc);

var _flexbox = __webpack_require__(441);

var _array2String = __webpack_require__(483);

var _array2String2 = _interopRequireDefault(_array2String);

var _value2name = __webpack_require__(436);

var _value2name2 = _interopRequireDefault(_value2name);

var _mixin_uuid = __webpack_require__(445);

var _mixin_uuid2 = _interopRequireDefault(_mixin_uuid);

var _transferDom = __webpack_require__(484);

var _transferDom2 = _interopRequireDefault(_transferDom);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var getObject = function getObject(obj) {
  return JSON.parse((0, _stringify2.default)(obj));
};

exports.default = {
  name: 'popup-picker',
  directives: {
    TransferDom: _transferDom2.default
  },
  created: function created() {
    if (typeof this.show !== 'undefined') {
      this.showValue = this.show;
    }
  },

  mixins: [_mixin_uuid2.default],
  components: {
    Picker: _picker2.default,
    Cell: _cell2.default,
    Popup: _popup2.default,
    PopupHeader: _popupHeader2.default,
    Flexbox: _flexbox.Flexbox,
    FlexboxItem: _flexbox.FlexboxItem,
    InlineDesc: _inlineDesc2.default
  },
  filters: {
    array2string: _array2String2.default,
    value2name: _value2name2.default
  },
  props: {
    valueTextAlign: {
      type: String,
      default: 'right'
    },
    title: String,
    cancelText: String,
    confirmText: String,
    data: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    placeholder: String,
    columns: {
      type: Number,
      default: 0
    },
    fixedColumns: {
      type: Number,
      default: 0
    },
    value: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    showName: Boolean,
    inlineDesc: [String, Number, Array, Object, Boolean],
    showCell: {
      type: Boolean,
      default: true
    },
    show: Boolean,
    displayFormat: Function,
    isTransferDom: {
      type: Boolean,
      default: true
    },
    columnWidth: Array,
    popupStyle: Object,
    popupTitle: String,
    disabled: Boolean
  },
  computed: {
    labelStyles: function labelStyles() {
      return {
        display: 'block',
        width: this.$parent.labelWidth || this.$parent.$parent.labelWidth || 'auto',
        textAlign: this.$parent.labelAlign || this.$parent.$parent.labelAlign,
        marginRight: this.$parent.labelMarginRight || this.$parent.$parent.labelMarginRight
      };
    },
    labelClass: function labelClass() {
      return {
        'vux-cell-justify': this.$parent.labelAlign === 'justify' || this.$parent.$parent.labelAlign === 'justify'
      };
    }
  },
  methods: {
    value2name: _value2name2.default,
    getNameValues: function getNameValues() {
      return (0, _value2name2.default)(this.currentValue, this.data);
    },
    onClick: function onClick() {
      if (!this.disabled) {
        this.showValue = true;
      }
    },
    onHide: function onHide(type) {
      this.showValue = false;
      if (type) {
        this.closeType = true;
        this.currentValue = getObject(this.tempValue);
      }
      if (!type) {
        this.closeType = false;
        if (this.value.length > 0) {
          this.tempValue = getObject(this.currentValue);
        }
      }
    },
    onPopupShow: function onPopupShow() {
      // reset close type to false
      this.closeType = false;
      this.$emit('on-show');
    },
    onPopupHide: function onPopupHide(val) {
      if (this.value.length > 0) {
        this.tempValue = getObject(this.currentValue);
      }
      this.$emit('on-hide', this.closeType);
    },
    onPickerChange: function onPickerChange(val) {
      if ((0, _stringify2.default)(this.currentValue) !== (0, _stringify2.default)(val)) {
        // if has value, replace it
        if (this.value.length) {
          var nowData = (0, _stringify2.default)(this.data);
          if (nowData !== this.currentData && this.currentData !== '[]') {
            this.tempValue = getObject(val);
          }
          this.currentData = nowData;
        } else {// if no value, stay quiet
          // if set to auto update, do update the value
        }
      }
      var _val = getObject(val);
      this.$emit('on-shadow-change', _val, (0, _value2name2.default)(_val, this.data).split(' '));
    }
  },
  watch: {
    value: function value(val) {
      if ((0, _stringify2.default)(val) !== (0, _stringify2.default)(this.tempValue)) {
        this.tempValue = getObject(val);
        this.currentValue = getObject(val);
      }
    },
    currentValue: function currentValue(val) {
      this.$emit('input', getObject(val));
      this.$emit('on-change', getObject(val));
    },
    show: function show(val) {
      this.showValue = val;
    },
    showValue: function showValue(val) {
      this.$emit('update:show', val);
    }
  },
  data: function data() {
    return {
      onShowProcess: false,
      tempValue: getObject(this.value),
      closeType: false,
      currentData: (0, _stringify2.default)(this.data), // used for detecting if it is after data change
      showValue: false,
      currentValue: this.value
    };
  }
};

/***/ }),
/* 588 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "vux-cell-box" }, [
    _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.showCell,
            expression: "showCell"
          }
        ],
        staticClass: "weui-cell vux-tap-active",
        class: { "weui-cell_access": !_vm.disabled },
        on: { click: _vm.onClick }
      },
      [
        _c(
          "div",
          { staticClass: "weui-cell__hd" },
          [
            _vm._t(
              "title",
              [
                _vm.title
                  ? _c("label", {
                      staticClass: "weui-label",
                      class: _vm.labelClass,
                      style: _vm.labelStyles,
                      domProps: { innerHTML: _vm._s(_vm.title) }
                    })
                  : _vm._e()
              ],
              {
                labelClass: "weui-label",
                labelStyle: _vm.labelStyles,
                labelTitle: _vm.title
              }
            ),
            _vm._v(" "),
            _vm.inlineDesc
              ? _c("inline-desc", [_vm._v(_vm._s(_vm.inlineDesc))])
              : _vm._e()
          ],
          2
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "vux-cell-primary vux-popup-picker-select-box" },
          [
            _c(
              "div",
              {
                staticClass: "vux-popup-picker-select",
                style: { textAlign: _vm.valueTextAlign }
              },
              [
                !_vm.displayFormat && !_vm.showName && _vm.value.length
                  ? _c(
                      "span",
                      { staticClass: "vux-popup-picker-value vux-cell-value" },
                      [_vm._v(_vm._s(_vm._f("array2string")(_vm.value)))]
                    )
                  : _vm._e(),
                _vm._v(" "),
                !_vm.displayFormat && _vm.showName && _vm.value.length
                  ? _c(
                      "span",
                      { staticClass: "vux-popup-picker-value vux-cell-value" },
                      [
                        _vm._v(
                          _vm._s(_vm._f("value2name")(_vm.value, _vm.data))
                        )
                      ]
                    )
                  : _vm._e(),
                _vm._v(" "),
                _vm.displayFormat && _vm.value.length
                  ? _c(
                      "span",
                      { staticClass: "vux-popup-picker-value vux-cell-value" },
                      [
                        _vm._v(
                          _vm._s(
                            _vm.displayFormat(
                              _vm.value,
                              _vm.value2name(_vm.value, _vm.data)
                            )
                          )
                        )
                      ]
                    )
                  : _vm._e(),
                _vm._v(" "),
                !_vm.value.length && _vm.placeholder
                  ? _c("span", {
                      staticClass:
                        "vux-popup-picker-placeholder vux-cell-placeholder",
                      domProps: { textContent: _vm._s(_vm.placeholder) }
                    })
                  : _vm._e()
              ]
            )
          ]
        ),
        _vm._v(" "),
        _c("div", { staticClass: "weui-cell__ft" })
      ]
    ),
    _vm._v(" "),
    _c(
      "div",
      {
        directives: [
          {
            name: "transfer-dom",
            rawName: "v-transfer-dom",
            value: _vm.isTransferDom,
            expression: "isTransferDom"
          }
        ]
      },
      [
        _c(
          "popup",
          {
            staticClass: "vux-popup-picker",
            attrs: {
              id: "vux-popup-picker-" + _vm.uuid,
              "popup-style": _vm.popupStyle
            },
            on: { "on-hide": _vm.onPopupHide, "on-show": _vm.onPopupShow },
            model: {
              value: _vm.showValue,
              callback: function($$v) {
                _vm.showValue = $$v
              },
              expression: "showValue"
            }
          },
          [
            _c(
              "div",
              { staticClass: "vux-popup-picker-container" },
              [
                _c("popup-header", {
                  attrs: {
                    "left-text": _vm.cancelText || "取消",
                    "right-text": _vm.confirmText || "完成",
                    title: _vm.popupTitle
                  },
                  on: {
                    "on-click-left": function($event) {
                      _vm.onHide(false)
                    },
                    "on-click-right": function($event) {
                      _vm.onHide(true)
                    }
                  }
                }),
                _vm._v(" "),
                _c("picker", {
                  attrs: {
                    data: _vm.data,
                    columns: _vm.columns,
                    "fixed-columns": _vm.fixedColumns,
                    container: "#vux-popup-picker-" + _vm.uuid,
                    "column-width": _vm.columnWidth
                  },
                  on: { "on-change": _vm.onPickerChange },
                  model: {
                    value: _vm.tempValue,
                    callback: function($$v) {
                      _vm.tempValue = $$v
                    },
                    expression: "tempValue"
                  }
                })
              ],
              1
            )
          ]
        )
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-c23b5128", esExports)
  }
}

/***/ }),
/* 589 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _name2value = __webpack_require__(467);

var _name2value2 = _interopRequireDefault(_name2value);

var _value2name = __webpack_require__(436);

var _value2name2 = _interopRequireDefault(_value2name);

var _popupPicker = __webpack_require__(470);

var _popupPicker2 = _interopRequireDefault(_popupPicker);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  name: 'x-address',
  components: {
    PopupPicker: _popupPicker2.default
  },
  props: {
    title: {
      type: String,
      required: true
    },
    value: {
      type: Array,
      default: function _default() {
        return [];
      }
    },
    rawValue: Boolean,
    list: {
      type: Array,
      required: true
    },
    labelWidth: String,
    inlineDesc: String,
    placeholder: String,
    hideDistrict: Boolean,
    valueTextAlign: String,
    confirmText: String,
    cancelText: String,
    displayFormat: {
      type: Function,
      default: function _default(val, names) {
        return names;
      }
    },
    popupStyle: Object,
    popupTitle: String,
    show: Boolean,
    disabled: Boolean
  },
  created: function created() {
    if (this.currentValue.length && this.rawValue) {
      var parsedVal = (0, _name2value2.default)(this.currentValue, this.list);
      if (/__/.test(parsedVal)) {
        console.error('[VUX] Wrong address value', this.currentValue);
        this.currentValue = [];
      } else {
        this.currentValue = parsedVal.split(' ');
      }
    }
    if (this.show) {
      this.showValue = true;
    }
  },

  methods: {
    emitHide: function emitHide(val) {
      this.$emit('on-hide', val);
    },
    getAddressName: function getAddressName() {
      return (0, _value2name2.default)(this.value, this.list);
    },
    onShadowChange: function onShadowChange(ids, names) {
      this.$emit('on-shadow-change', ids, names);
    }
  },
  data: function data() {
    return {
      currentValue: this.value,
      showValue: false
    };
  },

  computed: {
    nameValue: function nameValue() {
      return (0, _value2name2.default)(this.currentValue, this.list);
    },
    labelClass: function labelClass() {
      return {
        'vux-cell-justify': this.$parent.labelAlign === 'justify' || this.$parent.$parent.labelAlign === 'justify'
      };
    }
  },
  watch: {
    currentValue: function currentValue(val) {
      this.$emit('input', val);
    },
    value: function value(val) {
      if (val.length && !/\d+/.test(val[0])) {
        var id = (0, _name2value2.default)(val, this.list).split(' ');
        if (id[0] !== '__' && id[1] !== '__') {
          this.currentValue = id;
          return;
        }
      }
      this.currentValue = val;
    },
    show: function show(val) {
      this.showValue = val;
    },
    showValue: function showValue(val) {
      this.$emit('update:show', val);
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 590 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("popup-picker", {
    attrs: {
      "fixed-columns": _vm.hideDistrict ? 2 : 0,
      columns: 3,
      data: _vm.list,
      title: _vm.title,
      "show-name": "",
      "inline-desc": _vm.inlineDesc,
      placeholder: _vm.placeholder,
      "value-text-align": _vm.valueTextAlign,
      "confirm-text": _vm.confirmText,
      "cancel-text": _vm.cancelText,
      "display-format": _vm.displayFormat,
      "popup-style": _vm.popupStyle,
      "popup-title": _vm.popupTitle,
      show: _vm.showValue,
      disabled: _vm.disabled
    },
    on: {
      "update:show": function($event) {
        _vm.showValue = $event
      },
      "on-shadow-change": _vm.onShadowChange,
      "on-hide": _vm.emitHide,
      "on-show": function($event) {
        _vm.$emit("on-show")
      }
    },
    scopedSlots: _vm._u([
      {
        key: "title",
        fn: function(props) {
          return [
            _vm._t(
              "title",
              [
                props.labelTitle
                  ? _c("label", {
                      class: [props.labelClass, _vm.labelClass],
                      style: props.labelStyle,
                      domProps: { innerHTML: _vm._s(props.labelTitle) }
                    })
                  : _vm._e()
              ],
              {
                labelClass: props.labelClass,
                labelStyle: props.labelStyles,
                labelTitle: props.title
              }
            )
          ]
        }
      }
    ]),
    model: {
      value: _vm.currentValue,
      callback: function($$v) {
        _vm.currentValue = $$v
      },
      expression: "currentValue"
    }
  })
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-b5672610", esExports)
  }
}

/***/ }),
/* 591 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(592);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(109)("12d85e9e", content, false, {});
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-7f806bc4\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../../_css-loader@0.28.11@css-loader/index.js!../../../../_vue-loader@13.7.3@vue-loader/lib/style-compiler/index.js?{\"vue\":true,\"id\":\"data-v-7f806bc4\",\"scoped\":false,\"hasInlineConfig\":false}!../../../../_vux-loader@1.2.9@vux-loader/src/after-less-loader.js!../../../../_less-loader@4.1.0@less-loader/dist/cjs.js!../../../../_vux-loader@1.2.9@vux-loader/src/style-loader.js!../../../../_vue-loader@13.7.3@vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 592 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(108)(false);
// imports


// module
exports.push([module.i, "/**\n* actionsheet\n*/\n/**\n* en: primary type text color of menu item\n* zh-CN: 菜单项primary类型的文本颜色\n*/\n/**\n* en: warn type text color of menu item\n* zh-CN: 菜单项warn类型的文本颜色\n*/\n/**\n* en: default type text color of menu item\n* zh-CN: 菜单项default类型的文本颜色\n*/\n/**\n* en: disabled type text color of menu item\n* zh-CN: 菜单项disabled类型的文本颜色\n*/\n/**\n* datetime\n*/\n/**\n* tabbar\n*/\n/**\n* tab\n*/\n/**\n* dialog\n*/\n/**\n* en: title and content's padding-left and padding-right\n* zh-CN: 标题及内容区域的 padding-left 和 padding-right\n*/\n/**\n* x-number\n*/\n/**\n* checkbox\n*/\n/**\n* check-icon\n*/\n/**\n* Cell\n*/\n/**\n* Mask\n*/\n/**\n* Range\n*/\n/**\n* Tabbar\n*/\n/**\n* Header\n*/\n/**\n* Timeline\n*/\n/**\n* Switch\n*/\n/**\n* Button\n*/\n/**\n* en: border radius\n* zh-CN: 圆角边框\n*/\n/**\n* en: font color\n* zh-CN: 字体颜色\n*/\n/**\n* en: margin-top value between previous button, not works when there is only one button\n* zh-CN: 与相邻按钮的 margin-top 间隙，只有一个按钮时不生效\n*/\n/**\n* en: button height\n* zh-CN: 按钮高度\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: the font color in disabled\n* zh-CN: disabled状态下的字体颜色\n*/\n/**\n* en: font size\n* zh-CN: 字体大小\n*/\n/**\n* en: the font size of the mini type\n* zh-CN: mini类型的字体大小\n*/\n/**\n* en: the line height of the mini type\n* zh-CN: mini类型的行高\n*/\n/**\n* en: the background color of the warn type\n* zh-CN: warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in active\n* zh-CN: active状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the warn type in disabled\n* zh-CN: disabled状态下，warn类型的背景颜色\n*/\n/**\n* en: the background color of the default type\n* zh-CN: default类型的背景颜色\n*/\n/**\n* en: the font color of the default type\n* zh-CN: default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in active\n* zh-CN: active状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in disabled\n* zh-CN: disabled状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the default type in disabled\n* zh-CN: disabled状态下，default类型的背景颜色\n*/\n/**\n* en: the font color of the default type in active\n* zh-CN: active状态下，default类型的字体颜色\n*/\n/**\n* en: the background color of the primary type\n* zh-CN: primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in active\n* zh-CN: active状态下，primary类型的背景颜色\n*/\n/**\n* en: the background color of the primary type in disabled\n* zh-CN: disabled状态下，primary类型的背景颜色\n*/\n/**\n* en: the font color of the plain primary type\n* zh-CN: plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type\n* zh-CN: plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的字体颜色\n*/\n/**\n* en: the border color of the plain primary type in active\n* zh-CN: active状态下，plain的primary类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type\n* zh-CN: plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type\n* zh-CN: plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的字体颜色\n*/\n/**\n* en: the border color of the plain default type in active\n* zh-CN: active状态下，plain的default类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type\n* zh-CN: plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type\n* zh-CN: plain的warn类型的边框颜色\n*/\n/**\n* en: the font color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的字体颜色\n*/\n/**\n* en: the border color of the plain warn type in active\n* zh-CN: active状态下，plain的warn类型的边框颜色\n*/\n/**\n* swipeout\n*/\n/**\n* Cell\n*/\n/**\n* Badge\n*/\n/**\n* en: badge background color\n* zh-CN: badge的背景颜色\n*/\n/**\n* Popover\n*/\n/**\n* Button tab\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: border radius color\n* zh-CN: 圆角边框的半径\n*/\n/**\n* en: border color\n* zh-CN: 边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 默认状态下圆角边框的颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default background color\n* zh-CN: 默认状态下的背景颜色\n*/\n/**\n* en: selected background color\n* zh-CN: 选中状态下的背景颜色\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/* alias */\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* en: default text color\n* zh-CN: 默认状态下的文本颜色\n*/\n/**\n* en: height\n* zh-CN: 元素高度\n*/\n/**\n* en: line height\n* zh-CN: 元素行高\n*/\n/**\n* Swiper\n*/\n/**\n* checklist\n*/\n/**\n* popup-picker\n*/\n/**\n* popup\n*/\n/**\n* popup-header\n*/\n/**\n* form-preview\n*/\n/**\n* sticky\n*/\n/**\n* group\n*/\n/**\n* en: margin-top of title\n* zh-CN: 标题的margin-top\n*/\n/**\n* en: margin-bottom of title\n* zh-CN: 标题的margin-bottom\n*/\n/**\n* en: margin-top of footer title\n* zh-CN: 底部标题的margin-top\n*/\n/**\n* en: margin-bottom of footer title\n* zh-CN: 底部标题的margin-bottom\n*/\n/**\n* toast\n*/\n/**\n* en: text color of content\n* zh-CN: 内容文本颜色\n*/\n/**\n* en: default top\n* zh-CN: 默认状态下距离顶部的高度\n*/\n/**\n* en: position top\n* zh-CN: 顶部显示的高度\n*/\n/**\n* en: position bottom\n* zh-CN: 底部显示的高度\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n/**\n* icon\n*/\n/**\n* calendar\n*/\n/**\n* en: forward and backward arrows color\n* zh-CN: 前进后退的箭头颜色\n*/\n/**\n* en: text color of week highlight\n* zh-CN: 周末高亮的文本颜色\n*/\n/**\n* en: background color when selected\n* zh-CN: 选中时的背景颜色\n*/\n/**\n* en: text color when disabled\n* zh-CN: 禁用时的文本颜色\n*/\n/**\n* en: text color of today\n* zh-CN: 今天的文本颜色\n*/\n/**\n* en: font size of cell\n* zh-CN: 单元格的字号\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: size of date cell\n* zh-CN: 日期单元格尺寸大小\n*/\n/**\n* en: line height of date cell\n* zh-CN: 日期单元格的行高\n*/\n/**\n* en: text color of header\n* zh-CN: 头部的文本颜色\n*/\n/**\n* week-calendar\n*/\n/**\n* search\n*/\n/**\n* en: text color of cancel button\n* zh-CN: 取消按钮文本颜色\n*/\n/**\n* en: background color\n* zh-CN: 背景颜色\n*/\n/**\n* en: text color of placeholder\n* zh-CN: placeholder文本颜色\n*/\n/**\n* radio\n*/\n/**\n* en: checked icon color\n* zh-CN: 选中状态的图标颜色\n*/\n/**\n* loadmore\n*/\n/**\n* en: not used\n* zh-CN: 未被使用\n*/\n/**\n* loading\n*/\n/**\n* en: z-index\n* zh-CN: z-index\n*/\n.weui-btn {\n  position: relative;\n  display: block;\n  margin-left: auto;\n  margin-right: auto;\n  padding-left: 14px;\n  padding-right: 14px;\n  box-sizing: border-box;\n  font-size: 18px;\n  text-align: center;\n  text-decoration: none;\n  color: #FFFFFF;\n  line-height: 2.33333333;\n  border-radius: 5px;\n  -webkit-tap-highlight-color: rgba(0, 0, 0, 0);\n  overflow: hidden;\n}\n.weui-btn:after {\n  content: \" \";\n  width: 200%;\n  height: 200%;\n  position: absolute;\n  top: 0;\n  left: 0;\n  border: 1px solid rgba(0, 0, 0, 0.2);\n  transform: scale(0.5);\n  transform-origin: 0 0;\n  box-sizing: border-box;\n  border-radius: 10px;\n}\n.weui-btn_inline {\n  display: inline-block;\n}\n.weui-btn_default {\n  color: #000000;\n  background-color: #F8F8F8;\n}\n.weui-btn_default:not(.weui-btn_disabled):visited {\n  color: #000000;\n}\n.weui-btn_default:not(.weui-btn_disabled):active {\n  color: rgba(0, 0, 0, 0.6);\n  background-color: #DEDEDE;\n}\n.weui-btn_primary {\n  background-color: #1AAD19;\n}\n.weui-btn_primary:not(.weui-btn_disabled):visited {\n  color: #FFFFFF;\n}\n.weui-btn_primary:not(.weui-btn_disabled):active {\n  color: rgba(255, 255, 255, 0.6);\n  background-color: #179B16;\n}\n.weui-btn_warn {\n  background-color: #E64340;\n}\n.weui-btn_warn:not(.weui-btn_disabled):visited {\n  color: #FFFFFF;\n}\n.weui-btn_warn:not(.weui-btn_disabled):active {\n  color: rgba(255, 255, 255, 0.6);\n  background-color: #CE3C39;\n}\n.weui-btn_disabled {\n  color: rgba(255, 255, 255, 0.6);\n}\n.weui-btn_disabled.weui-btn_default {\n  color: rgba(0, 0, 0, 0.3);\n  background-color: #F7F7F7;\n}\n.weui-btn_disabled.weui-btn_primary {\n  background-color: #9ED99D;\n}\n.weui-btn_disabled.weui-btn_warn {\n  background-color: #EC8B89;\n}\n.weui-btn_loading .weui-loading {\n  margin: -0.2em 0.34em 0 0;\n}\n.weui-btn_loading.weui-btn_primary,\n.weui-btn_loading.weui-btn_warn {\n  color: rgba(255, 255, 255, 0.6);\n}\n.weui-btn_loading.weui-btn_primary .weui-loading,\n.weui-btn_loading.weui-btn_warn .weui-loading {\n  background-image: url(\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHdpZHRoPScxMjAnIGhlaWdodD0nMTIwJyB2aWV3Qm94PScwIDAgMTAwIDEwMCc+PHBhdGggZmlsbD0nbm9uZScgZD0nTTAgMGgxMDB2MTAwSDB6Jy8+PHJlY3QgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjU2KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgwIC0zMCknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjUpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKDMwIDEwNS45OCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjQzKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSg2MCA3NS45OCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjM4KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSg5MCA2NSA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjMyKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgxMjAgNTguNjYgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4yOCknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoMTUwIDU0LjAyIDY1KScvPjxyZWN0IHdpZHRoPSc3JyBoZWlnaHQ9JzIwJyB4PSc0Ni41JyB5PSc0MCcgZmlsbD0ncmdiYSgyNTUsMjU1LDI1NSwuMjUpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKDE4MCA1MCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjIpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKC0xNTAgNDUuOTggNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4xNyknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoLTEyMCA0MS4zNCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjE0KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgtOTAgMzUgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4xKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgtNjAgMjQuMDIgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4wMyknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoLTMwIC01Ljk4IDY1KScvPjwvc3ZnPg==\");\n}\n.weui-btn_loading.weui-btn_primary {\n  background-color: #179B16;\n}\n.weui-btn_loading.weui-btn_warn {\n  background-color: #CE3C39;\n}\n.weui-btn_plain-primary {\n  color: #1aad19;\n  border: 1px solid #1aad19;\n}\n.weui-btn_plain-primary:not(.weui-btn_plain-disabled):active {\n  color: rgba(26, 173, 25, 0.6);\n  border-color: rgba(26, 173, 25, 0.6);\n  background-color: transparent;\n}\n.weui-btn_plain-primary:after {\n  border-width: 0;\n}\n.weui-btn_plain-default {\n  color: #353535;\n  border: 1px solid #353535;\n}\n.weui-btn_plain-default:not(.weui-btn_plain-disabled):active {\n  color: rgba(53, 53, 53, 0.6);\n  border-color: rgba(53, 53, 53, 0.6);\n}\n.weui-btn_plain-default:after {\n  border-width: 0;\n}\n/*\n* added by VUX\n*/\nbutton.weui-btn.weui-btn_plain-warn,\ninput.weui-btn.weui-btn_plain-warn {\n  border-width: 1px;\n  background-color: transparent;\n}\n.weui-btn_plain-warn {\n  color: #ce3c39;\n  border: 1px solid #ce3c39;\n  background: transparent;\n}\n.weui-btn_plain-warn:not(.weui-btn_plain-disabled):active {\n  color: rgba(206, 60, 57, 0.6);\n  border-color: rgba(206, 60, 57, 0.6);\n}\n.weui-btn_plain-warn:after {\n  border-width: 0;\n}\n.weui-btn_plain-disabled {\n  color: rgba(0, 0, 0, 0.2);\n  border-color: rgba(0, 0, 0, 0.2);\n}\nbutton.weui-btn,\ninput.weui-btn {\n  width: 100%;\n  border-width: 0;\n  outline: 0;\n  -webkit-appearance: none;\n}\nbutton.weui-btn:focus,\ninput.weui-btn:focus {\n  outline: 0;\n}\nbutton.weui-btn_inline,\ninput.weui-btn_inline,\nbutton.weui-btn_mini,\ninput.weui-btn_mini {\n  width: auto;\n}\nbutton.weui-btn_plain-primary,\ninput.weui-btn_plain-primary,\nbutton.weui-btn_plain-default,\ninput.weui-btn_plain-default {\n  border-width: 1px;\n  background-color: transparent;\n}\n.weui-btn_mini {\n  display: inline-block;\n  padding: 0 1.32em;\n  line-height: 2.3;\n  font-size: 13px;\n}\n/*gap between btn*/\n.weui-btn + .weui-btn {\n  margin-top: 15px;\n}\n.weui-btn.weui-btn_inline + .weui-btn.weui-btn_inline {\n  margin-top: auto;\n  margin-left: 15px;\n}\n.weui-btn-area {\n  margin: 1.17647059em 15px 0.3em;\n}\n.weui-btn-area_inline {\n  display: flex;\n}\n.weui-btn-area_inline .weui-btn {\n  margin-top: auto;\n  margin-right: 15px;\n  width: 100%;\n  flex: 1;\n}\n.weui-btn-area_inline .weui-btn:last-child {\n  margin-right: 0;\n}\n.weui-loading {\n  width: 20px;\n  height: 20px;\n  display: inline-block;\n  vertical-align: middle;\n  animation: weuiLoading 1s steps(12, end) infinite;\n  background: transparent url(\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMjAiIGhlaWdodD0iMTIwIiB2aWV3Qm94PSIwIDAgMTAwIDEwMCI+PHBhdGggZmlsbD0ibm9uZSIgZD0iTTAgMGgxMDB2MTAwSDB6Ii8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjRTlFOUU5IiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAgLTMwKSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iIzk4OTY5NyIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgzMCAxMDUuOTggNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjOUI5OTlBIiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKDYwIDc1Ljk4IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0EzQTFBMiIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSg5MCA2NSA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNBQkE5QUEiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoMTIwIDU4LjY2IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0IyQjJCMiIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgxNTAgNTQuMDIgNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjQkFCOEI5IiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKDE4MCA1MCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNDMkMwQzEiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTE1MCA0NS45OCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNDQkNCQ0IiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTEyMCA0MS4zNCA2NSkiLz48cmVjdCB3aWR0aD0iNyIgaGVpZ2h0PSIyMCIgeD0iNDYuNSIgeT0iNDAiIGZpbGw9IiNEMkQyRDIiIHJ4PSI1IiByeT0iNSIgdHJhbnNmb3JtPSJyb3RhdGUoLTkwIDM1IDY1KSIvPjxyZWN0IHdpZHRoPSI3IiBoZWlnaHQ9IjIwIiB4PSI0Ni41IiB5PSI0MCIgZmlsbD0iI0RBREFEQSIgcng9IjUiIHJ5PSI1IiB0cmFuc2Zvcm09InJvdGF0ZSgtNjAgMjQuMDIgNjUpIi8+PHJlY3Qgd2lkdGg9IjciIGhlaWdodD0iMjAiIHg9IjQ2LjUiIHk9IjQwIiBmaWxsPSIjRTJFMkUyIiByeD0iNSIgcnk9IjUiIHRyYW5zZm9ybT0icm90YXRlKC0zMCAtNS45OCA2NSkiLz48L3N2Zz4=\") no-repeat;\n  background-size: 100%;\n}\n.weui-loading.weui-loading_transparent {\n  background-image: url(\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHdpZHRoPScxMjAnIGhlaWdodD0nMTIwJyB2aWV3Qm94PScwIDAgMTAwIDEwMCc+PHBhdGggZmlsbD0nbm9uZScgZD0nTTAgMGgxMDB2MTAwSDB6Jy8+PHJlY3QgeG1sbnM9J2h0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnJyB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjU2KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3RyYW5zbGF0ZSgwIC0zMCknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjUpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKDMwIDEwNS45OCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjQzKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSg2MCA3NS45OCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjM4KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSg5MCA2NSA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjMyKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgxMjAgNTguNjYgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4yOCknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoMTUwIDU0LjAyIDY1KScvPjxyZWN0IHdpZHRoPSc3JyBoZWlnaHQ9JzIwJyB4PSc0Ni41JyB5PSc0MCcgZmlsbD0ncmdiYSgyNTUsMjU1LDI1NSwuMjUpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKDE4MCA1MCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjIpJyByeD0nNScgcnk9JzUnIHRyYW5zZm9ybT0ncm90YXRlKC0xNTAgNDUuOTggNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4xNyknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoLTEyMCA0MS4zNCA2NSknLz48cmVjdCB3aWR0aD0nNycgaGVpZ2h0PScyMCcgeD0nNDYuNScgeT0nNDAnIGZpbGw9J3JnYmEoMjU1LDI1NSwyNTUsLjE0KScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgtOTAgMzUgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4xKScgcng9JzUnIHJ5PSc1JyB0cmFuc2Zvcm09J3JvdGF0ZSgtNjAgMjQuMDIgNjUpJy8+PHJlY3Qgd2lkdGg9JzcnIGhlaWdodD0nMjAnIHg9JzQ2LjUnIHk9JzQwJyBmaWxsPSdyZ2JhKDI1NSwyNTUsMjU1LC4wMyknIHJ4PSc1JyByeT0nNScgdHJhbnNmb3JtPSdyb3RhdGUoLTMwIC01Ljk4IDY1KScvPjwvc3ZnPgo=\");\n}\n@-webkit-keyframes weuiLoading {\n0% {\n    transform: rotate3d(0, 0, 1, 0deg);\n}\n100% {\n    transform: rotate3d(0, 0, 1, 360deg);\n}\n}\n@keyframes weuiLoading {\n0% {\n    transform: rotate3d(0, 0, 1, 0deg);\n}\n100% {\n    transform: rotate3d(0, 0, 1, 360deg);\n}\n}\n.weui-btn.vux-x-button-no-border:after {\n  display: none;\n}\n", ""]);

// exports


/***/ }),
/* 593 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _router = __webpack_require__(434);

exports.default = {
  name: 'x-button',
  props: {
    type: {
      default: 'default'
    },
    disabled: Boolean,
    mini: Boolean,
    plain: Boolean,
    text: String,
    actionType: String,
    showLoading: Boolean,
    link: [String, Object],
    gradients: {
      type: Array,
      validator: function validator(val) {
        return val.length === 2;
      }
    }
  },
  methods: {
    onClick: function onClick() {
      !this.disabled && (0, _router.go)(this.link, this.$router);
    }
  },
  computed: {
    noBorder: function noBorder() {
      return Array.isArray(this.gradients);
    },
    buttonStyle: function buttonStyle() {
      if (this.gradients) {
        return {
          background: 'linear-gradient(90deg, ' + this.gradients[0] + ', ' + this.gradients[1] + ')',
          color: '#FFFFFF'
        };
      }
    },
    classes: function classes() {
      return [{
        'weui-btn_disabled': !this.plain && this.disabled,
        'weui-btn_plain-disabled': this.plain && this.disabled,
        'weui-btn_mini': this.mini,
        'vux-x-button-no-border': this.noBorder
      }, !this.plain ? 'weui-btn_' + this.type : '', this.plain ? 'weui-btn_plain-' + this.type : '', this.showLoading ? 'weui-btn_loading' : ''];
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 594 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _router = __webpack_require__(434);

exports.default = {
  name: 'x-button',
  props: {
    type: {
      default: 'default'
    },
    disabled: Boolean,
    mini: Boolean,
    plain: Boolean,
    text: String,
    actionType: String,
    showLoading: Boolean,
    link: [String, Object],
    gradients: {
      type: Array,
      validator: function validator(val) {
        return val.length === 2;
      }
    }
  },
  methods: {
    onClick: function onClick() {
      !this.disabled && (0, _router.go)(this.link, this.$router);
    }
  },
  computed: {
    noBorder: function noBorder() {
      return Array.isArray(this.gradients);
    },
    buttonStyle: function buttonStyle() {
      if (this.gradients) {
        return {
          background: 'linear-gradient(90deg, ' + this.gradients[0] + ', ' + this.gradients[1] + ')',
          color: '#FFFFFF'
        };
      }
    },
    classes: function classes() {
      return [{
        'weui-btn_disabled': !this.plain && this.disabled,
        'weui-btn_plain-disabled': this.plain && this.disabled,
        'weui-btn_mini': this.mini,
        'vux-x-button-no-border': this.noBorder
      }, !this.plain ? 'weui-btn_' + this.type : '', this.plain ? 'weui-btn_plain-' + this.type : '', this.showLoading ? 'weui-btn_loading' : ''];
    }
  }
}; //
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 595 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "button",
    {
      staticClass: "weui-btn",
      class: _vm.classes,
      style: _vm.buttonStyle,
      attrs: { disabled: _vm.disabled, type: _vm.actionType },
      on: { click: _vm.onClick }
    },
    [
      _vm.showLoading ? _c("i", { staticClass: "weui-loading" }) : _vm._e(),
      _vm._v(" "),
      _vm._t("default", [_vm._v(_vm._s(_vm.text))])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-7f806bc4", esExports)
  }
}

/***/ }),
/* 596 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "./images/home_banner_001.png?d305ca78493ae2686398118dbe098edf";

/***/ }),
/* 597 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "./images/home_banner_002.png?5898d5d58fbe4ca64d446f0c1bd8b0d9";

/***/ }),
/* 598 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "./images/home_banner_003.png?e6321dc6f52988c9db4a39bc4550f3c2";

/***/ }),
/* 599 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "./images/home_banner_004.png?8f057afe37c3c895e9fa7a4be2bdc530";

/***/ }),
/* 600 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _swiper = __webpack_require__(448);

var _swiper2 = _interopRequireDefault(_swiper);

var _index = __webpack_require__(454);

var _index2 = _interopRequireDefault(_index);

var _index3 = __webpack_require__(455);

var _index4 = _interopRequireDefault(_index3);

var _index5 = __webpack_require__(456);

var _index6 = _interopRequireDefault(_index5);

var _index7 = __webpack_require__(466);

var _index8 = _interopRequireDefault(_index7);

var _china_address = __webpack_require__(485);

var _china_address2 = _interopRequireDefault(_china_address);

var _flexbox = __webpack_require__(446);

var _flexbox2 = _interopRequireDefault(_flexbox);

var _flexboxItem = __webpack_require__(447);

var _flexboxItem2 = _interopRequireDefault(_flexboxItem);

var _index9 = __webpack_require__(486);

var _index10 = _interopRequireDefault(_index9);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
  components: {
    Swiper: _swiper2.default,
    Card: _index2.default,
    Group: _index4.default,
    XInput: _index6.default,
    XAddress: _index8.default,
    Flexbox: _flexbox2.default,
    FlexboxItem: _flexboxItem2.default,
    XButton: _index10.default
  },
  /**
  * 所有参数变量说明
  * paging             boolean   是否需要分页
  */
  data: function data() {
    return {
      swiperList: [],
      addressValue: [],
      addressData: _china_address2.default
    };
  },

  methods: {},
  created: function created() {
    for (var i = 1; i < 5; i++) {
      this.swiperList.push({
        url: "javascript:;",
        img: __webpack_require__(487)("./home_banner_00" + i + '.png'),
        title: "",
        fallbackImg: ""
      });
    }
  }
};

/***/ }),
/* 601 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    [
      _c("swiper", {
        attrs: {
          list: _vm.swiperList,
          "show-dots": true,
          "dots-position": "center",
          auto: true,
          loop: true,
          interval: 3800,
          height: "180px",
          duration: 280
        }
      }),
      _vm._v(" "),
      _c("span", { staticClass: "home-form-label" }, [
        _vm._v("业务开通进度查询")
      ]),
      _vm._v(" "),
      _c(
        "group",
        {
          staticClass: "home-form-p10",
          attrs: { slot: "content" },
          slot: "content"
        },
        [
          _c("x-input", { attrs: { title: "客户名称" } }),
          _vm._v(" "),
          _c("x-address", {
            attrs: {
              title: "地址选择",
              "raw-value": "",
              list: _vm.addressData,
              "value-text-align": "left"
            },
            model: {
              value: _vm.addressValue,
              callback: function($$v) {
                _vm.addressValue = $$v
              },
              expression: "addressValue"
            }
          }),
          _vm._v(" "),
          _c("x-input", { attrs: { title: "验证码" } }, [
            _c("img", {
              attrs: {
                slot: "right-full-height",
                src:
                  "https://ws1.sinaimg.cn/large/663d3650gy1fq684go3glj203m01hmwy.jpg"
              },
              slot: "right-full-height"
            })
          ])
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "x-button",
        {
          staticStyle: {
            "border-radius": "99px",
            width: "80%",
            margin: "15px 10%",
            height: "36px"
          },
          attrs: { mini: "", plain: "", type: "primary" }
        },
        [_vm._v("查询")]
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true
var esExports = { render: render, staticRenderFns: staticRenderFns }
/* harmony default export */ __webpack_exports__["a"] = (esExports);
if (false) {
  module.hot.accept()
  if (module.hot.data) {
    require("vue-loader/node_modules/vue-hot-reload-api")      .rerender("data-v-9611bf10", esExports)
  }
}

/***/ })
]));