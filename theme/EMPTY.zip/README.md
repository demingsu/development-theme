
## 研发说明
1. 不允许私自升级element-ui;
2. 所有路由导出采用异步(按需)

## 包功能点说明
1. defaultTemplate          默认模板，包含列表、详情、鱼骨图、侧滑框、步骤图等(登陆界面用户名、密码任意输入即可)

## 浏览器兼容说明
1. 整体架构支持 >= IE10+;
2. 最佳体验 >= IE11+;

## WEB技术栈
1. 架构于 vue2.5+ && vue-router3.0+ && vuex3.0+ && axios0.17 && webpack3.9+ && gulp

## 项目环境安装与运行（因部分库引用国外服务器install时，建议使用cnpm）
1. 安装开发库：
 `拷贝开发库文件到开发项目中`
2. 安装依赖：(需要跳转到对应的项目文件路径，开发环境依赖node8.X LTS版本，需要安装，不能用8.X以上版本，有node兼容性问题)
 `npm install`
3. 运行项目：(运行前确保依赖安装完成且无失败项)
 `npm run start`
3. 重启项目：(与运行一致，但不会打开首页)
 `npm run restart`
4. 打包发布命令：(发布规则为，只发布dist目录所有文件，nginx指向也指向文件所在目录)
 `npm run deploy`
5. 开发数据联调：(在进行数据联调的过程中，不需nginx代理，直接webpack devServer进行开发)
 `注意请求字段替代或则后端统一配置起始字段`
6. cnpm 安装路径 
  `npm install -g cnpm --registry=https://registry.npm.taobao.org`

## 与devOps平台对接，设置命令为export

## 解决vuex刷新浏览器数据清空问题：在store index.js中引入vuex-persistedstate 

## 已做token校验