/*********************************************************************
 * common api
 * Created by deming-su on 2017/12/30
 * 本文件提供通用的api方法，其余功能块独有方法，另起文件定义
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/url.config";


/**
 * 通过 params 以get方式获取数据
 * @param      key                 请求定义静态地址
 * @param      params              请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let getDataRequest = (key, params) => {
    return Ajax({
        url: UrlConfig[key],
        params
    });
};

/**
 * 通过 data 以post方式提交数据
 * @param      key                 请求定义静态地址
 * @param      data                请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let postDataRequest = (key, data) => {
    return Ajax({
        method: 'POST',
        url: UrlConfig[key],
        data
    });
};

/**
 * 通过FormData以post方式提交文件并获取文件上传进度
 * @param      key                 请求定义静态地址
 * @param      data                请求参数
 * @param      onUploadProgress    上传进度
 * @return     {Promise<*>}        返回promise对象
 */
let postFileRequest = (key, data, onUploadProgress) => {
    return Ajax({
        method: 'POST',
        url: UrlConfig[key],
        data,
        onUploadProgress
    });
};

/**
 * 返回一个完整请求地址
 */
let getFullUrl = (key, flag) => {
    if (!flag) return `${UrlConfig.BASE_URL}${UrlConfig[key]}`;
    return `${UrlConfig[key]}`;
};


/**
 * 引用页面用法释义
 * import { getDataRequest } form "@/api/common";
 * async getFunc()
 * let result = await getDataRequest('', {});
 */
export {
    getDataRequest,
    postDataRequest,
    postFileRequest,
    getFullUrl
};