/*********************************************************************
 * assets components import function file
 * Created by deming-su on 2017/12/30
 *********************************************************************/


class AssetsComponents {
    constructor(Vue) {
        this.Vue = Vue;
    }

    install() {

    }
}

export default AssetsComponents;