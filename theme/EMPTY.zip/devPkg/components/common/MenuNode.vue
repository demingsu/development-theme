/*********************************************************************
* Static variable file
* Created by deming-su on 2019/11/1
*********************************************************************/

<template>
    <div class="main-menu-container" :class="{collapse}">
        <div class="box">
            <div class="item" v-for="(item,i) in menuList" :key="`menu_key_${i}`">
                <span class="label" :class="{active: item.active && !item.expand}">
                    <i class="icon" v-html="item.img"></i>
                    <span class="text" @click="menuEvent(item, 'parant')">{{item.label}}</span>
                    <i v-if="item.hasChild" class="drop" @click="item.expand = !item.expand;" :class="{expand: !item.expand}">&#xe632;</i>
                </span>
                <div class="chidren-box"
                     :style="{height: item.expand && item.hasChild ? `${item.children.length * 46}px` : 0}">
                    <div class="box"
                    v-if="item.hasChild && item.expand"
                         :class="{active: it.active}"
                         v-for="(it, j) in item.children" 
                         :key="`menu_child_key_${j}`"
                         @click="menuEvent(item, 'child', it)">
                        <span class="children text">{{it.label}}</span> 
                    </div>
                </div>
                <!-- 目前只有二级菜单，popover自行添加 -->
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        props: {
            collapse: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {
                pageData: {},
                menuList: []
            }
        },
        watch: {
            collapse: function(val) {
                if (!!val) {
                    this.menuList.map(it => {
                        it.expand = false;
                    })
                }
            }
        },
        methods: {
            menuEvent(item, type, it) {
                this.menuList.map(o => {
                    o.active = o.label === item.label;
                    if (o.hasChild) {
                        o.children.map(oo => {
                            oo.active = false;
                        })
                    }
                })
                if (type === 'parant' && !!item.data) {
                    this.$router.push(item.data); 
                }
                if (type === 'child' && item.hasChild && !!it.data) {
                    item.children.map(o => {
                        o.active = o.label === it.label;
                    })
                    this.$router.push(it.data);
                }
            }
        },
        created() {
            this.$root.eventBus.$on('mainChangeMenu', data => {
                this.menuList = [];
                if (this.pageData.id !== data.data.id) {
                    this.pageData = data.data;
                }
                setTimeout(() => {
                    this.menuList = this.pageData.method;
                    let _path = this.$route.path;
                    this.menuList.map(it => {
                        it.hasChild = !!it.children && !!it.children.length;
                    });
                });
            })
        }
    }
</script>