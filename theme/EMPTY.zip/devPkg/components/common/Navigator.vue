/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="navigator-container">
        <div class="box">
            <!-- 图例 -->
            <div class="brand">
                <i class="icon"></i>
                <span class="text">信息化综合管理系统</span>
            </div>
            <!-- 菜单 -->
            <div class="content" :class="{'has-more': maxLength > 1}">
                <i class="expand-icon" @click="expandEvent" :class="{active: isCollapse}"></i>
                <div class="box" id="menuListNode">
                    <div class="navigator-menu-list"
                         :style="{width: `${maxLength * 100}%`, left: `-${currentPos * 100}%`}">
                        <div class="item"
                             v-for="(item,i) in menuList"
                             @click="menuClick(item)"
                             :class="{active: item.active}"
                             :key="`menu_key_${i}`">{{item.label}}</div>
                    </div>
                </div>
                <div class="more-box">
                    <i @click="moreEvent('previous')" class="icon"></i>
                    <i @click="moreEvent('next')" class="icon right"></i>
                </div>
            </div>
            <!-- 用户功能页面 -->
            <div class="info">
                <div @click="$emit('menuEvent', 'message')" class="message"></div>
                <el-popover placement="bottom" width="200" trigger="hover">
                    <span @click="logoutEvt" class="navigator-operate-text">退出</span>
                    <div class="user" slot="reference">{{userInfo.loginName}}</div>
                </el-popover>
            </div>
        </div>
    </div>
</template>
<script>
    import { mapGetters } from 'vuex';

    export default {
        computed: {
            ...mapGetters({
                userInfo: "getUserInfo"
            })
        },
        data() {
            return {
                hasInfo: true,
                isCollapse: false,
                menuList: [],
                maxLength: 1,
                currentPos: 0
            }
        },
        watch: {
            "$route.path": function() {
                this.resetMenu();
            }
        },
        methods: {
            logoutEvt() {
                sessionStorage.clear();
                this.$router.push("/");
            },
            resetMenu() {

                let _path = this.$route.path,
                    _hasActive = false;

                this.menuList.map(it => {
                    it.active = false;
                    if (!_hasActive && it.method && it.method.length > 0) {
                        for (let child of it.method) {
                            if (child.type === 'menu' && child.data === _path) {
                                this.$root.eventBus.$emit('mainChangeMenu', {id: Date.now(), data: it});
                                it.active = true;
                                _hasActive = true;
                                break;
                            }
                            if (child.type === 'menu' && child.data === '') {
                                this.$root.eventBus.$emit('mainChangeMenu', {id: Date.now(), data: it});
                                it.active = true;
                                _hasActive = true;
                                break;
                            }
                            if (!_hasActive && child.method && child.method.length > 0) {
                                for (let _child of child.method) {
                                    if (_child.type === 'menu' && _child.data === _path) {
                                        it.active = true;
                                        _hasActive = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                });
            },
            menuClick(item) {
                let _temp = [];
                this.menuList.map(it => {
                    it.active = it.id === item.id;
                    if (it.active) this.$root.eventBus.$emit('mainChangeMenu', {id: Date.now(), data: it});
                    _temp.push(it);
                });

                this.menuList = _temp;
            },
            calculateMoreButton() {

                let _width = 0,
                    _rect = document.getElementById('menuListNode').getBoundingClientRect();

                for (let item of this.menuList) {
                    _width += (item.label.length * 14 + 24);
                }
                this.maxLength = Math.ceil(_width / _rect.width);
            },
            moreEvent(type) {
                if (type === 'previous') {
                    if (this.currentPos > 0) --this.currentPos;
                } else {
                    if (this.currentPos < (this.maxLength - 1)) ++this.currentPos;
                }
            },
            expandEvent() {
                this.isCollapse = !this.isCollapse;
                this.$emit('menuEvent', 'collapse', this.isCollapse);
            }
        },
        mounted() {
            let _menu = sessionStorage.getItem('current_user_menu_data');
            try {
                _menu = JSON.parse(_menu);
                this.menuList = _menu.authority;

                /* 计算是否有更多按钮 */
                setTimeout(() => {
                    this.calculateMoreButton();
                });

                /* 重置菜单的选中状态 */
                this.resetMenu();
            } catch(e) {
                this.$message.error('用户菜单初始化失败，请重新登入');
            }

            window.addEventListener('resize', this.calculateMoreButton, false);
        },
        beforeDestroy() {
            window.addEventListener('resize', this.calculateMoreButton, true);
        }
    }
    </script>

