/*********************************************************************
 * Vue PageLayout file
 * Created by deming-su on 2019/7/18
 * title 必传页面标题
 * pageButton 页面全局按钮插槽
 * form 页面抬头form表单 必传属性为height
 * tab 表格抬头tab页签，如果存在页签则不会显示本栏标题
 * queryForm 表格查询form表单页面
 * content 表格内容区域
 * paging 分页区域
 *********************************************************************/

<template>
    <div class="common-page-layout" :style="{'padding-top': `${formHeight}px`}">
        <div class="common-page-layout-header">
            <div class="label">{{title}}</div>
            <div class="opt">
                <slot name="pageButton"></slot>
            </div>
        </div>
        <div v-if="hasForm" class="form">
            <slot name="form"></slot>
        </div>
        <div class="common-page-layout-table" :class="{'no-paging': !hasPaging, 'no-header': !hasHeader, 'no-shadow': !hasContentBg}">
            <div v-if="hasHeader" class="header">
                <div v-if="hasTab" class="label">
                    <slot name="tab"></slot>
                </div>
                <div v-else class="label">{{subTitle}}</div>
                <div class="form">
                    <slot name="queryForm"></slot>
                </div>
            </div>
            <div class="content">
                <slot name="content"></slot>
            </div>
            <div v-if="hasPaging" class="paging">
                <slot name="paging"></slot>
            </div>
        </div>
        <slot></slot>
    </div>
</template>
<script>

    export default {
        props: {
            title: {
                type: String,
                default: ''
            },
            subTitle: {
                type: String,
                default: ''
            },
            hasHeader: {
                type: Boolean,
                default: true
            },
            hasContentBg: {
                type: Boolean,
                default: true
            }
        },
        computed: {
            hasForm: function() {
                return !!this.$slots.form;
            },
            hasTab: function() {
                return !!this.$slots.tab;
            },
            hasPaging: function() {
                return !!this.$slots.paging;
            }
        },
        data() {
            return {
                formHeight: 68
            }
        },
        methods: {
            /* 计算所有需要展示的节点高度 */
            computedStyle() {
                /* 计算顶部form表单样式，下边距已经计入，内容不考虑下边距 */
                if (this.hasForm) {
                    let attr = this.$slots.form[0].data.attrs;
                    let _fh = attr ? parseInt(attr.height) : 0;
                    this.formHeight = 86 + (isNaN(_fh) ? 0 : parseInt(_fh));
                }
            }
        },
        mounted() {
            setTimeout(() => {

                /* 计算内容高度 */
                this.computedStyle();
            });
        }
    }
</script>