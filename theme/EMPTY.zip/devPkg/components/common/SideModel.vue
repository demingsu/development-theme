/*********************************************************************
* Vue SideMode file
* Created by deming-su on 2019/7/21
*********************************************************************/

<template>
    <div class="common-side-model" :class="{visible: visible}">
        <div v-show="visible" class="layer" :style="{opacity: layerOpacity}"></div>
        <div v-show="visible" class="content" :style="{right: `${sideDistance}%`}">
            <div class="header">
                <slot name="header"></slot>
                <div v-if="!hasHeader" class="label">{{title}}</div>
                <span class="close" @click="sideModelEvent('cancel')"></span>
            </div>
            <div class="body">
                <slot></slot>
            </div>
            <div class="footer">
                <slot name="footer"></slot>
                <el-button v-if="!hasFooter" size="small" @click="sideModelEvent('submit')" type="primary">确定</el-button>
                <el-button v-if="!hasFooter" size="small" @click="sideModelEvent('cancel')">取消</el-button>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: ['displayId', 'title'],
        computed: {
            hasHeader: function() {
                return this.$slots.header;
            },
            hasFooter: function() {
                return this.$slots.footer;
            }
        },
        data() {
            return {
                sideDistance: -100,
                layerOpacity: 0,
                visible: false
            }
        },
        watch: {
            displayId: function() {
                if (!this.visible) {
                    this.visible = true;
                    setTimeout(() => {
                        this.sideDistance = 0;
                        this.layerOpacity = .5;
                    });
                } else {
                    this.sideDistance = -100;
                    this.layerOpacity = 0;
                    setTimeout(() => {
                        this.visible = false;
                    }, 420);
                    this.$emit('dialogClose', {type: 'orient'});
                }
            }
        },
        methods: {
            /* 页面按钮点击事件 */
            sideModelEvent(type) {
                this.sideDistance = -100;
                this.layerOpacity = 0;
                setTimeout(() => {
                    this.visible = false;
                }, 420);
                this.$emit('dialogClose', {type});
            }
        },
        mounted() {
            document.body.appendChild(this.$el);
        },
        destroyed() {
            if (this.$el && this.$el.parentNode) {
                this.$el.parentNode.removeChild(this.$el);
            }
        }
    }
</script>