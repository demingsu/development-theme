/*********************************************************************
 * Vue components file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import SideModel from "./common/SideModel.vue";

export {
    SideModel
};