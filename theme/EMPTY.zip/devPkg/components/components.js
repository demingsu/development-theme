/*********************************************************************
 * Vue components file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import SideModel from "./common/SideModel.vue";
import PageLayout from "./common/PageLayout.vue";

export {
    SideModel,
    PageLayout
};