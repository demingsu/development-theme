/*********************************************************************
 * Static variable file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* Ajax请求超时设置 */
const TIMEOUT_TIME = 5000;


export default {
    TIMEOUT_TIME
};