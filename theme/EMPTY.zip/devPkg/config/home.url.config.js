/*********************************************************************
 * defined home page router file
 * Created by deming-su on 2019/7/5
 *********************************************************************/

const LOGIN_URL = "/login/login";
const HOME_INDEX_URL = "/static/assets";


export {
    LOGIN_URL,
    HOME_INDEX_URL
}