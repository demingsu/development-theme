/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2017/12/30
 * 所有的路由静态定义规则为：（首个单词必须唯一，与功能包名保持一致）功能块名字_功能名_获取/提交_数据类型 ex: HOME_LOGIN_SUBMIT_FORM
 * 所有路由都按功能块引入，不得再主路由添加
 *********************************************************************/

/* 页面启动路由，根据不同的环境启动不同的基础路由 */
let BASE_URL = "/api";


let nodeEnv = process.env.NODE_ENV.trim();

switch (nodeEnv) {
    case 'production':
        /* 现场正式地址 */ 
        BASE_URL = "http://10.154.2.251:8986";
        break;
    case 'ut':
        /* 现场测试地址 */
        BASE_URL = "http://10.154.2.251:8986";
        break;
    case 'test':
        /* 人保测试 */
        BASE_URL = 'http://183.221.28.214:22886"';
        break;
    case 'local':
        /* 本地地址 */
        BASE_URL = '/apis';
        break;
}


/* 主页路由引入 */
import * as HomeUrl from "./home.url.config";


/* 总路由导出 */
export default {
    BASE_URL,
    ...HomeUrl
};