/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 通用 ---start--- */

const BASE_URL = "/api";
// const BASE_URL = "";
const LOGIN_URL = "/login/login";
const HOME_INDEX_URL = "/static/assets/{a}/{b}";

/* 通用 ---end--- */

export default {
    BASE_URL,
    LOGIN_URL,
    HOME_INDEX_URL
};