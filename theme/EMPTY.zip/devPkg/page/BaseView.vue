/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<script>
    export default {
        methods: {
            handleErrorMessage(error, loading) {
                if (!!loading) loading.close();
                this.$message({message: error.message || "服务器错误，请重试"});
            }
        }
    }
</script>