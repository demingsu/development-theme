/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <component :is="currentLayout"></component>
</template>

<script>
    import MainLayout from "./layout/MainLayout";
    import BlankLayout from "./layout/BlankLayout";

    export default {
        props: ["layout"],
        components: {
            "main-layout": MainLayout,
            "blank-layout": BlankLayout
        },
        computed: {
            currentLayout() {
                return this.layout;
            }
        },
        beforeCreate() {

            /* 如果有本地缓存store数据，需要刷新数据 */
            /* let local = localStorage.getItem("vuex_local_storage_data");
            if (!!local) {
                this.$store.replaceState( Object.assign(this.$store.state, JSON.parse(local)) );
                localStorage.removeItem('vuex_local_storage_data');
            } */
        },
        created() {

            /* 注册页面刷新vuex数据缓存 */
            let _that = this;
            window.onbeforeunload = function() {
                localStorage.setItem("vuex_local_storage_data", JSON.stringify(_that.$store.state));
            }
        }
    }
</script>