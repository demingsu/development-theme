/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <router-view></router-view>
</template>

<script>
    
    export default { }
</script>