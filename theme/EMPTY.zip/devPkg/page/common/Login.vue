/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/28
*********************************************************************/

<template>
    <div>

    </div>
</template>

<script>

    export default {
        data() {
            return {

            }
        },
        methods: {
            async loginEvt() {

                /* 存储token */
                this.$store.dispatch('setApplicationToken', {data: window.btoa("RESULT.DATA.TOKEN")});
                this.$router.push("/home");
            }
        },
        created() {
            let _load = this.$loading();
            setTimeout(() => {
                this.loginEvt();
                _load.close();
            }, 680)
        }
    }
</script>