/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/28
*********************************************************************/

<template>
    <div class="login-page-container">
        <div class="box">
            <el-card class="box-card">
                <el-form size="small" label-width="80px">
                    <div class="login-title">用户登录</div>
                    <el-form-item label="用户名称">
                        <el-input v-model="userName" placeholder="请输入用户名称" clearable suffix-icon="el-icon-date"></el-input>
                    </el-form-item>
                    <el-form-item label="用户密码">
                        <el-input v-model="password" type="password" placeholder="请输入用户密码"
                                  suffix-icon="el-icon-date" clearable></el-input>
                    </el-form-item>
                    <el-form-item>
                        <el-checkbox v-model="rememberPassword">记住密码</el-checkbox>
                    </el-form-item>
                    <el-form-item>
                        <el-button @click="loginEvt" type="primary">登录</el-button>
                        <el-button @click="clearEvt" plain>清空</el-button>
                    </el-form-item>
                </el-form>
            </el-card>
        </div>
    </div>
</template>

<script>
    import {getRequestMethod} from "@/api/common";

    export default {
        data() {
            return {
                userName: '',
                password: '',
                rememberPassword: false
            }
        },
        methods: {
            async loginEvt() {
                if (this.userName.trim() === '' || this.userName === '') {
                    this.$message.error("请输入用户名！");
                    this.userName = '';
                    return;
                }
                if (this.password.trim() === '' || this.password === '') {
                    this.$message.error("请输入密码！");
                    this.password = '';
                    return;
                }
                let result = {
                    code: 'success',
                    data: {
                        token: "eyJhbGciOiJIUzI1NiIsInppcCI6IkRFRiJ9.eNo0y0EKgCAQAMC_7DnBVdPWn3SKtSy2QxQZBNHfq0PXgblgPxJEaHlhSbJM3VaggnyuELEm7UNoDFYgXD4I5oe5yNvIO48jaRXIWuWwYcVYW-UzM41p6LNjuB8AAAD__w.orA2-ogC34VJHg-5s7reuQNOWqppjTAl4RZNlDaBkWg",
                        userInfo: {email: "test@zznode.com",
                            loginName: "金翠",
                            loginNo: "Yanaibing_qt",
                            menu: [],
                            orgCode: 320201,
                            orgName: "群2本部",
                            phoneNo: "13688472379",
                            roleinfo: []
                        }
                    }
                };
                if (!!result && result.code === 'success') {

                    if (this.rememberPassword) {
                        localStorage.setItem('beijing_mis_user_info', JSON.stringify({
                            userName: this.userName,
                            password: this.password,
                            rememberPassword: true
                        }))
                    }

                    /** 清除缓存*/
                    sessionStorage.clear();

                    sessionStorage.setItem('current_user_request_token', result.data.token);
                    /* 设置个人信息到缓存 */
                    sessionStorage.setItem('login_user_info', JSON.stringify(result.data.userInfo));
                    this.userInfo = result.data.userInfo;

                    /* 存储token */
                    this.$store.dispatch('setApplicationToken', {data: result.data.token});

                    this.getMenuInfo();
                } else {
                    this.$message.error(result.mess);
                }
            },
            async getMenuInfo() {

                // let _res = await getRequestMethod('', {});
                let _res = {
                    code: 200,
                    description: '',
                    data: {
                        'account': 'admin',
                        'authority': [{
                            'id': '1',
                            'label': '首页',
                            'type': 'module',
                            'img': '',
                            'data': '',
                            'method': [{
                                'id': '11',
                                'label': '首页',
                                'type': 'menu',
                                'img': '&#xe614;',
                                'data': '',
                                'expand': true,
                                'active': true,
                                'method': [],
                                'children': [
                                    {
                                        'id': '111',
                                        'label': '首页',
                                        'data': '/default_template/template_list',
                                        'active': true
                                    },
                                    {
                                        'id': '111',
                                        'label': '完整首页',
                                        'data': '/default_template/template_page',
                                        'active': false
                                    },
                                    {
                                        'id': '111',
                                        'label': '完整首页1',
                                        'data': '/default_template/template_page',
                                        'active': false
                                    }, 
                                ]

                            },{
                                'id': '12',
                                'label': '一级菜单',
                                'type': 'menu',
                                'img': '&#xe614;',
                                'data': '/default_template/template_page',
                                'expand': false,
                                'active': false,
                                'method': [],
                                'children': []
                            }]
                        }]
                    }
                };
                sessionStorage.setItem('current_user_menu_data', JSON.stringify(_res.data || {}));

                this.$router.push("/default_template");
            },
            clearEvt() {
                this.userName = '';
                this.password = '';
            }
        },
        created() {

            let _cache = localStorage.getItem('beijing_mis_user_info') || "{}";
            if (!!_cache) {
                try {
                    _cache = JSON.parse(_cache);
                } catch (e) {
                    console.log(e)
                }
            }
            this.rememberPassword = _cache.rememberPassword || false;
            this.userName = this.rememberPassword ? (_cache.userName || '') : '';
            this.password = this.rememberPassword ? (_cache.password || '') : '';
        }
    }
</script>