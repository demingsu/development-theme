/*********************************************************************
 * Vue private blank layout file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
   <div>
       <h1 style="text-align: center; margin: 0; padding: 10%;">没有访问权限，你是外星人？。。。</h1>
       <button @click="backHistory">返回</button>
   </div>
</template>

<script>
    export default{
        methods: {
            backHistory() {
                this.$router.go(-2);
            }
        }
    };
</script>

