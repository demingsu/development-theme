/*********************************************************************
* Vue Index file
* Created by haolin-hu on 2019/6/6
*********************************************************************/
<template>
    <router-view></router-view>
</template>

<script>
    export default {
        name: "Index"
    }
</script>

<style scoped>

</style>
