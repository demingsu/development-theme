/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/31
*********************************************************************/

<template>
    <detail-layout v-loading="pageLoading" :goBack="true" >
        <div class="common-grid-list full">
            <div class="content">
                <div v-for="(item, i) in detailObj"
                     class="item"
                     :class="{'w100': item.key==='remark'}"
                     :key="`detail_key_${i}`">
                    <span class="label">{{item.label}}：</span>
                    <el-tooltip v-if="item.key!=='remark'" effect="dark" :content="item.value" placement="top" :disabled="!item.value">
                        <span class="value">{{item.value}}</span>
                    </el-tooltip>
                    <span v-else class="remark">{{item.value}}</span>
                </div>
            </div>
        </div>
        <el-button slot="footer" type="primary" size="small">填写公榜信息</el-button>
        <el-button slot="footer" @click="$router.go(-1)" size="small" plain>取消</el-button>
    </detail-layout>
</template>

<script>
    import DetailLayout from "@/page/layout/DetailLayout";
    import { getRequestMethod, getFullUrl } from "@/api/common";
    import Tool from "@/util/tool";

    export default {
        components: { DetailLayout },
        data() {
            return {
                pageLoading: false,
                rowId: '',
                detailObj: [
                    {label: '项目命题', cls: 'col-3 gray', key: 'name'},
                    {label: '成本剔除上限', cls: 'col-3 gray', key: 'bill'},
                    {label: '时限要求', cls: 'col-3 gray', key: 'time'},
                    {label: '发布时间', cls: 'col-3 gray', key: 'publishTime'},
                    {label: '截止时间', cls: 'col-3 gray', key: 'endTime'},
                    {label: '项目联系人', cls: 'col-3 gray', key: 'contact'},
                    {label: '联系电话', cls: 'col-3 gray', key: 'phone'},
                    {label: '项目命题', cls: 'col-3 gray', key: 'name'},
                    {label: '成本剔除上限', cls: 'col-3 gray', key: 'bill'},
                    {label: '时限要求', cls: 'col-3 gray', key: 'time'},
                    {label: '发布时间', cls: 'col-3 gray', key: 'publishTime'},
                    {label: '截止时间', cls: 'col-3 gray', key: 'endTime'},
                    {label: '项目联系人', cls: 'col-3 gray', key: 'contact'},
                    {label: '联系电话', cls: 'col-3 gray', key: 'phone'},
                    {label: '开发要求', cls: 'col-3 gray remark-height',type: 'remark', key: 'remark'},
                ],
            }
        },
        methods: {
            async getDetailInfo() {

                this.pageLoading = true;
                // let result = await getRequestMethod('', {id: this.rowId});
                let result = {
                    code: 200,
                    description: '',
                    data: {
                        name: '中移物联网地磁停车系统',
                        bill: '417万元（含风险预估等费用）',
                        time: '2019年10月上线试运营',
                        publishTime: '2019/07/08 13:25',
                        endTime: '2019/07/18 13:25',
                        contact: '沈腾',
                        phone: '15012345678',
                        remark: '明月几时有？把酒问青天。不知天上宫阙，今夕是何年。我欲乘风归去，又恐琼楼玉宇，高处不胜寒。起舞弄清影，何似在人间。转朱阁，低绮户，照无眠。不应有恨，何事长向别时圆？人有悲欢离合，月有阴晴圆缺，此事古难全。但愿人长久，千里共婵娟。明月几时有？把酒问青天。不知天上宫阙，今夕是何年。我欲乘风归去，又恐琼楼玉宇，高处不胜寒。起舞弄清影，何似在人间。转朱阁，低绮户，照无眠。不应有恨，何事长向别时圆？人有悲欢离合，月有阴晴圆缺，此事古难全。但愿人长久，千里共婵娟。明月几时有？把酒问青天。不知天上宫阙，今夕是何年。我欲乘风归去，又恐琼楼玉宇，高处不胜寒。起舞弄清影，何似在人间。转朱阁，低绮户，照无眠。不应有恨，何事长向别时圆？人有悲欢离合，月有阴晴圆缺，此事古难全。但愿人长久，千里共婵娟。明月几时有？把酒问青天。不知天上宫阙，今夕是何年。我欲乘风归去，又恐琼楼玉宇，高处不胜寒。起舞弄清影，何似在人间。转朱阁，低绮户，照无眠。不应有恨，何事长向别时圆？人有悲欢离合，月有阴晴圆缺，此事古难全。但愿人长久，千里共婵娟。明月几时有？把酒问青天。不知天上宫阙，今夕是何年。我欲乘风归去，又恐琼楼玉宇，高处不胜寒。起舞弄清影，何似在人间。',
                    }
                };
                setTimeout(() => {

                    let _d = !!result && result.code === 200 ? result.data : {archives: []};
                    this.detailObj.map(it => {
                        if (!!it.key) {
                            it.value = _d[it.key] || '';
                        }
                    });
                    this.pageLoading = false;
                }, 300);
            }
        },
        created() {
            this.rowId = this.$route.query.id;
            if (!this.rowId) {
                this.$message.error('非法进入页面，请重新进入');
            } else {
                this.getDetailInfo();
            }
        }
    }
</script>

<style lang="less" scoped>
    .remark-height {
        height: 180px!important;
        >.text {
            white-space: normal!important;
            text-overflow: inherit!important;
            overflow: auto!important;
        }
    }
    .flow-height {
        height: 130px!important;
    }
</style>