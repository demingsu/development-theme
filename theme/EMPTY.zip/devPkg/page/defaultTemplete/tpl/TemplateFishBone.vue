/*********************************************************************
* Vue FishboneNode file
* Created by deming-su on 2019/9/17
*********************************************************************/

<template>
    <div class="home-fish-bone-container" id="renderNodeBox">
        <i class="go-back" @click="returnPage()">&#xe61f;</i>
        <div class="previous" @click="fishPagingEvt('previous')" :class="{dis: current < 2}">&#xe645;</div>
        <div class="content" :style="{width: renderWidth, left: `-${(current - 1) * 100}%`}">
            <div class="chart" id="renderNode"></div>
        </div>
        <div class="next" @click="fishPagingEvt('next')" :class="{dis: current >= total}">&#xe72f;</div>
    </div>
</template>
<script>
    import zRender from "zrender";

    export default {
        props: {
            refreshId: {
                type: Number,
                default: 0
            },
            pageData: {
                type: Array,
                default: () => []
            }
        },
        data() {
            return {
                total: 0,
                current: 1,
                renderNode: null,
                renderList: [],
                renderWidth: '100%'
            }
        },
        watch: {
            refreshId: function(val) {
                if (!!this.renderNode && val > 0) {
                    this.initPage();
                }
            }
        },
        methods: {
            initPage() {
                let _temp = [];
                this.pageData.map(it => {
                    let _year = it.year;
                    if (!!it.data && it.data.length > 0) {
                        it.data.map(item => {
                            let _obj = JSON.parse(JSON.stringify(item));
                            _obj.year = _year;
                            _temp.push(_obj);
                        });
                    }
                });
                this.renderList = _temp;
                this.resetPaging(_cw => {
                    this.renderWidth = `${_cw}px`;
                });


                setTimeout(() => {
                    this.renderData();
                }, 300);
            },
            resetPaging(cb) {
                let node = document.getElementById('renderNodeBox'),
                    len = this.getDomMaxWidth() + 260,
                    _width = node.getBoundingClientRect().width,
                    _cw = _width > len ? _width : len;

                this.current = 1;
                this.total = Math.ceil(_cw / _width);
                if (cb) cb(_cw);
            },
            getDomMaxWidth() {
                let len = this.renderList.length,
                    _posX = 100,
                    _isNode = false,
                    _top = false;

                for (let i = 0;i < len;i ++) {
                    let _per = this.renderList[i],
                        _next = this.renderList[i+1];

                    if (i > 0) _posX += !_top ? 140 : 30;
                    _top = !_top;

                    if (_isNode) {
                        if (!_top) _posX += 140;
                        _top = true;
                    }
                    _isNode = !!_next ? (_next.month !== _per.month || _next.year !== _per.year) : false;
                }

                return _posX;
            },
            renderData() {

                /* 获取数据长度，重置画布宽度 */
                this.renderNode.resize();
                this.renderNode.clear();

                let rect = document.getElementById('renderNode').getBoundingClientRect();
                this.renderMainLine(rect);

                let len = this.renderList.length,
                    _posX = 100,
                    _isNode = false,
                    _top = false;

                for (let i = 0;i < len;i ++) {
                    let _per = this.renderList[i],
                        _next = this.renderList[i+1];

                    if (i > 0) _posX += !_top ? 140 : 30;
                    _top = !_top;

                    if (_isNode) {
                        if (!_top) _posX += 140;
                        _top = true;
                    }
                    this.renderTextGroup(rect, _posX, !_top,
                        {date: `${_per.year}-${_per.month}-${_per.day}`,
                            text: _per.desc || ''}, _per);

                    /* 如果是一个月份节点，需要画出月份节点，如果是最后需要画出结束节点 */
                    _isNode = !!_next ? (_next.month !== _per.month || _next.year !== _per.year) : false;
                    if (i >= len -1) {
                        this.renderMonthNode(rect, _posX + 100, `${_per.year}年${_per.month}月`);
                    } else {
                        if (_isNode)
                            this.renderMonthNode(rect, _posX + 100, `${_per.year}年${_per.month}月`);
                    }
                }
            },
            renderMonthNode(rect, x, date) {

                let point = new zRender.Circle({
                    shape: {
                        r: 6,
                        cx: x,
                        cy: rect.height/2
                    },
                    style: {
                        stroke: '#00CDFF',
                        fill: '#fff',
                        lineWidth: 2
                    }
                });
                this.renderNode.add(point);

                let titleText = new zRender.Text({
                    position: [x - 30, rect.height/2 + 10],
                    style: {
                        text: date,
                        stroke: '#1E1E1E',
                        fontSize: 12
                    }
                });
                this.renderNode.add(titleText);
            },
            renderTextGroup(rect, x, isBottom, info, data) {

                let y = rect.height / 2;

                let line = new zRender.Line({
                    shape: {
                        x1: x,
                        y1: y,
                        x2: x + 40,
                        y2: isBottom ? y + 60 : y - 60
                    },
                    style: {
                        lineWidth: 2,
                        stroke: '#00CDFF'
                    }
                });
                this.renderNode.add(line);

                let box = new zRender.Rect({
                    shape: {
                        r: [4],
                        x: x + 30,
                        y: isBottom ? y + 54 : y - 156,
                        width: 152,
                        height: 100
                    },
                    style: {
                        lineWidth: 1,
                        stroke: '#A8F49C',
                        fill: '#D3FFC8'
                    }
                });
                this.renderNode.add(box);

                let title = new zRender.Rect({
                    shape: {
                        r: [4, 4, 0, 0],
                        x: x + 30,
                        y: isBottom ? y + 54 : y - 156,
                        width: 152,
                        height: 30
                    },
                    style: {
                        lineWidth: 1,
                        fill: '#B3F9AA'
                    }
                });
                this.renderNode.add(title);

                let titleText = new zRender.Text({
                    position: [x + 38, isBottom ? y + 64 : y - 146],
                    style: {
                        text: info.date,
                        stroke: '#1E1E1E',
                        fontSize: 14
                    }
                });
                this.renderNode.add(titleText);

                data.eventType = 'contentText';
                let contentText = new zRender.Text({
                    position: [x + 38, isBottom ? y + 90 : y - 120],
                    style: {
                        text: this.assembleContent(info.text),
                        stroke: '#1E1E1E',
                        fontSize: 14
                    },
                    data
                });
                this.renderNode.add(contentText);
            },
            assembleContent(str) {

                let _str = str.split(''),
                    _ss = [],
                    _idx = 0;

                _str.map(it => {
                    _idx += (/^[\u4e00-\u9fa5]+$/.test(it)) ? 2 : ['【','】','：','，'].includes(it) ? 2 : 1;
                    _ss.push(it);
                    if (_idx >= 19) {
                        _ss.push('\n');
                        _idx = 0;
                    }
                });

                return _ss.join('');
            },
            renderMainLine(rect) {
                let start = new zRender.Circle({
                    shape: {
                        cx: 60,
                        cy: rect.height/2,
                        r: 8
                    },
                    style: {
                        fill: '#00CDFF'
                    },
                    position: [50, this.renderRect/2]
                });
                this.renderNode.add(start);

                let mainLine = new zRender.Line({
                    shape: {
                        x1: 60,
                        y1: rect.height/2,
                        x2: rect.width - 60,
                        y2: rect.height/2
                    },
                    style: {
                        lineWidth: 4,
                        stroke: '#00CDFF'
                    }
                });
                this.renderNode.add(mainLine);

                let triangle = new zRender.Polygon({
                    shape: {
                        points: [[rect.width - 60, rect.height/2 + 8],
                            [rect.width - 60, rect.height/2 - 8],
                            [rect.width - 50, rect.height/2]]
                    },
                    style: {
                        fill: '#00CDFF'
                    }
                });
                this.renderNode.add(triangle);
            },
            resizeRender() {
                if (!!this.renderNode) {
                    this.renderData();
                    this.resetPaging();
                }
            },
            fishPagingEvt(type) {
                if (type === 'previous' && this.current < 2) return;
                if (type === 'next' && this.current >= this.total) return;

                this.current = type === 'next' ? ++this.current : -- this.current;
            },
            returnPage() {
                this.$emit('returnList', 'table');
            }
        },
        mounted() {
            this.initPage();
            this.$nextTick(() => {
                this.renderNode = zRender.init(document.getElementById('renderNode'));
                window.addEventListener('resize', this.resizeRender);
                this.renderNode.on('click', data => {

                    let _tar = (data.target || {data: null}).data;

                    if (!!_tar && _tar.eventType === 'contentText') {
                        this.$emit('detailViewEvt', _tar);
                    }
                });
            });
        },
        beforeDestroy() {
            if (this.renderNode) {
                zRender.dispose(this.renderNode);
                this.renderNode = null;
            }

            window.removeEventListener('resize', this.resizeRender);
        }
    }
</script>