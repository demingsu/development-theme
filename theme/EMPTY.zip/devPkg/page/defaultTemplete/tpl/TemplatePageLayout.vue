/*********************************************************************
* Vue ValidateResult file
* Created by deming-su on 2019/7/24
*********************************************************************/

<template>
    <page-layout title="首页" v-if="displayType === 'table'" subTitle="表格">
        <div slot="pageButton">
            <el-button type="primary" plain size="small" icon="el-icon-search" @click="configureId = +new Date()">预警门限配置</el-button>
        </div>
        <div slot="form" height="118" class="resource-statistics">
            <div class="items" v-for="(item,i) in analysisList" :key="`analysis_key_${i}`">
                <div class="box">
                    <div class="title">{{item.name}}<i class="icon"></i></div>
                    <div class="body">
                        <div class="value">{{item.value}}</div>
                        <div class="chart">
                            <div :id="`analysisNode${item.key}`" class="node"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div slot="tab" class="common-table-tab">
            <div class="item active">全部客户(657)</div>
            <div class="item">专网卡(67)</div>
            <div class="item">行业卡(57)</div>
        </div>
        <div slot="queryForm" class="common-accurate-query-form">
            <div v-show="queryType !== 'accurate'" class="item w300">
                <el-date-picker v-model="queryForm.vagueDate"
                                size="small"
                                type="daterange"
                                unlink-panels
                                range-separator="至"
                                start-placeholder="开始日期"
                                end-placeholder="结束日期">
                </el-date-picker>
            </div>
            <div v-show="queryType !== 'accurate'" class="item">
                <el-input size="small" v-model="queryForm.vagueName" placeholder="输入任务名称/ID"></el-input>
            </div>
            <el-button v-show="queryType !== 'accurate'" type="primary" size="small" @click="queryEvent('vague')">查询</el-button>
            <el-button type="text" size="small"
                       @click="accurateEvent('accurateNode')">
                精确查询<i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <div v-show="queryType === 'accurate'" id="accurateNode" class="accurate-box">
                <div class="box">
                    <div class="item">
                        <span class="label">任务名称：</span>
                        <div class="ipt">
                            <el-input size="small" v-model="queryForm.name"></el-input>
                        </div>
                    </div>
                    <div class="item">
                        <span class="label">ID：</span>
                        <div class="ipt">
                            <el-input size="small" v-model="queryForm.id"></el-input>
                        </div>
                    </div>
                    <div class="item w2">
                        <span class="label">告警时间：</span>
                        <div class="ipt">
                            <el-date-picker v-model="queryForm.date"
                                            size="small"
                                            type="daterange"
                                            unlink-panels
                                            range-separator="至"
                                            start-placeholder="开始日期"
                                            end-placeholder="结束日期">
                            </el-date-picker>
                        </div>
                    </div>
                    <div class="item">
                        <span class="label o">维度类型：</span>
                        <div class="ipt">
                            <el-select size="small" v-model="queryForm.dimensionType">
                                <el-option v-for="(item, k) in dimensionList" :key="`demension_key_${k}`" :label="item.label" :value="item.value"></el-option>
                            </el-select>
                        </div>
                    </div>
                    <div class="item">
                        <span class="label">维度参数：</span>
                        <div class="ipt">
                            <el-input  size="small" v-model="queryForm.dimensionParam"></el-input>
                        </div>
                    </div>
                    <div class="item">
                        <span class="label">接口类型：</span>
                        <div class="ipt">
                            <el-select size="small" v-model="queryForm.interfaceType">
                                <el-option v-for="(item, k) in interfaceList" :key="`interface_key_${k}`" :label="item.label" :value="item.value"></el-option>
                            </el-select>
                        </div>
                    </div>
                    <div class="item">
                        <span class="label">异常类型：</span>
                        <div class="ipt">
                            <el-select size="small" v-model="queryForm.exceptionType">
                                <el-option v-for="(item, k) in exceptionTypeList" :key="`exception_key${k}`" :label="item.label" :value="item.value"></el-option>
                            </el-select>
                        </div>
                    </div>
                    <div class="item accurate-button">
                        <el-button type="primary" size="small" @click="queryEvent('accurate')">查询</el-button>
                        <el-button type="primary" size="small" @click="resetForm">重置</el-button>
                    </div>
                </div>
            </div>
        </div>
        <div slot="content" class="common-table-content" v-loading="tableData.loading">
            <el-table :data="tableData.data" style="width: 100%;" height="100%">
                <div class="common-no-data" slot="empty">
                    <i class="icon"></i>
                    <span class="text">暂无数据</span>
                </div>
                <el-table-column v-for="(item, k) in tableData.column"
                                 :prop="item.key"
                                 :label="item.label"
                                 header-align="center"
                                 align="center"
                                 :min-width="item.width"
                                 :key="`key_${k}`">
                    <template slot-scope="scope">
                        <!-- 侧滑框按钮 -->
                        <el-tooltip v-if="item.key=== 'jobName'" class="item" effect="dark" :content="scope.row[scope.column.property] + ''" placement="top" :disabled="!scope.row[scope.column.property]">
                            <span class="common-table-cell click-active" @click="showDetail(scope.row)">{{scope.row[scope.column.property] || '-'}}</span>
                        </el-tooltip>
                        <!-- 操作按钮--详情 -->
                        <div v-else-if="item.key === 'opt'">
                            <el-button type="text" size="mini" @click="tableCellEvt('pageLayout', scope.row)">pageLayout</el-button>
                            <el-button type="text" size="mini" @click="tableCellEvt('详情', scope.row)">详情</el-button>
                            <el-button type="text" size="mini" @click="tableCellEvt('鱼骨', scope.row)">鱼骨图</el-button>
                            <el-button type="text" size="mini" @click="tableCellEvt('流程', scope.row)">流程</el-button>
                        </div>
                        <el-tooltip v-else class="item" effect="dark" :content="scope.row[scope.column.property] + ''" placement="top" :disabled="!scope.row[scope.column.property]">
                            <span class="common-table-cell" >{{scope.row[scope.column.property] || '-'}}</span>
                        </el-tooltip>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div slot="paging" class="common-paging-box">
            <el-button type="primary" @click="exportEvent([], tableData.data, 'DIAL_TEST_LIST_EXPORT', false)" size="small">导出</el-button>
            <el-pagination @size-change="pagingEvent($event, 'size')"
                           @current-change="pagingEvent($event, 'current')"
                           :current-page="pagingData.current"
                           :page-sizes="pagingData.sizes"
                           :page-size="pagingData.size"
                           :total="pagingData.total"
                           style="float: right;"
                           layout="total, sizes, prev, pager, next, jumper">
            </el-pagination>
        </div>
        <!-- 侧滑框 -->
        <template-side-model :detailObject="detailObject"></template-side-model>

        
    </page-layout>

    <!-- 鱼骨图 -->
    <div v-else-if="displayType === 'fishBone'" class="fish-bone">
        <fishbone-node  :pageData="fishBoneData"
                        :refreshId="fishBoneId"
                        @detailViewEvt="detailViewEvt"
                        @returnList="returnList"></fishbone-node>
    </div>
</template>
<script>
    import BaseView from "@/page/BaseView.vue";
    import { postDataRequest, getDataRequest } from "@/api/common";
    import TemplateSideModel from './TemplateSideModel.vue';
    import FishboneNode from "./TemplateFishBone.vue";
    import Tool from '@/util/tool.js';

    export default {
        extends: BaseView,
        components: { 
            TemplateSideModel, FishboneNode
        },
        data() {
            return {
                analysisList: [
                    {store: '新品库', key: 'newly', name: '新品库统计', value: 0},
                    {store: '回收库', key: 'collection', name: '回收库统计', value: 0},
                    {store: '备件库', key: 'spare', name: '备件库统计', value: 0},
                    {store: '用户库', key: 'user', name: '用户库统计', value: 0}
                ],
                queryForm: {
                    vagueDate: '',
                    vagueName: '',
                    name: '',
                    id: '',
                    date: '',
                    dimensionType: '',
                    dimensionParam: '',
                    interfaceType: '',
                    exceptionType: ''
                },
                detailObject: {
                    showId: 0,
                    info: [
                        {label: '任务名称', value: '', key: 'jobName'},
                        {label: '任务ID', value: '', key: 'jobId'},
                        {label: '维度类型', value: '', key: 'dimensionType'},
                        {label: '维度参数', value: '', key: 'dimension'},
                        {label: '接口类型', value: '', key: 'interFace'},
                        {label: '异常类型', value: '', key: 'errorType'},
                        {label: '样本值', value: '', key: 'sampleValue'},
                        {label: '超标阈值', value: '', key: 'thresholdValue'},
                        {label: '超标值', value: '', key: 'targetValie'},
                        {label: '偏差', value: '', key: 'deviation'},
                        {label: '告警时间', value: '', key: 'eventTime'}
                        
                    ]
                },
                /* 维度类型 */
                dimensionList: [],
                /*  接口类型 */
                interfaceList: [],
                /* 异常类型 */
                exceptionTypeList: [],
                displayType: 'table',
                /*  鱼骨图id */
                fishBoneId: 0,
                /* 鱼骨图数据 */
                fishBoneData: []
            }
        },
        methods: {
            async getInitPaging(type) {
                /* 获取维度类型 */
                this.getDimensionList();

                /* 获取接口类型 */
                this.getInterfaceList();

                /* 获取异常类型 */
                this.getExceptionTypeList();

                /* 获取表格数据 */
                this.getTableData(type);
            },
             /* 表单重置 */
            resetForm() {
                for(let key in this.queryForm) {
                    if (this.queryForm.hasOwnProperty(key) && key != 'vagueDate' && key != 'vagueName') this.queryForm[key] = '';
                }
            },
            queryEvent(type) {
                /* 如果当前查询为精确查询，或则是当前form查询类型为精确查询，需要关闭精确查询框 */
                let isAccurate = type === 'accurate' || this.queryType === 'accurate';

                if (this.tableData.loading) return;
                this.pagingData.current = 1;

                if (isAccurate) {
                    /* 精确查询 */
                    this.accurateEvent('accurateNode');
                    this.queryForm.vagueDate = '';
                    this.queryForm.vagueName = '';
                    this.exportData = JSON.parse(JSON.stringify({
                        name: this.queryForm.name,
                        id: this.queryForm.id,
                        date: this.queryForm.date,
                        dimensionType: this.queryForm.dimensionType,
                        dimensionParam: this.queryForm.dimensionParam,
                        interfaceType: this.queryForm.interfaceType,
                        exceptionType: this.queryForm.exceptionType
                    }));
                } else {
                     this.exportData = JSON.parse(JSON.stringify({
                        vagueDate: this.queryForm.vagueDate,
                        vagueName: this.queryForm.vagueName
                    }));
                }
                this.getTableData();
            },
            /* 获取表格数据 */
            async getTableData() {
                this.tableData.loading = true;
                this.exportData.pageSize = this.pagingData.size;
                this.exportData.pageNum = this.pagingData.current;

                let result = {
                    code: 200,
                    data: {
                        total: 200,
                        rows: []
                    }
                };
                this.tableData.loading = false;
                let temp = [];
                if (!!result && result.code === 200) {
                    this.pagingData.total = result.data.total;
                    for (let i = 0; i < this.pagingData.size; i++) {
                        temp.push({
                            id: `job_${i}`,
                            jobName: `任务名称${i}`,
                            dimension: '维度参数',
                            dimensionType: '维度类型',
                            errorType: '异常类型',
                            eventTime: '2019-11-02 23:59:59',
                            step: ['经理', '副总', '使用中', '完成'][Math.floor(Math.random()*4)]
                        })
                    }
                } else {
                    this.$message.error("任务列表获取失败！");
                }

                this.tableData.data = temp;
            },
            /* 获取维度类型 */
            async getDimensionList() {
                let result = {
                    code: 200,
                    data: [
                        {label: '电力抄表', value: '电力抄表'},
                        {label: '国网充电桩', value: '国网充电桩'},
                        {label: '摩拜单车', value: '摩拜单车'}
                    ]
                };
                let temp = [];
                if (!!result && result.code === 200) {
                    result.data.map(it => {
                        temp.push({
                            label: it.label,
                            value: it.value
                        })
                    })
                } else {
                    this.$message.error(result.description);
                }
                this.dimensionList = temp;
            },
            /* 获取接口类型 */
            async getInterfaceList() {
                let result = {
                    code: 200,
                    data: [
                        {label: '电力抄表', value: '电力抄表'},
                        {label: '国网充电桩', value: '国网充电桩'},
                        {label: '摩拜单车', value: '摩拜单车'}
                    ]
                };
                let temp = [];
                if (!!result && result.code === 200) {
                    result.data.map(it => {
                        temp.push({
                            label: it.label,
                            value: it.value
                        })
                    })
                } else {
                    this.$message.error(result.description);
                }
                this.interfaceList = temp;
            },
            /* 获取异常类型 */
            async getExceptionTypeList() {
                let result = {
                    code: 200,
                    data: [
                        {label: '电力抄表', value: '电力抄表'},
                        {label: '国网充电桩', value: '国网充电桩'},
                        {label: '摩拜单车', value: '摩拜单车'}
                    ]
                };
                let temp = [];
                if (!!result && result.code === 200) {
                    result.data.map(it => {
                        temp.push({
                            label: it.label,
                            value: it.value
                        })
                    })
                } else {
                    this.$message.error(result.description);
                }
                this.exceptionTypeList = temp;
            },
            /* 查看详情 */
            showDetail(row) {
                this.detailObject.showId = +new Date();
                this.detailObject.info.map(it => it.value = row[it.key]);
            },
            /* 操作按钮 */
            tableCellEvt(type, row) {
                if (type === '详情') {
                    sessionStorage.setItem(this.cacheKey, JSON.stringify({...this.exportData, pageTotal: this.pagingData.total}));
                    this.$router.push({path: '/default_template/template_detail', query: {id: row.id}});
                } else if (type === '鱼骨') {
                    this.displayType = 'fishBone';
                    this.getFishBoneData(row);
                } else if (type === '流程') {
                    let cStep = row.step === '经理' ? 1 : row.step === '副总' ? 2 : row.step === '使用中' ? 3 : 4;
                    this.$router.push({path: "/default_template/template_steps", query: {cStep: cStep}});
                } else if (type === 'pageLayout') {
                    this.$router.push({path: "/default_template/template_page"});
                }
            },
            /* 获取鱼骨图数据 */
            async getFishBoneData(id) {
                let result = {
                    code: 200,
                    description: '',
                    data: [
                        {year: 2019, data: [
                                {day: 1, month: 1, orderType: '勘查', type: 'PRE', desc: '【勘查】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 1, orderType: '变勘', type: 'PRE', desc: '【变勘】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 1, orderType: '开通', type: 'IN', desc: '【开通】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 2, orderType: '变开', type: 'PRE', desc: '【变开】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 2, orderType: '停机', type: 'IN', desc: '【停机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 2, orderType: '复机', type: 'IN', desc: '【复机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 2, orderType: '拆机', type: 'IN', desc: '【拆机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 3, orderType: '故障', type: 'AFTER', desc: '【故障】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '投诉', type: 'AFTER', desc: '【投诉】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '重保', type: 'AFTER', desc: '【重保】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '割接', type: 'AFTER', desc: '【割接】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '巡检', type: 'AFTER', desc: '【巡检】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '拜访', type: 'AFTER', desc: '【拜访】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'}
                            ]},
                        {year: 2018, data: [
                                {day: 1, month: 1, orderType: '勘查', type: 'PRE', desc: '【勘查】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 1, orderType: '变勘', type: 'PRE', desc: '【变勘】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 2, orderType: '开通', type: 'IN', desc: '【开通】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 2, orderType: '变开', type: 'PRE', desc: '【变开】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 3, orderType: '停机', type: 'IN', desc: '【停机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 3, orderType: '复机', type: 'IN', desc: '【复机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 3, orderType: '拆机', type: 'IN', desc: '【拆机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '故障', type: 'AFTER', desc: '【故障】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 8, orderType: '投诉', type: 'AFTER', desc: '【投诉】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 8, orderType: '重保', type: 'AFTER', desc: '【重保】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 10, orderType: '割接', type: 'AFTER', desc: '【割接】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '巡检', type: 'AFTER', desc: '【巡检】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '拜访', type: 'AFTER', desc: '【拜访】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'}
                            ]},
                        {year: 2017, data: [
                                {day: 1, month: 1, orderType: '勘查', type: 'PRE', desc: '【勘查】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 1, orderType: '变勘', type: 'PRE', desc: '【变勘】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 1, orderType: '开通', type: 'IN', desc: '【开通】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 1, orderType: '变开', type: 'PRE', desc: '【变开】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 1, orderType: '停机', type: 'IN', desc: '【停机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 12, orderType: '复机', type: 'IN', desc: '【复机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 12, orderType: '拆机', type: 'IN', desc: '【拆机】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 12, orderType: '故障', type: 'AFTER', desc: '【故障】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 12, orderType: '投诉', type: 'AFTER', desc: '【投诉】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 12, orderType: '重保', type: 'AFTER', desc: '【重保】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 12, orderType: '割接', type: 'AFTER', desc: '【割接】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '巡检', type: 'AFTER', desc: '【巡检】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查'},
                                {day: 1, month: 4, orderType: '拜访', type: 'AFTER', desc: '【拜访】：11-12 12:00:00 数据专线-贵阳花溪-黔南福泉-10M 进行勘查', visitreport: 'dmsd'}
                            ]}
                        ]
                    }

                    this.fishBoneData = result.data;
                    this.fishBoneId = Date.now();
            },
            /* 鱼骨图弹出框详情 */
            async detailViewEvt(data) {
                this.$alert('鱼骨图弹出框', '标题名称', {
                    confirmButtonText: '确定',
                    callback: action => {
                        
                    }
                });
            },
            /* 鱼骨图返回按钮 */
            returnList(type) {
                this.displayType = type;
            }
        },
        created() {
            /* 初始化表格列属性 */
            this.tableData.column = [
                {label: '任务ID', key: 'id', width: 96},
                {label: '任务名称', key: 'jobName', width: 96},
                {label: '维度参数', key: 'dimension', width: 120},
                {label: '维度类型', key: 'dimensionType', width: 100},
                {label: '环节名称', key: 'step', width: 96},
                {label: '异常类型', key: 'errorType', width: 96},
                {label: '告警时间', key: 'eventTime', width: 166},
                {label: '操作', key: 'opt'}
            ];
           this.getInitPaging();
        },
        mounted() {
            /* 如果 exportData 存在数据需要对页面参数进行回填，主要判断是否有分页参数 */
            if (!!this.exportData.pageSize) {
                for(let key in this.exportData) {
                    if (this.queryForm.hasOwnProperty(key)) {
                        this.queryForm[key] = this.exportData[key];
                    }
                }
            }
        },
    }
</script>