/*********************************************************************
* Vue ValidateResult file
* Created by deming-su on 2019/7/24
*********************************************************************/

<template>
   <side-model :displayId="detailObject.showId" title="任务详情">
        <div class="threshold-form-box">
            <div class="common-form-container auto">
                <div class="box">
                    <div class="item label100" v-for="(item, k) in detailObject.info" :key="`detail_key_${k}`">
                        <span class="label">{{item.label}}：</span>
                        <div class="ipt">
                            <el-input size="small" v-model="item.value" disabled></el-input>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <el-button slot="footer" size="small" @click="detailObject.showId = +new Date()">取消</el-button>
    </side-model>
</template>
<script>
    import BaseView from "@/page/BaseView.vue";
    import { postDataRequest, getDataRequest } from "@/api/common";
    import Tool from '@/util/tool.js'

    export default {
        extends: BaseView,
        props: {
            detailObject: {
                type: Object,
                default: () => {}
            }
        },
        data() {
            return {
                
            }
        },
        methods: {
           
        },
        created() {
          
           
        }
    }
</script>