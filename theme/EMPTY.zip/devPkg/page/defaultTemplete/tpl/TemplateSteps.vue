<template>
    <div class="template-steps">
        <el-button @click="returnPage()" size="mini" plain class="go-back-btn">返回</el-button>
        <div class="page-content-container top45">
            <div class="timeline-container">
                <el-steps :active="activeIndex" finish-status="success" align-center>
                    <el-step v-for="(item, i) in stepsList" 
                             :key="`step_${item.key}_${i}`" 
                             :title="item.title"></el-step>
                </el-steps>
            </div>
        </div>
       
    </div>
</template>
<script>
    import Tool from "@/util/tool";
    import { postRequestMethod, getRequestMethod } from "@/api/common";
    import { mapGetters } from 'vuex';

    export default {
        data() {
            return {
                stepsList: [],
                activeIndex: 0,//当前流程位置 
            }
        },
        watch: {
           
        },
        methods: {
            returnPage() {
                this.$router.go(-1);
            }
        },
        created() {
            this.stepsList = [
                {title: '经理审核', key: 'manager'},
                {title: '副总审核', key: 'manager'},
                {title: '使用中', key: 'manager'},
                {title: '关闭', key: 'manager'}
            ],
            this.activeIndex = this.$route.query.cStep * 1;
        },
        mounted() {
           
        }
    }
</script>

    
