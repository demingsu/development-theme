/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/30
*********************************************************************/

<template>
    <div class="common-list-layout">
        <el-button v-if="goBack" @click="returnPage()" size="mini" plain class="go-back-btn">返回</el-button>
        <div class="content">
            <article class="detail" :class="{'no-footer': !hasFooter}">
                <section>
                    <slot></slot>
                </section>
                <footer v-if="hasFooter">
                    <slot name="footer"></slot>
                </footer>
            </article>
        </div>
    </div>
</template>

<script>

    export default {
        props: {
            breadcrumbList: {
                type: Array,
                default: () => []
            },
            goBack: {
                type: Boolean,
                default: false
            },
        },
        computed: {
            hasFooter() {
                return !!this.$slots.footer;
            }
        },
         methods: {
            returnPage() {
                this.$router.go(-1);
            }
        }
    }
</script>