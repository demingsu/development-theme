/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/30
*********************************************************************/

<template>
    <div class="common-list-layout">
        <bread-item :breadcrumbList="breadcrumbList"></bread-item>
        <div class="content" :class="{'no-query': !hasHeader}">
            <header>
                <slot name="header"></slot>
            </header>
            <article :class="{'no-footer': !hasFooter}">
                <slot></slot>
                <footer>
                    <slot name="footer"></slot>
                </footer>
            </article>
        </div>
    </div>
</template>

<script>

    export default {
        props: {
            breadcrumbList: {
                type: Array,
                default: () => []
            }
        },
        computed: {
            hasHeader() {
                return !!this.$slots.header;
            },
            hasFooter() {
                return !!this.$slots.footer;
            }
        }
    }
</script>