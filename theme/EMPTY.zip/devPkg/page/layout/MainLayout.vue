/*********************************************************************
* Vue private main layout file
* Created by deming-su on 2017/12/30
*********************************************************************/

<template>
    <div class="application-container">
        <!-- 顶部导航菜单 ---start--- -->
        <navigator-container @menuEvent="menuEvent"></navigator-container>
        <!-- 顶部导航菜单 ---end--- -->

        <!-- 左侧菜单 ---start--- -->
        <menu-node :collapse="collapse"></menu-node>
        <!-- 左侧菜单 ---end--- -->

        <!-- 主体路由样式 ---start--- -->
        <div class="application-view-container" :class="{collapse: collapse}">
            <router-view></router-view>
        </div>
        <!-- 主体路由样式 ---end--- -->
    </div>
</template>

<script>
    import NavigatorContainer from "../../components/common/Navigator.vue";
    import MenuNode from "@/components/common/MenuNode.vue";

    export default {
        components: {
            NavigatorContainer, MenuNode
        },
        data() {
            return {
                collapse: false
            }
        },
        methods: {
            menuEvent(type, data) {
                switch (type) {
                    case 'message':
                        console.log('message event ... ...');
                        break;
                    case 'collapse':
                        this.collapse = data;
                        break;
                }
            }
        },
        mounted() {
            this.$nextTick(() => {

                this.$root.eventBus.$emit('NoticeBroadcast', {type: 'notice', data: {}});
            });
        }
    };
</script>
