/*********************************************************************
 * Vue private main layout file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="application-container">

        <!-- 主体路由样式 ---start--- -->
        <div class="view-container">
            <router-view></router-view>
        </div>
        <!-- 主体路由样式 ---end--- -->
    </div>
</template>

<script>

    export default { };
</script>