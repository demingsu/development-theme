/*********************************************************************
* Vue MainLayout file
* Created by deming-su on 2019/7/7
*********************************************************************/

<template>
    <div class="application-container">
        <router-view></router-view>
    </div>
</template>
<script>
    export default {
        /**
         * 页面参数释义
         */
        data() {
            return {}
        },
        /**
         * 页面初始化
         */
        created() {

        }
    }
</script>