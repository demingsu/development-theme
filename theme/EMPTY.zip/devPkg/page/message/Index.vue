/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <div class="home-container">
        <i class="test">&#xe67a;</i>
    </div>
</template>

<script>
    import BaseView from "../BaseView.vue";
    import { getDataRequest } from "../../api/common";
    
    export default {
		mixins: [BaseView],
        /**
         * 所有参数变量说明
         * paging             boolean   是否需要分页
         */
        data() {
            return {

            }
        },
        methods: {
            async queryEvt() {

                let loading = this.$loading({
                    lock: true
                });

                let result = await getDataRequest('HOME_INDEX_URL', {}) || {};
                loading.close();
                if(result.code === 200) {
                    this.$message('接口请求成功');
                } else {
                    this.handleErrorMessage(result);
                }
            }
        },
        created() {
            this.queryEvt();
        }
    }
</script>