/*********************************************************************
 * Static variable file
 * Created by deming-su on 2019/10/28
 *********************************************************************/

/* 通用管理--页面未找到 404 */
const NotFoundNode = () => import(/* webpackChunkName: "NotFoundNode"*/"../page/common/NotFound.vue");

/* 通用管理--没有权限 403 */
const NotRightNode = () => import(/* webpackChunkName: "NotRightNode"*/"../page/common/NotRight.vue");

/* 通用管理--登录 */
const LoginNode = () => import(/* webpackChunkName: "LoginNode"*/"../page/common/Login.vue");


const routes = [
    {path: '/', redirect: '/default/login'},
    {path: '/default/notfound', component: NotFoundNode, meta: {  layout: 'blank-layout' }},
    {path: '/default/notright', component: NotRightNode, meta: {  layout: 'blank-layout' }},
    {path: '/default/login', component: LoginNode, meta: {  layout: 'blank-layout' }},
];

export default routes;