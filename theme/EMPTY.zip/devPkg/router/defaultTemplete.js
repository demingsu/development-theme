/*********************************************************************
 * defined text message page router file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 默认模板首页路由 */
const DefaultTemplateIndex = () => {
    return import(/* webpackChunkName: "DefaultTemplateIndex"*/"../page/defaultTemplete/Index.vue");
};

/* 默认模板列表路由 */
const DefaultTemplateList = () => {
    return import(/* webpackChunkName: "DefaultTemplateList"*/"../page/defaultTemplete/tpl/TemplateList.vue");
};

/* 默认模板详情路由 */
const DefaultTemplateDetail = () => {
    return import(/* webpackChunkName: "DefaultTemplateDetail"*/"../page/defaultTemplete/tpl/TemplateDetail.vue");
};

/* 默认模板详情路由 */
const DefaultTemplateSteps = () => {
    return import(/* webpackChunkName: "DefaultTemplateSteps"*/"../page/defaultTemplete/tpl/TemplateSteps.vue");
};

/* 默认模板完整首页路由 */
const DefaultPageLayout = () => {
    return import(/* webpackChunkName: "DefaultPageLayout"*/"../page/defaultTemplete/tpl/TemplatePageLayout.vue");
};


const routes = [
    {
        path: "/default_template",
        component: DefaultTemplateIndex,
        children: [
            {path: '', redirect: 'template_list'},
            {path: 'template_list', component: DefaultTemplateList, meta: {  layout: 'main-layout' }},
            {path: 'template_detail', component: DefaultTemplateDetail, meta: {  layout: 'main-layout' }},
            {path: 'template_steps', component: DefaultTemplateSteps, meta: {  layout: 'main-layout' }},
            {path: 'template_page', component: DefaultPageLayout, meta: {  layout: 'main-layout' }},

        ]
    }
];

export default routes;