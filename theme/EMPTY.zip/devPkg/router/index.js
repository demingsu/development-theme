/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/


"use strict";

/* 加载vue路由 */
import Router from "vue-router";

/* 各个功能模块 --start-- */

/* 首页路由 */
import Home from "./home";

/* 各个功能模块 --end-- */

/* 路由集合 */
const RouterCollection = [
    ...Home
];

/* 路由配置 */
const router = new Router({routes: RouterCollection});

/* 判断是否已经登录 */
let isUserLogin = () => {
    try {
        let user = JSON.parse(sessionStorage.getItem("current_login_user_info") || "{}");
        return !!user.id && !!user.name;
    } catch (e) {
        return false;
    }

};

/* 路由权限拦截 */
router.beforeEach((to, from, next) => {
    /* 是否需要登陆验证 */
    if (to.meta.requestLogin) {
        if (isUserLogin()) {
            next();
        } else {
            next("/home");
        }
    } else {
        next();
    }
});

export default router;