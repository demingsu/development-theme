/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/


"use strict";

/* 加载vue路由 */
import Router from "vue-router";

/* 各个功能模块 --start-- */

/* 通用路由 */
import Common from "./common";

/* 首页路由 */
import Home from "./home";

/* 各个功能模块 --end-- */

/* 路由集合 */
const RouterCollection = [
	...Common,
    ...Home
];

/* 路由配置 */
const router = new Router({routes: RouterCollection});

/* 是否是默认路由页面 */
let isDefaultRouter = (path) => {
    return ['/default/login', '/default/notfound', '/default/notright'].includes(path);
};

/* 检查是否存在此路由 */
let isExistPath = (path, routers) => {
    for (let item of routers) {
        let flag = loopPath(path, item);
        if (flag) {
            return flag;
        }
    }
    return false;
};

let loopPath = (path, item) => {
    if (item.path === path) {
        return true;
    }
    if (!!item.children && item.children.length > 0) {
        for (let it of item.children) {
            path = path.replace(`${item.path}/`, "");
            if (loopPath(path, it)) {
                return true;
            }
        }
    }
    return false;
};

/* 路由权限拦截 */
router.beforeEach((to, from, next) => {

    /* 是否是默认路由 */
    if (!!isDefaultRouter(to.path)) {
        next();
        return;
    }

    /* 是否存在访问路由 */
    if (!isExistPath(to.path, RouterCollection)) {
        next("/default/notfound");
        return;
    }

    let _token = router.app.$store.getters.getApplicationToken;
    if (!!_token) {
        next();
    } else {
        next('/default/notright');
    }
});

export default router;