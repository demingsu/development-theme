/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/


"use strict";

/* 加载vue路由 */
import Router from "vue-router";

/* 各个功能模块 --start-- */

/* 首页路由 */
import Message from "./message";

/* 各个功能模块 --end-- */

/* 路由集合 */
const RouterCollection = [
    ...Message
];

/* 路由配置 */
const router = new Router({routes: RouterCollection});

/* 路由权限拦截 */
router.beforeEach((to, from, next) => {
    next();
});

export default router;