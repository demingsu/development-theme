/*********************************************************************
 * defined text message page router file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 报告首页路由 */
const MessageIndex = () => {
    return import(/* webpackChunkName: "MessageIndex"*/"../page/message/Index.vue");
};

const routes = [
    { path: "/", redirect: '/message' },
    { path: "/message", component: MessageIndex, meta: { layout: 'blank-layout' }}
];

export default routes;