/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/**
 * 状态数据库对象
 */
const state = {
    applicationToken: ''
};

/**
 * 状态数据库设值方法
 */
const getters = {
    getApplicationToken: state => state.applicationToken
};

const actions = {
	setApplicationToken({commit}, {data}) {
        commit('mutationApplicationToken', {data});
    }
};

const mutations = {
    mutationApplicationToken(state, {data}) {
        /* 扭转数据状态 */
        state.applicationToken = data;
    }
};

export default {
	state,
	getters,
	actions,
	mutations
};