/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/**
 * 状态数据库对象
 */
const state = {
    userInfo: {},
    applicationToken: ''
};

/**
 * 状态数据库设值方法
 */
const getters = {
    getUserInfo: () => sessionStorage.getItem("login_user_info") !== null ? JSON.parse(sessionStorage.getItem("login_user_info")) : {},
    getApplicationToken: state => state.applicationToken
};

const actions = {
    setUserInfo({commit}, {data}) {
        commit('mutationUserInfo', {data});
    },
    setApplicationToken({commit}, {data}) {
        commit('mutationApplicationToken', {data});
    },
};

const mutations = {
    mutationUserInfo(state, {data}) {
        /* 扭转数据状态 */
        state.userInfo = data;
    },
    mutationApplicationToken(state, {data}) {
        /* 扭转数据状态 */
        state.applicationToken = data;
    },
};

export default {
	state,
	getters,
	actions,
	mutations
};