/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/**
 * 状态数据库对象
 */
const state = {

};

/**
 * 状态数据库获值方法
 */
const getters = {

};

/**
 * 状态数据库设值方法
 */
const actions = {
	setMenuList({commit}, {expandState}) {
    	commit('mutationMenuState', {expandState});
	}
};

const mutations = {
    mutationMenuState(state, {expandState}) {

		/* 扭转数据状态 */
		state.menuExpand = expandState;
	}
};

export default {
	state,
	getters,
	actions,
	mutations
};