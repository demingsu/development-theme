/*********************************************************************
 * common util function file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/**
 *  日期转换方法
 *  @param YYYY-MM-DD hh:mm:ss
 */
let dateFormat = (type, val) => {
    let date = val ? new Date(/^[0-9]*$/g.test(val) ? val * 1 : val) : new Date();
    let YYYY = date.getFullYear() + '';
    let m = date.getMonth() + 1;
    let MM = m > 9 ? m + '' : '0' + m;
    let d = date.getDate();
    let DD = d > 9 ? d + '' : '0' + d;
    let h = date.getHours();
    let hh = h > 9 ? h + '' : '0' + h;
    let $m = date.getMinutes();
    let mm = $m > 9 ? $m + '' : '0' + $m;
    let s = date.getSeconds();
    let ss = s > 9 ? s + '' : '0' + s;
    let obj = { YYYY, MM, DD, hh, mm, ss};

    return type.replace(/(YYYY)|(MM)|(DD)|(hh)|(mm)|(ss)/g, (key) => obj[key]);
};

/**
 *  去掉字段的两端空格
 *  @param Object
 */
let fileSize = (size, count) => {
    if (!count) count = 0;
    if (isNaN(size)) return 0;
    const names = ['byte', 'KByte', 'MB', 'GB', 'TB'];
    if (size < 1024) {
        return size + names[count];
    } else {
        return fileSize(parseFloat((size / 1024).toFixed(2)), ++count);
    }
};



/**
 * 打开新页签
 * @param url      [String]      新页签地址
 * @param flag     {Boolean}     是否直接用地址打开
 */
let openTabByUrl = (url, flag) => {
    let el = document.createElement("a");
    document.body.appendChild(el);
    el.href = flag ? url : encodeURI(`${location.protocol}//${location.host}${location.pathname}#${url}`);
    el.target = '_blank';

    el.click();
    document.body.removeChild(el);
};

/**
 * 文件上传，返回dom节点
 */
let fileUploadNode = async (isMulti) => {

    let _res = await filePick(isMulti)
        .catch(e => {
            return e;
        });

    if (!!_res) return _res;
};

let filePick = (isMulti) => {
    return new Promise((resolve, reject) => {
        let box = document.createElement('div');
        document.body.appendChild(box);
        box.setAttribute('style', 'display: block; height: 0; width: 0; overflow: hidden;');

        let input = document.createElement('input');
        input.setAttribute('type', 'file');
        if (isMulti) input.setAttribute('multiple', 'multiple');
        box.appendChild(input);

        input.addEventListener('change', function() {

            let file = null;
            if (input.files && input.files.length > 0) {
                file = input.files;
                resolve(file);
            } else {
                reject("ERROR_CODE");
            }

            setTimeout(() => {
                document.body.removeChild(box);
            });
        });

        input.click();
    });
};

export default {
    dateFormat,
    fileSize,
    openTabByUrl,
    fileUploadNode
};