/*********************************************************************
* Vue BaseLayout file
* Created by deming-su on 2019/1/31
*********************************************************************/

<template>
    <div class="layout-main-container">
        <header v-if="showHeader">
            <span @click="backEvent()" v-if="showBack" class="back"></span>
            <h1>{{pageTitle}}</h1>
            <span class="right">
                <span @click="backEvent('/home')" v-if="showHome" class="item home"></span>
                <span @click="filterEvent" v-if="showFilter" class="item filter"></span>
            </span>
        </header>
        <article>
            <slot></slot>
        </article>
    </div>


    <!--<view-box class="layout-header-padding">
        <x-header v-if="showHeader" slot="header" :left-options="{showBack: false}">
            <span @click="backEvent()" v-if="showBack" class="layout-header-icon back" slot="left"></span>
            {{pageTitle}}
            <span @click="backEvent('/home')" v-if="showHome" class="layout-header-icon" slot="right"> </span>
        </x-header>
        <div class="layout-body-container" :style="{top: showHeader ? '46px' : 0}">
            <slot></slot>
        </div>
    </view-box>-->
</template>
<script>
    export default {
        /**
         * 属性参数释义
         * @param {Boolean} showFooter 是否显示底部按钮组
         * @param {Boolean} showBack 是否显示返回按钮
         * @param {Boolean} showHome 是否显示返回首页按钮
         */
        props: {
            title: String,
            showBack: {
                type: Boolean,
                default: true
            },
            showHome: {
                type: Boolean,
                default: true
            },
            showFilter: {
                type: Boolean,
                default: false
            }
        },
        computed: {
            showHeader() {
                return this.pageTitle && this.pageTitle !== '';
            }
        },
        data() {
            return {
                pageTitle: ''
            }
        },
        methods: {
            /* 返回事件 */
            backEvent(path) {
                if (path) {
                    this.$router.push({path: path}).catch(() => {});
                } else {
                    this.$router.go(-1);
                }
            },
            filterEvent() {
                this.$root.eventBus.$emit('FILTER_EVENT');
            }
        },
        created() {
            this.pageTitle = this.title;

            /* 动态修改标题方法 */
            this.$root.eventBus.$on('changeMainTitle', d => {
                console.log(d);
                if (d.type === 'text') {
                    this.pageTitle = d.title;
                }
            });
        }
    }
</script>