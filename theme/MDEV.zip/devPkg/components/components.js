/*********************************************************************
 * Vux component import file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

const BaseLayout = () => { return import(/* webpackChunkName: "BaseLayout"*/"./common/BaseLayout.vue"); };

import {
    Loading,
    LoadingPlugin,
    TransferDom,
    ViewBox,
    XHeader,
    Popup,
    PopupHeader
} from 'vux';

const component = {
    BaseLayout,
    Loading,
    ViewBox,
    XHeader,
    Popup,
    PopupHeader
};

const prop = {
    LoadingPlugin
};

const drt = {
    TransferDom
};


export {
    component,
    prop,
    drt
}