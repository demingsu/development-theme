/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

/* 通用 ---start--- */
let BASE_URL = "/api";
if (process.env.NODE_ENV.trim() === "production") {

    /* 现场地址 */
    // BASE_URL = "http://192.168.2.2:8986";

    /* 测试地址 */
    BASE_URL = 'http://192.168.2.2:22886';
}
/* 通用 ---end--- */

export default {
    BASE_URL
};