/*********************************************************************
 * Created by deming-su on 2017/12/30
 *********************************************************************/

<template>
    <base-layout :show-filter="true" title="测试标题">
        <div class="common-list-layout">
            <header class="query-box">
                <div class="condition">
                    <div class="item w120">
                        <input type="text" v-model="text" placeholder="请输入条件"/>
                    </div>
                    <div class="item">
                        <input type="text" v-model="text" placeholder="请输入条件"/>
                    </div>
                </div>
                <i @click="getPageData" class="icon"></i>
            </header>
            <ul class="list-content">
                <li class="item" v-for="(item,i) in contentList" :key="`list_key_${i}`">
                    <span>项目名称：{{item.name}}</span>
                    <span>项目编号：{{item.code}}</span>
                    <span>计划开始时间：{{item.st}}</span>
                    <span>计划结束时间：{{item.et}}</span>
                    <span>项目经理：{{item.manager}}</span>
                    <span>项目状态：{{item.state}}</span>
                    <i class="icon"></i>
                </li>
            </ul>
        </div>
        <div v-transfer-dom>
            <popup v-model="filterData.show" position="bottom" should-rerender-on-show>
<!--                <popup-header left-text=""-->
<!--                              right-text="取消"-->
<!--                              @on-click-right="filterData.show = false"></popup-header>-->
                <ul class="common-list-container">
                    <li v-for="(item,i) in filterData.data"
                        :class="['item', {active: item.active}]"
                        @click="filterEvent(item)"
                        :key="`filter_key_${i}`">{{item.label}}</li>
                </ul>
            </popup>
        </div>
    </base-layout>
</template>

<script>

    export default {
        data() {
            return {
                text: '',
                contentList: [],
                filterData: {
                    show: false,
                    data: [
                        {label: '全量', key: '全量', active: true},
                        {label: '待审批', key: '待审批', active: false},
                        {label: '已驳回', key: '已驳回', active: false},
                        {label: '待受理', key: '待受理', active: false},
                        {label: '处理中', key: '处理中', active: false},
                        {label: '待确认', key: '待确认', active: false},
                        {label: '已归档', key: '已归档', active: false}
                    ]
                }
            }
        },
        methods: {
            async getPageData() {

                this.$vux.loading.show();
                let _result = {
                    code: 200,
                    description: '',
                    data: []
                };

                for (let i = 0;i < 10;i ++) {
                    _result.data.push({
                        name: '2018年国税局数据中心SDN',
                        code: 'B823323',
                        st: '2019-11-30',
                        et: '2019-11-30',
                        manager: '张老三',
                        state: '进行中'
                    })
                }

                setTimeout(() => {

                    this.contentList = !!_result && _result.code === 200 ? _result.data : [];
                    this.$vux.loading.hide();
                }, 1000);
            },
            filterEvent(item) {

                this.filterData.data.map(it => it.active = it.key === item.key);
                this.filterData.show = false;
                this.getPageData();
            }
        },
        async mounted() {

            this.getPageData();
            setTimeout(() => {
                this.$root.eventBus.$emit('changeMainTitle',{type: 'text', title: '首页'});
            }, 1200);

            this.$root.eventBus.$on('FILTER_EVENT', () => {
                this.filterData.show = true;
            });
        }
    }
</script>