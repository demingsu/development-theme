## 研发说明
1. 不允许私自升级element-ui
2. 所有路由导出采用异步(按需)
3. public/console.js 通用全局的数据都在此文件进行添加开发
4. 只用打包一次，以后每次请求的地址都在发布包的 js/console.js 修改对应的值（如：SYSTEM_BASE_URL)
5. token具体传递方法需要根据项目改进

## 浏览器兼容说明
1. 整体架构支持 >= IE10+;
2. 最佳体验 >= IE11+;

## WEB技术栈
1. 架构于 vue-cli4 + TS

## 项目环境安装与运行（因部分库引用国外服务器install时，建议使用cnpm）
1. 安装开发库：
 `拷贝开发库文件到开发项目中`
2. 安装依赖：(需要跳转到对应的项目文件路径，开发环境依赖node12.X LTS版本，需要安装)
 `cnpm install`
3. 运行项目：(运行前确保依赖安装完成且无失败项)
 `npm run start`
4. 打包发布命令：(发布规则为，只发布dist目录所有文件，nginx指向也指向文件所在目录)
 `npm run build`
5. 开发数据联调：(在进行数据联调的过程中，直接webpack devServer进行开发，前端起统一node服务通用配置数据开发)
 `注意请求字段替代或则后端统一配置起始字段`
6. cnpm 安装路径 
  `npm install -g cnpm --registry=https://registry.npm.taobao.org`

## 解决vuex刷新浏览器数据清空问题：在store index.js中引入vuex-persistedstate 

## 已集成socket.io.js