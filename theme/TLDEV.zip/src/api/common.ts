/*********************************************************************
 * Common ajax api
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/UrlConfig";

/**
 * 通过 params 以get方式获取数据
 * @param      key                 请求定义静态地址
 * @param      params              请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let getDataRequest = (key: string, params: any): Promise<any> => {
    console.log(new UrlConfig(key).currentUrl, key);
    return Ajax({
        url: new UrlConfig(key).currentUrl,
        params,
        data: params
    });
};

/**
 * 通过 data 以post方式获取数据
 * @param      key                 请求定义静态地址
 * @param      data                请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let postDataRequest = (key: string, data: any): Promise<any> => {
    return Ajax({
        url: new UrlConfig(key).currentUrl,
        data
    });
};

/**
 * 通过 data 以post方式获取数据
 * @param      key                 请求定义静态地址
 * @param      isFull              请求定义静态地址
 * @return     string              返回promise对象
 */
let getRequestPath = (key: string, isFull: boolean = false): string => {
    return isFull ? `${new UrlConfig(key).currentUrl}${new UrlConfig('BASE_URL').currentUrl}` : new UrlConfig(key).currentUrl;
};


export {
    getDataRequest,
    postDataRequest,
    getRequestPath
};