/*********************************************************************
 * Common ajax api
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import Ajax from "../util/request";
import UrlConfig from "../config/UrlConfig";

/**
 * 通过 params 以get方式获取数据
 * @param      key                 请求定义静态地址
 * @param      params              请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let getDataRequest = (key: string, params: any): Promise<any> => {
    return Ajax({
        url: new UrlConfig(key).currentUrl,
        params,
        data: params
    });
};

/**
 * 通过 params 以put方式获取数据
 * @param      key                 请求定义静态地址
 * @param      params                请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let putParamsRequest = (key: string, params: any): Promise<any> => {
    return Ajax({
        method: 'PUT',
        url: new UrlConfig(key).currentUrl,
        params
    });
};

/**
 * 通过 params 以delete方式获取数据
 * @param      key                 请求定义静态地址
 * @param      params                请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let deleteParamsRequest = (key: string, params: any): Promise<any> => {
    return Ajax({
        method: 'DELETE',
        url: new UrlConfig(key).currentUrl,
        params
    });
};

/**
 * 通过 params 以post方式获取数据
 * @param      key                 请求定义静态地址
 * @param      params                请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let postParamsRequest = (key: string, params: any): Promise<any> => {
    return Ajax({
        method: 'POST',
        url: new UrlConfig(key).currentUrl,
        params
    });
};

/**
 * 通过 data 以post方式获取数据
 * @param      key                 请求定义静态地址
 * @param      data                请求参数
 * @return     {Promise<*>}        返回promise对象
 */
let postDataRequest = (key: string, data: any): Promise<any> => {
    return Ajax({
        method: 'POST',
        url: new UrlConfig(key).currentUrl,
        data
    });
};

/**
 * 通过FormData以post方式提交文件并获取文件上传进度
 * @param      key                 请求定义静态地址
 * @param      data                请求参数
 * @param      onUploadProgress    上传进度
 * @return     {Promise<*>}        返回promise对象
 */
let postFileRequest = (key: string, data: any, onUploadProgress: any) => {
    return Ajax({
        method: 'POST',
        url: new UrlConfig(key).currentUrl,
        data,
        onUploadProgress
    });
};

/**
 * 通过 data 以post方式获取数据
 * @param      key                 请求定义静态地址
 * @param      isFull              请求定义静态地址
 * @return     string              返回promise对象
 */
let getRequestPath = (key: string, isFull: boolean = false): string => {
    return !isFull ? `${new UrlConfig('BASE_URL').currentUrl}${new UrlConfig(key).currentUrl}` : new UrlConfig(key).currentUrl;
};


export {
    getDataRequest,
    putParamsRequest,
    deleteParamsRequest,
    postParamsRequest,
    postDataRequest,
    postFileRequest,
    getRequestPath
};