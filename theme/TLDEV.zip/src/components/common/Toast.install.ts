/*********************************************************************
 * Toast file
 * Created by deming-su on 2017/12/30
 *********************************************************************/

import ToastComp from "./Toast.vue";
import {VueConstructor} from "vue";

const ToastNode = {
    install(Vue: VueConstructor) {
        let Constructor = Vue.extend(ToastComp),
            id: string = '';

        Vue.prototype.$zznode.testNode = {
            parentNode: null,
            toastNode: null,
            show(el: HTMLElement, time: number) {
                if (!!this.toastNode) this.close();
                this.parentNode = el;
                let p: HTMLElement = el.parentNode as HTMLElement,
                    pp: HTMLElement = p.parentNode as HTMLElement,
                    pr: ClientRect = p.getBoundingClientRect(),
                    rect: ClientRect = pp.getBoundingClientRect(),
                    isRight: boolean = (rect.left + rect.width - 100) < (pr.left + pr.width);
                let container = document.createElement('div');
                this.parentNode.appendChild(container);
                this.toastNode = new Constructor({
                    el: container,
                    propsData: {
                        msg: [{label: 'ewqeq', value: `current time: ${time}`}],
                        isRight
                    },
                    methods: {
                        test(evt: MouseEvent) {
                            let tar: HTMLElement = evt.target as HTMLElement;
                            if (tar.className.indexOf('test-class') > -1) return;
                            if ((tar.parentNode as HTMLElement).className.indexOf('test-class') > -1) return;
                            this.$destroy();
                            ((this.$el as HTMLElement).parentNode as HTMLElement).removeChild(this.$el);
                        }
                    },
                    mounted() {
                        document.addEventListener('click', this.test, true);
                    },
                    destroyed() {
                        document.removeEventListener('click', this.test, true);
                    }
                });
            },
            close() {
                if (!!this.toastNode) {
                    try {
                        this.toastNode.$destroy();
                        this.parentNode.removeChild(this.toastNode.$el);
                    } catch (e) {
                        console.log(e);
                    } finally {
                        this.toastNode = null;
                    }
                }
            }
        };
    }
};

export default ToastNode;
