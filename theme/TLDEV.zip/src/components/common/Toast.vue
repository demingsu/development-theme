/*********************************************************************
 * Created by deming-su on 2018/5/3
 *********************************************************************/
 

<template>
    <span class="test-class" :class="{right: isRight}">
        <span @click="$emit('testEvent', '')" v-for="item in msg">{{item.label}}: {{item.value}}</span>
    </span>
</template>
<script lang="ts">
    import {Vue, Component, Prop} from "vue-property-decorator";
    import {PopoverInf} from "common";

    @Component
    export default class Toast extends Vue {
        @Prop({required: true}) readonly msg: PopoverInf[];
        @Prop({required: true, type: Boolean}) readonly isRight: boolean;

        async mounted() {
            await this.$nextTick();
        }
    }
</script>
<style lang="less" scoped>
    .test-class {
        display: block;
        position: absolute;
        top: 0;
        right: -100px;
        min-height: 40px;
        width: 100px;
        background: #f00;
        &.right {
            right: 100px;
        }
    }
</style>
