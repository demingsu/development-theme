/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/06
*********************************************************************/

<template>
    <div id="commonListNode" class="common-list-layout">
        <div class="content">
            <header>
                <span class="title" v-html="breadTitle"></span>
                <slot name="header"></slot>
            </header>
            <section v-if="hasDetail">
                <slot name="detail"></slot>
            </section>
            <article v-else>
                <slot></slot>
            </article>
        </div>
        <div v-show="showTop" @click="goTopEvent" class="go-top">&#xe603;</div>
    </div>
</template>

<script lang="ts">
    import { Vue, Component, Prop } from "vue-property-decorator";

    @Component
    export default class ViewLayout extends Vue {
        private showTop: boolean = false;
        @Prop({default: '', required: true})
        private readonly title: string;

        get breadTitle(): string {
            let str: string[] = this.title.split('&&'),
                res: string = "";
            for (let s of str) {
                res += `<em>${s}</em>`;
            }
            return res;
        };

        get hasDetail() {
            return !!this.$slots.detail;
        }

        private scrollEvent(event: Event) {
            if (event.type === 'scroll') {
                this.showTop = (event.target as HTMLDivElement).scrollTop > 100;
            }
        }

        private goTopEvent() {
            let node: HTMLDivElement = document.getElementById('commonListNode') as HTMLDivElement;
            node.scrollTop = 0;
        }

        async mounted() {
            await this.$nextTick();
            let node: HTMLDivElement = document.getElementById('commonListNode') as HTMLDivElement;
            node.addEventListener('scroll', this.scrollEvent);
        }
    }
</script>