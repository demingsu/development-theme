/*********************************************************************
 * Vue components file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import ViewLayout from "./common/ViewLayout.vue";

export {
    ViewLayout
};