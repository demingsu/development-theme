/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

/* 页面启动路由，根据不同的环境启动不同的基础路由 */
let BASE_URL = "/api";
let nodeEnv = (process.env.NODE_ENV || '').trim();

switch (nodeEnv) {
    case 'production':
        BASE_URL = "http://10.221.139.197:8959";
        break;
    case 'ut':
        BASE_URL = "http://10.221.140.43:8959";
        break;
    case 'test':
        BASE_URL = "http://183.221.28.214:22859";
        break;
    default:
        BASE_URL = '/apis';
        break;
}

let obj: UrlKey[] = [],
    keys: any = {
        BASE_URL
    };

for (let name in keys) {
    if (keys.hasOwnProperty(name)) {
        obj.push({key: name, value: keys[name]});
    }
}

interface UrlKey {
    key: string;
    value: string;
}

class UrlConfig {
    private readonly nowKey: string;
    constructor(key: string) {
        this.nowKey = key;
    }
    get currentUrl(): string {
        let res: UrlKey = obj.find((it: UrlKey) => it.key === this.nowKey) || {key: '', value: ''};
        return res.value;
    }
}

/* 首页 ---end--- */
export default UrlConfig;