/*********************************************************************
 * defined const variable file
 * Created by deming-su on 2019/12/06
 *********************************************************************/
import {DetailBlockInf, DetailDataInf} from "common";

export const REQUEST_TIMEOUT: number = 15000;

const ORDER_BASE_INFO: DetailDataInf[] = [
    {label: '主题', key: '', value: '', state: '非常紧急&&danger', width: 3},
    {label: '工单号', key: '', value: '', width: 1},
    {label: '派单人', key: '', value: '', width: 1},
    {label: '联系方式', key: '', value: '', width: 1},
    {label: '派单部门', key: '', value: '', width: 1},
    {label: '派单时间', key: '', value: '', width: 1},
    {label: '处理时间', key: '', value: '', width: 1}
];

const ORDER_GROUP_INFO: DetailDataInf[] = [
    {label: '客户编号', key: '', value: '', width: 1},
    {label: '客户名称', key: '', value: '', width: 1},
    {label: '客户等级', key: '', value: '', width: 1},
    {label: '客户地址', key: '', value: '', width: 1},
    {label: '所属地方', key: '', value: '', width: 1},
    {label: '所属区县', key: '', value: '', width: 1},
    {label: '客户业务联系人', key: '', value: '', width: 1},
    {label: '联系人电话', key: '', value: '', width: 1},
    {label: '联系人邮箱', key: '', value: '', width: 1},
    {label: '客户经理', key: '', value: '', width: 1},
    {label: '客户经理电话', key: '', value: '', width: 1},
    {label: '客户经理邮箱', key: '', value: '', width: 1}
];

const ORDER_CUSTOMER_INFO: DetailDataInf[] = [
    {label: '用户编号', key: '', value: '', width: 1},
    {label: '用户名称', key: '', value: '', width: 2},
    {label: '接入地址', key: '', value: '', width: 1},
    {label: '接入地方', key: '', value: '', width: 1},
    {label: '所接入区县', key: '', value: '', width: 1},
    {label: '用户技术联系人', key: '', value: '', width: 1},
    {label: '联系人电话', key: '', value: '', width: 1},
    {label: '联系人邮箱', key: '', value: '', width: 1}
];

const ORDER_BUSINESS_INFO: DetailDataInf[] = [
    {label: 'CRM勘查单号', key: '', value: '', width: 1},
    {label: '产品实例标识', key: '', value: '', width: 1},
    {label: '产品类型', key: '', value: '', width: 1},
    {label: '业务保障等级', key: '', value: '', width: 1},
    {label: '带宽', key: '', value: '', width: 1},
];

export const ORDER_DETAIL_MAPPING: DetailBlockInf[] = [
    {
        title: '工单基本信息',
        data: ORDER_BASE_INFO
    },
    {
        title: '集团客户信息',
        data: ORDER_GROUP_INFO
    },
    {
        title: '用户基本信息',
        data: ORDER_CUSTOMER_INFO
    },
    {
        title: '业务受理信息',
        data: ORDER_BUSINESS_INFO
    }
];

export const FLOW_SEGMENT_TITLE: any[] = [
    {name: '集团客户部', width: 50/3},
    {name: '客户响应中心', width: 50/3},
    {name: '设计院', width: 50/3},
    {name: '施工单位', width: 100/2}
];

/**
 * state 的值有 info success danger
 */
export const FLOW_SEGMENT_BLOCK: any[] = [
    {id: 'ID01', label: ['工单派发'], row: 1, col: 1, state: 'success', isSE: true},
    {id: 'IDA0', label: ['A端审核'], row: 1, col: 2, state: 'success'},
    {id: 'IDA1', label: ['A端设计出图'], row: 1, col: 3, state: 'success'},
    {id: 'IDA2', label: ['A端物资领用'], row: 1, col: 4, state: 'success'},
    {id: 'IDA3', label: ['A端光缆施工'], row: 1, col: 5, state: 'success'},
    {id: 'IDA4', label: ['A端设备暗转加点'], row: 1, col: 6, state: 'success'},
    {id: 'IDA5', label: ['A端创建站点', 'A端创建站点'], row: 2, col: 3, state: 'success'},
    {id: 'IDA6', label: ['A端光缆资源接入'], row: 2, col: 5, state: 'success'},
    {id: 'IDA7', label: ['A端设备接入'], row: 2, col: 6, state: 'danger'},
    {id: 'IDA8', label: ['A端确认'], row: 6, col: 2, state: 'danger'},

    {id: 'IDB0', label: ['Z端审核'], row: 3, col: 2, state: 'success'},
    {id: 'IDB1', label: ['Z端设计出图'], row: 3, col: 3, state: 'info'},
    {id: 'IDB2', label: ['Z端物资领用'], row: 3, col: 4, state: 'info'},
    {id: 'IDB3', label: ['Z端光缆施工'], row: 3, col: 5, state: 'info'},
    {id: 'IDB4', label: ['Z端设备暗转加点'], row: 3, col: 6, state: 'info'},
    {id: 'IDB5', label: ['Z端创建站点'], row: 4, col: 3, state: 'info'},
    {id: 'IDB6', label: ['Z端光缆资源接入'], row: 4, col: 5, state: 'info'},
    {id: 'IDB7', label: ['Z端设备接入'], row: 4, col: 6, state: 'info'},
    {id: 'IDB8', label: ['Z端确认'], row: 5, col: 2, state: 'info'},

    {id: 'ID02', label: ['归档'], row: 6, col: 1, state: '', isSE: true}
];

export const FLOW_SEGMENT_LINE: any[] = [
    {from: 'ID01', to: 'IDA0', finish: ''},
    {from: 'ID01', to: 'IDB0', finish: ''},
    {from: 'IDA0', to: 'IDA1', finish: ''},
    {from: 'IDA0', to: 'IDA5', finish: '', type: 'dashed'},
    {from: 'IDA7', to: 'IDA8', finish: '', type: 'dashed'}
];