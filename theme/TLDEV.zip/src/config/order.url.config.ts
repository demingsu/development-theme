

/* 通用 ---start--- */

const LOGIN_URL = "/mock/form/config/list";

export {
    LOGIN_URL
};