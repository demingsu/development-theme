/*********************************************************************
* Static variable file
* Created by deming-su on 2019/11/13
*********************************************************************/

<template>
    <div class="authentication-node">

    </div>
</template>

<script lang="ts">
    import {Vue, Component} from "vue-property-decorator";
    import {Action} from "vuex-class";

    @Component
    export default class Authentication extends Vue {
        @Action('setApplicationToken', {namespace: 'common'})
        private changeToken: (token: string) => void;

        created() {

            let token: string = window.getRequestUrlParams('token') as string;
            if (!!token) {
                this.changeToken(token);
                this.$router.push("/home");
            } else {
                this.$router.push('/not/right');
            }
        }
    }
</script>
