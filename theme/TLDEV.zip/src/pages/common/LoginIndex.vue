/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/7
*********************************************************************/

<template>
    <div class="login-main-container" v-loading="pageLoading">
        <i class="title"></i>
        <div class="reg-box">
            <i class="t"></i>
            <el-row>
                <el-col :offset="1" :span="22">
                    <el-input size="small" v-model="loginName" placeholder="用户名"></el-input>
                </el-col>
                <el-col :offset="1" :span="22">
                    <el-input size="small" v-model="loginPwd" placeholder="密码"></el-input>
                </el-col>
                <el-col :offset="1" :span="12">
                    <el-input size="small" v-model="loginCode" placeholder="请输入验证码"></el-input>
                </el-col>
                <el-col :offset="1" :span="9">
                    <img @click="changeCode" src="../../images/login/login-code.png" alt="">
                </el-col>
                <el-col :offset="1" :span="22">
                    <el-checkbox v-model="loginRemember">记住密码</el-checkbox>
                </el-col>
                <el-col :offset="1" :span="22">
                    <div @click="loginEvent" class="login-btn">登录</div>
                </el-col>
            </el-row>
        </div>
        <i class="illustration"></i>
        <span class="role">系统热线电话：010-99999999       北京直真科技股份有限公司提供技术支持</span>
    </div>
</template>

<script lang="ts">
    import {Vue, Component} from "vue-property-decorator";
    import {postDataRequest} from "@/api/common";
    import {Action, Getter} from "vuex-class";
    import {CommonResult, CommonVuex} from "common";

    @Component
    export default class LoginIndex extends Vue {
        private pageLoading: boolean = false;
        private loginName: string = "";
        private loginPwd: string = "";
        private loginCode: string = "";
        private loginRemember: boolean = false;
        @Action('setLoginUserInfo', {namespace: 'common'})
        private cacheUserInfo: (data: CommonVuex) => void;

        @Action('setApplicationToken', {namespace: 'common'})
        private cacheToken: (data: CommonVuex) => void;

        @Getter("getApplicationToken", {namespace: 'common'})
        private currentToken: string;

        private async loginEvent() {
            if (!this.loginName.trim()) {
                this.$message.warning('请输入用户名');
                return;
            }

            if (!this.loginPwd.trim()) {
                this.$message.warning('请输入登录密码');
                return;
            }

            if (!this.loginCode.trim()) {
                this.$message.warning('请输入验证码');
                return;
            }

            this.pageLoading = true;
            let result: CommonResult = await postDataRequest('LOGIN_URL', {name: this.loginName, code: this.loginCode, pwd: this.loginPwd});
            this.pageLoading = false;

            /* TODO TEST DATA */
            result = {
                code: 200,
                description: '',
                data: {
                    userName: '张三',
                    token: window.btoa('user-login-test-data-of-token')
                }
            };

            if (!!result && result.code === 200) {
                if (this.loginRemember) {
                    localStorage.setItem("USER_LOGIN_INFO_CACHE", window.btoa(JSON.stringify({loginName: this.loginName, loginPwd: this.loginPwd})));
                }

                this.cacheUserInfo({loginUserInfo: result.data});
                this.cacheToken({applicationToken: result.data.token || ''});
                this.$message.success("登录成功");
                this.$router.push('/desktop');
            } else {
                this.$message.error(`登录错误，错误信息：${result.description}`);
            }
        }

        private async changeCode() {
            // TODO get new validate code image
        }

        created() {
            let cache: string = localStorage.getItem('USER_LOGIN_INFO_CACHE') as string;
            if (!!cache) {
                try {
                    let obj = JSON.parse(window.atob(cache));
                    this.loginName = obj.loginName || '';
                    this.loginPwd = obj.loginPwd || '';
                    this.loginRemember = true;
                } catch (e) {
                    console.log(e);
                }
            }
        }
    }
</script>