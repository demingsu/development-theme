<template>
    <div class="order-detail-info-container" :id="nodeId">
        <slot></slot>
    </div>
</template>

<script lang="ts">
    import {Vue, Component, Prop, PropSync, Watch} from "vue-property-decorator";

    @Component
    export default class ContainerNode extends Vue {
        @Prop({required: true}) readonly nodeId: string;
        @PropSync("show", {required: true}) readonly blockShow!: boolean;
        @Watch('blockShow', {immediate: true})
        private onShowChange(val: boolean) {
            let node: HTMLDivElement = document.getElementById(this.nodeId) as HTMLDivElement;
            if (!!node) {
                let tab = ((node.parentNode as HTMLDivElement).querySelector('div.el-tabs') as HTMLDivElement).getBoundingClientRect();
                if (val) {
                    node.setAttribute('style', `width: ${tab.width || 100}px; height: ${node.scrollHeight}px; opacity: 1;`);
                    setTimeout(() => {
                        node.setAttribute('style', `width: 100%; height: auto; opacity: 1;`);
                    }, 300);
                } else {
                    node.setAttribute('style', ``);
                }
            }
        }
    }
</script>