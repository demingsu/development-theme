/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <router-view></router-view>
</template>

<script lang="ts">
    import {Vue, Component} from "vue-property-decorator";

    @Component
    export default class Index extends Vue {
        created() {
            // todo something here
        }
    }
</script>