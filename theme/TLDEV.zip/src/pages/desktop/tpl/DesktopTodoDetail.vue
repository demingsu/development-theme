/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <view-layout title="工作台&&待办工单&&工单信息">
        <el-tabs v-model="tabKey" @tab-click="tabChangeEvent">
            <el-tab-pane v-for="item in tabList"
                         :label="item.label"
                         :name="item.key"
                         :key="`TAB_KEY_${item.key}`"></el-tab-pane>
        </el-tabs>
        <base-info :show="tabKey === 'base'" :order-id="orderId"></base-info>
        <process-info :show="tabKey === 'process'" :order-id="orderId"></process-info>
        <archive-list :show="tabKey === 'archive'" :order-id="orderId"></archive-list>
        <progress-info :show="tabKey === 'progress'" :order-id="orderId"></progress-info>
    </view-layout>
</template>

<script lang="ts">
    import {Vue, Component} from "vue-property-decorator";
    import BaseInfo from "@/pages/template/BaseInfo.vue";
    import ProcessInfo from "@/pages/template/ProcessInfo.vue";
    import ArchiveList from "@/pages/template/ArchiveList.vue";
    import ProgressInfo from "@/pages/template/ProgressInfo.vue";
    interface TabKeyInf {
        label: string;
        key: string;
    };

    @Component({
        components: { BaseInfo, ProcessInfo, ArchiveList, ProgressInfo }
    })
    export default class DesktopDetail extends Vue {
        private orderId: string = "";
        private tabKey: string = "";
        private tabList: TabKeyInf[] = [
            {label: '基本信息', key: 'base'},
            {label: '工单过程', key: 'process'},
            {label: '附件列表', key: 'archive'},
            {label: '流程图', key: 'progress'}
        ];

        private tabChangeEvent() {
            console.log(this.tabKey, '===============================');
        }

        async mounted() {
            await this.$nextTick();
            this.orderId = this.$route.query.orderId as string;
            this.tabKey = "base";
        }
    }
</script>
