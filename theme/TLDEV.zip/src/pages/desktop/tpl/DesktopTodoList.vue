/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <view-layout title="工作台&&待办工单">
        <el-form size="small">
            <el-row :gutter="16">
                <el-col :span="6">
                    <el-form-item label="工单编号" label-width="80px">
                        <el-input v-model="queryForm.orderCode"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="工单标题" label-width="80px">
                        <el-input v-model="queryForm.orderTitle"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="业务类型" label-width="80px">
                        <el-select v-model="queryForm.businessType" placeholder="请选择业务类型">
                            <el-option label="全部" value=""></el-option>
                            <el-option label="专线" value="special"></el-option>
                            <el-option label="企宽" value="company"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="工单类型" label-width="80px">
                        <el-select v-model="queryForm.orderType" placeholder="请选择工单类型">
                            <el-option v-for="item in orderType" :label="item.label" :value="item.value" :key="`order_type_${item.value}`"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="建单时间" label-width="80px">
                        <div @click="queryForm.orderTime = 'today'" :class="['order-radio-button', {active: queryForm.orderTime === 'today'}]">今天</div>
                        <div @click="queryForm.orderTime = 'three'" :class="['order-radio-button', {active: queryForm.orderTime === 'three'}]">3天内</div>
                        <div @click="queryForm.orderTime = 'week'" :class="['order-radio-button', {active: queryForm.orderTime === 'week'}]">本周</div>
                        <div @click="queryForm.orderTime = 'month'" :class="['order-radio-button', {active: queryForm.orderTime === 'month'}]">本月</div>
                        <el-checkbox style="margin-left: 30px;" v-model="queryForm.collection" label="1">我的收藏</el-checkbox>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="" style="text-align: right">
                        <el-button @click="getTableData" type="primary">查询</el-button>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <el-alert size="small" :title="`共搜索到 ${pagingData.total} 条数据`" type="success" :closable="false"></el-alert>
        <el-table v-loading="tableData.loading" :data="tableData.data" class="order-table-list" stripe style="width: 100%">
            <el-table-column align="center" label="" width="60">
                <template slot-scope="scope">
                    <i class="order-collection-icon"
                       @click="collectionEvent(scope.row)"
                       v-html="scope.row.state ? '&#xe611;' : '&#xe610;'"
                       :class="{active: scope.row.state}"></i>
                </template>
            </el-table-column>
            <el-table-column align="center" prop="code" label="工单编号" min-width="120"></el-table-column>
            <el-table-column align="center" prop="title" label="工单标题" min-width="180"></el-table-column>
            <el-table-column align="center" prop="btype" label="业务类型" width="100"></el-table-column>
            <el-table-column align="center" prop="otype" label="工单类型" width="100"></el-table-column>
            <el-table-column align="center" prop="stime" label="建单时间" width="160"></el-table-column>
            <el-table-column align="center" prop="ftime" label="处理时限" width="160"></el-table-column>
            <el-table-column align="center" prop="process" label="当前环节" width="110"></el-table-column>
            <el-table-column align="center" prop="area" label="区域" width="180"></el-table-column>
            <el-table-column align="center" label="操作" width="60">
                <template slot-scope="scope">
                    <span @click="operateEvent(scope.row)" class="common-table-cell link">审批</span>
                </template>
            </el-table-column>
        </el-table>
        <el-pagination background
                       @size-change="pagingEvent($event, 'size')"
                       @current-change="pagingEvent"
                       layout="prev, pager, next, sizes, jumper"
                       :total="pagingData.total"
                       :page-sizes="pagingData.sizes"
                       :page-size="pagingData.size"
                       :current-page="pagingData.current"></el-pagination>
    </view-layout>
</template>

<script lang="ts">
    import {Component, Watch} from "vue-property-decorator";
    import BaseView from "@/pages/BaseView.vue";
    import {CommonResult, TableData} from "common";

    @Component
    export default class DesktopList extends BaseView {
        protected tableData: TableData = {
            data: [],
            column: [],
            loading: false
        };
        private queryForm: any = {
            orderCode: '',
            orderTitle: '',
            businessType: '',
            orderType: '',
            collection: false,
            orderTime: 'month'
        } as any;
        private orderType: any[] = [];
        private orderTypes: any = {
            "": [{label: '全部', value: ''}, {label: '勘察', value: 'a'}, {label: '建设', value: 'b'}, {label: '开通', value: 'c'}],
            "special": [{label: '全部', value: ''}, {label: '勘察', value: 'a'}, {label: '建设', value: 'b'}],
            "company": [{label: '全部', value: ''}, {label: '勘察', value: 'a'}, {label: '开通', value: 'c'}]
        };
        @Watch('queryForm.businessType', {immediate: true})
        private onBusinessChange(val: string) {
            this.orderType = this.orderTypes[val];
        }

        protected async getTableData() {

            this.tableData.loading = true;

            let result: CommonResult = {
                code: 200,
                description: '',
                data: []
            };

            setTimeout(() => {
                for (let i = 0;i < this.pagingData.size;i ++) {
                    result.data.push({id: `ID-LIST-${i}`, state: i % 5 === 0, code: 'TradeCode21', title: '工单名称0001', btype: '专线',
                        otype: '开通', stime: '2019-09-09 12:12:12', ftime: '2019-09-09 12:12:12', process: '设计出图', area: '鄂尔多斯'});
                }
                this.tableData.data = !!result && result.code === 200 ? result.data : [];
                this.tableData.loading = false;
            }, 500);
        }

        private collectionEvent(row: any) {
            this.tableData.data.map((it: any) => {
                if (it.id === row.id) it.state = !it.state;
            });
        }

        private operateEvent(row: any) {
            this.$router.push({path: '/desktop/todo-detail', query: {orderId: window.btoa(row.id || '')}});
        }

        created() {
            this.getTableData();
        }
    }
</script>