<script lang="tsx">
    import {Vue, Component} from "vue-property-decorator";

    @Component
    export default class JsxView extends Vue {

        render() {

            return (
                <ul>
                    {this.makeList()}
                </ul>
            );
        }

        private makeList() {

            let list = [];
            for (let i = 0;i < 10;i ++) {
                list.push(<li>SEQ: {i}</li>)
            }

            return list;
        }

        async created() {
            
        }
    }
</script>
