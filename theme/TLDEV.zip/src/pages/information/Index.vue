/*********************************************************************
 * Information view file
 * Created by deming-su on 2019/12/9
 *********************************************************************/

<template>
    <view-layout v-loading="tableData.loading" title="消息管理">
        <el-tabs v-model="tabKey">
            <el-tab-pane v-for="item in tabList"
                         :label="`${item.label} (${item.value})`"
                         :name="item.key"
                         :key="`TAB_KEY_${item.key}`"></el-tab-pane>
        </el-tabs>

        <div class="order-information-operate">
            <el-button size="mini" plain>全部标为已读</el-button>
            <el-button size="mini" plain>清空全部消息</el-button>
        </div>

        <div class="order-information-container">
            <div class="row" v-for="(item,i) in tableData.data" :key="`table_key_${i}`">
                <i :class="['icon', {warning: tabKey === 'urge'}]">&#xe606;</i>
                <div class="text">
                    <span class="t">{{item.info}}</span>
                    <span class="s">{{item.time}}</span>
                </div>
                <span class="link">查看详情</span>
                <span :class="['state', {waring: item.read}]"></span>
                <div class="opt">
                    <el-button size="mini" plain>删除</el-button>
                </div>
            </div>
        </div>

        <el-pagination background
                       @size-change="pagingEvent($event, 'size')"
                       @current-change="pagingEvent"
                       layout="prev, pager, next, sizes, jumper"
                       :total="pagingData.total"
                       :page-sizes="pagingData.sizes"
                       :page-size="pagingData.size"
                       :current-page="pagingData.current"></el-pagination>
    </view-layout>
</template>

<script lang="ts">
    import {Component, Watch} from "vue-property-decorator";
    import BaseView from "@/pages/BaseView.vue";
    import {CommonResult, TableData} from "common";
    interface TabKeyInf {
        label: string;
        key: string;
        value: number;
    };

    @Component
    export default class DesktopDetail extends BaseView {
        protected tableData: TableData = {
            data: [],
            loading: false
        };
        private tabKey: string = "urge";
        private tabList: TabKeyInf[] = [
            {label: '催办信息', key: 'urge', value: 0},
            {label: '代办信息', key: 'schema', value: 0}
        ];

        @Watch('tabKey')
        private onTabKeyChange() {

            this.getTableData();
        }

        private async getStatisticsData() {

            let result: CommonResult = {
                code: 200,
                description: '',
                data: {
                    urgeTotal: 10,
                    schemaTotal: 20
                }
            };

            this.tabList[0].value = !!result && result.code === 200 ? result.data.urgeTotal : 0;
            this.tabList[1].value = !!result && result.code === 200 ? result.data.schemaTotal : 0;

            this.getTableData();
        }

        protected async getTableData() {

            this.tableData.loading = true;
            let result: CommonResult = {
                code: 200,
                description: '',
                data: {
                    total: 111,
                    rows: []
                }
            };

            setTimeout(() => {
                for (let i = 0;i < this.pagingData.size;i ++) {
                    result.data.rows.push({
                        info: '工单NM-234324324-23432已超时，请及时处理！',
                        time: '2019-12-06 12:00:00',
                        read: i % 3
                    });
                }
                this.tableData.data = result.data.rows;
                this.pagingData.total = result.data.total;
                this.tableData.loading = false;
            }, 500);
        }

        async mounted() {
            await this.$nextTick();
            this.getStatisticsData();
        }
    }
</script>