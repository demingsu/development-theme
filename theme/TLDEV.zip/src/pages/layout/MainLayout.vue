/*********************************************************************
 * Vue private main layout file
 * Created by deming-su on 2019/12/06
 * 菜单太多处理逻辑了，不想处理，全部是写死的，如果要跳转，请重写方法或则组件
 *********************************************************************/

<template>
    <div class="application-container main" :class="{collapse: collapseState}">
        <!-- 导航区域 -->
        <div class="navigator">
            <div class="brand">
                <i class="icon">&#xe600;</i>
                政企业务甩单支撑系统
            </div>
            <el-popover popper-class="common-popover-theme" placement="bottom" width="200" trigger="click">
                <ul class="navigator-user-info-box">
                    <li class="p m">部门：客户响应中心</li>
                    <li class="p">角色：项目经理</li>
                    <li class="m">
                        <span @click="pwdShow = true" class="b">&#xe616; 修改密码</span>
                        <span @click="logoutEvent">&#xe618; 退出登录</span>
                    </li>
                </ul>
                <i class="icons" slot="reference"><i></i> <em>{{userInfo.userName}}</em></i>
            </el-popover>
            <el-popover popper-class="common-popover-theme" placement="bottom" width="300" trigger="click">
                <div class="navigator-information-list-box">
                    <span class="tab">
                        <span @click="infoTabKey = '1'" :class="{active: infoTabKey === '1'}">催办消息 ({{infoTabData.oneList.length}})</span>
                        <span @click="infoTabKey = '2'" :class="{active: infoTabKey === '2'}">代办消息 ({{infoTabData.twoList.length}})</span>
                    </span>
                    <div class="info-content" :style="{left: `${infoTabKey === '1' ? 0 : -100}%`}">
                        <ul class="list-box">
                            <li v-for="(item,i) in infoTabData.oneList" :key="`info_one_key_${i}`">
                                <span>{{item.info}}</span>
                                <span>{{item.time}}</span>
                            </li>
                        </ul>
                        <ul class="list-box">
                            <li v-for="(item,i) in infoTabData.twoList" class="s" :key="`info_two_key_${i}`">
                                <span>{{item.info}}</span>
                                <span>{{item.time}}</span>
                            </li>
                        </ul>
                    </div>
                    <span class="clear-btn">&#xe619; 清空通知</span>
                </div>
                <i class="icons info" :class="{active: infoTabData.oneList.length > 0 || infoTabData.twoList.length > 0}" slot="reference">&#xe608;</i>
            </el-popover>

        </div>
        <!-- 菜单区域 -->
        <div class="menu">
            <div @click="collapseEvent" class="expand"></div>
            <div class="menu-container-box">
                <div class="item">
                    <span class="label">
                        <i class="icon">&#xe602;</i>
                        <span class="text">工作台</span>
                        <i id="expandNode" @click="expandEvent" class="more"></i>
                    </span>
                    <div class="item-box">
                        <div class="item">
                            <span class="label" :class="{active: currentPathKey === 'todo'}">
                                <span @click="menuEvent('/desktop/todo-list')" class="text">代办工单</span>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label" :class="{active: currentPathKey === 'done'}">
                                <span @click="menuEvent('/desktop/done-list')" class="text">已办工单</span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="item">
                    <span class="label" :class="{active: currentPathKey === 'query'}">
                        <i @click="menuEvent('/query', 'icon')" class="icon">&#xe604;</i>
                        <span @click="menuEvent('/query')" class="text">工单综合查询</span>
                    </span>
                </div>
                <div class="item">
                    <span class="label" :class="{active: currentPathKey === 'statistics'}">
                        <i @click="menuEvent('/statistics', 'icon')" class="icon">&#xe601;</i>
                        <span @click="menuEvent('/statistics')" class="text">工单统计报表</span>
                    </span>
                </div>
                <div class="item">
                    <span class="label" :class="{active: currentPathKey === 'information'}">
                        <i @click="menuEvent('/information', 'icon')" class="icon">&#xe605;</i>
                        <span @click="menuEvent('/information')" class="text">消息管理</span>
                    </span>
                </div>
            </div>
        </div>
        <!-- 内容区域 -->
        <div class="view">
            <router-view></router-view>
        </div>

        <el-dialog title="修改密码"
                   :append-to-body="true"
                   :close-on-click-modal="false"
                   :show-close="false"
                   :visible.sync="pwdShow"
                   width="600px">
            <el-form :model="pwdData" :rules="pwdRule">
                <el-form-item label="原密码" prop="sourcePwd">
                    <el-input v-model="pwdData.sourcePwd"></el-input>
                </el-form-item>
                <el-form-item label="新密码" prop="currentPwd">
                    <el-input v-model="pwdData.currentPwd"></el-input>
                </el-form-item>
                <el-form-item label="确认密码" prop="confirmPwd">
                    <el-input v-model="pwdData.confirmPwd"></el-input>
                </el-form-item>
                <el-form-item style="text-align: center;">
                    <el-button size="small" type="primary" @click="pwdShow = false">确认</el-button>
                    <el-button size="small" plain @click="pwdShow = false">取消</el-button>
                </el-form-item>
            </el-form>
        </el-dialog>
    </div>
</template>

<script lang="ts">
    import { Component, Vue, Watch } from "vue-property-decorator";
    import { Action, Getter } from "vuex-class";

    @Component
    export default class MainLayout extends Vue {
        private pwdShow: boolean = false;
        private collapseState: boolean = false;
        private pathKeyMapping: any[] = [
            {'todo': '/desktop/todo-list&&/desktop/todo-detail'},
            {'done': '/desktop/done-list&&/desktop/done-detail'},
            {'query': '/query'},
            {'statistics': '/statistics'},
            {'information': '/information'}
        ];
        private currentPathKey: string = '';

        private pwdData = {
            sourcePwd: "",
            currentPwd: "",
            confirmPwd: ""
        };
        private pwdRule = {
            sourcePwd: [{required: true, message: '请输入原密码', trigger: 'blur'}],
            currentPwd: [{required: true, message: '请输入新密码', trigger: 'blur'}],
            confirmPwd: [{validator: this.confirmValidator, trigger: 'blur'}]
        };

        private infoTabKey: string = "1";
        private infoTabData = {
            oneList: [
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'}
            ],
            twoList: [
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'},
                {info: '工单NM-234324324-23432已超时，请及时处理！', time: '2019-12-06 12:00:00'}
            ]
        };

        @Action('resetCommonVuexData', {namespace: 'common'})
        private resetVuex: () => void;
        @Getter("getLoginUserInfo", {namespace: 'common'}) readonly userInfo: any;
        // @Watch('$route.path', {immediate: true}) 因为需要展开节点，所以不能用这个方法
        @Watch('$route.path')
        private onRouteChange(val: string) {
            this.resetMenuState(val);
        }

        async mounted() {
            await this.$nextTick();
            let val: string = this.resetMenuState(this.$route.path);
            if (val === 'todo') (document.getElementById('expandNode') as HTMLElement).click();

            // this.registerSocket();
        }

        private resetMenuState(val: string): string {
            let key: string = "";
            for (let item of this.pathKeyMapping) {
                let names = Object.keys(item),
                    keys: string[] = item[names[0]].split('&&'),
                    hasKeys: boolean = !!(keys.find((oo: string) => oo.startsWith(val)));
                if (hasKeys) {
                    key = this.currentPathKey = names[0];
                    break;
                }
            }
            return key;
        }

        /* 代码全部是写死的，要改需要修改方法 */
        private expandEvent(event: MouseEvent) {
            let tarNode: HTMLElement = event.target as HTMLElement,
                tarClass: string = tarNode.className,
                hasExpand: boolean = tarClass.indexOf('expand') > -1,
                labelNode: HTMLSpanElement = tarNode.parentNode as HTMLSpanElement,
                parentNode: HTMLElement = labelNode.parentNode as HTMLElement,
                labelRect: ClientRect = labelNode.getBoundingClientRect(),
                boxNode: HTMLElement = parentNode.querySelector("div.item-box") as HTMLElement;
            tarNode.setAttribute('class', hasExpand ? 'more' : 'more expand');
            boxNode.setAttribute('style', `height: ${labelRect.height * 2}px;`);
            parentNode.setAttribute('style', `height: ${labelRect.height * 3}px;`);
            if (hasExpand) {
                setTimeout(() => {
                    boxNode.setAttribute('style', '');
                    parentNode.setAttribute('style', '');
                });
            } else {
                setTimeout(() => {
                    boxNode.setAttribute('style', 'height: auto;');
                    parentNode.setAttribute('style', 'height: auto;');
                }, 300);
            }
        }

        private menuEvent(path: string, icon?: string) {
            if (!icon) {
                this.$router.push({path});
            } else {
                if (icon === 'icon' && this.collapseState) this.$router.push({path});
            }

        }

        private collapseEvent() {
            this.collapseState = !this.collapseState;
        }

        private confirmValidator(rule: any, value: string, cb: (data?: Error) => void) {
            if (value.trim() === '') {
                cb(new Error('请输入确认密码'));
            } else if (value !== this.pwdData.currentPwd) {
                cb(new Error('两次输入的密码不一致'));
            } else {
                cb();
            }
        }

        private logoutEvent() {
            this.resetVuex();
            let cache: string = localStorage.getItem('USER_LOGIN_INFO_CACHE') as string;
            localStorage.clear();
            if (!!cache) {
                localStorage.setItem('USER_LOGIN_INFO_CACHE', cache);
            }
            this.$router.push({path: "/login"});
        }

        private registerSocket() {
            let socket: any = io.connect('http://localhost:16000');
            socket.on('message', (data: any) => {
                console.log(data);
            });
            socket.on('connection', (data: any) => {
                console.log(data);
            });

            socket.emit('message', {fd: 13221});

            setTimeout(() => {
                socket.emit('message', {fd: "fdjskfjdsjlkfjldsjflkdsjlkfjldsjflsdkj"});
                socket.close();

                setTimeout(() => {
                    socket.open();
                    socket.emit('message', {fd: "房贷首付绝对是"});
                }, 2000);
            }, 2600);
        }
    };
</script>
