/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <view-layout title="工单统计报表">
        <el-form size="small">
            <el-row :gutter="16">
                <el-col :span="6">
                    <el-form-item label="统计粒度" label-width="80px">
                        <el-select v-model="queryForm.granularity" placeholder="请选择统计粒度">
                            <el-option label="日" value="date"></el-option>
                            <el-option label="周" value="week"></el-option>
                            <el-option label="月" value="month"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="工单标题" label-width="80px">
                        <el-date-picker v-model="queryForm.time"
                                        :type="queryForm.granularity"
                                        format="yyyy-MM-dd"
                                        :placeholder="`选择${queryForm.granularity === 'date' ? '日' : queryForm.granularity === 'week' ? '周' : '年'}`">
                        </el-date-picker>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="业务类型" label-width="80px">
                        <el-select v-model="queryForm.businessType" placeholder="请选择业务类型">
                            <el-option label="全部" value=""></el-option>
                            <el-option label="专线" value="special"></el-option>
                            <el-option label="企宽" value="company"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="工单类型" label-width="80px">
                        <el-select v-model="queryForm.orderType" placeholder="请选择工单类型">
                            <el-option v-for="item in orderType" :label="item.label" :value="item.value" :key="`order_type_${item.value}`"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="区域" label-width="80px">
                        <el-select v-model="queryForm.city" placeholder="请选择区域">
                            <el-option label="全区" value=""></el-option>
                            <el-option label="呼和浩特" value="呼和浩特"></el-option>
                            <el-option label="呼伦贝尔" value="呼伦贝尔"></el-option>
                            <el-option label="阿拉善" value="阿拉善"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="" style="text-align: right">
                        <el-button @click="getTableData" type="primary">查询</el-button>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
        <el-alert size="small" :title="`共搜索到 ${pagingData.total} 条数据`" type="success" :closable="false"></el-alert>
        <el-table v-loading="tableData.loading" :data="tableData.data" class="order-table-list" stripe style="width: 100%">
            <el-table-column align="center" prop="city" label="区域" min-width="100"></el-table-column>
            <el-table-column align="center" prop="type" label="业务类型" min-width="100"></el-table-column>
            <el-table-column align="center" prop="oType" label="工单类型" min-width="100"></el-table-column>
            <el-table-column align="center" prop="amount" label="工单量" min-width="100"></el-table-column>
            <el-table-column align="center" prop="time" label="平均处理时长(天)" min-width="100"></el-table-column>
        </el-table>
    </view-layout>
</template>

<script lang="ts">
    import {Component, Watch} from "vue-property-decorator";
    import BaseView from "@/pages/BaseView.vue";
    import {CommonResult, TableData} from "common";

    @Component
    export default class DesktopList extends BaseView {
        protected tableData: TableData = {
            data: [],
            column: [],
            loading: false
        };
        private queryForm: any = {
            granularity: 'date',
            time: '',
            businessType: '',
            orderType: '',
            city: ''
        } as any;
        private orderType: any[] = [];
        private orderTypes: any = {
            "": [{label: '全部', value: ''}, {label: '勘察', value: 'a'}, {label: '建设', value: 'b'}, {label: '开通', value: 'c'}],
            "special": [{label: '全部', value: ''}, {label: '勘察', value: 'a'}, {label: '建设', value: 'b'}],
            "company": [{label: '全部', value: ''}, {label: '勘察', value: 'a'}, {label: '开通', value: 'c'}]
        };
        @Watch('queryForm.businessType', {immediate: true})
        private onBusinessChange(val: string) {
            this.orderType = this.orderTypes[val];
        }
        @Watch('queryForm.granularity', {immediate: true})
        private onTimeChange() {
            this.queryForm.time = '';
        }

        protected async getTableData() {

            this.tableData.loading = true;
            if (this.queryForm.granularity === 'week' && !!this.queryForm.time) {
                let date: Date = this.queryForm.time,
                    day: number = date.getDay(),
                    time: number = 24 * 60 * 60 * 1000;

                let first = new Date(date.getTime() - (day - 1) * time),
                    last = new Date(date.getTime() + (7 - day) * time);
                console.log(first, last);
            }

            let result: CommonResult = {
                code: 200,
                description: '',
                data: []
            };

            setTimeout(() => {
                for (let i = 0;i < this.pagingData.size;i ++) {
                    result.data.push({id: `ID-LIST-${i}`, city: '呼和浩特市', type: '专线', oType: '勘察',
                        amount: Math.ceil(Math.random() * 1000), time: Math.ceil(Math.random() * 10)});
                }
                this.tableData.data = !!result && result.code === 200 ? result.data : [];
                this.tableData.loading = false;
            }, 500);
        }

        private collectionEvent(row: any) {
            this.tableData.data.map((it: any) => {
                if (it.id === row.id) it.state = !it.state;
            });
        }

        private operateEvent(row: any) {
            this.$router.push({path: '/desktop/done-detail', query: {orderId: window.btoa(row.id || '')}});
        }

        created() {
            this.getTableData();
        }
    }
</script>