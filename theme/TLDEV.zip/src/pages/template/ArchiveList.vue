/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <container-node :show="show" v-loading="pageLoading" node-id="archive-list-container-node">
        <div class="order-archive-list-container">
            <div class="archive-item" v-for="(item,i) in archiveData" :key="`archive_key_${i}`">
                <div class="title">
                    <div class="picker"><el-checkbox v-model="item.active" @change="pikerChange($event, i)"></el-checkbox></div>
                    <i class="icon">&#xe60c;</i>
                    <span class="text b">环节：{{item.processName}}（{{item.data.length}}个）</span>
                    <i @click="downloadEvent('all', i)" class="link b">批量下载</i>
                    <i @click="expandEvent(i)" :class="['expand-icon', {active: item.expand}]">&#xe60e;</i>
                </div>
                <div class="archive-list" :style="{height: `${item.expand ? item.data.length * 47 : 0}px`}">
                    <div class="item" v-for="(info,k) in item.data" :key="`archive_key_${i}_${k}`">
                        <i class="picker"><el-checkbox v-model="info.active" @change="pikerChange($event, i, k)"></el-checkbox></i>
                        <span class="text">{{info.fileName}}</span>
                        <i @click="downloadEvent('per', i, k)" class="link">&#xe613;</i>
                        <span class="info">{{info.description}}</span>
                    </div>
                </div>
            </div>
        </div>
    </container-node>
</template>

<script lang="ts">
    import {Vue, Component, Prop, Watch} from "vue-property-decorator";
    import ContainerNode from "@/pages/template/common/ContainerNode.vue";
    import {CommonResult} from "common";

    @Component({
        components: {ContainerNode}
    })
    export default class ArchiveList extends Vue {
        private pageLoading: boolean = false;
        private archiveData: any[] = [];

        @Prop({required: true}) readonly orderId: string;
        @Prop({required: true}) readonly show: boolean;
        @Watch("show", {immediate: true})
        private onShowChange(val: boolean) {
            if (val) {
                this.pageLoading = true;
                setTimeout(() => {
                    this.getArchiveList();
                }, 300);
            }
        }

        private async getArchiveList() {

            let result: CommonResult = {
                code: 200,
                description: '',
                data: [
                    {}
                ]
            };

            setTimeout(() => {
                this.archiveData = [
                    {processName: '设计出图', expand: true, active: false, data: [
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'}
                        ]},
                    {processName: '设计出图', expand: false, active: false, data: [
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'}
                        ]},
                    {processName: '设计出图', expand: false, active: false, data: [
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'}
                        ]},
                    {processName: '设计出图', expand: false, active: false, data: [
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'},
                            {active: false, fileName: '测试文档测试文档测试文档测试文档.doc', description: '张三上传于2018-09-10 12:30:10'}
                        ]}
                ];

                this.pageLoading = false;
            }, 500);
        }

        private pikerChange(val: boolean, i: number, k: number = -1) {
            let data: any[] = this.archiveData[i].data;
            if (k > -1) {
                let hasUnpick: boolean = data.findIndex((oo: any) => !oo.active) > -1;
                this.archiveData[i].active = !hasUnpick;
            } else {
                data.map((it: any) => it.active = val);
            }
        }

        private expandEvent(index: number) {
            this.archiveData[index].expand = !this.archiveData[index].expand;
        }

        private downloadEvent(type: string, i: number, k: number = -1) {
            console.log(type, i, k, "downloadEvent");
        }
    }
</script>