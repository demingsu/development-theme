/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
* 通用信息设置，每个环节根据当前信息的环节展示不同的表单
*********************************************************************/

<template>
    <common-info v-show="show" :show="show" v-loading="pageLoading" :detailConfig="detailConfig">
        <!-- 审批环节 -->
        <approve-segment v-if="segmentType === 'approve'"></approve-segment>
    </common-info>
</template>

<script lang="ts">
    import {Vue, Component, Prop, Watch} from "vue-property-decorator";
    import {CommonResult, DetailBlockInf} from "common";
    import {ORDER_DETAIL_MAPPING} from "@/config/common.config";

    import CommonInfo from "./common/CommonInfo.vue";
    import ApproveSegment from "./segment/ApproveSegment.vue";

    @Component({
        components: {CommonInfo, ApproveSegment}
    })
    export default class BaseInfo extends Vue {
        @Prop({required: true}) readonly orderId: string;
        @Prop({required: true}) readonly show: boolean;

        private pageLoading: boolean = false;
        private detailConfig: DetailBlockInf[] = JSON.parse(JSON.stringify(ORDER_DETAIL_MAPPING));
        private segmentType: string = '';

        @Watch('show', {immediate: true})
        private onShowChange(val: boolean) {
            if (val) {
                this.pageLoading = true;
                setTimeout(() => {
                    this.getDetailInfo();
                }, 300);
            }
        }

        /** 根据返回的详情展示不同的表单信息 */
        private async getDetailInfo() {

            let result: CommonResult = {
                code: 200,
                description: '',
                data: {}
            };

            this.segmentType = 'approve';

            setTimeout(() => {
                this.pageLoading = false;
            }, 500);
        }
    }
</script>