/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <container-node :show="show" v-loading="pageLoading" node-id="process-info-container-node">
        <div class="order-base-block-container"
             v-for="(item,i) in processList"
             :key="`block_key_${i}`">
            <div class="process-title">
                <i>{{i + 1}}</i>
                <span>{{item.title}}</span>
                <em></em>
            </div>
            <div class="info-box">
                <span class="info-item w1" v-for="(info,k) in item.data"
                      :key="`block_info_key_${i}_${k}`">
                    <em>{{info.label}}：{{info.value}}</em>
                    <i v-if="!info.state" :class="info.state">{{info.state}}</i>
                </span>
            </div>
        </div>
    </container-node>
</template>

<script lang="ts">
    import {Vue, Component, Prop, Watch} from "vue-property-decorator";
    import ContainerNode from "@/pages/template/common/ContainerNode.vue";
    import {CommonResult} from "common";

    @Component({
        components: {ContainerNode}
    })
    export default class ProcessInfo extends Vue {
        private pageLoading: boolean = false;
        private processList: any[] = [];
        @Prop({required: true}) readonly orderId: string;
        @Prop({required: true}) readonly show: boolean;
        @Watch('show', {immediate: true})
        private onShowChange(val: boolean) {
            if (val) {
                this.pageLoading = true;
                setTimeout(() => {
                    this.getDetailInfo();
                }, 300);
            }
        }

        private async getDetailInfo() {

            let result: CommonResult = {
                code: 200,
                description: '',
                data: [
                    {}
                ]
            };

            setTimeout(() => {
                this.processList = [
                    {title: '工单派发', data: [
                            {label: '操作人', key: '', value: ''},
                            {label: '操作人部门', key: '', value: ''},
                            {label: '操作人角色', key: '', value: ''},
                            {label: '操作人电话', key: '', value: ''},
                            {label: '派往对象', key: '', value: ''},
                            {label: '操作时间', key: '', value: ''}
                        ]},
                    {title: '审核', data: [
                            {label: '操作人', key: '', value: ''},
                            {label: '操作人部门', key: '', value: ''},
                            {label: '操作人角色', key: '', value: ''},
                            {label: '操作人电话', key: '', value: ''},
                            {label: '派往对象', key: '', value: ''},
                            {label: '操作时间', key: '', value: ''}
                        ]},
                    {title: '设计出图', data: [
                            {label: '操作人', key: '', value: ''},
                            {label: '操作人部门', key: '', value: ''},
                            {label: '操作人角色', key: '', value: ''},
                            {label: '操作人电话', key: '', value: ''},
                            {label: '派往对象', key: '', value: ''},
                            {label: '操作时间', key: '', value: ''}
                        ]},
                    {title: '物资领用', data: [
                            {label: '操作人', key: '', value: ''},
                            {label: '操作人部门', key: '', value: ''},
                            {label: '操作人角色', key: '', value: ''},
                            {label: '操作人电话', key: '', value: ''},
                            {label: '派往对象', key: '', value: ''},
                            {label: '操作时间', key: '', value: ''}
                        ]}
                ];
                this.pageLoading = false;
            }, 500);
        }
    }
</script>