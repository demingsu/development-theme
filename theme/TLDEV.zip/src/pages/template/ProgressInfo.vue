/*********************************************************************
* flow paint file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <div class="flow-page-main-container" v-show="show">
        <paint-flow :title-list="titleList" ref="paintNode" @paintEvent="paintEvent"></paint-flow>
    </div>
</template>

<script lang="ts">
    import {Vue, Component, Prop, Watch} from "vue-property-decorator";
    import PaintFlow from "./common/PaintFlow.vue";
    import {FLOW_SEGMENT_TITLE, FLOW_SEGMENT_BLOCK, FLOW_SEGMENT_LINE} from "@/config/common.config";

    @Component({components: {PaintFlow}})
    export default class ProgressInfo extends Vue {
        @Prop({required: true}) private readonly orderId: string;
        @Prop({required: true}) private readonly show: boolean;

        private titleList: any[] = JSON.parse(JSON.stringify(FLOW_SEGMENT_TITLE));
        private blockList: any[] = JSON.parse(JSON.stringify(FLOW_SEGMENT_BLOCK));
        private lineList: any[] = JSON.parse(JSON.stringify(FLOW_SEGMENT_LINE));

        @Watch('show', {immediate: true})
        private async onShowChange(val: boolean) {
            if (!!val) {
                await this.$nextTick();
                this.getProgressInfo();
            }
        }

        private async getProgressInfo() {
            let node: any = this.$refs.paintNode;
            node.drawBlock(this.blockList, (d: any[]) => {
                this.lineList.map((it: any, i: number) => {
                    let fn: any = d.find((oo: any) => oo.id === it.from),
                        tn: any = d.find((oo: any) => oo.id === it.to);

                    if (i === 0) {
                        it.point = [[fn.cx + (fn.w / 2) + 8, fn.cy], [tn.cx - (tn.w / 2) - 8, tn.cy]];
                        it.end = 'right';
                    }
                    if (i === 1) {
                        it.point = [[fn.cx, fn.cy + (fn.h / 2) + 8], [fn.cx, tn.cy], [tn.cx - (tn.w / 2) - 8, tn.cy]];
                        it.end = 'right';
                    }
                    if (i === 2) {
                        it.point = [[fn.cx + (fn.w / 2) + 8, fn.cy], [tn.cx - (tn.w / 2) - 8, tn.cy]];
                        it.end = 'right';
                    }
                    if (i === 3) {
                        it.point = [[fn.cx, fn.cy + (fn.h / 2) + 8], [fn.cx, tn.cy], [tn.cx - (tn.w / 2) - 8, tn.cy]];
                        it.end = 'right';
                    }
                    if (i === 4) {
                        it.point = [[fn.cx + (fn.w / 2) + 8, fn.cy], [fn.cx + (fn.w / 2) + 30, fn.cy], [fn.cx + (fn.w / 2) + 30, tn.cy], [tn.cx + (tn.w / 2) + 8, tn.cy]];
                        it.end = 'left';
                    }
                    it.finish = tn.state;
                });
                node.drawLine(this.lineList);
            });
        }

        private paintEvent(data: any) {
            console.log('+++++++++++++++++++ start +++++++++++++++++++');
            console.log(data);
        }
    }
</script>
