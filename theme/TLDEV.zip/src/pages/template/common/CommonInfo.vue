/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <container-node :show.sync="show" node-id="base-info-container-node">
        <div class="order-base-block-container"
             v-for="(item,i) in detailConfig"
             :key="`block_key_${i}`">
            <div class="title">{{item.title}}</div>
            <div class="info-box">
                <span class="info-item" v-for="(info,k) in item.data"
                      :class="`w${info.width}`"
                      :key="`block_info_key_${i}_${k}`">
                    <em>{{info.label}}：{{info.value}}</em>
                    <i v-if="!info.state" :class="info.state">{{info.state}}</i>
                </span>
            </div>
        </div>
        <slot></slot>
    </container-node>
</template>

<script lang="ts">
    import {Vue, Component, Prop, Watch} from "vue-property-decorator";
    import ContainerNode from "@/pages/template/common/ContainerNode.vue";
    import {DetailBlockInf} from "common";

    @Component({
        components: {ContainerNode}
    })
    export default class BaseInfo extends Vue {
        @Prop({required: true}) readonly detailConfig: DetailBlockInf[];
        @Prop({required: true}) readonly show: boolean;
        
    }
</script>