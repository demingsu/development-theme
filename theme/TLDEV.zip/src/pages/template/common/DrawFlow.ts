
class DrawFlow {
    private callback: (d: any) => void;
    private id: string;
    private zr: any;
    private row: number;
    private col: number;
    private nodeWidth: number;
    private nodeHeight: number;
    constructor(id: string, cb: (d: any) => void, nw: number = 118, nh: number = 32) {
        this.id = id;
        this.nodeWidth = nw;
        this.nodeHeight = nh;
        this.callback = cb;
    }

    protected drawBlock(block: any[], row: number, col: number): any[] {
        this.row = row;
        this.col = col;
        let el: HTMLElement = document.getElementById(this.id) as HTMLElement;
        if (!el) throw new Error(`Not exist HTML element of ${this.id} on document`);
        if (!this.zr) {
            this.zr = zrender.init(el);
            this.zr.on('click', (dd: any) => {
                let tar: any = (dd.target || {data: null}).data;
                if (!!tar && tar.eventType === 'nodeEvent') {
                    this.callback(tar);
                }
            });
        } else {
            this.zr.resize();
            this.zr.clear();
        }
        let rect: ClientRect = el.getBoundingClientRect();
        let dn: any[] = this.calculateNode(rect.width, rect.height, block);
        dn.map((it: any) => {
            let r = new zrender.Rect({
                shape: {
                    r: it.isSE ? (this.nodeHeight / 2) : 0,
                    x: it.tx,
                    y: it.ty,
                    width: this.nodeWidth,
                    height: this.nodeHeight
                },
                style: {
                    lineWidth: 1,
                    fill: it.state === 'success' ? '#3cbb5b' : it.state === 'danger' ? '#d93b25' : '#657180',
                },
                data: {
                    ...it,
                    eventType: 'nodeEvent'
                }
            });
            this.zr.add(r);
            let t = new zrender.Text({
                position: [it.cx, it.cy - 6],
                style: {
                    text: it.label.join('\n'),
                    textFill: '#fff',
                    textAlign: 'center',
                    textShadow: '#fff',
                    fontSize: 14
                },
                data: {
                    ...it,
                    eventType: 'nodeEvent'
                }
            });
            this.zr.add(t);
        });
        return dn;
    }

    protected drawLine(lines: any[]) {
        for (let line of lines) {
            let color = line.finish === 'success' ? '#3cbb5b' : line.finish === 'danger' ? '#d93b25' : '#657180',
                l = new zrender.Polyline({
                    shape: {points: line.point},
                    style: {
                        lineWidth: 1,
                        stroke: color,
                        lineDash: line.dashed ? [6, 6] : []
                    }
                });
            this.zr.add(l);
            let len = line.point.length,
                ex = line.point[len - 1][0],
                ey = line.point[len - 1][1],
                i = new zrender.Isogon({
                shape: {
                    x: ex,
                    y: ey,
                    r: 6,
                    n: 3
                },
                style: {
                    fill: color
                }
            });
            i.attr('origin', [ex, ey]);
            i.attr('rotation', [(line.end === 'right' ? 1.5 : line.end === 'bottom' ? 1 : line.end === 'left' ? .5 : 0) * Math.PI]);
            this.zr.add(i);
        }
    }

    private calculateNode(rw: number, rh: number, node: any[]): any[] {
        let perWidth = Math.ceil(rw / this.col),
            perHeight = Math.ceil(rh / this.row);
        node.map((it: any) => {
            it.cx = perWidth * it.col - perWidth / 2;
            it.cy = perHeight * it.row - perHeight / 2;
            it.tx = it.cx - this.nodeWidth / 2;
            it.ty = it.cy - this.nodeHeight / 2;
            it.w = this.nodeWidth;
            it.h = this.nodeHeight;
        });
        return node;
    }
}

export default DrawFlow;