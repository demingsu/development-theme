/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <div class="flow-main-content">
        <div class="title">
            <span v-for="(item, i) in titleList" :style="{width: `${item.width}%`}" :key="`BODY_${i}`">{{item.name}}</span>
        </div>
        <div class="body" :style="{height: `${maxRow * 72}px`}">
            <div class="col w6" v-for="(item, i) in titleList" :style="{width: `${item.width}%`}" :key="`BODY_${i}`"></div>
            <div id="renderBox" class="box"></div>
        </div>
    </div>
</template>

<script lang="ts">
    import {Vue, Component, Prop, Watch} from "vue-property-decorator";
    import {ProgressItemInf} from "common";
    import DrawFlow from "@/pages/template/common/DrawFlow";

    @Component
    export default class ProgressInfo extends Vue {
        @Prop({required: true}) private readonly titleList: any[];
        @Prop({default: 1}) private readonly textLine: number;
        @Prop({default: 6}) private readonly maxCol: number;

        private maxRow: number = 1;
        private df: any;

        public async mounted() {
            await this.$nextTick();
            this.df = new DrawFlow('renderBox', (d: any) => {
                this.$emit('paintEvent', d);
            });
        }

        public async drawBlock(block: any[], cb: (d: any[]) => void) {
            this.getMaxRow(block);
            await this.$nextTick();
            let nodes = this.df.drawBlock(block, this.maxRow, this.maxCol);
            cb(nodes);
        }

        public drawLine(line: any[]) {
            this.df.drawLine(line);
        }

        private getMaxRow(blockList: any[]) {
            let max: number = 1;
            blockList.map((it: any) => {
                if (it.row > max) max = it.row;
            });
            this.maxRow = max;
        }
    }
</script>