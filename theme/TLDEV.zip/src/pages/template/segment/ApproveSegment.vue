/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/9
*********************************************************************/

<template>
    <div class="order-base-block-container">
            <div class="title">审批</div>
            <div class="info-box">
                <el-form ref="form" label-width="80px" size="small">
                    <el-row :gutter="12">
                        <el-col :span="8">
                            <el-form-item label="审批人:">
                                <el-input v-model="queryForm.approveName"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="审批类型:">
                                <el-input v-model="queryForm.approveType"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="8">
                            <el-form-item label="审批日期:">
                                <el-input v-model="queryForm.approveTime"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="24">
                            <el-form-item label="审批备注:">
                                <el-input type="textarea" resize="none" :autosize="{minRows: 6}" v-model="queryForm.approveRemark"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="24" style="text-align: center;">
                            <el-button type="primary" size="small">审核</el-button>
                        </el-col>
                    </el-row>
                </el-form>
            </div>
        </div>
</template>

<script lang="ts">
    import {Vue, Component, Prop, Watch} from "vue-property-decorator";

    @Component
    export default class BaseInfo extends Vue {
        private queryForm: any = {
            approveName: '',
            approveType: '',
            approveTime: '',
            approveRemark: ''
        };
    }
</script>