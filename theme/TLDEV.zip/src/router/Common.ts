/*********************************************************************
 * defined Order page router file
 * Created by deming-su on 2019/12/09
 *********************************************************************/

import {AsyncComponent} from "vue";
import {RouteConfig} from "vue-router";

/* 通用路由--页面路由不存在 */
const CommonNotFound: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "CommonNotFound"*/"../pages/common/NotFound.vue");
};

/* 通用路由--登录路由 */
const LoginIndex: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "LoginIndex"*/"../pages/common/LoginIndex.vue");
};

const routes: RouteConfig[] = [
    { path: "/", redirect: "/login" },
    { path: "/login", component: LoginIndex, meta: {  layout: "blank-layout" } },
    { path: "/not/found", component: CommonNotFound, meta: {  layout: "blank-layout" } }
];

export default routes;