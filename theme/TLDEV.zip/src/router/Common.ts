/*********************************************************************
 * defined Order page router file
 * Created by deming-su on 2019/12/09
 *********************************************************************/

import {AsyncComponent} from "vue";
import {RouteConfig} from "vue-router";

/* 通用路由--页面路由不存在 */
const CommonNotFound: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "CommonNotFound"*/"../pages/common/NotFound.vue");
};

/* 通用路由--登录路由 */
const LoginIndex: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "LoginIndex"*/"../pages/common/LoginIndex.vue");
};

/* 通用路由--示例路由 */
const Example: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "Example"*/"../pages/common/Example.vue");
};

/* 通用路由--示例路由 */
const Example0: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "Example0"*/"../pages/common/Example01.vue");
};

const routes: RouteConfig[] = [
    { path: "/", redirect: "/login" },
    { path: "/login", component: LoginIndex, meta: {  layout: "blank-layout" } },
    { path: "/example", component: Example, meta: {  layout: "main-layout" } },
    { path: "/example0", component: Example0, meta: {  layout: "main-layout" } },
    { path: "/not/found", component: CommonNotFound, meta: {  layout: "blank-layout" } }
];

export default routes;