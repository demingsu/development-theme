/*********************************************************************
 * defined Order page router file
 * Created by deming-su on 2019/12/09
 *********************************************************************/

import {AsyncComponent} from "vue";
import {RouteConfig} from "vue-router";

/* 工作台--主路由 */
const DesktopIndex: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "DesktopIndex"*/"../pages/desktop/Index.vue");
};

/* 工作台--代办列表路由 */
const DesktopTodoList: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "DesktopTodoList"*/"../pages/desktop/tpl/DesktopTodoList.vue");
};

/* 工作台--代办详情路由 */
const DesktopTodoDetail: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "DesktopTodoDetail"*/"../pages/desktop/tpl/DesktopTodoDetail.vue");
};

/* 工作台--代办列表路由 */
const DesktopDoneList: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "DesktopDoneList"*/"../pages/desktop/tpl/DesktopDoneList.vue");
};

/* 工作台--代办详情路由 */
const DesktopDoneDetail: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "DesktopDoneDetail"*/"../pages/desktop/tpl/DesktopDoneDetail.vue");
};

/* 综合查询--列表路由 */
const QueryIndex: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "QueryIndex"*/"../pages/query/Index.vue");
};

/* 统计分析--主路由 */
const StatisticsIndex: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "StatisticsIndex"*/"../pages/statistics/Index.vue");
};

/* 消息管理--主路由 */
const InformationIndex: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "InformationIndex"*/"../pages/information/Index.vue");
};

const routes: RouteConfig[] = [
    {
        path: "/desktop",
        component: DesktopIndex,
        children: [
            {path: '', redirect: 'todo-list'},
            {path: 'todo-list', component: DesktopTodoList},
            {path: 'todo-detail', component: DesktopTodoDetail},
            {path: 'done-list', component: DesktopDoneList},
            {path: 'done-detail', component: DesktopDoneDetail}
        ]
    },
    {path: "/query", component: QueryIndex, meta: {layout: "main-layout"}},
    {path: "/statistics", component: StatisticsIndex, meta: {layout: "main-layout"}},
    {path: "/information", component: InformationIndex, meta: {layout: "main-layout"}}
];

export default routes;