/*********************************************************************
 * router config entry file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import Vue from "vue";
import Router, { Route } from "vue-router";
import store from "@/store";

/* 导入通用子模块路由 */
import Common from "./Common";

/* 导入工单模块路由 */
import Order from "./Order";

/* 注入路由 */
Vue.use(Router);

/* 创建路由对象 */
const router = new Router({routes: [
    ...Common,
    ...Order
]});

/**
 * 路由定向方法
 * 保证页面菜单完整性，需先获取页面菜单，再判断用户是否已经登录
 */
router.beforeEach((to: Route, from: Route, next) => {

    let isDefault: boolean = Common.findIndex((oo: any) => oo.path === to.path) > -1;
    if (isDefault) {
        next();
        return;
    }

    /* 检测地址是否有token，如果有token缓存token */
    let token: string = (!!to.query ? to.query.token || "" : "") as string;
    if (!!token) {
        store.dispatch("common/setApplicationToken", {applicationToken: token});
    }

    /* 检测是否有登录信息，没有登录信息直接跳转到登录页面 */
    let ct: string = store.getters["common/getApplicationToken"] as string;
    if (!ct) {
        localStorage.clear();
        store.dispatch('common/resetCommonVuexData');
        next('/login');
    } else {
        next();
    }
});

export default router;