declare var document: Document;
declare var socket: any;
declare var getRequestUrlParams: (s: string) => string;
declare namespace io {
    let on: (data?: any) => void;
    let emit: (flag: string, data?: any) => void;
    let connect: (url?: string, opt?: any) => any;
    let close: () => void;
    let open: () => void;
}

declare module "element-ui/lib/transitions/collapse-transition";
declare module "element-ui";
