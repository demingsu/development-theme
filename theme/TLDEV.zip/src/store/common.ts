/*********************************************************************
 * common Vue store file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import { Module, ActionTree, GetterTree, MutationTree } from "vuex";
import { CommonVuex } from "common";

const initState: CommonVuex = {
    applicationToken: "",
    loginUserInfo: {}
};

const getters: GetterTree<any, any> = {
    getApplicationToken(state): CommonVuex {
        return state.applicationToken;
    },
    getLoginUserInfo(state): CommonVuex {
        return state.loginUserInfo;
    }
};

const actions: ActionTree<any, any> = {
    setApplicationToken({commit}, obj: CommonVuex): void {
        commit('mutationApplicationToken', obj);
    },
    setLoginUserInfo({commit}, obj: CommonVuex): void {
        commit('mutationLoginUserInfo', obj);
    },
    resetCommonVuexData({commit}): void {
        commit('mutationCommonVuexData');
    }
};

const mutations: MutationTree<any> = {
    mutationApplicationToken(state, obj: CommonVuex) {
        state.applicationToken = obj.applicationToken;
    },
    mutationLoginUserInfo(state, obj: CommonVuex) {
        state.loginUserInfo = obj.loginUserInfo;
    },
    mutationCommonVuexData(state) {
        state.applicationToken = "";
        state.loginUserInfo = {};
    }
};

export const common: Module<any, any> = {
    namespaced: true,
    state: {...initState},
    getters,
    actions,
    mutations
};