/*********************************************************************
 * project common interface defined file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

/* 请求参数接口 */
interface RequestData {
    url: string;
    method?: string;
    data?: object;
    params?: object;
    contentType?: string;
    urlParam?: any;
    onUploadProgress?: any;
}

/* 页面缓存接口 */
interface CommonVuex {
    applicationToken?: string;
    loginUserInfo?: any;
}

/* 列属性 */
interface tableColumn {
    label: string;
    key: string;
    width?: number;
    minWidth?: number;
    isTooltip?: boolean;
    isLink?: boolean;
}

/* 表格接口 */
interface TableData {
    data: any[];
    column?: tableColumn[];
    loading: boolean;
}

/* 分页接口 */
interface PagingData {
    size: number;
    current: number;
    sizes: number[];
    total: number;
}

/* 通用返回接口 */
interface CommonResult {
    code: number;
    description: string;
    data: any | any[];
}

/* 详情数据接口 */
interface DetailDataInf {
    label: string;
    key: string;
    value: string;
    width: number;
    stateName?: string; // 格式为：非常紧急这样的文字
    state?: string; // 格式为：danger,warning,info
}
interface DetailBlockInf {
    title: string;
    data: DetailDataInf[];
}

export {
    RequestData,
    CommonVuex,
    TableData,
    PagingData,
    CommonResult,

    DetailDataInf,
    DetailBlockInf
};
