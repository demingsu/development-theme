/*********************************************************************
 * ajax request file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import axios, {AxiosRequestConfig, AxiosResponse} from "axios";
import store from "@/store";

import {RequestData} from "common.d.ts";
import UrlConfig from "@/config/UrlConfig";
import {REQUEST_TIMEOUT} from "@/config/common.config";

/**
 * 获取请求地址
 * @param url 请求地址
 * @param params 需要替换地址中的数据对象
 * @returns {string} 返回完整请求地址
 */
const getUrl = (url: string, params?: any): string => {
    url = url.replace(/{(\w+)}/g, (reg: string, key: string): string => params[key]);
    return `${new UrlConfig('BASE_URL').currentUrl}${url}`;
};

/**
 * 获取消息请求地址
 * @param url 请求地址
 * @param params 需要替换地址中的数据对象
 * @returns {string} 返回完整请求地址
 */
const getMessUrl = (url: string, params?: any): string => {
    url = url.replace(/{(\w+)}/g, (reg: string, key: string): string => params[key]);
    return `${new UrlConfig('MESSAGE_URL').currentUrl}${url}`;
};

/**
 * 构建请求参数
 * @param data 请求参数对象
 * @returns {AxiosRequestConfig} 返回请求对象
 */
const buildRequestData = (data: RequestData): AxiosRequestConfig => {
    let result: AxiosRequestConfig = {};

    result.method = !!data.method ? data.method : "GET";
    result.params = data.params;
    result.data = data.data;

    /* 如果有上传进度接口 */
    if (!!data.onUploadProgress) {
        result.onUploadProgress = data.onUploadProgress;
    }

    /* 设置全局请求的token和domainName */
    let token = store.getters["common/getApplicationToken"];
    result.headers = {
        token
    };

    if (result.method === "POST") {

        /* 设置请求头文档类型 */
        Object.assign(result.headers, {"Content-Type": data.contentType ? data.contentType : "application/json;charset=utf-8"});

        /* form提交 */
        result.transformRequest = (requestData) => {
            if (data.contentType && data.contentType.indexOf("application/x-www-form-urlencoded") !== -1) {
                let str = "";

                for (let key in requestData) {
                    if (requestData.hasOwnProperty(key)) {
                        str += `${key}=${requestData[key]}&`;
                    }
                }
                return encodeURI(str.slice(0, str.length - 1));
            } else if (!!data.onUploadProgress) {
                let form = new FormData();

                for (let key in requestData) {
                    if (requestData.hasOwnProperty(key)) {
                        let files = requestData[key];
                        // for (let i: number = 0; i < files.length; i ++) {
                        //     form.append(key, files[i]);
                        // }
                        for (let i of files) {
                            form.append(key, i);
                        }
                    }
                }

                return form;
            } else {
                return JSON.stringify(requestData);
            }
        };
    }
    /* 设置超时 */
    result.timeout = REQUEST_TIMEOUT;
    return result;
};

/**
 * Ajax 请求方法
 * @param request 请求参数
 */
const sendRequest = async (request: RequestData): Promise<any> => {
    let requestData: AxiosRequestConfig = buildRequestData(request);
    requestData.url = request.url.startsWith('/message') ? getMessUrl(request.url, request.urlParam) : getUrl(request.url, request.urlParam);

    /* axios 发起请求 */
    let result: AxiosResponse<any> = await axios(requestData).catch((e: AxiosResponse) => {
        return e;
    });
    if (!!result) {
        return result.data;
    }
};

export default sendRequest;