/*********************************************************************
 * common util function file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

/**
 *  去掉字段的两端空格
 *  @param size           文件当前大小
 *  @param count          计量
 */
let fileSize = (size: number, count: number = 0): string => {
    const names = ['byte', 'KByte', 'MB', 'GB', 'TB'];
    if (size < 1024) {
        return size + names[count];
    } else {
        return fileSize(parseFloat((size / 1024).toFixed(2)), ++count);
    }
};

/**
 *  日期转换方法
 * @param formatter              返回格式 YYYY MM DD hh mm dd
 * @param val                    传入时间
 */
let dateFormat = (formatter: string, val: Date | number) => {
    let date: Date = val ? new Date(val) : new Date();
    let YYYY: string = date.getFullYear() + '';
    let m: number = date.getMonth() + 1;
    let MM: string = m > 9 ? m + '' : '0' + m;
    let d: number = date.getDate();
    let DD: string = d > 9 ? d + '' : '0' + d;
    let h: number = date.getHours();
    let hh: string = h > 9 ? h + '' : '0' + h;
    let $m: number = date.getMinutes();
    let mm: string = $m > 9 ? $m + '' : '0' + $m;
    let s: number = date.getSeconds();
    let ss: string = s > 9 ? s + '' : '0' + s;
    let obj: any = { YYYY, MM, DD, hh, mm, ss} as any;

    return formatter.replace(/(YYYY)|(MM)|(DD)|(hh)|(mm)|(ss)/g, (key: string): string => obj[key]);
};

/**
 * 打开新页签
 * @param url      [String]      新页签地址
 * @param flag     {Boolean}     是否直接用地址打开
 */
let openTabByUrl = (url: string, flag: boolean): void => {
    let el = document.createElement("a");
    document.body.appendChild(el);
    el.href = flag ? url : encodeURI(`${location.protocol}//${location.host}${location.pathname}#${url}`);
    el.target = '_blank';

    el.click();
    document.body.removeChild(el);
};

/**
 * 文件上传，返回dom节点
 * @param isMulti          是否多选文件
 */
let fileUploadNode = async (isMulti: boolean = false): Promise<any> => {

    let result = await filePick(isMulti)
        .catch((e: any) => {
            return e;
        });

    if (!!result) {
        return result;
    }
};

let filePick = (isMulti: boolean) => {
    return new Promise((resolve, reject) => {
        let box = document.createElement('div');
        document.body.appendChild(box);
        box.setAttribute('style', 'display: block; height: 0; width: 0; overflow: hidden;');

        let input = document.createElement('input');
        input.setAttribute('type', 'file');
        if (isMulti) input.setAttribute('multiple', 'multiple');
        box.appendChild(input);

        input.addEventListener('change', function() {

            let file = null,
                fileNode = input.files || [];
            if (fileNode.length > 0) {
                file = fileNode;
                resolve(file);
            } else {
                reject("ERROR_CODE");
            }

            setTimeout(() => {
                document.body.removeChild(box);
            });
        });

        input.click();
    });
};

export {
    dateFormat,
    fileSize,
    openTabByUrl,
    fileUploadNode
};