const path = require("path"),
    env = process.env.NODE_ENV.trim(),
    isPRD = env === "production",
    outputDir = 'hebei_ict',
    title = "河北ICT";

const config = {
    publicPath: "./",
    outputDir,
    lintOnSave: false,
    chainWebpack: () => { },
    pages: {
        index: {
            entry: "src/main.ts",
            template: "public/index.html",
            filename: "index.html",
            title
        }
    },
    configureWebpack: config => {
        config.mode = isPRD ? "production" : "development";
        Object.assign(config, {
            resolve: {
                extensions: [".js", ".vue", ".json", ".ts", ".tsx"],
                alias: {
                    "@": path.resolve(__dirname, "./src")
                }
            }
        });
    },
    productionSourceMap: !isPRD,
    css: {
        extract: true,
        sourceMap: false,
        loaderOptions: {},
        modules: false
    },
    parallel: require("os").cpus().length > 1,
    devServer: {
        open: 'Google Chrome',
        openPage: '/index.html',
        host: "localhost",
        port: 13520,
        https: false,
        hotOnly: false,
        proxy: {
            "/apis": {
                target: "http://127.0.0.1:19999",
                // pathRewrite: {"^/apis": ""},
                secure: false
            }
        }
    },
    pluginOptions: {
        // TODO something here
    }
};

if (env !== 'publish') module.exports = config;
