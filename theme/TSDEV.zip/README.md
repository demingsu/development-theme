## 开发库说明
1. 不允许私自升级element-ui;
2. 所有路由导出采用异步(按需)

## Vue前端构架使用说明
### 浏览器兼容说明
1. 整体架构支持 >= IE9;
2. 最佳体验 >= IE10+

### WEB技术栈
架构于 vue2.5 + vue-router + vuex + axios + Typescript + webpack3.0 + gulp
1. vue2.5 主体架构
2. vue-router 异步路由加载器
3. vuex 数据仓库
4. axios 数据异步请求方式
5. Typescript 开发库
6. webpack 模块化架构工具
7. gulp 代码检测及压缩、打码构建工具
8. 在同一个Vue文件中只能存在一种注入方式，及InjectReactive和Inject

### 项目环境安装与运行
1. 安装依赖：(需要跳转到对应的项目文件路径，开发环境依赖node8.X LTS版本，需要安装，不能用10.X版本，有兼容问题)
 `cnpm install`
2. 运行项目：(运行前确保依赖安装完成且无失败项)
 `npm run start`
3. 打包发布命令：(发布规则为，只发布打包目录所有文件，nginx指向也指向文件所在目录)
 `npm run deploy`