/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/06
*********************************************************************/

<template>
    <div class="common-list-layout">
        <div class="content">
            <header>
                <span class="title">{{title}}</span>
                <slot name="header"></slot>
            </header>
            <article :class="{'no-footer': !hasFooter}">
                <section>
                    <slot></slot>
                </section>
                <footer>
                    <slot name="footer"></slot>
                </footer>
            </article>
        </div>
    </div>
</template>

<script lang="ts">
    import { Vue, Component, Prop } from "vue-property-decorator";

    @Component
    export default class ListLayout extends Vue {
        @Prop({default: '', required: true})
        private readonly title: string;

        get hasFooter() {
            return !!this.$slots.footer;
        }
    }
</script>