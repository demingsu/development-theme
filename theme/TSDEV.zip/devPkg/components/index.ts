/*********************************************************************
 * Vue private components export file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import {VueConstructor} from "vue";
import * as Filter from "./filter";
import * as Directive from "./directive";
import * as Components from "./components";
import * as Property from "./property";

export default {
    install(Vue: VueConstructor) {
        if (!Vue.prototype.$zznode) {
            Vue.prototype.$zznode = {};
        }
        this.registerFilter(Vue);
        this.registerDirective(Vue);
        this.registerPrototype(Vue);
        this.registerComponents(Vue);
    },

    registerFilter(Vue: VueConstructor) {
        let Filters = Filter as any;
        for (let name in Filters) {
            if (Filters.hasOwnProperty(name)) {
                /* 注册过滤器 */
                Vue.filter(name, Filters[name]);
            }
        }
    },

    registerDirective(Vue: VueConstructor) {
        let Directives = Directive as any;
        for (let name in Directives) {
            if (Directives.hasOwnProperty(name)) {
                /* 注册指令 */
                Vue.directive(name.toLowerCase(), Directives[name]);
            }
        }
    },

    registerPrototype(Vue: VueConstructor) {
        let Properties = Property as any;
        for (let name in Properties) {
            if (Properties.hasOwnProperty(name)) {
                Properties[name].install(Vue);
            }
        }
    },

    registerComponents(Vue: VueConstructor) {
        let Comps = Components as any;
        for (let name in Comps) {
            if (Comps.hasOwnProperty(name)) {
                /* 生成组件key */
                let key = name.replace(/[A-Z]/g, (char, index) => {
                    let res = char.toLowerCase();
                    res = index > 0 ? `-${res}` : res;
                    return res;
                });

                /* 注册组件 */
                Vue.component(key, Comps[name]);
            }
        }
    }
};