/*********************************************************************
 * defined const variable file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

export const REQUEST_TIMEOUT: number = 5000;