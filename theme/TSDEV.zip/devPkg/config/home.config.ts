/*********************************************************************
 * defined const variable file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

/* 表格属性 */
const HOME_TABLE_COLUMN = [
    {label: '表单ID', key: 'formId', width: 150, inLink: true},
    {label: '表单名称', key: 'formName', minWidth: 120, isTooltip: true},
    {label: '表单状态', key: 'formState', width: 120},
    {label: '表单类型', key: 'formType', width: 120},
    {label: '表单类型名称', key: 'formType', width: 140},
    {label: '创建时间', key: 'createTime', width: 160},
    {label: '修改时间', key: 'updateTime', width: 160},
    {label: '创建人', key: 'creator', width: 120},
];

/* 详情属性 */
const HOME_DETAIL_PROPERTY = [
    {label: '工单编号', key: 'orderId', value: '', width: 8},
    {label: '工单标题', key: 'orderTitle', value: '', width: 16},
    {label: '任务类型ID', key: 'taskTypeNo', value: '', width: 8},
    {label: '任务类型', key: 'taskType', value: '', width: 8},
    {label: '一级业务ID', key: 'firstCategoryNo', value: '', width: 8},
    {label: '一级业务类型', key: 'firstCategory', value: '', width: 8},
    {label: '二级业务ID', key: 'secondCategoryNo', value: '', width: 8},
    {label: '二级业务类型', key: 'secondCategory', value: '', width: 8},
    {label: '三级业务ID', key: 'thirdCategoryNo', value: '', width: 8},
    {label: '三级业务类型', key: 'thirdCategory', value: '', width: 8},
    {label: '处理时间', key: 'dealTime', value: '', width: 8},
    {label: '审批人账号', key: 'exaName', value: '', width: 8},
    {label: '审批人', key: 'exaNameZh', value: '', width: 8},
    {label: '审批人电话', key: 'exaPhone', value: '', width: 8},
    {label: '审批时限', key: 'exaTimeLimit', value: '', width: 8},
    {label: '任务描述', key: 'taskDesc', value: '', width: 24},
    {label: '审批信息', key: 'exaInf', value: '', width: 24}
];

export {
    HOME_TABLE_COLUMN,
    HOME_DETAIL_PROPERTY
};