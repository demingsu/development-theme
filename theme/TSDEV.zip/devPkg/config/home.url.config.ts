

/* 通用 ---start--- */

const MOCK_LIST = "/mock/form/config/list.json";
const MOCK_COLLECTION = "/mock/form/config/collection.json";
const MOCK_EMPLOYEE = "/mock/form/config/employee.json";

export {
    MOCK_LIST,
    MOCK_COLLECTION,
    MOCK_EMPLOYEE
};