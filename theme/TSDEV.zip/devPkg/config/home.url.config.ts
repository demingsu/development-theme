

/* 通用 ---start--- */

const MOCK_LIST = "/mock/form/config/list.json";

export {
    MOCK_LIST
};