/*********************************************************************
* Created by deming-su on 2019/12/06
 *********************************************************************/

<template>
    <div class="home-main-container">

    </div>
</template>
<script lang="ts">
    import { Vue, Component } from "vue-property-decorator";
    import { Getter } from "vuex-class";

    @Component
    export default class extends Vue {
        @Getter('getApplicationCache', {namespace: 'common'})
        private currentToken: string;

        protected created(): void {

            console.log('Current Token: ', this.currentToken);
        }
    }
</script>