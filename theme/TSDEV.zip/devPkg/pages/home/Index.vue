/*********************************************************************
* Created by deming-su on 2019/12/06
 *********************************************************************/

<template>
    <div class="home-main-container">
        <router-view :token-value="currentToken"></router-view>
    </div>
</template>
<script lang="ts">
    import { Vue, Component, ProvideReactive } from "vue-property-decorator";
    import { Getter } from "vuex-class";

    @Component
    export default class extends Vue {
        @Getter('getApplicationCache', {namespace: 'common'})
        private currentToken: string;

        @ProvideReactive() token: string = '';
        @ProvideReactive() role: string = window.btoa('admin-role');

        protected created(): void {
            this.token = this.currentToken;
        }
    }
</script>