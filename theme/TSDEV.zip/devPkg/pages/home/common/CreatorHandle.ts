/*********************************************************************
 * Static variable file
 * Created by deming-su on 2019/12/5
 *********************************************************************/

import { Vue, Component } from "vue-property-decorator";
import { CreateElement, VNode } from "vue";
import {DetailItemInf} from "common";
import { HOME_DETAIL_PROPERTY } from "@/config/home.config";

@Component({
    props: {
        tokenValue: {
            type: String,
            required: true
        }
    }
})
export default class CreatorHandle extends Vue {
    protected detailData: DetailItemInf[] = JSON.parse(JSON.stringify(HOME_DETAIL_PROPERTY));

    protected createMainNode(ce: CreateElement, title: string = '', child: VNode[]): VNode {
        return ce('list-layout', {
            props: {
                title
            }
        }, child);
    }

    protected makeChildNodes(ce: CreateElement): VNode {
        let rows: VNode[] = [];
        for (let item of this.detailData) {
            rows.push(ce('el-col', {
                props: {span: item.width}
            }, [ce('el-form-item', {props: {label: item.label}}, [
                ce('el-input', {
                    class: {'flow-detail-input': true},
                    domProps: {value: item.value},
                    // on: {input: (e: Event) => this.$emit('input', e.target.value)}
                })
            ])]));
        }
        let btnNode: VNode = ce('el-col', {
            props: {span: 24},
            style: {"text-align": "center"}
        }, [
            ce('el-button', {props: {size: "small", plain: true}}, ["保存"]),
            ce('el-button', {props: {size: "small", plain: true}, on: {click: () => this.$router.go(-1)}}, ["返回"])
        ]);
        let rowNode: VNode = ce('el-row', {
            props: { gutter: 16 }
        }, [...rows, btnNode]);
        return ce('el-form', {
            class: { "flow-detail-form": true },
            props: { "label-width": "100px", "size": "small"}
        }, [rowNode]);
    }

}