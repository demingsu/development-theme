/*********************************************************************
 * Static variable file
 * Created by deming-su on 2019/12/5
 *********************************************************************/


interface EmployeeInfo {
    id: string;
    name: string;
    phone: string;
    duty?: string;
}

import { getDataRequest } from "@/api/common";

class CreatorHandler {
    private employeeData: EmployeeInfo[];

    constructor() {
        // TODO something here
    }

    set employeeList(value: EmployeeInfo[]) {
        this.employeeData = value;
    }

    get employeeList() {
        return this.employeeData;
    }

    public async getEmployeeData() {
        let result = await getDataRequest('MOCK_EMPLOYEE', {});
        this.employeeData = !!result && result.code === 200 ? result.data : [];
    }
}

export default CreatorHandler;