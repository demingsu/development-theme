/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/5
*********************************************************************/

<!--<template>
    <list-layout :title="title">
        <el-form class="flow-detail-form" label-width="110px" size="small">
            <el-row :gutter="16">
                <el-col v-for="(item,i) in detailData" :span="item.width" :key="`item_key_${i}`">
                    <el-form-item :label="item.label">
                        <el-input class="flow-detail-input" v-model="item.value" placeholde=""></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="24" style="text-align: center;">
                    <el-button size="small" plain>保存</el-button>
                    <el-button @click="$router.go(-1)" size="small" plain>返回</el-button>
                </el-col>
            </el-row>
        </el-form>
    </list-layout>
</template>-->

<script lang="ts">
    import { Component, Mixins } from "vue-property-decorator";
    import { CreateElement, VNode } from "vue";
    import { getDataRequest } from "@/api/common";
    import CreatorHandler from "@/pages/home/common/CreatorHandler";
    import CreatorHandle from "@/pages/home/common/CreatorHandle";
    import {DetailItemInf} from "common";

    @Component
    export default class HomeCreator extends Mixins(CreatorHandle) {
        private orderId: string;
        private isModify: boolean = false;
        private handler = new CreatorHandler();
        private title: string = '';

        private async getDetailInfo() {
            let result = await getDataRequest('MOCK_COLLECTION', {orderId: this.orderId});
            let _d: any = !!result && result.code === 200 ? result.data : {};
            this.detailData.map((it: DetailItemInf) => it.value = _d[it.key] || '');
        }

        protected render(createElement: CreateElement): VNode {

            let childNodes: VNode = this.makeChildNodes(createElement);
            return this.createMainNode(createElement, this.title, [childNodes]);
        }

        protected created() {
            this.orderId = (this.$route.query || {orderId: ''}).orderId as string;
            this.isModify = !!this.orderId;
            this.handler.getEmployeeData();
            if (!!this.orderId) {
                this.title = "首页详情修改";
                this.getDetailInfo();
            } else {
                this.title = "首页详情新增";
            }
        }
    }
</script>