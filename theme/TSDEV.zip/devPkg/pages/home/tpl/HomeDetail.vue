/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/5
*********************************************************************/

<template>
    <el-dialog title="新增工单"
               :visible.sync="dialogShow"
               :append-to-body="true"
               :close-on-click-modal="false"
               :show-close="false"
               width="1100px"
               top="10vh">
        <el-form class="flow-detail-form" label-width="110px" size="small">
            <el-row :gutter="16">
                <el-col v-for="(item,i) in detailData" :span="item.width" :key="`item_key_${i}`">
                    <el-form-item :label="item.label">
                        <el-input class="flow-detail-input" readonly v-model="item.value" placeholde=""></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="24" style="text-align: right;">
                    <el-button @click="refreshList(Date.now())" size="small" plain>返回</el-button>
                </el-col>
            </el-row>
        </el-form>
    </el-dialog>
</template>

<script lang="ts">
    import {Vue, Component, PropSync, Prop, Watch, Emit} from "vue-property-decorator";
    import { HOME_DETAIL_PROPERTY } from "@/config/home.config";
    import { getDataRequest } from "@/api/common";
    import { DetailItemInf } from "@/types/common";

    @Component
    export default class DetailInfo extends Vue {
        @PropSync("dialogShow", {required: true, type: Boolean, default: false})
        private showValue: boolean;

        @Prop({type: String, required: true})
        private readonly orderId: string;

        private detailData: DetailItemInf[] = JSON.parse(JSON.stringify(HOME_DETAIL_PROPERTY));

        @Watch("dialogShow")
        private onDialogShowChange(val: boolean) {
            if (val) this.getDetailInfo();
        }

        @Emit("refresh-list")
        refreshList(time: number) {
            this.showValue = false;
            return time;
        }

        /* TODO 与上边写法一致
        @Emit()
        refreshList(time: number) {
            this.showValue = false;
            return time;
        }*/

        private async getDetailInfo() {

            let load = this.$loading({});
            let result = await getDataRequest('MOCK_COLLECTION', {orderId: this.orderId});
            load.close();

            let _d = (!!result && result.code === 200 ? result.data : {}) as any;
            this.detailData.map((it: DetailItemInf) => {
                it.value = _d[it.key] || '';
            });
        }
    }
</script>