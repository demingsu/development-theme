/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/5
*********************************************************************/

<template>
    <list-layout title="首页列表">
        <el-form slot="header" class="flow-query-form" size="small">
            <el-row>
                <el-col :span="3">
                    <el-form-item>
                        <el-button type="primary" @click="queryEvent">查询</el-button>
                        <el-button @click="operateEvent('add', null)">新增</el-button>
                    </el-form-item>
                </el-col>
                <el-col :span="6">
                    <el-form-item label="发起时间" label-width="70px">
                        <el-date-picker v-model="queryParams.time"
                                        type="daterange"
                                        align="right"
                                        unlink-panels
                                        value-format="yyyy-MM-dd"
                                        range-separator="至"
                                        start-placeholder="开始日期"
                                        end-placeholder="结束日期"></el-date-picker>
                    </el-form-item>
                </el-col>
                <el-col :span="3">
                    <el-form-item label="工单状态" label-width="70px">
                        <el-select v-model="queryParams.state" placeholder="请选择">
                            <el-option label="全量" value=""></el-option>
                            <el-option label="待审批" value="待审批"></el-option>
                            <el-option label="已驳回" value="已驳回"></el-option>
                            <el-option label="待受理" value="待受理"></el-option>
                            <el-option label="处理中" value="处理中"></el-option>
                            <el-option label="待确认" value="待确认"></el-option>
                            <el-option label="已归档" value="已归档"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="3">
                    <el-form-item label="工单编号" label-width="70px">
                        <el-input v-model="queryParams.code" placeholder="请输入"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>

        <el-table border :data="tableData.data" height="100%" style="width: 100%">
            <el-table-column v-for="(item,i) in tableData.column"
                             :prop="item.key"
                             :label="item.label"
                             :width="item.width"
                             header-align="center"
                             :min-width="item.minWidth"
                             :key="`table_key_${i}`">
                <template slot-scope="scope">
                    <span v-if="item.inLink" @click="operateEvent('detail', scope.row)" class="common-table-cell link">{{scope.row[item.key]}}</span>
                    <el-tooltip v-else-if="item.isTooltip" class="item" effect="dark" :content="scope.row[item.key]" placement="top">
                        <span class="common-table-cell">{{scope.row[item.key]}}</span>
                    </el-tooltip>
                    <span v-else class="common-table-cell">{{scope.row[item.key]}}</span>
                </template>
            </el-table-column>
            <el-table-column label="操作" header-align="center" width="140">
                <template slot-scope="scope">
                    <span class="common-table-cell link">
                        <i v-if="pageRole === 'admin-role'" @click="operateEvent('delete', scope.row)" class="error">删除</i>
                        <i @click="operateEvent('edit', scope.row)" class="link">编辑</i>
                    </span>
                </template>
            </el-table-column>
        </el-table>

        <el-pagination slot="footer"
                       :current-page="pagingData.current"
                       :page-sizes="pagingData.sizes"
                       :page-size="pagingData.size"
                       layout="total, sizes, prev, pager, next, jumper"
                       @size-change="pagingEvent($event, 'size')"
                       @current-change="pagingEvent"
                       :total="pagingData.total">
        </el-pagination>

        <home-detail @refresh-list="refreshData" :order-id="detailDialog.id" :dialog-show.sync="detailDialog.show"></home-detail>
    </list-layout>
</template>
<script lang="ts">
    import { Component, InjectReactive } from "vue-property-decorator";
    import BaseView from "@/pages/BaseView.vue";
    import { HOME_TABLE_COLUMN } from "@/config/home.config";
    import {PagingData, TableData} from "common";
    import { getDataRequest } from "@/api/common";
    import HomeDetail from "@/pages/home/tpl/HomeDetail.vue";
    interface QueryParams {
        time: string | string[];
        code: string;
        state: string;
    }
    interface DetailDialogInf {
        show: boolean;
        title: string;
        id: string;
    }

    @Component({
        components: { HomeDetail }
    })
    export default class extends BaseView {
        @InjectReactive() readonly token!: string;
        @InjectReactive() readonly role: string;

        private pageRole: string = '';
        protected tableData: TableData = {
            data: [],
            column: HOME_TABLE_COLUMN,
            loading: false
        };
        protected pagingData: PagingData;
        protected exportData: QueryParams;
        private queryParams: QueryParams = {
            code: '',
            state: '',
            time: ''
        };
        private detailDialog: DetailDialogInf = {
            show: false,
            title: '详情',
            id: ''
        };

        protected mounted(): void {
            this.queryEvent();
            this.pageRole = window.atob(this.role || '');
        }

        private queryEvent() {

            this.exportData = JSON.parse(JSON.stringify(this.queryParams));
            this.getTableData();
        }

        protected async getTableData() {

            let _query = Object.assign({pageSize: this.pagingData.size, pageNum: this.pagingData.current, token: this.token}, this.exportData);
            let result = await getDataRequest('MOCK_LIST', _query);

            let _si = (this.pagingData.current - 1) * this.pagingData.size,
                _d = !!result && result.code === 200 ? result.data : {rows: [], total: 0},
                _temp = [];
            for (let i = _si;i < _d.rows.length;i ++) {
                _temp.push(_d.rows[i]);
            }
            this.tableData.data = _temp;
            this.pagingData.total = _d.total;
        }

        private operateEvent(type: string, row: any) {

            switch (type) {
                case 'detail':
                    this.detailDialog.id = row.formId;
                    this.detailDialog.show = true;
                    break;
                case 'delete':
                    this.$confirm('是否确认要删除此条数据？')
                        .then(() => {
                            this.$message.success("删除成功");
                        }).catch(() => {});
                    break;
                case 'edit':
                    this.$router.push({path: '/home/creator', query: {orderId: row.formId}});
                    break;
                case 'add':
                    this.$router.push({path: '/home/creator'});
                    break;
            }
        }

        private refreshData(time: number) {
            console.log('Refresh emit event from detail page.', time);
        }
    }
</script>