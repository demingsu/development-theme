/*********************************************************************
 * defined Home page router file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import {AsyncComponent} from "vue";
import {RouteConfig} from "vue-router";

/* 通用路由--页面路由不存在 */
const CommonNotFound: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "CommonNotFound"*/"../pages/common/NotFound.vue");
};

/* 通用路由--首页路由 */
const HomeIndex: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "HomeIndex"*/"../pages/home/Index.vue");
};

/* 通用路由--首页列表路由 */
const HomeList: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "HomeList"*/"../pages/home/tpl/HomeList.vue");
};

/* 通用路由--首页创建路由 */
const HomeCreator: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "HomeCreator"*/"../pages/home/tpl/HomeCreator.vue");
};

const routes: RouteConfig[] = [
    { path: "/", redirect: "/home" },
    { path: "/not/found", component: CommonNotFound, meta: {  layout: "blank-layout" } },
    {
        path: "/home",
        component: HomeIndex,
        meta: {  layout: "main-layout" },
        children: [
            {path: '', redirect: 'list'},
            {path: 'list', component: HomeList},
            {path: 'creator', component: HomeCreator}
        ]
    }
];

export default routes;