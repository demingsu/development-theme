/*********************************************************************
 * defined Home page router file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import {AsyncComponent} from "vue";
import {RouteConfig} from "vue-router";

/* 通用路由--页面路由不存在 */
const CommonNotFound: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "CommonNotFound"*/"../pages/common/NotFound.vue");
};

/* 通用路由--首页路由 */
const HomeIndex: AsyncComponent = (): any => {
    return import(/* webpackChunkName: "HomeIndex"*/"../pages/home/Index.vue");
};

const routes: RouteConfig[] = [
    { path: "/", redirect: "/home" },
    { path: "/not/found", component: CommonNotFound, meta: {  layout: "blank-layout" } },
    {path: "/home", component: HomeIndex, meta: {  layout: "main-layout" }}
];

export default routes;