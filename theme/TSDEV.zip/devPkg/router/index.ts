/*********************************************************************
 * router config entry file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import Vue from "vue";
import Router, { Route } from "vue-router";
import store from "@/store";

/* 导入各个子模块路由 */
import Home from "./Home";

/* 注入路由 */
Vue.use(Router);

/* 创建路由对象 */
const router = new Router({routes: [
    ...Home
]});

/**
 * 路由定向方法
 * 保证页面菜单完整性，需先获取页面菜单，再判断用户是否已经登录
 */
router.beforeEach((to: Route, from: Route, next) => {

    /* 检测地址是否有token，如果有token缓存token */
    let token: string = (!!to.query ? to.query.token || "" : "") as string;
    if (!!token) {
        store.dispatch("common/setApplicationCache", {applicationToken: token});
    }

    next();
});

export default router;