/*********************************************************************
 * common Vue store file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import { Module, ActionTree, GetterTree, MutationTree } from "vuex";
import { CommonVuex } from "common";

const initState: CommonVuex = {
    applicationToken: ""
};

const getters: GetterTree<any, any> = {
    getApplicationCache(state): CommonVuex {
        return state.applicationCache;
    }
};

const actions: ActionTree<any, any> = {
    /* 设置用户信息 */
    setApplicationCache({commit}, obj: CommonVuex): void {
        commit('mutationApplicationCache', obj);
    }
};

const mutations: MutationTree<any> = {
    mutationApplicationCache(state, obj: CommonVuex) {
        state.applicationCache = obj.applicationToken;
    }
};

export const common: Module<any, any> = {
    namespaced: true,
    state: {...initState},
    getters,
    actions,
    mutations
};