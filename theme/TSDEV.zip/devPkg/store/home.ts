/*********************************************************************
 * Home Vue store file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import { Module, ActionTree, GetterTree, MutationTree } from "vuex";
import { CommonVuex } from "common";

const initState: CommonVuex = {
    homeDetailInfo: {}
};

const getters: GetterTree<any, any> = {
    getHomeDetailInfo(state): CommonVuex {
        return state.homeDetailInfo;
    }
};

const actions: ActionTree<any, any> = {
    /* 设置用户信息 */
    setHomeDetailInfo({commit}, obj: CommonVuex): void {
        commit('mutationHomeDetailInfo', obj);
    }
};

const mutations: MutationTree<any> = {
    mutationHomeDetailInfo(state, obj: CommonVuex) {
        state.homeDetailInfo = obj.homeDetailInfo;
    }
};

export const common: Module<any, any> = {
    namespaced: true,
    state: {...initState},
    getters,
    actions,
    mutations
};