/*********************************************************************
 * project common interface defined file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

/* 请求参数接口 */
interface RequestData {
    url: string;
    method?: string;
    data?: object;
    params?: object;
    contentType?: string;
    urlParam?: any;
}

/* 页面缓存接口 */
interface CommonVuex {
    applicationToken?: string;
    homeDetailInfo?: any;
}

/* 列属性 */
interface tableColumn {
    label: string;
    key: string;
    width?: number;
    minWidth?: number;
    isTooltip?: boolean;
    isLink?: boolean;
}

/* 表格接口 */
interface TableData {
    data: any[];
    column: tableColumn[];
    loading: boolean;
}

/* 分页接口 */
interface PagingData {
    size: number;
    current: number;
    sizes: number[];
    total: number;
}

/* 详情接口 */
interface DetailItemInf {
    label: string;
    key: string;
    value: string | number;
    width?: number;
}

export {
    RequestData,
    CommonVuex,
    TableData,
    PagingData,
    DetailItemInf
};
