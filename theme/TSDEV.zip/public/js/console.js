/* 添加console在IE9下的支持，仅重写了常用的warn，log，error，assert，debug，info */
(function() {
    if(!window.console) {
        window.console = {
            warn: function() {
                // 提示信息
            },
            log: function() {
                // 提示信息
            },
            error: function() {
                // 提示信息
            },
            assert: function() {
                // 提示信息
            },
            debug: function() {
                // 提示信息
            },
            info: function() {
                // 提示信息
            }
        };
    }

    /* 获取页面的url地址解析 */
    window.getRequestUrlParams = function(key) {
        var str = location.search;

        if (!str) {
            var i = location.hash.indexOf('?');
            str = i > -1 ? location.hash.substring(i) : '';
        }

        str = str.substring(1).split('&');

        var _s = key + '=';
        var params = '';
        for (var i = 0;i < str.length;i ++) {
            if (str[i].indexOf(_s) > -1) {
                params = str[i];
                break;
            }
        }

        return params !== '' ? params.replace(_s, '') : '';
    };
})(window);
