/*********************************************************************
 * Created by deming-su on 2018/5/3
 *********************************************************************/
 

<template>
    <div class="test" :class="{right: isRight}">
        <span v-for="item in msg">{{item.label}}: {{item.value}}</span>
    </div>
</template>
<script lang="ts">
    import {Vue, Component, Prop} from "vue-property-decorator";

    @Component
    export default class Toast extends Vue {
        @Prop({required: true}) readonly msg: any[];
        @Prop({required: true, type: Boolean}) readonly isRight: boolean;
    }
</script>
<style lang="less" scoped>
    .test {
        display: block;
        position: absolute;
        top: 0;
        right: -100px;
        height: 40px;
        width: 100px;
        background: #f00;
        &.right {
            right: 100px;
        }
    }
</style>