/*********************************************************************
 * ajax request url file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

/* 页面启动路由，根据不同的环境启动不同的基础路由 */
let BASE_URL = "/apis";
let nodeEnv = (process.env.NODE_ENV || '').trim();

/* 首页请求路由 */
import * as HomeUrl from "./home.url.config";

let PathUrlList: UrlKey[] = [],
    keys: any = {
        BASE_URL,
        ...HomeUrl
    };

for (let name in keys) {
    if (keys.hasOwnProperty(name)) {
        PathUrlList.push({key: name, value: keys[name]});
    }
}

interface UrlKey {
    key: string;
    value: string;
}

class UrlConfig {
    private readonly nowKey: string;
    constructor(key: string = '') {
        this.nowKey = key;
    }
    public initBaseUrl(path: string) {
        PathUrlList.map((it: UrlKey) => {
            if (it.key === 'BASE_URL') it.value = path;
        });
    }
    get currentUrl(): string {
        let res: UrlKey = PathUrlList.find((it: UrlKey) => it.key === this.nowKey) || {key: '', value: ''};
        return res.value;
    }
}

/* 首页 ---end--- */
export default UrlConfig;
