/*********************************************************************
* Static variable file
* Created by deming-su on 2019/12/06
*********************************************************************/

<template>
    <div class="common-default-page">
        <img class="found" src="../../images/common/not-found.png" alt=""/>
        <div class="btn">
            <el-button size="small" type="primary" @click="$router.push('/home')" icon="el-icon-arrow-left">返回首页</el-button>
        </div>
    </div>
</template>

<script lang="ts">
    import {Component, Vue} from "vue-property-decorator";

    @Component
    export default class NotFound extends Vue {
        protected created() {
            this.$message.warning('页面丢失');
        }
    }
</script>