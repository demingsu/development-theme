/*********************************************************************
* Static variable file
* Created by deming-su on 2019/10/28
*********************************************************************/

<template>
    <div class="common-default-page">
        <img class="right" src="../../images/common/no-permission.jpg" alt=""/>
        <div class="page-btn">
            <el-button size="small" @click="$router.push('/authentication')" plain>前往鉴权</el-button>
        </div>
    </div>
</template>

<script lang="ts">
    import {Vue, Component} from "vue-property-decorator";

    @Component
    export default class NotRight extends Vue {
        created() {
            // todo something here
        }
    }
</script>

<style lang="less" scoped>
    .page-btn {
        display: block;
        position: absolute;
        top: 50%;
        left: 0;
        width: 100%;
        text-align: center;
        z-index: 99;
    }
</style>
