/*********************************************************************
 * router config entry file
 * Created by deming-su on 2019/12/06
 *********************************************************************/

import Vue from "vue";
import Router, { Route, Location } from "vue-router";
import store from "@/store";

/* 导入各个子模块路由 */
import Common from "./common";

/* 注入路由 */
Vue.use(Router);

/* 创建路由对象 */
const router = new Router({routes: [
    ...Common
]});

/* 是否是默认路由 */
let isDefaultRoute = (path: string) => {

    let routes = ['/authentication', '/not/right'];
    return routes.findIndex((oo: string) => path.startsWith(oo)) > -1;
};

/* 路由权限拦截 */
router.beforeEach((to: Route, from: Route, next) => {

    /* 是否是默认路由 */
    if (isDefaultRoute(to.path)) {
        next();
        return;
    }

    /* 检测地址是否有token，如果有token缓存token */
    let token: string = (!!to.query ? to.query.token || "" : "") as string;
    if (!!token) {
        store.dispatch("common/setApplicationToken", token);
    }

    let currentToken = router.app.$store.getters["common/getApplicationToken"];
    if (!!currentToken) {
        next();
    } else {
        localStorage.clear();
        store.dispatch('common/resetCommonVuexData');
        next("/not/right");
    }

    next();
});

export default router;
