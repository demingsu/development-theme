declare var document: Document;
declare var socket: any;
declare var getRequestUrlParams: (s: string) => string;

declare module "element-ui/lib/transitions/collapse-transition";
declare module "element-ui";
